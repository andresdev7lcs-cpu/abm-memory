import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    // distDir en next.config.ts es "dist": sin ignorarlo eslint recorre
    // todo el output generado y agota la memoria del proceso.
    "dist/**",
    "next-env.d.ts",
  ]),
]);

export default eslintConfig;
