# Floristeria Valery

Base tecnica para `floristeriaenneiva.com`.

## Estado

- Fase 0: preparacion completada.
- Fase 1: base tecnica completada.
- Fase 2: CMS y contenido estructural completada.
- Fase 3: catalogo + WhatsApp asistido completada.
- Fase 4: SEO tecnico, redirecciones y QA completada.
- Fase 5: pre-lanzamiento y preparacion de produccion en progreso.
- Sin carga comercial definitiva.
- Sin lanzamiento.

## Repo y staging

- Repositorio local: `/Users/work945/Documents/Proyectos/ABM/proyectos/floristeria-valery`
- Staging local: `http://localhost:3000`
- Preview local: `http://localhost:3001`
- Staging externo protegido: pendiente de version salvada y despliegue.

## Requisitos

- Node.js 18 o superior.
- npm.

## Instalacion

```bash
cd /Users/work945/Documents/Proyectos/ABM/proyectos/floristeria-valery
npm install
```

## Comandos

- `npm run dev` - desarrollo local.
- `npm run staging` - staging local en `0.0.0.0:3000`.
- `npm run preview` - servidor de preview en `0.0.0.0:3001` despues de `npm run build`.
- `npm run build` - compilacion de produccion.
- `npm run lint` - revision de lint.

## Estructura creada

```text
src/
  app/
    [section]/
    [section]/[slug]/
    bouquets/
    comprar-flores/
    comprar-flores/[slug]/
    comprar-flores/condolencias/
    comprar-flores/personalizados/
    exoticos/
    fruteros/
    contacto/
    comprar-desde-lejos/
    entrega-hoy/
    rosas/
    studio/[[...index]]/
    topiarios/
  components/
    cms/
    catalog/
    base/
    layout/
  content/
  lib/
  sanity/
docs/
redirects/
sanity.config.ts
```

## Componentes base

- `SiteShell`
- `SectionHeading`
- `StatusPill`
- `InfoCard`
- `RouteShell`
- `PhaseCard`
- `ModelCard`
- `RouteGrid`
- `TechTable`
- `WhatsAppCTA`
- `CmsFamilyPage`
- `CatalogBrowser`
- `CatalogProductCard`
- `CatalogProductDetail`
- `FlowPage`
- `LeadCaptureForm`

## Modelos CMS

- `SiteSettings`
- `Product`
- `Category`
- `Occasion`
- `Campaign`
- `Testimonial`
- `FAQ`
- `LeadFormSubmission`
- `Redirect`
- `DeliveryRule`
- `B2BContact`
- `PolicyPage`
- `EventPage`
- `CompanyPage`

## Familias CMS conectadas

- `/productos/`
- `/categorias/`
- `/ocasiones/`
- `/campanas/`
- `/faq/`
- `/testimonios/`
- `/politicas/`
- `/eventos/`
- `/empresas/`

## URLs preservadas

- `/bouquets/`
- `/rosas/`
- `/topiarios/`
- `/exoticos/`
- `/fruteros/`

## Pendientes detectados

- Integraciones reales de analytics y verificacion.
- Staging externo protegido por version salvada.
- IDs de GA4, GTM, Search Console y Meta Pixel.
- `projectId` y `dataset` reales de Sanity.
- Numero de WhatsApp.
- Logo editable.
- Inventario completo de URLs actuales.
- Top ventas, ticket promedio, capacidad diaria y contactos B2B.

## Fase 0 a 5

- La base tecnica ya existe.
- Las rutas preservadas estan creadas.
- El CMS propuesto ya esta configurado a nivel de estructura.
- La capa estructural de CMS ya tiene rutas genericas y scaffolds.
- La analitica esta preparada en esquema, pero no conectada a IDs reales.
- No se ha cargado contenido comercial final.
- No se ha publicado produccion.
- El pre-lanzamiento externo esta en preparacion.
