import { StatusPill } from "./status-pill";

type PhaseCardProps = {
  phase: string;
  status: string;
  detail: string;
};

export function PhaseCard({ phase, status, detail }: PhaseCardProps) {
  return (
    <article className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <p className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">
          {phase}
        </p>
        <StatusPill tone="accent">{status}</StatusPill>
      </div>
      <p className="mt-3 text-sm leading-6 text-slate-600">{detail}</p>
    </article>
  );
}
