type TechTableRow = {
  label: string;
  value: string;
};

type TechTableProps = {
  title: string;
  rows: TechTableRow[];
};

export function TechTable({ title, rows }: TechTableProps) {
  return (
    <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
      <h2 className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">
        {title}
      </h2>
      <dl className="mt-4 divide-y divide-slate-200">
        {rows.map((row) => (
          <div key={row.label} className="grid gap-2 py-4 sm:grid-cols-[0.4fr_0.6fr]">
            <dt className="text-sm font-medium text-slate-500">{row.label}</dt>
            <dd className="text-sm leading-6 text-slate-700">{row.value}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
