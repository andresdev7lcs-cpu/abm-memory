type StatusPillProps = {
  children: React.ReactNode;
  tone?: "neutral" | "success" | "warning" | "danger" | "accent";
};

const toneStyles: Record<NonNullable<StatusPillProps["tone"]>, string> = {
  neutral: "bg-stone-100 text-stone-700 ring-stone-200",
  success: "bg-emerald-100 text-emerald-800 ring-emerald-200",
  warning: "bg-amber-100 text-amber-800 ring-amber-200",
  danger: "bg-rose-100 text-rose-800 ring-rose-200",
  accent: "bg-brand-100 text-brand-900 ring-brand-200",
};

export function StatusPill({
  children,
  tone = "neutral",
}: StatusPillProps) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ring-1 ring-inset ${toneStyles[tone]}`}
    >
      {children}
    </span>
  );
}
