import { StatusPill } from "./status-pill";

type InfoCardProps = {
  title: string;
  value: string;
  description?: string;
  tone?: "neutral" | "success" | "warning" | "danger" | "accent";
  badgeLabel?: string;
};

export function InfoCard({
  title,
  value,
  description,
  tone = "neutral",
  badgeLabel,
}: InfoCardProps) {
  return (
    <article className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-slate-500">{title}</p>
          <p className="mt-3 text-2xl font-semibold tracking-tight text-slate-950">
            {value}
          </p>
        </div>
        {badgeLabel ? <StatusPill tone={tone}>{badgeLabel}</StatusPill> : null}
      </div>
      {description ? (
        <p className="mt-4 text-sm leading-6 text-slate-600">{description}</p>
      ) : null}
    </article>
  );
}
