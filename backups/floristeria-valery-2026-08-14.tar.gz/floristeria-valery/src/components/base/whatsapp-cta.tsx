import { siteConfig } from "@/content/site";

type WhatsAppCTAProps = {
  label: string;
  message: string;
  number?: string;
  note?: string;
  trackingEventName?: string;
  fallbackHref?: string;
  fallbackLabel?: string;
};

export function sanitizePhoneNumber(value: string) {
  return value.replace(/[^\d]/g, "");
}

export function buildWhatsAppHref(number: string, message: string) {
  const digits = sanitizePhoneNumber(number);

  if (!digits) {
    return "";
  }

  const encodedMessage = message.trim() ? `?text=${encodeURIComponent(message)}` : "";
  return `https://wa.me/${digits}${encodedMessage}`;
}

export function WhatsAppCTA({
  label,
  message,
  number = siteConfig.whatsappNumber,
  note,
  trackingEventName = "whatsapp_cta_clicked",
  fallbackHref,
  fallbackLabel = "Si WhatsApp no abre, usa la llamada directa",
}: WhatsAppCTAProps) {
  const sanitizedNumber = sanitizePhoneNumber(number);
  const whatsappHref = buildWhatsAppHref(number, message);
  const fallbackTarget = fallbackHref ?? (sanitizedNumber ? `tel:+${sanitizedNumber}` : undefined);
  const primaryLabel = sanitizedNumber ? "Abrir WhatsApp" : "Configurar WhatsApp";
  const primaryTarget = whatsappHref ? "_blank" : undefined;

  return (
    <div className="rounded-[2rem] border border-brand-200 bg-brand-50 p-6">
      <p className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">
        WhatsApp
      </p>
      <p className="mt-3 text-sm leading-6 text-slate-700">{label}</p>
      {note ? <p className="mt-2 text-sm text-slate-500">{note}</p> : null}
      <a
        className="mt-4 inline-flex rounded-full bg-brand-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700"
        href={whatsappHref || fallbackTarget || "#"}
        target={primaryTarget}
        rel={primaryTarget ? "noreferrer noopener" : undefined}
        data-track-event={trackingEventName}
        data-track-component="WhatsAppCTA"
        data-track-message={message}
        data-track-number={sanitizedNumber || undefined}
      >
        {primaryLabel}
      </a>
      {fallbackTarget ? (
        <a
          className="mt-3 inline-flex text-sm font-medium text-brand-800 underline decoration-brand-300 underline-offset-4 transition hover:text-brand-900"
          href={fallbackTarget}
        >
          {fallbackLabel}
        </a>
      ) : (
        <p className="mt-3 text-sm text-slate-600">
          Configura un numero de WhatsApp para habilitar la via directa y su fallback.
        </p>
      )}
    </div>
  );
}
