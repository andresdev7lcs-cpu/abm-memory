type ModelCardProps = {
  name: string;
  purpose: string;
};

export function ModelCard({ name, purpose }: ModelCardProps) {
  return (
    <article className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <p className="text-sm font-semibold text-slate-950">{name}</p>
      <p className="mt-2 text-sm leading-6 text-slate-600">{purpose}</p>
    </article>
  );
}
