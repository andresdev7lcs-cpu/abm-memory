import Link from "next/link";
import { StatusPill } from "./status-pill";
import type { RouteEntry } from "@/content/site";

type RouteGridProps = {
  title: string;
  routes: RouteEntry[];
};

export function RouteGrid({ title, routes }: RouteGridProps) {
  return (
    <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
      <h2 className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">
        {title}
      </h2>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        {routes.map((route) => (
          <article
            key={route.path}
            className="rounded-2xl border border-slate-200 bg-slate-50 p-4"
          >
            <div className="flex flex-wrap items-center gap-2">
              <StatusPill tone={route.category === "preserved" ? "success" : route.category === "hub" ? "accent" : "warning"}>
                {route.category}
              </StatusPill>
              <p className="text-xs text-slate-500">{route.path}</p>
            </div>
            <p className="mt-3 text-sm font-medium text-slate-950">
              {route.label}
            </p>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              {route.description}
            </p>
            <Link
              className="mt-4 inline-flex text-sm font-medium text-brand-700 underline-offset-4 hover:underline"
              href={route.path}
            >
              Abrir ruta
            </Link>
          </article>
        ))}
      </div>
    </section>
  );
}
