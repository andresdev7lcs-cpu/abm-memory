"use client";

import { useEffect, useRef, useState } from "react";

function prefersReducedMotion() {
  return (
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

type ScrollRevealProps = {
  children: React.ReactNode;
  /** Retraso en ms para escalonar hermanos. */
  delay?: number;
  className?: string;
  as?: "div" | "li" | "section";
};

/**
 * Revela al entrar y desvanece al salir del viewport.
 * Sin librerias: IntersectionObserver + una clase.
 */
export function ScrollReveal({
  children,
  delay = 0,
  className = "",
  as = "div",
}: ScrollRevealProps) {
  const ref = useRef<HTMLElement | null>(null);
  // Con motion reducido nace visible, sin observer ni escritura en el efecto.
  const [shown, setShown] = useState(() => prefersReducedMotion());

  useEffect(() => {
    const node = ref.current;
    if (!node || prefersReducedMotion()) return;

    const observer = new IntersectionObserver(
      ([entry]) => setShown(entry.isIntersecting),
      // Margen inferior negativo: entra cuando ya subio un poco en pantalla.
      { threshold: 0.15, rootMargin: "0px 0px -8% 0px" },
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  const Tag = as;

  return (
    <Tag
      ref={ref as React.Ref<never>}
      className={`fv-reveal ${shown ? "is-shown" : ""} ${className}`.trim()}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}
