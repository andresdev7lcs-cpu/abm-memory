"use client";

import Image from "next/image";
import { useCallback, useEffect, useRef, useState } from "react";
import { flowerCategories, marqueeMessages } from "@/content/categories";

const TOTAL = flowerCategories.length;
/* 196deg reparte las 5 etiquetas sin que se toquen y sin empujarlas detras
   del ramo (a 232deg quedaban ocultas). Paso por caracter corto para que
   las largas ("Dia de la Mujer") ocupen menos arco. */
const MAX_ARC = 196;
const ANGLE_STEP = Math.min(49, MAX_ARC / Math.max(1, TOTAL - 1));
const START_ANGLE = -((TOTAL - 1) / 2) * ANGLE_STEP;
const CHAR_ANGLE_STEP = 1.85;

/** En movil el arco se cierra para que las etiquetas quepan en pantalla. */
const MOBILE_ANGLE_STEP = 36;
const MOBILE_START_ANGLE = -((TOTAL - 1) / 2) * MOBILE_ANGLE_STEP;

/** Texto curvado sobre el anillo: un span rotado por caracter. */
function CurvedLabel({ text }: { text: string }) {
  const totalAngle = (text.length - 1) * CHAR_ANGLE_STEP;
  const startTextAngle = -totalAngle / 2;

  return (
    <>
      {text.split("").map((char, i) => (
        <span
          key={`${char}-${i}`}
          className="fv-cat-char"
          style={{
            transform: `rotate(${startTextAngle + i * CHAR_ANGLE_STEP}deg)`,
          }}
        >
          {char === " " ? " " : char}
        </span>
      ))}
    </>
  );
}

type RotatingCategoriesProps = {
  whatsappHref: string;
};

export function RotatingCategories({ whatsappHref }: RotatingCategoriesProps) {
  const [index, setIndex] = useState(0);
  // Imagen saliente: se mantiene montada durante la animacion de salida.
  const [outgoing, setOutgoing] = useState<{ key: string; dir: number } | null>(
    null,
  );
  const outTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const active = flowerCategories[index];

  /* Los petalos viven en testimonios, otra seccion: sin ancestro comun no hay
     forma de apagarlos por CSS local. La marca sube al <html> para que
     cualquier ornamento festivo de la pagina pueda ceder ante el duelo. */
  useEffect(() => {
    const root = document.documentElement;
    if (active.solemn) root.setAttribute("data-solemn", "true");
    else root.removeAttribute("data-solemn");
    return () => root.removeAttribute("data-solemn");
  }, [active.solemn]);

  const goTo = useCallback((next: number) => {
    setIndex((prev) => {
      if (next === prev) return prev;

      let dir = next > prev ? 1 : -1;
      if (prev === TOTAL - 1 && next === 0) dir = 1;
      if (prev === 0 && next === TOTAL - 1) dir = -1;

      setOutgoing({ key: flowerCategories[prev].key, dir });
      if (outTimer.current) clearTimeout(outTimer.current);
      outTimer.current = setTimeout(() => setOutgoing(null), 1000);

      return next;
    });
  }, []);

  const goPrev = useCallback(
    () => goTo((index - 1 + TOTAL) % TOTAL),
    [goTo, index],
  );
  const goNext = useCallback(() => goTo((index + 1) % TOTAL), [goTo, index]);

  useEffect(() => {
    return () => {
      if (outTimer.current) clearTimeout(outTimer.current);
    };
  }, []);

  const indicatorAngle = START_ANGLE + index * ANGLE_STEP;
  const indicatorAngleMobile = MOBILE_START_ANGLE + index * MOBILE_ANGLE_STEP;

  return (
    <section
      className="fv-cat-section"
      data-solemn={active.solemn ? "true" : undefined}
      id="categorias"
      aria-roledescription="carrusel"
      aria-label="Categorias de flores por ocasion"
    >
      {/* Capa de fondo: cada categoria se cruza con la anterior */}
      <div className="fv-cat-bg" aria-hidden="true">
        {flowerCategories.map((cat, i) => (
          <div
            key={cat.key}
            className={`fv-cat-bg-layer ${i === index ? "is-active" : ""}`}
            style={{ background: cat.background }}
          />
        ))}
      </div>

      <div className="fv-cat-grid">
        <div className="fv-cat-info">
          <span className="fv-kicker">Para cada ocasion</span>
          <h2 key={`t-${active.key}`} className="fv-cat-title">
            {active.name}
          </h2>
          <p key={`d-${active.key}`} className="fv-cat-desc">
            {active.desc}
          </p>
          <a
            href={whatsappHref}
            target="_blank"
            rel="noreferrer noopener"
            className="fv-cat-cta"
            data-track-event="whatsapp_cta_clicked"
            data-track-component="RotatingCategories"
            data-track-category={active.key}
          >
            <span className="fv-cat-cta-label">
              {active.ctaLabel ?? "Pedir este arreglo"}
            </span>
            <span className="fv-cat-cta-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" focusable="false">
                <path
                  d="M4 12h15M13 6l6 6-6 6"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </span>
          </a>

          {/* Bajo el CTA, no flotando sobre el aro: la navegacion acompana
              a la lectura del texto en vez de competir con la imagen. */}
          <div className="fv-cat-nav">
            <button
              type="button"
              className="fv-cat-nav-btn"
              onClick={goPrev}
              aria-label="Ocasion anterior"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                <path
                  d="M15 5l-7 7 7 7"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
            <span className="fv-cat-counter" aria-hidden="true">
              {String(index + 1).padStart(2, "0")}
              <span className="fv-cat-counter-sep" />
              {String(TOTAL).padStart(2, "0")}
            </span>
            <button
              type="button"
              className="fv-cat-nav-btn"
              onClick={goNext}
              aria-label="Ocasion siguiente"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                <path
                  d="M9 5l7 7-7 7"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </button>
          </div>
        </div>

        <div className="fv-cat-stage">
          <div
            className="fv-cat-circle"
            style={
              { "--fv-img-fit": active.imgFit ?? 1 } as React.CSSProperties
            }
          >
            <div className="fv-cat-ring">
              {flowerCategories.map((cat, i) => (
                <button
                  key={cat.key}
                  type="button"
                  className={`fv-cat-item ${i === index ? "is-active" : ""}`}
                  style={
                    {
                      "--fv-cat-angle": `${START_ANGLE + i * ANGLE_STEP}deg`,
                      "--fv-cat-angle-mobile": `${
                        MOBILE_START_ANGLE + i * MOBILE_ANGLE_STEP
                      }deg`,
                    } as React.CSSProperties
                  }
                  onClick={() => goTo(i)}
                  aria-label={`Ver ${cat.name}`}
                  aria-current={i === index}
                  // La activa se atenua: su nombre ya se lee grande a la izquierda.
                  tabIndex={i === index ? -1 : 0}
                >
                  <CurvedLabel text={cat.ringLabel} />
                </button>
              ))}
            </div>
            <div
              className="fv-cat-indicator"
              style={
                {
                  "--fv-cat-angle": `${indicatorAngle}deg`,
                  "--fv-cat-angle-mobile": `${indicatorAngleMobile}deg`,
                } as React.CSSProperties
              }
              aria-hidden="true"
            >
              <span className="fv-cat-indicator-dot" />
            </div>

            <div className="fv-cat-images">
              {outgoing ? (
                <Image
                  key={`out-${outgoing.key}`}
                  src={
                    flowerCategories.find((c) => c.key === outgoing.key)
                      ?.image ?? ""
                  }
                  alt=""
                  aria-hidden="true"
                  fill
                  sizes="(max-width: 980px) 62vw, 42vw"
                  className="fv-cat-img is-leaving"
                  style={
                    {
                      "--fv-cat-exit": `${-outgoing.dir * 45}deg`,
                    } as React.CSSProperties
                  }
                />
              ) : null}
              <Image
                key={`in-${active.key}`}
                src={active.image}
                alt={active.name}
                fill
                priority
                sizes="(max-width: 980px) 62vw, 42vw"
                className="fv-cat-img is-entering"
                style={
                  {
                    "--fv-cat-enter": `${(outgoing?.dir ?? 1) * 45}deg`,
                  } as React.CSSProperties
                }
              />
            </div>
          </div>

        </div>
      </div>

      {/* Filigranas de esquina: detalle sutil, no protagonista. */}
      <svg
        className="fv-cat-corner fv-cat-corner-tl"
        viewBox="0 0 120 120"
        aria-hidden="true"
        focusable="false"
      >
        <g fill="none" stroke="currentColor" strokeWidth="1">
          <path d="M2 46C2 22 22 2 46 2" />
          <path d="M2 70c0-38 30-68 68-68" strokeOpacity=".45" />
          <circle cx="30" cy="30" r="2.4" fill="currentColor" stroke="none" />
        </g>
      </svg>
      <svg
        className="fv-cat-corner fv-cat-corner-br"
        viewBox="0 0 120 120"
        aria-hidden="true"
        focusable="false"
      >
        <g fill="none" stroke="currentColor" strokeWidth="1">
          <path d="M118 74c0 24-20 44-44 44" />
          <path d="M118 50c0 38-30 68-68 68" strokeOpacity=".45" />
          <circle cx="90" cy="90" r="2.4" fill="currentColor" stroke="none" />
        </g>
      </svg>

      {/* Banner infinito */}
      <div className="fv-marquee" aria-hidden="true">
        <div className="fv-marquee-track">
          {[0, 1].map((copy) => (
            <div className="fv-marquee-group" key={copy}>
              {marqueeMessages.map((msg) => (
                <span className="fv-marquee-item" key={`${copy}-${msg}`}>
                  {msg}
                  <span className="fv-marquee-sep" />
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>

      <p className="fv-sr-only" aria-live="polite">
        {active.name}
      </p>
    </section>
  );
}
