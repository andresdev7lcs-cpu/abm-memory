"use client";

import { useEffect, useRef, useState } from "react";
import { landingFaqs, typedQuestions } from "@/content/landing";

const TICK_MS = 45;
const PAUSE_TICKS = 22;

function prefersReducedMotion() {
  return (
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

function TypedSearchBox() {
  // Con motion reducido se muestra la primera pregunta completa y estatica,
  // por eso es el estado inicial y no una escritura dentro del efecto.
  const [typedText, setTypedText] = useState(() =>
    prefersReducedMotion() ? typedQuestions[0] : "",
  );
  const stateRef = useRef({
    questionIndex: 0,
    charIndex: 0,
    deleting: false,
    pauseTicks: 0,
  });

  useEffect(() => {
    if (prefersReducedMotion()) {
      return;
    }

    const timer = setInterval(() => {
      const s = stateRef.current;
      const full = typedQuestions[s.questionIndex];

      if (!s.deleting) {
        s.charIndex += 1;
        if (s.charIndex > full.length) {
          s.deleting = true;
          s.pauseTicks = PAUSE_TICKS;
        }
      } else if (s.pauseTicks > 0) {
        s.pauseTicks -= 1;
      } else {
        s.charIndex -= 1;
        if (s.charIndex <= 0) {
          s.deleting = false;
          s.questionIndex = (s.questionIndex + 1) % typedQuestions.length;
        }
      }

      setTypedText(full.slice(0, Math.max(s.charIndex, 0)));
    }, TICK_MS);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fv-search-shell">
      <div className="fv-google-search-box">
        <span className="fv-search-icon" aria-hidden="true">
          🔍
        </span>
        <span className="fv-search-typed" aria-hidden="true">
          {typedText}
          <span className="fv-search-cursor" />
        </span>
        <span className="fv-search-mic" aria-hidden="true">
          🎙
        </span>
      </div>
    </div>
  );
}

export function FaqSection() {
  const [openIndex, setOpenIndex] = useState(-1);

  return (
    <section className="fv-faq-section" id="faq">
      <div className="fv-section-header">
        <span className="fv-kicker">Antes de pedir</span>
        <h2>Preguntas Frecuentes</h2>
        <p>Resolvemos tus dudas para que elegir sea facil.</p>
      </div>

      <TypedSearchBox />

      <div className="fv-faq-compact-grid">
        {landingFaqs.map((faq, index) => {
          const isOpen = index === openIndex;

          return (
            <div
              key={faq.q}
              className={`fv-faq-chip ${isOpen ? "is-active" : ""}`}
            >
              <button
                type="button"
                className="fv-faq-chip-q"
                onClick={() => setOpenIndex(isOpen ? -1 : index)}
                aria-expanded={isOpen}
                aria-controls={`fv-faq-answer-${index}`}
              >
                <span>{faq.q}</span>
                <span className="fv-chev" aria-hidden="true">
                  ▾
                </span>
              </button>
              <div
                className="fv-faq-chip-a"
                id={`fv-faq-answer-${index}`}
                role="region"
              >
                <p>{faq.a}</p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
