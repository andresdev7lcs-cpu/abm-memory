"use client";

import { useEffect, useState } from "react";
import { siteConfig } from "@/content/site";

type LandingNavProps = {
  whatsappHref: string;
};

export function LandingNav({ whatsappHref }: LandingNavProps) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const closeMenu = () => setMenuOpen(false);
  const activeClass = menuOpen ? "is-active" : "";

  // Fuera del hero la barra necesita fondo solido para no dejar ver el contenido.
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > window.innerHeight * 0.6);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <nav className={`fv-nav ${scrolled ? "is-scrolled" : ""}`}>
        <span className="fv-brand-mark">{siteConfig.displayName}</span>
        <div className="fv-nav-links">
          <a href="#categorias">Flores</a>
          <a href="#categories">Ocasiones</a>
          <a href="#brand">Nosotros</a>
          <a href="#faq">Preguntas</a>
        </div>
        <div className="fv-nav-actions">
          <a
            className="fv-btn-solid fv-gold fv-small"
            href={whatsappHref}
            target="_blank"
            rel="noreferrer noopener"
            data-track-event="whatsapp_cta_clicked"
            data-track-component="LandingNav"
          >
            WhatsApp
          </a>
          <button
            type="button"
            className="fv-menu-toggle"
            onClick={() => setMenuOpen(true)}
            aria-label="Abrir menu"
            aria-expanded={menuOpen}
            aria-controls="fv-side-menu"
          >
            ☰
          </button>
        </div>
      </nav>

      <div
        className={`fv-side-menu-overlay ${activeClass}`}
        onClick={closeMenu}
        aria-hidden="true"
      />

      <div
        id="fv-side-menu"
        className={`fv-side-menu ${activeClass}`}
        hidden={!menuOpen}
      >
        <button
          type="button"
          className="fv-menu-close"
          onClick={closeMenu}
          aria-label="Cerrar menu"
        >
          ✕
        </button>
        <div className="fv-side-menu-list">
          <a className="fv-menu-link" href="#categories" onClick={closeMenu}>
            Fechas Especiales
          </a>
          <a className="fv-menu-link" href="#categories" onClick={closeMenu}>
            Ramos
          </a>
          <a className="fv-menu-link" href="#faq" onClick={closeMenu}>
            Preguntas Frecuentes
          </a>
          <span className="fv-menu-link" style={{ cursor: "default" }}>
            {siteConfig.displayName}
          </span>
          <div className="fv-submenu">
            <a href="#brand" onClick={closeMenu}>
              Sobre Nosotros
            </a>
            <a href="#footer" onClick={closeMenu}>
              Contacto
            </a>
            <a
              href={whatsappHref}
              target="_blank"
              rel="noreferrer noopener"
              onClick={closeMenu}
              data-track-event="whatsapp_cta_clicked"
              data-track-component="LandingSideMenu"
            >
              WhatsApp
            </a>
          </div>
        </div>
      </div>
    </>
  );
}
