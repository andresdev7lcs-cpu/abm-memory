"use client";

import { useMemo, useSyncExternalStore } from "react";

function prefersReducedMotion() {
  return (
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

/**
 * Cada petalo compone drop-shadow + blur y dos animaciones a la vez, asi que
 * el coste en GPU sube rapido. En movil se reduce la cuenta: el efecto sigue
 * leyendose igual con menos elementos porque la pantalla es mas estrecha.
 */
const PETAL_COUNT_DESKTOP = 11;
const PETAL_COUNT_MOBILE = 6;
const MOBILE_BREAKPOINT = 768;

function petalCount() {
  if (typeof window === "undefined") return PETAL_COUNT_DESKTOP;
  return window.innerWidth <= MOBILE_BREAKPOINT
    ? PETAL_COUNT_MOBILE
    : PETAL_COUNT_DESKTOP;
}

/**
 * Petalo con volumen: el degradado radial simula la luz sobre la curva y el
 * borde interno hace de vena. Cada instancia rota en dos ejes al caer, asi
 * que se ve de canto en parte del recorrido en vez de plano.
 */
const PETAL_TONES = [
  { light: "#ffd7e2", mid: "#f2a8bc", dark: "#c76a86" },
  { light: "#ffe9d2", mid: "#f3c396", dark: "#c98f5c" },
  { light: "#ffdce6", mid: "#e88fa8", dark: "#b45a76" },
  { light: "#fff0dc", mid: "#f0d58a", dark: "#c9a45c" },
];

type Petal = {
  id: number;
  left: number;
  delay: number;
  duration: number;
  scale: number;
  drift: number;
  spin: number;
  tone: (typeof PETAL_TONES)[number];
};

function buildPetals(): Petal[] {
  return Array.from({ length: petalCount() }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 26,
    duration: 34 + Math.random() * 22,
    scale: 0.4 + Math.random() * 0.45,
    drift: -50 + Math.random() * 100,
    spin: 140 + Math.random() * 220,
    tone: PETAL_TONES[i % PETAL_TONES.length],
  }));
}

export function PetalRain() {
  // useSyncExternalStore distingue servidor de cliente sin escribir estado en
  // un efecto: en SSR devuelve false, tras hidratar true. Asi el azar de los
  // petalos nunca corre en el servidor y no hay mismatch.
  const isClient = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );

  const petals = useMemo(
    () => (isClient && !prefersReducedMotion() ? buildPetals() : []),
    [isClient],
  );

  if (petals.length === 0) return null;

  return (
    <div className="fv-petals" aria-hidden="true">
      {petals.map((p) => (
        <span
          key={p.id}
          className="fv-petal"
          style={
            {
              left: `${p.left}%`,
              "--fv-petal-delay": `${p.delay}s`,
              "--fv-petal-duration": `${p.duration}s`,
              "--fv-petal-scale": p.scale,
              "--fv-petal-drift": `${p.drift}px`,
              "--fv-petal-spin": `${p.spin}deg`,
            } as React.CSSProperties
          }
        >
          <svg viewBox="0 0 40 52" focusable="false">
            <defs>
              <radialGradient
                id={`fv-petal-grad-${p.id}`}
                cx="34%"
                cy="26%"
                r="82%"
              >
                <stop offset="0%" stopColor={p.tone.light} />
                <stop offset="52%" stopColor={p.tone.mid} />
                <stop offset="100%" stopColor={p.tone.dark} />
              </radialGradient>
            </defs>
            {/* Contorno asimetrico: un petalo real no es una elipse. */}
            <path
              d="M20 1c9 7 19 18 19 30 0 12-8.5 21-19 21S1 43 1 31C1 19 11 8 20 1z"
              fill={`url(#fv-petal-grad-${p.id})`}
            />
            <path
              d="M20 5c0 14 0 30-1 44"
              stroke={p.tone.dark}
              strokeOpacity="0.35"
              strokeWidth="1"
              fill="none"
            />
          </svg>
        </span>
      ))}
    </div>
  );
}
