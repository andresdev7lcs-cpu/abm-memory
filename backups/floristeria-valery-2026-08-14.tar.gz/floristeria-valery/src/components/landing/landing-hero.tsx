import {
  heroCopy,
  heroPoster,
  heroVideoUrl,
} from "@/content/landing";
import { LandingNav } from "@/components/landing/landing-nav";

type LandingHeroProps = {
  whatsappHref: string;
};

export function LandingHero({ whatsappHref }: LandingHeroProps) {
  return (
    <section className="fv-hero" id="hero">
      {/* preload auto + capa propia de composicion: el video no vuelve a
          repintarse con el scroll, que es lo que lo hacia ver a tirones. */}
      <video
        autoPlay
        muted
        playsInline
        loop
        preload="auto"
        poster={heroPoster}
      >
        <source src={heroVideoUrl} type="video/mp4" />
      </video>

      <LandingNav whatsappHref={whatsappHref} />

      <div className="fv-hero-content">
        <h1>{heroCopy.h1}</h1>
        <h2>{heroCopy.h2}</h2>
        <div className="fv-hero-ctas">
          <a
            href={whatsappHref}
            target="_blank"
            rel="noreferrer noopener"
            className="fv-btn-neon"
            data-track-event="whatsapp_cta_clicked"
            data-track-component="LandingHero"
          >
            <span className="fv-label">{heroCopy.cta}</span>
          </a>
          <a href="#categories" className="fv-btn-solid fv-rose">
            Ver arreglos
          </a>
        </div>
      </div>

      <div className="fv-scroll-cue">Desliza</div>
    </section>
  );
}
