"use client";

import { useEffect, useState } from "react";
import { categoryPhrases } from "@/content/categories";
import { landingReviews } from "@/content/landing";
import { PetalRain } from "@/components/landing/petal-rain";

const PHRASE_MS = 4000;
const FADE_MS = 600;

export function Testimonials() {
  // Indice de la frase visible. Arranca en 0 para que el HTML del servidor
  // y el del cliente coincidan; a partir de ahi se elige al azar.
  const [phraseIndex, setPhraseIndex] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;

    const hide = setTimeout(() => setVisible(false), PHRASE_MS);
    const next = setTimeout(() => {
      setPhraseIndex((prev) => {
        // Al azar, pero nunca repite la que se acaba de mostrar.
        let candidate = prev;
        while (candidate === prev) {
          candidate = Math.floor(Math.random() * categoryPhrases.length);
        }
        return candidate;
      });
      setVisible(true);
    }, PHRASE_MS + FADE_MS);

    return () => {
      clearTimeout(hide);
      clearTimeout(next);
    };
  }, [phraseIndex]);

  const current = categoryPhrases[phraseIndex];
  // Duplicado para que el bucle vertical no muestre huecos.
  const loopReviews = [...landingReviews, ...landingReviews];

  return (
    <section className="fv-testi" id="testimonios">
      <PetalRain />
      {/* Vineta: esquinas oscuras, centro limpio. */}
      <div className="fv-testi-vignette" aria-hidden="true" />

      <div className="fv-testi-grid">
        <div className="fv-testi-rail" aria-label="Opiniones de clientes">
          <div className="fv-testi-track">
            {loopReviews.map((review, i) => (
              <figure className="fv-testi-card" key={`${review.name}-${i}`}>
                <span className="fv-testi-stars" aria-label="5 de 5 estrellas">
                  {Array.from({ length: 5 }).map((_, s) => (
                    <svg
                      key={s}
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                      focusable="false"
                    >
                      <path
                        d="M12 2.6l2.9 5.9 6.5.9-4.7 4.6 1.1 6.4-5.8-3-5.8 3 1.1-6.4L2.6 9.4l6.5-.9z"
                        fill="currentColor"
                      />
                    </svg>
                  ))}
                </span>
                <blockquote className="fv-testi-quote">
                  {review.text}
                </blockquote>
                <figcaption className="fv-testi-name">{review.name}</figcaption>
              </figure>
            ))}
          </div>
        </div>

        <div className="fv-testi-message">
          <span className="fv-kicker">Lo que se dice con flores</span>
          <div
            className={`fv-testi-phrase ${visible ? "is-visible" : ""}`}
          >
            <h2 className="fv-testi-cat">{current.category}</h2>
            <p className="fv-testi-line">{current.line}</p>
          </div>
        </div>
      </div>
    </section>
  );
}
