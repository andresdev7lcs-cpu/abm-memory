import Link from "next/link";
import { Breadcrumbs } from "@/components/base/breadcrumbs";
import { CatalogProductCard } from "@/components/catalog/catalog-product-card";
import { SectionHeading } from "@/components/base/section-heading";
import { StatusPill } from "@/components/base/status-pill";
import type { CatalogPageData } from "@/lib/catalog";

type CatalogBrowserProps = {
  data: CatalogPageData;
};

function catalogValue(value: string | undefined) {
  return value ?? "all";
}

export function CatalogBrowser({ data }: CatalogBrowserProps) {
  const { filters, activeFilters, visibleProducts, featuredProducts, source } = data;

  return (
    <div className="space-y-10">
      <Breadcrumbs
        items={[
          { label: "Inicio", href: "/" },
          { label: "Comprar flores" },
        ]}
      />

      <section className="grid gap-6 rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm lg:grid-cols-[1.15fr_0.85fr] lg:p-8">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <StatusPill tone={source === "sanity" ? "success" : "accent"}>
              {source === "sanity" ? "CMS conectado" : "Base de catalogo"}
            </StatusPill>
            <StatusPill tone="warning">Noindex staging</StatusPill>
          </div>
          <h1 className="mt-5 font-display text-4xl tracking-tight text-slate-950 sm:text-5xl">
            Catalogo asistido de compra
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-slate-600">
            El flujo combina fichas de producto, filtros basicos y WhatsApp contextual sin activar pagos ni cargar catalogo definitivo.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              className="rounded-full bg-brand-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700"
              href="/comprar-flores/"
            >
              Limpiar filtros
            </Link>
            <Link
              className="rounded-full border border-slate-200 px-5 py-3 text-sm font-medium text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
              href="/contacto/"
            >
              Ir a contacto
            </Link>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <article className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">
              Productos visibles
            </p>
            <p className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">
              {visibleProducts.length}
            </p>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Los filtros actuales mantienen visible solo la parte que coincide con el contexto elegido.
            </p>
          </article>
          <article className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">
              Destacados
            </p>
            <p className="mt-3 text-3xl font-semibold tracking-tight text-slate-950">
              {featuredProducts.length}
            </p>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Base preparada para revisar la estructura principal del catalogo.
            </p>
          </article>
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
          <SectionHeading
            eyebrow="Filtros"
            title="Filtro basico de catalogo"
            description="Los filtros funcionan por categoria, ocasion, disponibilidad y rango de precio por confirmar."
          />
          <form className="mt-6 grid gap-4" action="/comprar-flores/" method="get">
            <label className="grid gap-2 text-sm font-medium text-slate-700">
              Categoria
              <select
                className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900"
                defaultValue={catalogValue(activeFilters.category)}
                name="category"
              >
                <option value="all">Todas</option>
                {filters.categories.map((category) => (
                  <option key={category.slug} value={category.slug}>
                    {category.title}
                  </option>
                ))}
              </select>
            </label>

            <label className="grid gap-2 text-sm font-medium text-slate-700">
              Ocasion
              <select
                className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900"
                defaultValue={catalogValue(activeFilters.occasion)}
                name="occasion"
              >
                <option value="all">Todas</option>
                {filters.occasions.map((occasion) => (
                  <option key={occasion.slug} value={occasion.slug}>
                    {occasion.title}
                  </option>
                ))}
              </select>
            </label>

            <label className="grid gap-2 text-sm font-medium text-slate-700">
              Disponibilidad
              <select
                className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900"
                defaultValue={catalogValue(activeFilters.availability)}
                name="availability"
              >
                <option value="all">Todas</option>
                {filters.availability.map((state) => (
                  <option key={state.key} value={state.key}>
                    {state.label}
                  </option>
                ))}
              </select>
            </label>

            <label className="grid gap-2 text-sm font-medium text-slate-700">
              Rango de precio
              <select
                className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900"
                defaultValue={catalogValue(activeFilters.price)}
                name="price"
              >
                {filters.price.map((state) => (
                  <option key={state.key} value={state.key}>
                    {state.label}
                  </option>
                ))}
              </select>
            </label>

            <div className="flex flex-wrap gap-3">
              <button
                className="rounded-full bg-brand-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700"
                type="submit"
              >
                Aplicar filtros
              </button>
              <Link
                className="rounded-full border border-slate-200 px-5 py-3 text-sm font-medium text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
                href="/comprar-flores/"
              >
                Quitar filtros
              </Link>
            </div>
          </form>

        <div className="mt-8 rounded-3xl border border-dashed border-slate-200 bg-slate-50 p-4">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">
              Precio por confirmar
          </p>
          <p className="mt-2 text-sm leading-6 text-slate-600">
              El rango de precio sigue en revision mientras no entren los valores finales.
          </p>
        </div>
        </section>

        <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
          <SectionHeading
            eyebrow="Estados"
            title="Leyenda de disponibilidad"
            description="La interfaz expone todos los estados que el catalogo puede presentar durante la fase de revisiones."
          />
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            {filters.availability.map((state) => (
              <article
                key={state.key}
                className="rounded-3xl border border-slate-200 bg-slate-50 p-4"
              >
                <StatusPill tone={state.tone}>{state.label}</StatusPill>
                <p className="mt-3 text-sm leading-6 text-slate-600">
                  {state.description}
                </p>
              </article>
            ))}
          </div>
        </section>
      </section>

      <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
          <SectionHeading
            eyebrow="Flujos asistidos"
            title="Accesos rapidos por necesidad"
            description="Cada flujo prepara WhatsApp con contexto y usa formularios minimos donde corresponde."
          />
        <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {[
            { href: "/entrega-hoy/", label: "Entrega hoy" },
            { href: "/comprar-desde-lejos/", label: "Comprar desde lejos" },
            { href: "/comprar-flores/condolencias/", label: "Condolencias" },
            { href: "/comprar-flores/personalizados/", label: "Personalizados" },
            { href: "/eventos/", label: "Eventos" },
            { href: "/empresas/", label: "Empresas" },
          ].map((entry) => (
            <Link
              key={entry.href}
              className="rounded-3xl border border-slate-200 bg-slate-50 p-5 transition hover:border-brand-300 hover:bg-white"
              href={entry.href}
            >
              <p className="text-sm font-semibold text-slate-950">{entry.label}</p>
              <p className="mt-2 text-sm leading-6 text-slate-600">
                Flujo asistido con WhatsApp contextual y datos por confirmar.
              </p>
            </Link>
          ))}
        </div>
      </section>

      <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
          <SectionHeading
            eyebrow="Catalogo"
            title="Fichas visibles"
            description={
              visibleProducts.length
              ? "Las fichas se conectan a Sanity cuando hay datos publicados y caen a la base tecnica si el CMS no esta listo."
              : "No hay coincidencias con los filtros actuales. Prueba otra combinacion o limpia el formulario."
            }
        />
        <div className="mt-6 grid gap-6 xl:grid-cols-2">
          {visibleProducts.map((product) => (
            <CatalogProductCard
              key={product.slug}
              detailPath={`/comprar-flores/${product.slug}/`}
              product={product}
            />
          ))}
        </div>
      </section>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "ItemList",
            name: "Catalogo asistido de compra",
            itemListElement: visibleProducts.map((product, index) => ({
              "@type": "ListItem",
              position: index + 1,
              name: product.title,
              url: `https://floristeriaenneiva.com/comprar-flores/${product.slug}/`,
            })),
          }),
        }}
      />
    </div>
  );
}
