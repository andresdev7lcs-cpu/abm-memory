import Link from "next/link";
import { InfoCard } from "@/components/base/info-card";
import { StatusPill } from "@/components/base/status-pill";
import { WhatsAppCTA } from "@/components/base/whatsapp-cta";
import type { CatalogProduct } from "@/content/commerce";

function toneForAvailability(
  availability: CatalogProduct["availability"],
): "success" | "warning" | "danger" | "accent" | "neutral" {
  switch (availability) {
    case "available":
      return "success";
    case "sold_out":
      return "warning";
    case "unavailable":
      return "accent";
    case "draft":
      return "neutral";
    case "error":
      return "danger";
    default:
      return "neutral";
  }
}

function availabilityLabel(availability: CatalogProduct["availability"]) {
  switch (availability) {
    case "available":
      return "Disponible";
    case "sold_out":
      return "Agotado";
    case "unavailable":
      return "No disponible";
    case "draft":
      return "Borrador";
    case "error":
      return "Error";
    default:
      return "No disponible";
  }
}

type CatalogProductCardProps = {
  product: CatalogProduct;
  detailPath: string;
};

export function CatalogProductCard({
  product,
  detailPath,
}: CatalogProductCardProps) {
  return (
    <article className="overflow-hidden rounded-[2rem] border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 bg-gradient-to-r from-brand-50 to-ivory-100 p-5">
        <div className="flex flex-wrap items-center gap-2">
          <StatusPill tone={toneForAvailability(product.availability)}>
            {availabilityLabel(product.availability)}
          </StatusPill>
          <p className="text-xs text-slate-500">{product.slug}</p>
        </div>
        <h3 className="mt-4 text-xl font-semibold tracking-tight text-slate-950">
          {product.title}
        </h3>
        <p className="mt-3 text-sm leading-6 text-slate-600">{product.summary}</p>
      </div>

      <div className="grid gap-4 p-5 sm:grid-cols-2">
        <InfoCard
          title="Categoria"
          value={product.category.title}
          description={product.category.slug}
          tone="accent"
          badgeLabel="categoria"
        />
        <InfoCard
          title="Precio"
          value={product.priceLabel}
          description="Valor comercial por confirmar."
          tone="warning"
          badgeLabel="por confirmar"
        />
        <InfoCard
          title="Preparacion"
          value={product.prepTime}
          description="Dato operativo editable desde CMS."
          tone="success"
          badgeLabel="cms"
        />
        <InfoCard
          title="Ocasiones"
          value={`${product.occasions.length}`}
          description={product.occasions.map((occasion) => occasion.title).join(", ")}
          tone="neutral"
          badgeLabel="relaciones"
        />
      </div>

      <div className="flex flex-wrap gap-2 px-5 pb-4">
        {product.occasions.map((occasion) => (
          <Link
            key={occasion.slug}
            className="rounded-full border border-slate-200 px-3 py-1 text-xs font-medium text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
            href={`/comprar-flores/?occasion=${occasion.slug}`}
          >
            {occasion.title}
          </Link>
        ))}
      </div>

      <div className="grid gap-4 border-t border-slate-100 p-5">
        <Link
          className="inline-flex rounded-full border border-brand-300 px-4 py-2 text-sm font-medium text-brand-800 transition hover:bg-brand-50"
          href={detailPath}
        >
          Ver ficha
        </Link>
        <WhatsAppCTA
          label="Abrir WhatsApp con esta ficha preparada"
          message={product.whatsappMessage}
          note="El mensaje ya incluye contexto por producto."
        />
      </div>
    </article>
  );
}
