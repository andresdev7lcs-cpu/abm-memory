import Link from "next/link";
import { Breadcrumbs } from "@/components/base/breadcrumbs";
import { InfoCard } from "@/components/base/info-card";
import { SectionHeading } from "@/components/base/section-heading";
import { StatusPill } from "@/components/base/status-pill";
import { TechTable } from "@/components/base/tech-table";
import { WhatsAppCTA } from "@/components/base/whatsapp-cta";
import type { CatalogProduct } from "@/content/commerce";

function toneForAvailability(
  availability: CatalogProduct["availability"],
): "success" | "warning" | "danger" | "accent" | "neutral" {
  switch (availability) {
    case "available":
      return "success";
    case "sold_out":
      return "warning";
    case "unavailable":
      return "accent";
    case "draft":
      return "neutral";
    case "error":
      return "danger";
    default:
      return "neutral";
  }
}

function availabilityLabel(availability: CatalogProduct["availability"]) {
  switch (availability) {
    case "available":
      return "Disponible";
    case "sold_out":
      return "Agotado";
    case "unavailable":
      return "No disponible";
    case "draft":
      return "Borrador";
    case "error":
      return "Error";
    default:
      return "No disponible";
  }
}

type CatalogProductDetailProps = {
  product: CatalogProduct;
  relatedProducts: CatalogProduct[];
  source: "scaffold" | "sanity";
};

export function CatalogProductDetail({
  product,
  relatedProducts,
  source,
}: CatalogProductDetailProps) {
  return (
    <div className="space-y-10">
      <Breadcrumbs
        items={[
          { label: "Inicio", href: "/" },
          { label: "Comprar flores", href: "/comprar-flores/" },
          { label: product.title },
        ]}
      />

      <section className="grid gap-6 rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm lg:grid-cols-[1.15fr_0.85fr] lg:p-8">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <StatusPill tone={toneForAvailability(product.availability)}>
              {availabilityLabel(product.availability)}
            </StatusPill>
            <StatusPill tone={source === "sanity" ? "success" : "accent"}>
              {source === "sanity" ? "CMS conectado" : "Base tecnica"}
            </StatusPill>
          </div>
          <h1 className="mt-5 font-display text-4xl tracking-tight text-slate-950 sm:text-5xl">
            {product.title}
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-slate-600">
            {product.summary}
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              className="rounded-full bg-brand-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700"
              href="/comprar-flores/"
            >
              Volver al catalogo
            </Link>
            <Link
              className="rounded-full border border-slate-200 px-5 py-3 text-sm font-medium text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
              href="/contacto/"
            >
              Pedir orientacion
            </Link>
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <InfoCard
            title="Categoria"
            value={product.category.title}
            description={product.category.slug}
            tone="accent"
            badgeLabel="categoria"
          />
          <InfoCard
            title="Precio"
            value={product.priceLabel}
            description="Los valores comerciales finales siguen por confirmar."
            tone="warning"
            badgeLabel="por confirmar"
          />
          <InfoCard
            title="Preparacion"
            value={product.prepTime}
            description="Tiempo operativo editable desde CMS."
            tone="success"
            badgeLabel="cms"
          />
          <InfoCard
            title="Ocasiones"
            value={`${product.occasions.length}`}
            description={product.occasions.map((occasion) => occasion.title).join(", ")}
            tone="neutral"
            badgeLabel="relaciones"
          />
        </div>
      </section>

      <section className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
        <TechTable
          title="Ficha tecnica"
          rows={[
            { label: "Slug", value: product.slug },
            { label: "Availability", value: product.availability },
            { label: "Sizes", value: product.sizes.join(", ") },
            { label: "Colors", value: product.colors.join(", ") },
            { label: "Delivery zones", value: product.deliveryZones.join(", ") },
            { label: "Add-ons", value: product.addOns.join(", ") },
          ]}
        />
        <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
          <SectionHeading
            eyebrow="WhatsApp"
            title="Mensaje contextual por producto"
            description="El CTA se prepara con la ficha actual y conserva tracking y fallback."
          />
          <div className="mt-6">
            <WhatsAppCTA
              label="Abrir WhatsApp con esta ficha"
              message={product.whatsappMessage}
              note="El texto ya viaja contextualizado al chat."
            />
          </div>
        </section>
      </section>

      <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
          <SectionHeading
            eyebrow="Relacionados"
            title="Otros productos de referencia"
          description="Se muestran como base de referencia para orientar navegacion sin inventar catalogo definitivo."
        />
        <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {relatedProducts.map((entry) => (
            <article
              key={entry.slug}
              className="rounded-3xl border border-slate-200 bg-slate-50 p-5"
            >
              <StatusPill tone={toneForAvailability(entry.availability)}>
                {availabilityLabel(entry.availability)}
              </StatusPill>
              <h3 className="mt-4 text-lg font-semibold tracking-tight text-slate-950">
                {entry.title}
              </h3>
              <p className="mt-3 text-sm leading-6 text-slate-600">{entry.summary}</p>
              <Link
                className="mt-5 inline-flex text-sm font-medium text-brand-700 underline-offset-4 hover:underline"
                href={`/comprar-flores/${entry.slug}/`}
              >
                Ver ficha
              </Link>
            </article>
          ))}
        </div>
      </section>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "Product",
            name: product.title,
            description: product.summary,
            category: product.category.title,
            sku: product.slug,
            url: `https://floristeriaenneiva.com/comprar-flores/${product.slug}/`,
            offers:
              typeof product.price === "number"
                ? {
                    "@type": "Offer",
                    price: product.price,
                    priceCurrency: "COP",
                    availability:
                      product.availability === "available"
                        ? "https://schema.org/InStock"
                        : "https://schema.org/OutOfStock",
                  }
                : undefined,
          }),
        }}
      />
    </div>
  );
}
