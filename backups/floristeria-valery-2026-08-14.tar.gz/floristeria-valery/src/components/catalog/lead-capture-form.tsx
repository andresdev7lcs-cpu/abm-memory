"use client";

import { useState, type ChangeEvent, type FormEvent } from "react";
import { buildWhatsAppHref, sanitizePhoneNumber } from "@/components/base/whatsapp-cta";
import { siteConfig } from "@/content/site";
import type { CatalogFlowDefinition } from "@/content/commerce";

type LeadCaptureFormProps = {
  flow: CatalogFlowDefinition;
  trackingEventName?: string;
  whatsappNumber?: string;
  fallbackLabel?: string;
  note?: string;
};

type FormState = Record<string, string>;

function buildMessage(flow: CatalogFlowDefinition, values: FormState) {
  const lines = [
    flow.whatsappMessage,
    ...flow.fields.map((field) => {
      const value = values[field.name]?.trim();
      return value ? `${field.label}: ${value}` : null;
    }),
  ].filter(Boolean);

  return lines.join("\n");
}

export function LeadCaptureForm({
  flow,
  trackingEventName = "lead_form_whatsapp_clicked",
  whatsappNumber = siteConfig.whatsappNumber,
  fallbackLabel = "Si WhatsApp no abre, usa el enlace directo",
  note,
}: LeadCaptureFormProps) {
  const initialState = flow.fields.reduce<FormState>((accumulator, field) => {
    accumulator[field.name] = "";
    return accumulator;
  }, {});

  const [values, setValues] = useState<FormState>(initialState);
  const [fallbackHref, setFallbackHref] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<string>("");

  function handleChange(name: string, value: string) {
    setValues((current) => ({
      ...current,
      [name]: value,
    }));
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const message = buildMessage(flow, values);
    const href = buildWhatsAppHref(whatsappNumber, message);

    if (!href) {
      setFeedback("Configura un numero de WhatsApp para activar el envio directo.");
      setFallbackHref(null);
      return;
    }

    const opened = window.open(href, "_blank", "noopener,noreferrer");

    if (!opened) {
      setFallbackHref(href);
      setFeedback("No se pudo abrir WhatsApp. Usa el enlace visible como respaldo.");
      return;
    }

    setFeedback("WhatsApp se abrio con el contexto preparado.");
    setFallbackHref(null);
  }

  const messagePreview = buildMessage(flow, values);
  const sanitizedNumber = sanitizePhoneNumber(whatsappNumber);

  return (
    <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
      <p className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">
        Formulario
      </p>
      <h2 className="mt-3 text-2xl font-semibold tracking-tight text-slate-950">
        {flow.formTitle}
      </h2>
      <p className="mt-3 text-sm leading-6 text-slate-600">{flow.formDescription}</p>
      {note ? <p className="mt-3 text-sm text-slate-500">{note}</p> : null}
      <form
        className="mt-6 grid gap-4"
        data-track-component="LeadCaptureForm"
        data-track-event={trackingEventName}
        onSubmit={handleSubmit}
      >
        {flow.fields.map((field) => {
          const commonProps = {
            id: field.name,
            name: field.name,
            required: field.required,
            placeholder: field.placeholder,
            value: values[field.name] ?? "",
            onChange: (
              event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
            ) =>
              handleChange(field.name, event.target.value),
            className:
              "w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-brand-400 focus:bg-white",
          };

          return (
            <label key={field.name} className="grid gap-2 text-sm font-medium text-slate-700">
              <span className="flex items-center gap-2">
                {field.label}
                {field.required ? (
                  <span className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">
                    requerido
                  </span>
                ) : null}
              </span>
              {field.type === "textarea" ? (
                <textarea {...commonProps} rows={4} />
              ) : (
                <input {...commonProps} type={field.type} />
              )}
              {field.helper ? (
                <span className="text-xs font-normal text-slate-500">{field.helper}</span>
              ) : null}
            </label>
          );
        })}
        <button
          className="inline-flex items-center justify-center rounded-full bg-brand-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700"
          type="submit"
        >
          {flow.submitLabel}
        </button>
      </form>

      <div className="mt-6 rounded-3xl border border-dashed border-slate-200 bg-slate-50 p-4">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">
          Mensaje preparado
        </p>
        <pre className="mt-3 overflow-x-auto whitespace-pre-wrap text-sm leading-6 text-slate-700">
          {messagePreview}
        </pre>
      </div>

      {feedback ? <p className="mt-4 text-sm text-slate-600">{feedback}</p> : null}
      {fallbackHref ? (
        <a
          className="mt-3 inline-flex text-sm font-medium text-brand-800 underline decoration-brand-300 underline-offset-4 transition hover:text-brand-900"
          href={fallbackHref}
        >
          {fallbackLabel}
        </a>
      ) : sanitizedNumber ? null : (
        <p className="mt-3 text-sm text-slate-600">
          Configura `NEXT_PUBLIC_WHATSAPP_NUMBER` para activar el envio directo.
        </p>
      )}
    </section>
  );
}
