import Link from "next/link";
import { Breadcrumbs } from "@/components/base/breadcrumbs";
import { LeadCaptureForm } from "@/components/catalog/lead-capture-form";
import { SectionHeading } from "@/components/base/section-heading";
import { StatusPill } from "@/components/base/status-pill";
import { WhatsAppCTA } from "@/components/base/whatsapp-cta";
import type { CatalogFlowDefinition } from "@/content/commerce";

type FlowPageProps = {
  flow: CatalogFlowDefinition;
  source?: "scaffold" | "sanity";
  intro?: string;
};

export function FlowPage({
  flow,
  source = "scaffold",
  intro,
}: FlowPageProps) {
  return (
    <div className="space-y-10">
      <Breadcrumbs
        items={[
          { label: "Inicio", href: "/" },
          { label: "Comprar flores", href: "/comprar-flores/" },
          { label: flow.title },
        ]}
      />

      <section className="grid gap-6 rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm lg:grid-cols-[1.1fr_0.9fr] lg:p-8">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <StatusPill tone={source === "sanity" ? "success" : "accent"}>
              {source === "sanity" ? "CMS conectado" : "Flujo asistido"}
            </StatusPill>
            <StatusPill tone="warning">Noindex staging</StatusPill>
          </div>
          <h1 className="mt-5 font-display text-4xl tracking-tight text-slate-950 sm:text-5xl">
            {flow.title}
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-slate-600">
            {intro ?? flow.summary}
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              className="rounded-full bg-brand-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700"
              href="/comprar-flores/"
            >
              Ir al catalogo
            </Link>
            <Link
              className="rounded-full border border-slate-200 px-5 py-3 text-sm font-medium text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
              href="/contacto/"
            >
              Contacto general
            </Link>
          </div>
        </div>
        <div className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
          <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">
            Nota de flujo
          </p>
          <p className="mt-3 text-sm leading-6 text-slate-600">{flow.note}</p>
          <div className="mt-5">
            <WhatsAppCTA
              label="Abrir WhatsApp con contexto preparado"
              message={flow.whatsappMessage}
              note="El mensaje del flujo ya sale armado desde el contexto de la pagina."
            />
          </div>
        </div>
      </section>

      <LeadCaptureForm flow={flow} note={flow.note} />

      <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
        <SectionHeading
          eyebrow="Escenario"
          title="Uso previsto"
          description="Este flujo queda listo para orientacion tecnica sin checkout ni pagos."
        />
        <p className="mt-4 max-w-3xl text-sm leading-7 text-slate-600">
          {flow.summary}
        </p>
      </section>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebPage",
            name: flow.title,
            description: flow.summary,
            url: `https://floristeriaenneiva.com${flow.path}`,
          }),
        }}
      />
    </div>
  );
}
