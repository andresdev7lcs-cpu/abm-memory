import Link from "next/link";
import { Breadcrumbs } from "@/components/base/breadcrumbs";
import { InfoCard } from "@/components/base/info-card";
import { ModelCard } from "@/components/base/model-card";
import { SectionHeading } from "@/components/base/section-heading";
import { StatusPill } from "@/components/base/status-pill";
import { TechTable } from "@/components/base/tech-table";
import { LeadCaptureForm } from "@/components/catalog/lead-capture-form";
import { SiteShell } from "@/components/layout/site-shell";
import { getCatalogFlowDefinition } from "@/lib/catalog";
import type {
  CmsFamilyDefinition,
  CmsFamilyState,
  CmsRecord,
} from "@/content/cms";

type CmsFamilyPageProps = {
  family: CmsFamilyDefinition;
  records: CmsRecord[];
  source: "scaffold" | "sanity";
  selectedRecord?: CmsRecord | null;
};

function toneForStatus(status: CmsRecord["status"]) {
  switch (status) {
    case "ready":
      return "success";
    case "placeholder":
      return "warning";
    default:
      return "accent";
  }
}

function statusLabelForSource(source: CmsFamilyPageProps["source"]) {
  return source === "sanity" ? "CMS conectado" : "Base tecnica";
}

function statusLabelForRecord(status: CmsRecord["status"]) {
  switch (status) {
    case "ready":
      return "Publicado";
    case "placeholder":
      return "Por confirmar";
    case "scaffold":
    default:
      return "Base tecnica";
  }
}

function resolveFamilyState(
  family: CmsFamilyDefinition,
  source: CmsFamilyPageProps["source"],
  records: CmsRecord[],
  selectedRecord?: CmsRecord | null,
): CmsFamilyState {
  if (records.length === 0) {
    return family.states.find((state) => state.key === "sin-contenido") ?? family.states[0];
  }

  if (source === "sanity") {
    return (
      family.states.find((state) => state.key === "con-contenido") ??
      family.states[0]
    );
  }

  if (selectedRecord) {
    return family.states.find((state) => state.key === "borrador") ?? family.states[0];
  }

  return family.states.find((state) => state.key === "no-disponible") ?? family.states[0];
}

function RecordCard({
  family,
  record,
}: {
  family: CmsFamilyDefinition;
  record: CmsRecord;
}) {
  return (
    <article className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex flex-wrap items-center gap-2">
        <StatusPill tone={toneForStatus(record.status)}>
          {statusLabelForRecord(record.status)}
        </StatusPill>
        <p className="text-xs text-slate-500">{record.slug}</p>
      </div>
      <h3 className="mt-4 text-lg font-semibold tracking-tight text-slate-950">
        {record.title}
      </h3>
      <p className="mt-3 text-sm leading-6 text-slate-600">{record.summary}</p>
      <div className="mt-4 flex flex-wrap gap-2">
        {record.relatedFamilies.map((relatedFamily) => (
          <Link
            key={relatedFamily}
            className="rounded-full border border-slate-200 px-3 py-1 text-xs font-medium text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
            href={`/${relatedFamily}/`}
          >
            {relatedFamily}
          </Link>
        ))}
      </div>
      <Link
        className="mt-5 inline-flex text-sm font-medium text-brand-700 underline-offset-4 hover:underline"
        href={`${family.path}${record.slug}/`}
      >
        Abrir ficha
      </Link>
    </article>
  );
}

export function CmsFamilyPage({
  family,
  records,
  source,
  selectedRecord,
}: CmsFamilyPageProps) {
  const isDetail = Boolean(selectedRecord);
  const record = selectedRecord ?? records[0] ?? null;
  const currentState = resolveFamilyState(family, source, records, selectedRecord);
  const leadFlow =
    family.key === "eventos"
      ? getCatalogFlowDefinition("eventos")
      : family.key === "empresas"
        ? getCatalogFlowDefinition("empresas")
        : null;

  return (
    <SiteShell>
      <Breadcrumbs
        items={[
          { label: "Inicio", href: "/" },
          { label: family.title },
        ]}
      />

      <section className="grid gap-6 rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm lg:grid-cols-[1.15fr_0.85fr] lg:p-8">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <StatusPill tone="accent">{statusLabelForSource(source)}</StatusPill>
            <StatusPill tone="warning">noindex tecnico</StatusPill>
          </div>
          <h1 className="mt-5 font-display text-4xl tracking-tight text-slate-950 sm:text-5xl">
            {isDetail && record ? record.title : family.title}
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-slate-600">
            {isDetail && record ? record.summary : family.description}
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              className="rounded-full bg-brand-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700"
              href="/studio/"
            >
              Open Sanity Studio
            </Link>
            <Link
              className="rounded-full border border-slate-200 px-5 py-3 text-sm font-medium text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
              href="/"
            >
              Back to dashboard
            </Link>
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <InfoCard
            title="Route"
            value={family.path}
            description="Generic section route connected to the CMS base."
            tone="success"
            badgeLabel="route"
          />
          <InfoCard
            title="CMS type"
            value={family.cmsType}
            description="Mapped to a Sanity document schema."
            tone="accent"
            badgeLabel="schema"
          />
          <InfoCard
            title="Template"
            value={family.template.kind}
            description={family.template.primaryPanelTitle}
            tone="neutral"
            badgeLabel="layout"
          />
          <InfoCard
            title="Records"
            value={String(records.length)}
            description="Registros listos para ser reemplazados por contenido CMS."
            tone="warning"
            badgeLabel="base"
          />
          <InfoCard
            title="Current state"
            value={currentState.label}
            description={currentState.description}
            tone={currentState.tone}
            badgeLabel="state"
          />
          <InfoCard
            title="Indexing"
            value="Noindex"
            description="Technical pages stay out of search until content is promoted."
            tone="danger"
            badgeLabel="safe"
          />
        </div>
      </section>

      <section className="mt-10 grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
        <TechTable
          title="CMS alignment"
          rows={[
            { label: "Section", value: family.title },
            { label: "CMS model", value: family.cmsType },
            { label: "Route", value: family.path },
            { label: "Template", value: family.template.kind },
            { label: "State", value: currentState.label },
            {
              label: "Status",
              value: `${source === "sanity" ? "CMS" : "Base"} source`,
            },
          ]}
        />
        <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
          <SectionHeading
            eyebrow="Template blueprint"
            title="Family layout"
            description="Each family now has a concrete visual and functional base, ready to swap from review content to published content."
          />
          <div className="mt-6 grid gap-4 lg:grid-cols-3">
            <ModelCard
              name={family.template.primaryPanelTitle}
              purpose={family.template.primaryPanelDescription}
            />
            <ModelCard
              name={family.template.secondaryPanelTitle}
              purpose={family.template.secondaryPanelDescription}
            />
            <ModelCard
              name={family.template.emptyStateTitle}
              purpose={family.template.emptyStateDescription}
            />
          </div>
          <div className="mt-6 rounded-3xl border border-dashed border-slate-200 bg-slate-50 p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-brand-700">
              Regla de contenido
            </p>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              {family.placeholderNote}
            </p>
          </div>
        </section>
      </section>

      <section className="mt-10 rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
        <SectionHeading
          eyebrow="State matrix"
          title="Template states"
          description="The same five states are exposed for every family so review and QA can validate empty, draft, and fallback behaviour without changing URLs."
        />
        <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-5">
          {family.states.map((state) => (
            <article
              key={state.key}
              className="rounded-3xl border border-slate-200 bg-slate-50 p-5"
            >
              <StatusPill tone={state.tone}>{state.label}</StatusPill>
              <p className="mt-4 text-sm leading-6 text-slate-600">
                {state.description}
              </p>
            </article>
          ))}
        </div>
      </section>

      <section className="mt-10 rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
        <SectionHeading
          eyebrow="Field base"
          title="Current structure"
          description="The content shape is explicit, even when the value set is still pending confirmation."
        />
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          {family.fields.map((field) => (
            <ModelCard key={field} name={field} purpose="Editable field" />
          ))}
        </div>
      </section>

      <section className="mt-10 rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
        <SectionHeading
          eyebrow={isDetail ? "Record detail" : "Record list"}
          title={
            isDetail && record ? record.title : `Review records for ${family.title}`
          }
          description={
            isDetail && record
              ? "This detail view is wired to CMS or base data."
              : family.template.emptyStateDescription
          }
        />
        {isDetail && record ? (
          <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_0.9fr]">
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-2">
                <StatusPill tone={toneForStatus(record.status)}>
                  {statusLabelForRecord(record.status)}
                </StatusPill>
                <p className="text-xs text-slate-500">{record.slug}</p>
              </div>
              <p className="text-sm leading-7 text-slate-600">{record.summary}</p>
              <div className="rounded-3xl border border-slate-200 bg-slate-50 p-4">
                <h3 className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">
                  Focus
                </h3>
                <ul className="mt-4 space-y-3 text-sm leading-6 text-slate-700">
                  {record.focus.map((item) => (
                    <li key={item} className="flex gap-3">
                      <span className="mt-2 h-2 w-2 rounded-full bg-brand-500" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="rounded-3xl border border-slate-200 bg-white p-5">
              <h3 className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">
                Related families
              </h3>
              <div className="mt-4 flex flex-wrap gap-2">
                {record.relatedFamilies.map((relatedFamily) => (
                  <Link
                    key={relatedFamily}
                    className="rounded-full border border-slate-200 px-3 py-1 text-xs font-medium text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
                    href={`/${relatedFamily}/`}
                  >
                    {relatedFamily}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <>
            <p className="mt-4 max-w-3xl text-sm leading-7 text-slate-600">
              {family.placeholderNote}
            </p>
            <div className="mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {records.map((entry) => (
                <RecordCard key={entry.slug} family={family} record={entry} />
              ))}
            </div>
          </>
        )}
      </section>

      {leadFlow ? (
        <section className="mt-10">
          <LeadCaptureForm flow={leadFlow} note={leadFlow.note} />
        </section>
      ) : null}
    </SiteShell>
  );
}
