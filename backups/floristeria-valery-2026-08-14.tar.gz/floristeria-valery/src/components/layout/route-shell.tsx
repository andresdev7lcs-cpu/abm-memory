import Link from "next/link";
import { StatusPill } from "@/components/base/status-pill";
import { siteConfig } from "@/content/site";

type RouteShellProps = {
  path: string;
  title: string;
  description: string;
  category: "preserved" | "hub" | "planned";
};

export function RouteShell({
  path,
  title,
  description,
  category,
}: RouteShellProps) {
  return (
    <section className="overflow-hidden rounded-[2rem] border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 bg-gradient-to-r from-brand-50 to-ivory-100 px-6 py-8 sm:px-8">
        <div className="flex flex-wrap items-center gap-3">
          <StatusPill tone={category === "preserved" ? "success" : category === "hub" ? "accent" : "warning"}>
            {category}
          </StatusPill>
          <p className="text-sm text-slate-500">{path}</p>
        </div>
        <h1 className="mt-4 text-3xl font-semibold tracking-tight text-slate-950 sm:text-4xl">
          {title}
        </h1>
        <p className="mt-4 max-w-3xl text-base leading-7 text-slate-600">
          {description}
        </p>
      </div>
      <div className="grid gap-6 p-6 sm:p-8 lg:grid-cols-[1.4fr_0.6fr]">
        <div className="space-y-4">
          <h2 className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">
            Estado de esta ruta
          </h2>
          <p className="text-sm leading-6 text-slate-600">
            Esta pagina preserva la estructura indexada actual y deja listo el
            espacio para edicion futura desde CMS, sin publicar contenido
            comercial definitivo todavia.
          </p>
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
            <p className="font-medium text-slate-900">Dominio canonico</p>
            <p className="mt-1">{siteConfig.canonicalDomain}</p>
          </div>
        </div>
        <aside className="rounded-2xl border border-brand-200 bg-brand-50 p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-800">
            Navegacion
          </h2>
          <div className="mt-4 flex flex-col gap-3 text-sm">
            <Link
              className="rounded-full bg-brand-600 px-4 py-2 text-center font-medium text-white transition hover:bg-brand-700"
              href="/"
            >
              Volver al dashboard
            </Link>
            <Link
              className="rounded-full border border-brand-300 px-4 py-2 text-center font-medium text-brand-800 transition hover:bg-brand-100"
              href="/comprar-flores/"
            >
              Abrir hub
            </Link>
          </div>
        </aside>
      </div>
    </section>
  );
}
