import Link from "next/link";
import { siteConfig } from "@/content/site";

type SiteShellProps = {
  children: React.ReactNode;
};

export function SiteShell({ children }: SiteShellProps) {
  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top,_rgba(30,58,46,0.12),_transparent_40%),linear-gradient(180deg,#f8f4eb_0%,#fffdf9_100%)] text-slate-950">
      <header className="sticky top-0 z-40 border-b border-white/70 bg-white/80 backdrop-blur">
        <div className="mx-auto flex w-full max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.28em] text-brand-700">
              {siteConfig.domain}
            </p>
            <p className="mt-1 text-sm text-slate-600">
              Base tecnica, CMS y staging
            </p>
          </div>
          <nav className="flex flex-wrap items-center gap-2 text-sm">
            <Link
              className="rounded-full border border-slate-200 px-4 py-2 text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
              href="/"
            >
              Inicio
            </Link>
            <Link
              className="rounded-full border border-slate-200 px-4 py-2 text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
              href="/comprar-flores/"
            >
              Hub
            </Link>
            <Link
              className="rounded-full border border-brand-200 bg-brand-600 px-4 py-2 font-medium text-white transition hover:bg-brand-700"
              href="/studio/"
            >
              Studio
            </Link>
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        {children}
      </main>
      <footer className="border-t border-white/70 bg-white/70">
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-2 px-4 py-6 text-sm text-slate-600 sm:px-6 lg:px-8">
          <p>
            Fase 5 en curso. No hay publicacion de produccion ni ecommerce.
          </p>
          <p>{siteConfig.domain}</p>
        </div>
      </footer>
    </div>
  );
}
