export type FlowerCategory = {
  key: string;
  /** Texto curvo del anillo — corto para que no se solape */
  ringLabel: string;
  name: string;
  /** Frase editorial: habla del gesto, no del producto */
  desc: string;
  image: string;
  /** Fondo del panel; el crossfade usa este valor */
  background: string;
  /**
   * Compensa el ratio del PNG. Con object-fit: contain los 16:9 solo llenan
   * ~50% de la altura del aro y condolencias (vertical) el 88%. Este factor
   * iguala a todas con esa proporcion. Omitir = 1 (sin correccion).
   */
  imgFit?: number;
  /**
   * Ocasion de duelo. Apaga los petalos, el rebote del carrusel y cambia el
   * CTA por uno que acompana en vez de vender. Misma marca, registro serio.
   */
  solemn?: boolean;
  /** CTA propio; por defecto "Pedir este arreglo". */
  ctaLabel?: string;
};

/**
 * Los PNG horizontales (1500x844) llenan solo ~50% de la altura del aro con
 * object-fit: contain, y quedaba un vacio grande contra el borde mientras
 * condolencias (vertical) se veia equilibrada. Con el aro reducido un 4%,
 * 1.16 acerca el ramo al anillo sin que lo cruce: las etiquetas curvas son
 * navegacion y deben leerse siempre.
 */
const FIT_LANDSCAPE = 1.12;

export const flowerCategories: FlowerCategory[] = [
  {
    key: "dia-mujer",
    ringLabel: "Dia de la Mujer",
    name: "Dia de la Mujer",
    desc: "Hay mujeres que sostienen todo y casi nunca reciben nada. Este es el dia para decirle que la ves.",
    image: "/ocasiones/dia-mujer.png",
    background:
      `radial-gradient(
        ellipse 70% 60% at 78% 45%,
        rgba(122, 60, 255, 0.22),
        transparent 68%
      ),
      radial-gradient(
        ellipse 90% 70% at 8% 60%,
        rgba(122, 60, 255, 0.1),
        transparent 62%
      ),
      linear-gradient(270deg, #050506 0%, #0d0912 60%, #150e22 100%)`,
    imgFit: FIT_LANDSCAPE,
  },
  {
    key: "aniversario",
    ringLabel: "Aniversario",
    name: "Aniversario",
    desc: "Un ano mas juntos no se celebra solo. Que ella recuerde por que dijo que si.",
    image: "/ocasiones/aniversario.png",
    background:
      `radial-gradient(
        ellipse 70% 60% at 78% 45%,
        rgba(216, 70, 114, 0.2),
        transparent 68%
      ),
      radial-gradient(
        ellipse 90% 70% at 8% 60%,
        rgba(212, 85, 58, 0.1),
        transparent 62%
      ),
      linear-gradient(270deg, #050506 0%, #100809 60%, #1c0d10 100%)`,
    imgFit: FIT_LANDSCAPE,
  },
  {
    key: "cumpleanos",
    ringLabel: "Cumpleanos",
    name: "Cumpleanos",
    desc: "Todos mandan un mensaje. Muy pocos mandan flores. Se el que se acordo de verdad.",
    image: "/ocasiones/cumpleanos.png",
    background:
      `radial-gradient(
        ellipse 70% 60% at 78% 45%,
        rgba(87, 168, 63, 0.18),
        transparent 68%
      ),
      radial-gradient(
        ellipse 90% 70% at 8% 60%,
        rgba(201, 164, 92, 0.1),
        transparent 62%
      ),
      linear-gradient(270deg, #050506 0%, #080d08 60%, #0d160e 100%)`,
    imgFit: FIT_LANDSCAPE,
  },
  {
    key: "graduacion",
    ringLabel: "Graduacion",
    name: "Graduacion",
    desc: "Anos de esfuerzo caben en un solo dia. Que ese dia se sienta tan grande como fue.",
    image: "/ocasiones/graduacion.png",
    background:
      `radial-gradient(
        ellipse 70% 60% at 78% 45%,
        rgba(201, 164, 92, 0.2),
        transparent 68%
      ),
      radial-gradient(
        ellipse 90% 70% at 8% 60%,
        rgba(240, 213, 138, 0.09),
        transparent 62%
      ),
      linear-gradient(270deg, #050506 0%, #0f0b06 60%, #1a1309 100%)`,
    imgFit: FIT_LANDSCAPE,
  },
  {
    key: "condolencias",
    ringLabel: "Condolencias",
    name: "Condolencias",
    desc: "Cuando no sabes que decir, no digas nada. Acompana. Nosotros nos encargamos del resto.",
    image: "/ocasiones/condolencias.png",
    background:
      `radial-gradient(
        ellipse 70% 60% at 78% 45%,
        rgba(142, 154, 163, 0.16),
        transparent 68%
      ),
      radial-gradient(
        ellipse 90% 70% at 8% 60%,
        rgba(244, 234, 220, 0.07),
        transparent 62%
      ),
      linear-gradient(270deg, #050506 0%, #0a0b0d 60%, #121417 100%)`,
    solemn: true,
    ctaLabel: "Hablemos",
  },
];

/** Banner infinito de la seccion de categorias. */
export const marqueeMessages = [
  "Te ayudamos a elegir por WhatsApp",
  "Te lo entregamos el mismo dia en Neiva",
  "Armamos tu ramo el dia que lo mandas",
  "Te mandamos foto antes de salir",
  "Pagas cuando llega",
];

export type CategoryPhrase = {
  category: string;
  line: string;
};

/**
 * Tres frases por categoria para el bloque de testimonios.
 * Se muestran en orden aleatorio, 4 segundos cada una.
 */
export const categoryPhrases: CategoryPhrase[] = [
  {
    category: "Cumpleanos",
    line: "Hoy celebramos tu vida y no alcanzan las flores para decirte cuanto te amo.",
  },
  {
    category: "Cumpleanos",
    line: "Un ano mas de ti en el mundo. Eso, para mi, siempre va a ser motivo de fiesta.",
  },
  {
    category: "Cumpleanos",
    line: "Que la vida te siga dando dias como este y gente que te los quiera celebrar.",
  },
  {
    category: "Aniversario",
    line: "Volveria a elegirte, incluso sabiendo todo lo que costo llegar hasta aqui.",
  },
  {
    category: "Aniversario",
    line: "No celebro el tiempo que paso. Celebro que todavia me eliges cada manana.",
  },
  {
    category: "Aniversario",
    line: "Un ano mas contigo y sigo pensando que me gane la loteria.",
  },
  {
    category: "Dia de la Mujer",
    line: "Sostienes mas de lo que cualquiera imagina. Hoy te toca a ti recibir.",
  },
  {
    category: "Dia de la Mujer",
    line: "Gracias por la fuerza que nunca presumes y que todos aprovechamos.",
  },
  {
    category: "Dia de la Mujer",
    line: "El mundo se mueve porque mujeres como tu deciden no rendirse.",
  },
  {
    category: "Graduacion",
    line: "Nadie vio las noches que te costo. Yo si, y por eso hoy estoy tan orgulloso.",
  },
  {
    category: "Graduacion",
    line: "Lo lograste. Que nadie te quite nunca lo que aprendiste llegando hasta aqui.",
  },
  {
    category: "Graduacion",
    line: "Empieza lo bueno. Y ya demostraste que puedes con lo dificil.",
  },
  {
    category: "Condolencias",
    line: "No hay palabras para esto. Solo quiero que sepas que no estas solo.",
  },
  {
    category: "Condolencias",
    line: "Lo que se quiere de verdad no se va del todo. Se queda en quienes lo recuerdan.",
  },
  {
    category: "Condolencias",
    line: "Te acompano en silencio, que a veces es la unica forma honesta de acompanar.",
  },
];
