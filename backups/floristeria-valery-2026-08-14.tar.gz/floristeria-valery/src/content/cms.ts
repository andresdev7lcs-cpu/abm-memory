export type CmsFamilyKey =
  | "productos"
  | "categorias"
  | "ocasiones"
  | "campanas"
  | "faq"
  | "testimonios"
  | "politicas"
  | "eventos"
  | "empresas";

export type CmsRecordStatus = "scaffold" | "placeholder" | "ready";

export type CmsFamilyStateKey =
  | "con-contenido"
  | "sin-contenido"
  | "borrador"
  | "no-disponible"
  | "error";

export type CmsFamilyState = {
  key: CmsFamilyStateKey;
  label: string;
  description: string;
  tone: "success" | "warning" | "danger" | "accent" | "neutral";
};

export type CmsTemplateKind =
  | "catalogo"
  | "coleccion"
  | "intencion"
  | "activacion"
  | "soporte"
  | "social"
  | "legal"
  | "evento"
  | "corporativo";

export type CmsTemplateDefinition = {
  kind: CmsTemplateKind;
  primaryPanelTitle: string;
  primaryPanelDescription: string;
  secondaryPanelTitle: string;
  secondaryPanelDescription: string;
  emptyStateTitle: string;
  emptyStateDescription: string;
};

export type CmsRecord = {
  slug: string;
  title: string;
  summary: string;
  status: CmsRecordStatus;
  focus: string[];
  relatedFamilies: CmsFamilyKey[];
};

export type CmsFamilyDefinition = {
  key: CmsFamilyKey;
  path: `/${string}/`;
  title: string;
  cmsType: string;
  description: string;
  placeholderNote: string;
  template: CmsTemplateDefinition;
  states: CmsFamilyState[];
  fields: string[];
  relatedFamilies: CmsFamilyKey[];
  records: CmsRecord[];
};

const sharedFamilyStates: CmsFamilyState[] = [
  {
    key: "con-contenido",
    label: "Con contenido",
    description:
      "La plantilla ya puede renderizar contenido real publicado desde Sanity.",
    tone: "success",
  },
  {
    key: "sin-contenido",
    label: "Sin contenido",
    description:
      "La familia está lista, pero todavía no hay documentos publicados para mostrar.",
    tone: "warning",
  },
  {
    key: "borrador",
    label: "Borrador",
    description:
      "Hay registros de trabajo esperando revisión editorial.",
    tone: "accent",
  },
  {
    key: "no-disponible",
    label: "No disponible",
    description:
      "La ruta existe como estructura, pero el contenido todavía no debe activarse.",
    tone: "neutral",
  },
  {
    key: "error",
    label: "Error",
    description:
      "Fallback técnico para fallos de lectura, esquemas incompletos o datos inválidos.",
    tone: "danger",
  },
];

const families = {
  productos: {
    key: "productos",
    path: "/productos/",
    title: "Productos",
    cmsType: "product",
    description:
      "Base de fichas de producto conectadas al CMS con relaciones a categorias, ocasiones, campanas y testimonios.",
    placeholderNote:
      "Los valores comerciales siguen por confirmar hasta que el contenido final entre por CMS.",
    template: {
      kind: "catalogo",
      primaryPanelTitle: "Ficha de producto",
      primaryPanelDescription:
        "Imagenes, composicion, disponibilidad y CTA por WhatsApp para cada pieza.",
      secondaryPanelTitle: "Relaciones editoriales",
      secondaryPanelDescription:
        "Categoria, ocasion, campana y testimonios para sostener descubrimiento y SEO.",
      emptyStateTitle: "Producto sin publicar",
      emptyStateDescription:
        "Mostrar la base tecnica y mantener los campos comerciales por confirmar.",
    },
    states: sharedFamilyStates,
    fields: [
      "name",
      "slug",
      "category reference",
      "occasion references",
      "campaign references",
      "testimonial references",
      "price placeholder",
      "sizes",
      "composition",
      "colors",
      "images",
      "availability",
      "prepTime",
      "deliveryZones",
      "addOns",
      "whatsappCta",
      "seoTitle",
      "seoDescription",
    ],
    relatedFamilies: [
      "categorias",
      "ocasiones",
      "campanas",
      "testimonios",
    ],
    records: [
      {
        slug: "producto-base-floral",
        title: "Producto base floral",
        summary:
          "Plantilla de ficha para una pieza floral editable con WhatsApp, SEO y relaciones.",
        status: "scaffold",
        focus: [
          "category reference",
          "occasion references",
          "campaign references",
          "seo fields",
        ],
        relatedFamilies: [
          "categorias",
          "ocasiones",
          "campanas",
          "testimonios",
        ],
      },
      {
        slug: "arreglo-personalizable",
        title: "Arreglo personalizable",
        summary:
          "Ficha base para variaciones de tamano, disponibilidad y complementos.",
        status: "placeholder",
        focus: [
          "availability",
          "sizes",
          "add-ons",
          "delivery zones",
        ],
        relatedFamilies: ["categorias", "ocasiones", "campanas"],
      },
    ],
  },
  categorias: {
    key: "categorias",
    path: "/categorias/",
    title: "Categorias",
    cmsType: "category",
    description:
      "Base de agrupaciones de catalogo con relaciones a productos y ocasiones.",
    placeholderNote:
      "Las categorias existen como estructura editable, no como catalogo comercial definitivo.",
    template: {
      kind: "coleccion",
      primaryPanelTitle: "Navegacion de catalogo",
      primaryPanelDescription:
        "Agrupaciones para orientar descubrimiento, filtros y SEO sin inventar oferta final.",
      secondaryPanelTitle: "Destacados y cruces",
      secondaryPanelDescription:
        "Productos destacados y ocasiones relacionadas para enlazar contenidos del catalogo.",
      emptyStateTitle: "Categoria vacia",
      emptyStateDescription:
        "La estructura permanece visible mientras se espera contenido real del CMS.",
    },
    states: sharedFamilyStates,
    fields: [
      "name",
      "slug",
      "intro",
      "hero",
      "featuredProducts references",
      "relatedOccasions references",
      "seoTitle",
      "seoDescription",
    ],
    relatedFamilies: ["productos", "ocasiones"],
    records: [
      {
        slug: "categoria-base",
        title: "Categoria base",
        summary:
          "Agrupacion editable para navegar el catalogo desde el CMS.",
        status: "scaffold",
        focus: ["intro", "hero", "featured products", "seo"],
        relatedFamilies: ["productos", "ocasiones"],
      },
      {
        slug: "categoria-temporal",
        title: "Categoria temporal",
        summary:
          "Base para una familia estacional o por tipo de pedido.",
        status: "placeholder",
        focus: ["featured products", "related occasions"],
        relatedFamilies: ["productos", "campanas", "ocasiones"],
      },
    ],
  },
  ocasiones: {
    key: "ocasiones",
    path: "/ocasiones/",
    title: "Ocasiones",
    cmsType: "occasion",
    description:
      "Plantillas por intencion de compra con enlaces hacia productos y campanas.",
    placeholderNote:
      "Las ocasiones son estructura de contenido, no campañas reales ni oferta cerrada.",
    template: {
      kind: "intencion",
      primaryPanelTitle: "Contexto emocional",
      primaryPanelDescription:
        "La pagina presenta la necesidad, el tono y la seleccion de productos recomendada.",
      secondaryPanelTitle: "Cruces de contenido",
      secondaryPanelDescription:
        "Productos, campanas y FAQ que ayudan a resolver la intencion de compra.",
      emptyStateTitle: "Ocasion sin contenido",
      emptyStateDescription:
        "La estructura queda lista para cuando exista el copy definitivo de la ocasion.",
    },
    states: sharedFamilyStates,
    fields: [
      "name",
      "slug",
      "emotionalCopy",
      "hero",
      "featuredProducts references",
      "relatedCampaigns references",
      "seoTitle",
      "seoDescription",
    ],
    relatedFamilies: ["productos", "campanas", "faq"],
    records: [
      {
        slug: "cumpleanos",
        title: "Cumpleanos",
        summary:
          "Pagina base para una ocasion frecuente con contenido editable.",
        status: "scaffold",
        focus: ["emotionalCopy", "featured products", "related campaigns"],
        relatedFamilies: ["productos", "campanas", "faq"],
      },
      {
        slug: "condolencias",
        title: "Condolencias",
        summary:
          "Pagina sensible con estructura informativa y sin promesas comerciales.",
        status: "scaffold",
        focus: ["tone", "support guidance", "faq", "seo"],
        relatedFamilies: ["faq", "politicas", "productos"],
      },
    ],
  },
  campanas: {
    key: "campanas",
    path: "/campanas/",
    title: "Campanas",
    cmsType: "campaign",
    description:
      "Plantillas temporales y activables por fecha, listas para conectar con productos y ocasiones.",
    placeholderNote:
      "No hay campañas reales cargadas aun; la estructura queda lista para activacion futura.",
    template: {
      kind: "activacion",
      primaryPanelTitle: "Ventana temporal",
      primaryPanelDescription:
        "Landing activa por fecha con estado, CTA y productos destacados, sin contenido comercial final.",
      secondaryPanelTitle: "Cobertura de campaña",
      secondaryPanelDescription:
        "Categorias y ocasiones relacionadas para mantener coherencia editorial y SEO.",
      emptyStateTitle: "Campana sin activar",
      emptyStateDescription:
        "Los datos comerciales siguen bloqueados hasta recibir aprobacion real.",
    },
    states: sharedFamilyStates,
    fields: [
      "name",
      "slug",
      "startDate",
      "endDate",
      "hero",
      "cta",
      "status",
      "featuredProducts references",
      "relatedCategories references",
      "relatedOccasions references",
      "seoTitle",
      "seoDescription",
    ],
    relatedFamilies: ["productos", "categorias", "ocasiones"],
    records: [
      {
        slug: "temporada-base",
        title: "Temporada base",
        summary:
          "Base para una landing temporal activable por fecha.",
        status: "placeholder",
        focus: ["startDate", "endDate", "status", "cta"],
        relatedFamilies: ["productos", "categorias", "ocasiones"],
      },
      {
        slug: "campana-fecha-especial",
        title: "Campana fecha especial",
        summary:
          "Base para una campana estacional sin contenido real cargado.",
        status: "scaffold",
        focus: ["featured products", "related occasions", "seo"],
        relatedFamilies: ["productos", "ocasiones"],
      },
    ],
  },
  faq: {
    key: "faq",
    path: "/faq/",
    title: "FAQ",
    cmsType: "faq",
    description:
      "Preguntas frecuentes estructuradas para resolver dudas y objeciones sin depender de copy duro.",
    placeholderNote:
      "Las respuestas siguen siendo una base tecnica hasta que el contenido operativo y comercial se apruebe.",
    template: {
      kind: "soporte",
      primaryPanelTitle: "Pregunta y respuesta",
      primaryPanelDescription:
        "Bloques de apoyo para resolver dudas antes de compra sin inventar condiciones.",
      secondaryPanelTitle: "Objetos relacionados",
      secondaryPanelDescription:
        "Productos, categorias, ocasiones y politicas que contextualizan la respuesta.",
      emptyStateTitle: "FAQ sin publicar",
      emptyStateDescription:
        "Mantener la estructura lista mientras se redactan las respuestas oficiales.",
    },
    states: sharedFamilyStates,
    fields: [
      "question",
      "answer",
      "scope",
      "relatedProducts references",
      "relatedCategories references",
      "relatedOccasions references",
      "relatedCampaigns references",
    ],
    relatedFamilies: ["productos", "categorias", "ocasiones", "politicas"],
    records: [
      {
        slug: "pedido-basico",
        title: "Pedido basico",
        summary:
          "Respuesta estructural para dudas de compra y flujo de pedido.",
        status: "scaffold",
        focus: ["order flow", "scope", "support", "tracking"],
        relatedFamilies: ["productos", "categorias"],
      },
      {
        slug: "envio-y-entrega",
        title: "Envio y entrega",
        summary:
          "Pregunta de soporte para explicar la capa operativa sin inventar condiciones.",
        status: "placeholder",
        focus: ["delivery rules", "zones", "prep time", "support"],
        relatedFamilies: ["politicas", "productos"],
      },
    ],
  },
  testimonios: {
    key: "testimonios",
    path: "/testimonios/",
    title: "Testimonios",
    cmsType: "testimonial",
    description:
      "Pruebas sociales con procedencia verificable y relaciones a productos u ocasiones cuando existan.",
    placeholderNote:
      "Solo se deben cargar testimonios reales cuando la fuente este verificada.",
    template: {
      kind: "social",
      primaryPanelTitle: "Cita y procedencia",
      primaryPanelDescription:
        "La plantilla muestra procedencia, valoracion y comentario sin inventar prueba social.",
      secondaryPanelTitle: "Relaciones verificables",
      secondaryPanelDescription:
        "Vinculos a productos y ocasiones para asociar la opinion con una experiencia concreta.",
      emptyStateTitle: "Testimonio pendiente",
      emptyStateDescription:
        "No publicar texto social hasta contar con una fuente aprobada.",
    },
    states: sharedFamilyStates,
    fields: [
      "source",
      "name",
      "rating",
      "comment",
      "sourceUrl",
      "relatedProducts references",
      "relatedOccasions references",
    ],
    relatedFamilies: ["productos", "ocasiones", "faq"],
    records: [
      {
        slug: "testimonio-referencia",
        title: "Testimonio referencia",
        summary:
          "Base para una opinion verificada con fuente rastreable.",
        status: "placeholder",
        focus: ["source", "rating", "sourceUrl", "related products"],
        relatedFamilies: ["productos", "ocasiones"],
      },
      {
        slug: "testimonio-whatsapp",
        title: "Testimonio WhatsApp",
        summary:
          "Base para una referencia de WhatsApp que solo se activa si hay fuente aprobada.",
        status: "scaffold",
        focus: ["source", "comment", "verification", "seo"],
        relatedFamilies: ["faq", "productos"],
      },
    ],
  },
  politicas: {
    key: "politicas",
    path: "/politicas/",
    title: "Politicas",
    cmsType: "policyPage",
    description:
      "Paginas legales y operativas separadas por tema para mantener claridad y control editorial.",
    placeholderNote:
      "Las politicas quedan estructuradas, pero su texto final se completa con aprobacion real.",
    template: {
      kind: "legal",
      primaryPanelTitle: "Resumen y cuerpo legal",
      primaryPanelDescription:
        "Las paginas legales muestran una sintesis y el cuerpo completo sin copiar texto definitivo.",
      secondaryPanelTitle: "Referencias cruzadas",
      secondaryPanelDescription:
        "FAQ y productos relacionados para no dejar la politica aislada del resto del sitio.",
      emptyStateTitle: "Politica pendiente",
      emptyStateDescription:
        "El marco legal permanece como base tecnica hasta recibir revision definitiva.",
    },
    states: sharedFamilyStates,
    fields: [
      "name",
      "slug",
      "summary",
      "body",
      "policyType",
      "relatedFaq references",
      "relatedProducts references",
      "seoTitle",
      "seoDescription",
    ],
    relatedFamilies: ["faq", "productos", "eventos"],
    records: [
      {
        slug: "sustitucion",
        title: "Sustitucion",
        summary:
          "Pagina tecnica para reglas de sustitucion y consistencia de entrega.",
        status: "scaffold",
        focus: ["body", "faq", "support guidance"],
        relatedFamilies: ["faq", "productos"],
      },
      {
        slug: "privacidad",
        title: "Privacidad",
        summary:
          "Base legal para la politica de privacidad y tratamiento de datos.",
        status: "placeholder",
        focus: ["data handling", "consent", "seo"],
        relatedFamilies: ["faq"],
      },
    ],
  },
  eventos: {
    key: "eventos",
    path: "/eventos/",
    title: "Eventos",
    cmsType: "eventPage",
    description:
      "Plantillas para bodas, eventos corporativos y celebraciones con relaciones a productos y ocasiones.",
    placeholderNote:
      "Los eventos quedan listos como estructura; la oferta concreta sigue pendiente.",
    template: {
      kind: "evento",
      primaryPanelTitle: "Contexto y logistica",
      primaryPanelDescription:
        "La pagina de evento organiza la necesidad, el tipo de evento y las piezas sugeridas.",
      secondaryPanelTitle: "Productos y ocasiones",
      secondaryPanelDescription:
        "Relaciona composiciones, ocasiones y contexto empresarial cuando aplique.",
      emptyStateTitle: "Evento sin activar",
      emptyStateDescription:
        "La plantilla ya existe, pero la propuesta concreta sigue pendiente.",
    },
    states: sharedFamilyStates,
    fields: [
      "name",
      "slug",
      "summary",
      "hero",
      "eventType",
      "featuredProducts references",
      "relatedOccasions references",
      "seoTitle",
      "seoDescription",
    ],
    relatedFamilies: ["productos", "ocasiones", "empresas"],
    records: [
      {
        slug: "boda",
        title: "Boda",
        summary:
          "Base para una pagina de evento con enfoque en composicion y logistica.",
        status: "scaffold",
        focus: ["hero", "featured products", "related occasions"],
        relatedFamilies: ["productos", "ocasiones"],
      },
      {
        slug: "corporativo",
        title: "Corporativo",
        summary:
          "Base para un evento empresarial o activacion de marca.",
        status: "placeholder",
        focus: ["event type", "faq", "support"],
        relatedFamilies: ["empresas", "productos"],
      },
    ],
  },
  empresas: {
    key: "empresas",
    path: "/empresas/",
    title: "Empresas",
    cmsType: "companyPage",
    description:
      "Plantillas para alianzas, regalos corporativos y servicio a empresas sin cargar una oferta final.",
    placeholderNote:
      "La base corporativa queda preparada, pero los acuerdos y contactos se completan despues.",
    template: {
      kind: "corporativo",
      primaryPanelTitle: "Servicio corporativo",
      primaryPanelDescription:
        "Una plantilla para alianzas, regalos y pedidos B2B sin cargar contactos reales.",
      secondaryPanelTitle: "Escenarios de uso",
      secondaryPanelDescription:
        "Campanas y eventos relacionados para ordenar activaciones empresariales.",
      emptyStateTitle: "Pagina corporativa pendiente",
      emptyStateDescription:
        "La estructura queda visible mientras se definen acuerdos y responsables.",
    },
    states: sharedFamilyStates,
    fields: [
      "name",
      "slug",
      "summary",
      "hero",
      "serviceType",
      "featuredProducts references",
      "relatedCampaigns references",
      "seoTitle",
      "seoDescription",
    ],
    relatedFamilies: ["productos", "campanas", "eventos"],
    records: [
      {
        slug: "empresa-base",
        title: "Empresa base",
        summary:
          "Base para una pagina corporativa con servicios y relaciones.",
        status: "scaffold",
        focus: ["serviceType", "featured products", "seo"],
        relatedFamilies: ["productos", "campanas"],
      },
      {
        slug: "alianzas",
        title: "Alianzas",
        summary:
          "Base para acuerdos o colaboraciones empresariales.",
        status: "placeholder",
        focus: ["support", "campaign links", "contact flow"],
        relatedFamilies: ["campanas", "eventos"],
      },
    ],
  },
} as const satisfies Record<CmsFamilyKey, CmsFamilyDefinition>;

export const cmsFamilyOrder: CmsFamilyKey[] = [
  "productos",
  "categorias",
  "ocasiones",
  "campanas",
  "faq",
  "testimonios",
  "politicas",
  "eventos",
  "empresas",
];

export const cmsFamilies = families;

export const cmsIndexRoutes = cmsFamilyOrder.map((key) => ({
  path: cmsFamilies[key].path,
  label: cmsFamilies[key].title,
  description: cmsFamilies[key].description,
  category: "planned" as const,
}));

export function isCmsFamilyKey(value: string): value is CmsFamilyKey {
  return value in cmsFamilies;
}

export function getCmsFamily(key: CmsFamilyKey) {
  return cmsFamilies[key];
}

export function getCmsRecord(key: CmsFamilyKey, slug: string) {
  return cmsFamilies[key].records.find((record) => record.slug === slug);
}
