export type SiteSettings = {
  name: string;
  domain: string;
  canonicalUrl: string;
  whatsappNumber: string;
  hours: string;
  location: string;
  analytics: {
    ga4Id: string;
    gtmId: string;
    metaPixelId: string;
    searchConsoleVerified: boolean;
  };
};

export type ProductModel = {
  name: string;
  slug: string;
  category: string;
  occasions: string[];
  campaigns?: string[];
  testimonials?: string[];
  price?: number;
  sizes: string[];
  composition: string[];
  colors: string[];
  images: string[];
  availability: "available" | "sold_out" | "unavailable" | "draft";
  prepTime: string;
  deliveryZones: string[];
  addOns: string[];
  seoTitle: string;
  seoDescription: string;
  whatsappCta: string;
};

export type CategoryModel = {
  name: string;
  slug: string;
  intro: string;
  hero: string;
  featuredProducts?: string[];
  relatedOccasions?: string[];
  seoTitle: string;
  seoDescription: string;
};

export type OccasionModel = {
  name: string;
  slug: string;
  emotionalCopy: string;
  hero: string;
  products: string[];
  relatedCampaigns?: string[];
  seoTitle: string;
  seoDescription: string;
};

export type CampaignModel = {
  name: string;
  slug: string;
  startDate: string;
  endDate: string;
  hero: string;
  cta: string;
  status: "draft" | "scheduled" | "live";
  featuredProducts?: string[];
  relatedCategories?: string[];
  relatedOccasions?: string[];
};

export type TestimonialModel = {
  source: "Google" | "WhatsApp" | "Manual";
  name: string;
  rating: number;
  comment: string;
  sourceUrl?: string;
  relatedProducts?: string[];
  relatedOccasions?: string[];
};

export type FAQModel = {
  question: string;
  answer: string;
  scope: string[];
  relatedProducts?: string[];
  relatedCategories?: string[];
  relatedOccasions?: string[];
  relatedCampaigns?: string[];
};

export type LeadFormSubmissionModel = {
  type: string;
  name: string;
  contact: string;
  message: string;
  consent: boolean;
  status: "new" | "contacted" | "closed";
};

export type RedirectModel = {
  source: string;
  destination: string;
  code: 301;
  reason: string;
  active: boolean;
};

export type DeliveryRuleModel = {
  schedule: string;
  maxFee: string;
  zones: string[];
  exceptions: string[];
};

export type PolicyPageModel = {
  name: string;
  slug: string;
  summary: string;
  body: string;
  policyType: "sustitucion" | "privacidad" | "datos" | "terminos";
  relatedFaq?: string[];
  relatedProducts?: string[];
  seoTitle: string;
  seoDescription: string;
};

export type EventPageModel = {
  name: string;
  slug: string;
  summary: string;
  hero: string;
  eventType: "boda" | "corporativo" | "celebracion";
  featuredProducts?: string[];
  relatedOccasions?: string[];
  seoTitle: string;
  seoDescription: string;
};

export type CompanyPageModel = {
  name: string;
  slug: string;
  summary: string;
  hero: string;
  serviceType: "empresas" | "alianzas" | "regalos_corporativos";
  featuredProducts?: string[];
  relatedCampaigns?: string[];
  seoTitle: string;
  seoDescription: string;
};

export type B2BContactModel = {
  company: string;
  name: string;
  role: string;
  channel: string;
  notes: string;
  status: "pending" | "active" | "archived";
};

export type ContentModelName =
  | "SiteSettings"
  | "Product"
  | "Category"
  | "Occasion"
  | "Campaign"
  | "Testimonial"
  | "FAQ"
  | "LeadFormSubmission"
  | "Redirect"
  | "DeliveryRule"
  | "B2BContact"
  | "PolicyPage"
  | "EventPage"
  | "CompanyPage";
