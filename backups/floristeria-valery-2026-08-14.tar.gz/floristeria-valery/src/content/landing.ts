import { siteConfig } from "@/content/site";
import { buildWhatsAppHref } from "@/components/base/whatsapp-cta";

/**
 * Contenido de la landing publica.
 * El diseno original fijaba el numero; aqui se prefiere la variable de entorno
 * y se cae al numero del diseno cuando no esta configurada.
 */
export const landingWhatsAppNumber =
  siteConfig.whatsappNumber || "+573176353320";

export const landingWhatsAppMessage =
  "Hola Flores Valery, quisiera ayuda para elegir el arreglo perfecto.";

export const landingWhatsAppHref = buildWhatsAppHref(
  landingWhatsAppNumber,
  landingWhatsAppMessage,
);

export const heroVideoUrl =
  "https://sujmhbbnhffmdfqlzidl.supabase.co/storage/v1/object/public/Files%20Web/Hero_video_FV.mp4";

export const heroPoster =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1920 1080'%3E%3Crect fill='%23101014' width='1920' height='1080'/%3E%3C/svg%3E";

export const heroCopy = {
  h1: "Cada flor es elegida para decir lo que las palabras no pueden.",
  h2: "No entregamos flores. Creamos momentos que perduran.",
  cta: "Elijamos juntos",
} as const;

export type LandingFaq = {
  q: string;
  a: string;
};

export const landingFaqs: LandingFaq[] = [
  {
    q: "Como hago un pedido por WhatsApp?",
    a: "Escribenos indicando la ocasion y el estilo que buscas. Te acompanamos hasta confirmar disponibilidad, precio y entrega.",
  },
  {
    q: "Me ayudan a elegir si no se que enviar?",
    a: "Por supuesto. Cuentanos la ocasion y la persona, y te sugerimos el arreglo perfecto.",
  },
  {
    q: "Puedo personalizar colores, flores o tamano?",
    a: "Si, cada ramo puede ajustarse a tu gusto y presupuesto.",
  },
  {
    q: "Con cuanta anticipacion debo pedir?",
    a: "Idealmente 24 horas antes. Tambien atendemos pedidos urgentes segun disponibilidad.",
  },
  {
    q: "Que zonas cubren?",
    a: "Entregamos en Neiva, Huila y alrededores.",
  },
  {
    q: "Como puedo pagar?",
    a: "Aceptamos transferencia, Nequi y efectivo contra entrega.",
  },
  {
    q: "Hacen arreglos de duelo o condolencia?",
    a: "Si, creamos arreglos discretos y elegantes para momentos de despedida.",
  },
  {
    q: "Puedo incluir una tarjeta con mensaje?",
    a: "Si, puedes escribir un mensaje personal y lo incluimos sin costo adicional.",
  },
];

export const typedQuestions = [
  "Como hago un pedido por WhatsApp?",
  "Puedo personalizar mi ramo?",
  "Hacen entregas el mismo dia?",
  "Que zonas cubren?",
];

export type LandingReview = {
  name: string;
  text: string;
};

export const landingReviews: LandingReview[] = [
  {
    name: "Maria C.",
    text: "Pedi a las 10 y a la 1 ya estaba entregado. Mi mama lloro.",
  },
  {
    name: "Laura M.",
    text: "No tenia idea que mandar. Me preguntaron por ella y acertaron.",
  },
  {
    name: "Camila R.",
    text: "Me mandaron foto antes de salir. Eso me dio mucha confianza.",
  },
  {
    name: "Andres P.",
    text: "Estoy fuera del pais y resolvieron todo por WhatsApp.",
  },
  {
    name: "Diana R.",
    text: "El arreglo de condolencias fue discreto y muy digno. Gracias.",
  },
];

/** Pasos del proceso, en el orden en que los vive el cliente. */
export const valueBlocks = [
  {
    title: "Nos cuentas la ocasion",
    body: "Un mensaje basta. Si no sabes que enviar, te ayudamos a decidir.",
  },
  {
    title: "Lo armamos ese mismo dia",
    body: "Nada de flores de ayer. Se arma fresco y te mandamos foto antes de salir.",
  },
  {
    title: "Llega cuando tiene que llegar",
    body: "Entregamos en Neiva y alrededores. Pagas cuando lo recibe.",
  },
];

export const businessHours = [
  "Lunes a viernes 8am a 6pm",
  "Sabados 8am a 3pm",
  "Domingos y Festivos: Cerrado",
];
