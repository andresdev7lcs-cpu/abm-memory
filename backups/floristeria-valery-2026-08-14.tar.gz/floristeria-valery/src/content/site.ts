import { cmsIndexRoutes } from "@/content/cms";

export const siteEnvironment =
  process.env.NEXT_PUBLIC_SITE_ENV ?? process.env.VERCEL_ENV ?? "staging";

export const isProductionSite = siteEnvironment === "production";

export const siteConfig = {
  name: "Floristeria Valery",
  displayName: "Floristeria Valery",
  domain: "floristeriaenneiva.com",
  canonicalDomain: "https://floristeriaenneiva.com",
  whatsappNumber: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "",
  stageName: "Technical staging",
  stageUrl: "http://localhost:3000",
  launchStatus: "Phase 5 in progress",
} as const;

export type RouteEntry = {
  path: string;
  label: string;
  description: string;
  category: "preserved" | "hub" | "planned";
};

export const preservedRoutes: RouteEntry[] = [
  {
    path: "/bouquets/",
    label: "Bouquets",
    description: "URL indexada preservada.",
    category: "preserved",
  },
  {
    path: "/rosas/",
    label: "Rosas",
    description: "URL indexada preservada.",
    category: "preserved",
  },
  {
    path: "/topiarios/",
    label: "Topiarios",
    description: "URL indexada preservada.",
    category: "preserved",
  },
  {
    path: "/exoticos/",
    label: "Exoticos",
    description: "URL indexada preservada.",
    category: "preserved",
  },
  {
    path: "/fruteros/",
    label: "Fruteros",
    description: "URL indexada preservada.",
    category: "preserved",
  },
];

export const plannedRoutes: RouteEntry[] = [
  {
    path: "/comprar-flores/",
    label: "Comprar flores",
    description: "Hub de descubrimiento sin mover las URLs preservadas.",
    category: "hub",
  },
  ...cmsIndexRoutes,
  {
    path: "/comprar-flores/cajas-florales/",
    label: "Cajas florales",
    description: "Ruta prevista.",
    category: "planned",
  },
  {
    path: "/comprar-flores/ramos-buchones/",
    label: "Ramos buchones",
    description: "Ruta prevista.",
    category: "planned",
  },
  {
    path: "/comprar-flores/tropicales/",
    label: "Tropicales",
    description: "Ruta prevista.",
    category: "planned",
  },
  {
    path: "/comprar-flores/condolencias/",
    label: "Condolencias",
    description: "Ruta prevista.",
    category: "planned",
  },
  {
    path: "/comprar-flores/personalizados/",
    label: "Personalizados",
    description: "Ruta prevista.",
    category: "planned",
  },
  {
    path: "/ocasiones/",
    label: "Ocasiones",
    description: "Hub de intención futura.",
    category: "planned",
  },
  {
    path: "/entrega-hoy/",
    label: "Entrega hoy",
    description: "Ruta de urgencia futura.",
    category: "planned",
  },
  {
    path: "/comprar-desde-lejos/",
    label: "Comprar desde lejos",
    description: "Ruta remota futura.",
    category: "planned",
  },
  {
    path: "/contacto/",
    label: "Contacto",
    description: "Formulario base de consulta.",
    category: "planned",
  },
];

export const phaseSummary = [
  {
    phase: "Fase 0",
    status: "completed",
    detail: "Preparacion, accesos, inventario de URLs y pendientes comerciales.",
  },
  {
    phase: "Fase 1",
    status: "completed",
    detail: "Base tecnica, estructura de rutas, CMS, staging y analitica.",
  },
  {
    phase: "Fase 2",
    status: "completed",
    detail: "CMS estructural, plantillas conectadas y contenido base.",
  },
  {
    phase: "Fase 3",
    status: "completed",
    detail: "Catalogo funcional, fichas de producto y WhatsApp asistido.",
  },
  {
    phase: "Fase 4",
    status: "completed",
    detail: "SEO tecnico, redirecciones y QA.",
  },
  {
    phase: "Fase 5",
    status: "in progress",
    detail: "Pre-lanzamiento, integraciones y staging externo protegido.",
  },
  {
    phase: "No ahora",
    status: "blocked by scope",
    detail: "Carga comercial definitiva, campañas y lanzamiento.",
  },
];

export const baseComponents = [
  "SiteShell",
  "SectionHeading",
  "StatusPill",
  "InfoCard",
  "RouteShell",
  "RouteGrid",
  "TechTable",
  "WhatsAppCTA",
  "CmsFamilyPage",
  "PhaseCard",
  "ModelCard",
  "CatalogBrowser",
  "CatalogProductCard",
  "CatalogProductDetail",
  "FlowPage",
  "LeadCaptureForm",
];

export const cmsModels = [
  {
    name: "SiteSettings",
    purpose: "Ajustes globales, horarios, NAP y enlaces.",
  },
  {
    name: "Product",
    purpose: "Ficha de producto editable.",
  },
  {
    name: "Category",
    purpose: "Agrupacion de catalogo.",
  },
  {
    name: "Occasion",
    purpose: "Pagina por intencion.",
  },
  {
    name: "Campaign",
    purpose: "Landing temporal.",
  },
  {
    name: "Testimonial",
    purpose: "Resenas reales.",
  },
  {
    name: "FAQ",
    purpose: "Objeciones y respuestas.",
  },
  {
    name: "LeadFormSubmission",
    purpose: "Registro de formularios.",
  },
  {
    name: "Redirect",
    purpose: "Mapa de redirecciones 301.",
  },
  {
    name: "DeliveryRule",
    purpose: "Reglas operativas.",
  },
  {
    name: "B2BContact",
    purpose: "Contactos comerciales.",
  },
  {
    name: "PolicyPage",
    purpose: "Pagina legal u operativa por tema.",
  },
  {
    name: "EventPage",
    purpose: "Pagina de evento o celebracion.",
  },
  {
    name: "CompanyPage",
    purpose: "Pagina corporativa o de alianzas.",
  },
  {
    name: "CatalogProduct",
    purpose: "Ficha de producto conectada al catalogo.",
  },
  {
    name: "CatalogFlow",
    purpose: "Flujo asistido por WhatsApp.",
  },
  {
    name: "LeadCaptureForm",
    purpose: "Formulario minimo sin checkout.",
  },
];

export const pendingItems = [
  "Top ventas",
  "Ticket promedio",
  "Capacidad diaria",
  "Contactos B2B",
  "Precios finales",
];

export const accessChecklist = [
  "Repositorio remoto externo",
  "Hosting y staging externos",
  "Sanity projectId y dataset",
  "GA4 / GTM / Search Console / Meta Pixel",
  "WhatsApp number",
  "Google Business Profile",
  "Logo editable o captura origen",
  "Inventario de URLs actual",
  "Banco de imagenes",
  "Politicas operativas reales",
];
