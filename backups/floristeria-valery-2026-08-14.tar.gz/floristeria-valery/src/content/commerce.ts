import { cmsFamilies } from "@/content/cms";

export type CatalogAvailabilityState =
  | "available"
  | "sold_out"
  | "unavailable"
  | "draft"
  | "error";

export type CatalogTaxon = {
  slug: string;
  title: string;
};

export type CatalogProduct = {
  slug: string;
  title: string;
  summary: string;
  category: CatalogTaxon;
  occasions: CatalogTaxon[];
  availability: CatalogAvailabilityState;
  price: number | null;
  priceLabel: string;
  sizes: string[];
  composition: string[];
  colors: string[];
  prepTime: string;
  deliveryZones: string[];
  addOns: string[];
  whatsappMessage: string;
  seoTitle: string;
  seoDescription: string;
  featured: boolean;
};

export type CatalogFilterState = {
  category?: string;
  occasion?: string;
  availability?: string;
  price?: string;
};

export type CatalogFlowKey =
  | "entrega-hoy"
  | "comprar-desde-lejos"
  | "condolencias"
  | "personalizados"
  | "eventos"
  | "empresas"
  | "contacto";

export type CatalogFlowField = {
  name: string;
  label: string;
  type: "text" | "email" | "tel" | "date" | "textarea";
  placeholder: string;
  required?: boolean;
  helper?: string;
};

export type CatalogFlowDefinition = {
  key: CatalogFlowKey;
  path: `/${string}/`;
  title: string;
  summary: string;
  whatsappMessage: string;
  note: string;
  formTitle: string;
  formDescription: string;
  submitLabel: string;
  fields: CatalogFlowField[];
};

const categoryOptions: CatalogTaxon[] = cmsFamilies.categorias.records.map(
  (record) => ({
    slug: record.slug,
    title: record.title,
  }),
);

const occasionOptions: CatalogTaxon[] = cmsFamilies.ocasiones.records.map(
  (record) => ({
    slug: record.slug,
    title: record.title,
  }),
);

export const catalogTaxonomy = {
  categories: categoryOptions,
  occasions: occasionOptions,
};

export const catalogAvailabilityStates: Array<{
  key: CatalogAvailabilityState;
  label: string;
  description: string;
  tone: "success" | "warning" | "danger" | "accent" | "neutral";
}> = [
  {
    key: "available",
    label: "Disponible",
    description: "El producto puede mostrarse como activo en el catalogo.",
    tone: "success",
  },
  {
    key: "sold_out",
    label: "Agotado",
    description: "La ficha existe, pero no debe invitar a compra inmediata.",
    tone: "warning",
  },
  {
    key: "unavailable",
    label: "No disponible",
    description: "El documento existe solo como referencia tecnica.",
    tone: "accent",
  },
  {
    key: "draft",
    label: "Borrador",
    description: "Aun no se publica ni se expone como catalogo final.",
    tone: "neutral",
  },
  {
    key: "error",
    label: "Error",
    description: "Fallback tecnico para problemas de carga o validacion.",
    tone: "danger",
  },
];

export const catalogPriceOptions = [
  {
    key: "all",
    label: "Todos los rangos",
  },
  {
    key: "without-price",
    label: "Sin precio final",
  },
  {
    key: "with-price",
    label: "Con precio publicado",
  },
];

export const catalogProducts: CatalogProduct[] = [
  {
    slug: "producto-base-floral",
    title: "Producto base floral",
    summary:
      "Base de ficha de producto para revisar filtros, relaciones y mensajes de WhatsApp sin cargar catalogo definitivo.",
    category: categoryOptions[0],
    occasions: [occasionOptions[0]],
    availability: "available",
    price: null,
    priceLabel: "Valor por confirmar",
    sizes: ["Tamanos por definir"],
    composition: ["Composicion por confirmar"],
    colors: ["Color por confirmar"],
    prepTime: "Tiempo de preparacion por confirmar",
    deliveryZones: ["Cobertura por definir"],
    addOns: ["Complementos por revisar"],
    whatsappMessage:
      "Hola, quiero consultar el Producto base floral. Necesito confirmacion de disponibilidad y detalles del flujo.",
    seoTitle: "Producto base floral | Floristeria Valery",
    seoDescription:
      "Ficha tecnica base para validar la estructura de catalogo y el flujo de WhatsApp.",
    featured: true,
  },
  {
    slug: "arreglo-personalizable",
    title: "Arreglo personalizable",
    summary:
      "Ficha editable pensada para personalizacion tecnica, con valor por confirmar y disponibilidad controlada.",
    category: categoryOptions[1],
    occasions: [occasionOptions[1]],
    availability: "sold_out",
    price: null,
    priceLabel: "Valor por confirmar",
    sizes: ["Tamanos por definir"],
    composition: ["Composicion por confirmar"],
    colors: ["Color por confirmar"],
    prepTime: "Tiempo de preparacion por confirmar",
    deliveryZones: ["Cobertura por definir"],
    addOns: ["Complementos por revisar"],
    whatsappMessage:
      "Hola, quiero revisar el Arreglo personalizable. Quiero saber si vuelve a estar disponible y que datos faltan para cerrarlo.",
    seoTitle: "Arreglo personalizable | Floristeria Valery",
    seoDescription:
      "Ficha base para personalizaciones y disponibilidad revisable.",
    featured: true,
  },
  {
    slug: "pieza-logistica-base",
    title: "Pieza logistica base",
    summary:
      "Base tecnica para probar el estado no disponible, el control editorial y los enlaces de categoria.",
    category: categoryOptions[0],
    occasions: [occasionOptions[0], occasionOptions[1]],
    availability: "unavailable",
    price: null,
    priceLabel: "Valor por confirmar",
    sizes: ["Tamanos por definir"],
    composition: ["Composicion por confirmar"],
    colors: ["Color por confirmar"],
    prepTime: "Tiempo de preparacion por confirmar",
    deliveryZones: ["Cobertura por definir"],
    addOns: ["Complementos por revisar"],
    whatsappMessage:
      "Hola, quiero revisar la Pieza logistica base. Necesito saber si el flujo debe mantenerse como no disponible.",
    seoTitle: "Pieza logistica base | Floristeria Valery",
    seoDescription:
      "Ficha tecnica base para revisar el estado no disponible.",
    featured: false,
  },
  {
    slug: "producto-borrador-revision",
    title: "Producto borrador revision",
    summary:
      "Registro de trabajo para validar el estado borrador antes de pasar a contenido real.",
    category: categoryOptions[1],
    occasions: [occasionOptions[0]],
    availability: "draft",
    price: null,
    priceLabel: "Valor por confirmar",
    sizes: ["Tamanos por definir"],
    composition: ["Composicion por confirmar"],
    colors: ["Color por confirmar"],
    prepTime: "Tiempo de preparacion por confirmar",
    deliveryZones: ["Cobertura por definir"],
    addOns: ["Complementos por revisar"],
    whatsappMessage:
      "Hola, quiero revisar el Producto borrador revision. Solo busco confirmar el estado de la base tecnica.",
    seoTitle: "Producto borrador revision | Floristeria Valery",
    seoDescription:
      "Ficha borrador para revisar estados y validacion editorial.",
    featured: false,
  },
];

export const catalogFlowDefinitions: Record<CatalogFlowKey, CatalogFlowDefinition> =
  {
    "entrega-hoy": {
      key: "entrega-hoy",
      path: "/entrega-hoy/",
      title: "Entrega hoy",
      summary:
        "Flujo urgente con mensajes preparados para confirmar cobertura y tiempos sin activar pagos.",
      whatsappMessage:
        "Hola, necesito revisar la opcion de entrega hoy. Quiero confirmar cobertura, tiempos y si el producto elegido puede salir en el mismo dia.",
      note:
        "El flujo esta listo para revisar urgencias, pero no promete disponibilidad final ni compra cerrada.",
      formTitle: "Solicitud de entrega hoy",
      formDescription:
        "Completa el minimo necesario para derivar la consulta a WhatsApp con contexto.",
      submitLabel: "Abrir WhatsApp con urgencia",
      fields: [
        {
          name: "name",
          label: "Nombre",
          type: "text",
          placeholder: "Tu nombre",
          required: true,
        },
        {
          name: "contact",
          label: "Contacto",
          type: "tel",
          placeholder: "Telefono o WhatsApp",
          required: true,
        },
        {
          name: "message",
          label: "Detalle",
          type: "textarea",
          placeholder: "Escribe la direccion, ventana horaria o duda principal",
          required: true,
        },
      ],
    },
    "comprar-desde-lejos": {
      key: "comprar-desde-lejos",
      path: "/comprar-desde-lejos/",
      title: "Comprar desde lejos",
      summary:
        "Flujo remoto para pedir desde otra ciudad o pais con contexto para la entrega.",
      whatsappMessage:
        "Hola, quiero comprar desde lejos. Necesito confirmar como funciona el pedido, la entrega y que datos debo dejar listos.",
      note:
        "El flujo remoto mantiene el mismo tono asistido y no activa pagos ni checkout.",
      formTitle: "Solicitud de compra remota",
      formDescription:
        "Captura la informacion minima para orientar la conversacion por WhatsApp.",
      submitLabel: "Abrir WhatsApp remoto",
      fields: [
        {
          name: "name",
          label: "Nombre",
          type: "text",
          placeholder: "Tu nombre",
          required: true,
        },
        {
          name: "contact",
          label: "Contacto",
          type: "email",
          placeholder: "Correo o WhatsApp",
          required: true,
        },
        {
          name: "message",
          label: "Mensaje",
          type: "textarea",
          placeholder: "Indica ciudad de origen, fecha y dudas",
          required: true,
        },
      ],
    },
    condolencias: {
      key: "condolencias",
      path: "/comprar-flores/condolencias/",
      title: "Condolencias",
      summary:
        "Flujo sensible con mensajes contextuales y sin promesas comerciales cerradas.",
      whatsappMessage:
        "Hola, necesito apoyo con una entrega de condolencias. Quiero revisar el tono, el producto y los datos necesarios para avanzar con respeto.",
      note:
        "El flujo mantiene lenguaje cuidadoso y evita inventar politicas o inventario.",
      formTitle: "Solicitud por condolencias",
      formDescription:
        "Deja la informacion minima y te llevas una derivacion contextual a WhatsApp.",
      submitLabel: "Abrir WhatsApp por condolencias",
      fields: [
        {
          name: "name",
          label: "Nombre",
          type: "text",
          placeholder: "Tu nombre",
          required: true,
        },
        {
          name: "contact",
          label: "Contacto",
          type: "tel",
          placeholder: "Telefono",
          required: true,
        },
        {
          name: "message",
          label: "Mensaje",
          type: "textarea",
          placeholder: "Escribe el contexto o la fecha requerida",
          required: true,
        },
      ],
    },
    personalizados: {
      key: "personalizados",
      path: "/comprar-flores/personalizados/",
      title: "Personalizados",
      summary:
        "Formulario minimo para piezas personalizadas sin inventar catalogo definitivo.",
      whatsappMessage:
        "Hola, quiero solicitar una pieza personalizada. Necesito revisar opciones, tiempos y que informacion debo compartir.",
      note:
        "La ruta no activa pagos ni configurador comercial final; solo levanta contexto.",
      formTitle: "Solicitud personalizada",
      formDescription:
        "Comparte la idea general y la derivacion se prepara para WhatsApp.",
      submitLabel: "Abrir WhatsApp personalizado",
      fields: [
        {
          name: "name",
          label: "Nombre",
          type: "text",
          placeholder: "Tu nombre",
          required: true,
        },
        {
          name: "contact",
          label: "Contacto",
          type: "tel",
          placeholder: "Telefono",
          required: true,
        },
        {
          name: "message",
          label: "Idea",
          type: "textarea",
          placeholder: "Describe la ocasion, colores o referencias",
          required: true,
        },
      ],
    },
    eventos: {
      key: "eventos",
      path: "/eventos/",
      title: "Eventos",
      summary:
        "Formulario minimo para eventos y celebraciones conectado a la plantilla CMS.",
      whatsappMessage:
        "Hola, quiero revisar un evento. Necesito confirmar fecha, alcance y si el flujo puede adaptarse al tipo de celebracion.",
      note:
        "Este formulario vive sobre la plantilla de eventos ya creada en CMS.",
      formTitle: "Solicitud de evento",
      formDescription:
        "Usa este formulario minimo para enviar una consulta con contexto editorial.",
      submitLabel: "Abrir WhatsApp de eventos",
      fields: [
        {
          name: "name",
          label: "Nombre",
          type: "text",
          placeholder: "Tu nombre",
          required: true,
        },
        {
          name: "contact",
          label: "Contacto",
          type: "email",
          placeholder: "Correo o WhatsApp",
          required: true,
        },
        {
          name: "message",
          label: "Evento",
          type: "textarea",
          placeholder: "Tipo de evento, fecha y necesidades",
          required: true,
        },
      ],
    },
    empresas: {
      key: "empresas",
      path: "/empresas/",
      title: "Empresas",
      summary:
        "Formulario minimo para consultas corporativas sobre regalos y alianzas.",
      whatsappMessage:
        "Hola, quiero revisar una solicitud para empresa. Necesito confirmar el tipo de necesidad, fecha y la mejor forma de seguimiento.",
      note:
        "La plantilla corporativa permanece editable y sin contactos reales cargados.",
      formTitle: "Solicitud corporativa",
      formDescription:
        "Comparte el contexto minimo para un seguimiento por WhatsApp.",
      submitLabel: "Abrir WhatsApp corporativo",
      fields: [
        {
          name: "name",
          label: "Nombre",
          type: "text",
          placeholder: "Tu nombre",
          required: true,
        },
        {
          name: "contact",
          label: "Contacto",
          type: "email",
          placeholder: "Correo o WhatsApp",
          required: true,
        },
        {
          name: "message",
          label: "Necesidad",
          type: "textarea",
          placeholder: "Describe el pedido, alianza o activacion",
          required: true,
        },
      ],
    },
    contacto: {
      key: "contacto",
      path: "/contacto/",
      title: "Contacto",
      summary:
        "Formulario base para consultas generales, sin activar un CRM ni un checkout.",
      whatsappMessage:
        "Hola, quiero hacer una consulta general sobre Floristeria Valery.",
      note:
        "Este formulario solo encola la consulta para WhatsApp y deja un fallback visible.",
      formTitle: "Formulario de contacto",
      formDescription:
        "Comparte la consulta y el sistema te prepara el mensaje de WhatsApp.",
      submitLabel: "Abrir WhatsApp de contacto",
      fields: [
        {
          name: "name",
          label: "Nombre",
          type: "text",
          placeholder: "Tu nombre",
          required: true,
        },
        {
          name: "contact",
          label: "Contacto",
          type: "tel",
          placeholder: "Telefono o correo",
          required: true,
        },
        {
          name: "message",
          label: "Mensaje",
          type: "textarea",
          placeholder: "Escribe tu consulta",
          required: true,
        },
      ],
    },
  };

export function buildCatalogMessage(
  product: Pick<
    CatalogProduct,
    "title" | "category" | "availability"
  >,
  extraMessage?: string,
) {
  const lines = [
    `Hola, quiero revisar ${product.title}.`,
    `Categoria: ${product.category.title}.`,
    `Estado: ${product.availability}.`,
    extraMessage?.trim(),
  ].filter(Boolean);

  return lines.join("\n");
}

export function buildFlowMessage(
  flowKey: CatalogFlowKey,
  extraMessage?: string,
) {
  const flow = catalogFlowDefinitions[flowKey];

  return [flow.whatsappMessage, extraMessage?.trim()].filter(Boolean).join("\n");
}
