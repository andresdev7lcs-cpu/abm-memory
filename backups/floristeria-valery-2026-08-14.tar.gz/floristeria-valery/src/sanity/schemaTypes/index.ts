import { defineField, defineType } from "sanity";

const slugField = () =>
  defineField({
    name: "slug",
    title: "Slug",
    type: "slug",
    options: {
      source: "name",
      maxLength: 96,
    },
  });

const referenceArrayField = (name: string, title: string, types: string[]) =>
  defineField({
    name,
    title,
    type: "array",
    of: [
      {
        type: "reference",
        to: types.map((type) => ({ type })),
      },
    ],
  });

const seoFields = [
  defineField({
    name: "seoTitle",
    title: "SEO title",
    type: "string",
  }),
  defineField({
    name: "seoDescription",
    title: "SEO description",
    type: "text",
    rows: 3,
  }),
];

export const schemaTypes = [
  defineType({
    name: "siteSettings",
    title: "Site settings",
    type: "document",
    fields: [
      defineField({ name: "name", title: "Name", type: "string" }),
      defineField({ name: "domain", title: "Domain", type: "string" }),
      defineField({
        name: "canonicalUrl",
        title: "Canonical URL",
        type: "url",
      }),
      defineField({
        name: "whatsappNumber",
        title: "WhatsApp number",
        type: "string",
      }),
      defineField({ name: "hours", title: "Hours", type: "string" }),
      defineField({ name: "location", title: "Location", type: "string" }),
      defineField({
        name: "analytics",
        title: "Analytics",
        type: "object",
        fields: [
          defineField({ name: "ga4Id", title: "GA4 ID", type: "string" }),
          defineField({ name: "gtmId", title: "GTM ID", type: "string" }),
          defineField({
            name: "metaPixelId",
            title: "Meta Pixel ID",
            type: "string",
          }),
          defineField({
            name: "searchConsoleVerified",
            title: "Search Console verified",
            type: "boolean",
          }),
        ],
      }),
    ],
  }),
  defineType({
    name: "product",
    title: "Product",
    type: "document",
    fields: [
      defineField({ name: "name", title: "Name", type: "string" }),
      slugField(),
      defineField({
        name: "category",
        title: "Category",
        type: "reference",
        to: [{ type: "category" }],
      }),
      referenceArrayField("occasions", "Occasions", ["occasion"]),
      referenceArrayField("campaigns", "Campaigns", ["campaign"]),
      referenceArrayField("testimonials", "Testimonials", ["testimonial"]),
      defineField({ name: "price", title: "Price", type: "number" }),
      defineField({
        name: "sizes",
        title: "Sizes",
        type: "array",
        of: [{ type: "string" }],
      }),
      defineField({
        name: "composition",
        title: "Composition",
        type: "array",
        of: [{ type: "string" }],
      }),
      defineField({
        name: "colors",
        title: "Colors",
        type: "array",
        of: [{ type: "string" }],
      }),
      defineField({
        name: "images",
        title: "Images",
        type: "array",
        of: [{ type: "image" }],
      }),
      defineField({
        name: "availability",
        title: "Availability",
        type: "string",
        options: {
          list: [
            { title: "Available", value: "available" },
            { title: "Sold out", value: "sold_out" },
            { title: "Unavailable", value: "unavailable" },
            { title: "Draft", value: "draft" },
          ],
        },
      }),
      defineField({ name: "prepTime", title: "Prep time", type: "string" }),
      defineField({
        name: "deliveryZones",
        title: "Delivery zones",
        type: "array",
        of: [{ type: "string" }],
      }),
      defineField({
        name: "addOns",
        title: "Add-ons",
        type: "array",
        of: [{ type: "string" }],
      }),
      defineField({
        name: "whatsappCta",
        title: "WhatsApp CTA",
        type: "string",
      }),
      ...seoFields,
    ],
  }),
  defineType({
    name: "category",
    title: "Category",
    type: "document",
    fields: [
      defineField({ name: "name", title: "Name", type: "string" }),
      slugField(),
      defineField({ name: "intro", title: "Intro", type: "text", rows: 3 }),
      defineField({ name: "hero", title: "Hero", type: "text", rows: 4 }),
      referenceArrayField("featuredProducts", "Featured products", [
        "product",
      ]),
      referenceArrayField("relatedOccasions", "Related occasions", [
        "occasion",
      ]),
      ...seoFields,
    ],
  }),
  defineType({
    name: "occasion",
    title: "Occasion",
    type: "document",
    fields: [
      defineField({ name: "name", title: "Name", type: "string" }),
      slugField(),
      defineField({
        name: "emotionalCopy",
        title: "Emotional copy",
        type: "text",
        rows: 3,
      }),
      defineField({ name: "hero", title: "Hero", type: "text", rows: 4 }),
      referenceArrayField("featuredProducts", "Featured products", [
        "product",
      ]),
      referenceArrayField("relatedCampaigns", "Related campaigns", [
        "campaign",
      ]),
      ...seoFields,
    ],
  }),
  defineType({
    name: "campaign",
    title: "Campaign",
    type: "document",
    fields: [
      defineField({ name: "name", title: "Name", type: "string" }),
      slugField(),
      defineField({ name: "startDate", title: "Start date", type: "date" }),
      defineField({ name: "endDate", title: "End date", type: "date" }),
      defineField({ name: "hero", title: "Hero", type: "text", rows: 4 }),
      defineField({ name: "cta", title: "CTA", type: "string" }),
      defineField({
        name: "status",
        title: "Status",
        type: "string",
        options: {
          list: [
            { title: "Draft", value: "draft" },
            { title: "Scheduled", value: "scheduled" },
            { title: "Live", value: "live" },
          ],
        },
      }),
      referenceArrayField("featuredProducts", "Featured products", [
        "product",
      ]),
      referenceArrayField("relatedCategories", "Related categories", [
        "category",
      ]),
      referenceArrayField("relatedOccasions", "Related occasions", [
        "occasion",
      ]),
      ...seoFields,
    ],
  }),
  defineType({
    name: "testimonial",
    title: "Testimonial",
    type: "document",
    fields: [
      defineField({
        name: "source",
        title: "Source",
        type: "string",
        options: {
          list: [
            { title: "Google", value: "Google" },
            { title: "WhatsApp", value: "WhatsApp" },
            { title: "Manual", value: "Manual" },
          ],
        },
      }),
      defineField({ name: "name", title: "Name", type: "string" }),
      slugField(),
      defineField({ name: "rating", title: "Rating", type: "number" }),
      defineField({ name: "comment", title: "Comment", type: "text", rows: 4 }),
      defineField({ name: "sourceUrl", title: "Source URL", type: "url" }),
      referenceArrayField("relatedProducts", "Related products", ["product"]),
      referenceArrayField("relatedOccasions", "Related occasions", [
        "occasion",
      ]),
    ],
  }),
  defineType({
    name: "faq",
    title: "FAQ",
    type: "document",
    fields: [
      defineField({ name: "question", title: "Question", type: "string" }),
      slugField(),
      defineField({ name: "answer", title: "Answer", type: "text", rows: 4 }),
      defineField({
        name: "scope",
        title: "Scope",
        type: "array",
        of: [{ type: "string" }],
      }),
      referenceArrayField("relatedProducts", "Related products", ["product"]),
      referenceArrayField("relatedCategories", "Related categories", [
        "category",
      ]),
      referenceArrayField("relatedOccasions", "Related occasions", [
        "occasion",
      ]),
      referenceArrayField("relatedCampaigns", "Related campaigns", [
        "campaign",
      ]),
    ],
  }),
  defineType({
    name: "policyPage",
    title: "Policy page",
    type: "document",
    fields: [
      defineField({ name: "name", title: "Name", type: "string" }),
      slugField(),
      defineField({ name: "summary", title: "Summary", type: "text", rows: 3 }),
      defineField({ name: "body", title: "Body", type: "text", rows: 8 }),
      defineField({
        name: "policyType",
        title: "Policy type",
        type: "string",
        options: {
          list: [
            { title: "Sustitucion", value: "sustitucion" },
            { title: "Privacidad", value: "privacidad" },
            { title: "Datos", value: "datos" },
            { title: "Terminos", value: "terminos" },
          ],
        },
      }),
      referenceArrayField("relatedFaq", "Related FAQ", ["faq"]),
      referenceArrayField("relatedProducts", "Related products", ["product"]),
      ...seoFields,
    ],
  }),
  defineType({
    name: "eventPage",
    title: "Event page",
    type: "document",
    fields: [
      defineField({ name: "name", title: "Name", type: "string" }),
      slugField(),
      defineField({ name: "summary", title: "Summary", type: "text", rows: 3 }),
      defineField({ name: "hero", title: "Hero", type: "text", rows: 4 }),
      defineField({
        name: "eventType",
        title: "Event type",
        type: "string",
        options: {
          list: [
            { title: "Boda", value: "boda" },
            { title: "Corporativo", value: "corporativo" },
            { title: "Celebracion", value: "celebracion" },
          ],
        },
      }),
      referenceArrayField("featuredProducts", "Featured products", [
        "product",
      ]),
      referenceArrayField("relatedOccasions", "Related occasions", [
        "occasion",
      ]),
      ...seoFields,
    ],
  }),
  defineType({
    name: "companyPage",
    title: "Company page",
    type: "document",
    fields: [
      defineField({ name: "name", title: "Name", type: "string" }),
      slugField(),
      defineField({ name: "summary", title: "Summary", type: "text", rows: 3 }),
      defineField({ name: "hero", title: "Hero", type: "text", rows: 4 }),
      defineField({
        name: "serviceType",
        title: "Service type",
        type: "string",
        options: {
          list: [
            { title: "Empresas", value: "empresas" },
            { title: "Alianzas", value: "alianzas" },
            {
              title: "Regalos corporativos",
              value: "regalos_corporativos",
            },
          ],
        },
      }),
      referenceArrayField("featuredProducts", "Featured products", [
        "product",
      ]),
      referenceArrayField("relatedCampaigns", "Related campaigns", [
        "campaign",
      ]),
      ...seoFields,
    ],
  }),
  defineType({
    name: "leadFormSubmission",
    title: "Lead form submission",
    type: "document",
    fields: [
      defineField({ name: "type", title: "Type", type: "string" }),
      defineField({ name: "name", title: "Name", type: "string" }),
      defineField({ name: "contact", title: "Contact", type: "string" }),
      defineField({ name: "message", title: "Message", type: "text", rows: 4 }),
      defineField({ name: "consent", title: "Consent", type: "boolean" }),
      defineField({
        name: "status",
        title: "Status",
        type: "string",
        options: {
          list: [
            { title: "New", value: "new" },
            { title: "Contacted", value: "contacted" },
            { title: "Closed", value: "closed" },
          ],
        },
      }),
    ],
  }),
  defineType({
    name: "redirect",
    title: "Redirect",
    type: "document",
    fields: [
      defineField({ name: "source", title: "Source", type: "string" }),
      defineField({ name: "destination", title: "Destination", type: "string" }),
      defineField({
        name: "code",
        title: "Code",
        type: "number",
        initialValue: 301,
      }),
      defineField({ name: "reason", title: "Reason", type: "string" }),
      defineField({ name: "active", title: "Active", type: "boolean" }),
    ],
  }),
  defineType({
    name: "deliveryRule",
    title: "Delivery rule",
    type: "document",
    fields: [
      defineField({ name: "schedule", title: "Schedule", type: "string" }),
      defineField({ name: "maxFee", title: "Max fee", type: "string" }),
      defineField({
        name: "zones",
        title: "Zones",
        type: "array",
        of: [{ type: "string" }],
      }),
      defineField({
        name: "exceptions",
        title: "Exceptions",
        type: "array",
        of: [{ type: "string" }],
      }),
    ],
  }),
  defineType({
    name: "b2bContact",
    title: "B2B contact",
    type: "document",
    fields: [
      defineField({ name: "company", title: "Company", type: "string" }),
      defineField({ name: "name", title: "Name", type: "string" }),
      defineField({ name: "role", title: "Role", type: "string" }),
      defineField({ name: "channel", title: "Channel", type: "string" }),
      defineField({ name: "notes", title: "Notes", type: "text", rows: 3 }),
      defineField({
        name: "status",
        title: "Status",
        type: "string",
        options: {
          list: [
            { title: "Pending", value: "pending" },
            { title: "Active", value: "active" },
            { title: "Archived", value: "archived" },
          ],
        },
      }),
    ],
  }),
];
