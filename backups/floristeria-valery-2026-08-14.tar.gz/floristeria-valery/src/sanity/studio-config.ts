import { structureTool } from "sanity/structure";
import { defineConfig } from "sanity";
import { schemaTypes } from "./schemaTypes";

const projectId = process.env.NEXT_PUBLIC_SANITY_PROJECT_ID || "change-me";
const dataset = process.env.NEXT_PUBLIC_SANITY_DATASET || "production";

const config = defineConfig({
  name: "floristeria-valery",
  title: "Floristeria Valery",
  projectId,
  dataset,
  basePath: "/studio",
  plugins: [structureTool()],
  schema: {
    types: schemaTypes,
  },
});

export default config;
