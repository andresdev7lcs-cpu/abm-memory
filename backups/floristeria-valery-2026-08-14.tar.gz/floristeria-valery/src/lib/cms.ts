import { cmsFamilies, cmsFamilyOrder, type CmsFamilyDefinition, type CmsFamilyKey, type CmsRecord } from "@/content/cms";
import { sanityClient, sanityIsConfigured } from "@/lib/sanity.client";

type CmsFetchResult = {
  family: CmsFamilyDefinition;
  records: CmsRecord[];
  source: "scaffold" | "sanity";
};

const queries: Record<
  CmsFamilyKey,
  {
    list: string;
    detail: string;
    titleField: string;
    summaryField: string;
  }
> = {
  productos: {
    list: `*[_type == "product"] | order(coalesce(_updatedAt, _createdAt) desc) {
      "slug": slug.current,
      "title": coalesce(name, "Producto sin nombre"),
      "summary": coalesce(seoDescription, whatsappCta, "Ficha base"),
      "status": select(
        availability == "available" => "ready",
        availability == "sold_out" => "placeholder",
        availability == "unavailable" => "scaffold",
        availability == "draft" => "placeholder",
        true => "placeholder"
      ),
      "focus": [
        "category reference",
        "occasion references",
        "campaign references",
        "seo fields"
      ],
      "relatedFamilies": [
        "categorias",
        "ocasiones",
        "campanas",
        "testimonios"
      ]
    }`,
    detail: `*[_type == "product" && slug.current == $slug][0] {
      "slug": slug.current,
      "title": coalesce(name, "Producto sin nombre"),
      "summary": coalesce(seoDescription, whatsappCta, "Ficha base"),
      "status": select(
        availability == "available" => "ready",
        availability == "sold_out" => "placeholder",
        availability == "unavailable" => "scaffold",
        availability == "draft" => "placeholder",
        true => "placeholder"
      ),
      "focus": [
        "category reference",
        "occasion references",
        "campaign references",
        "seo fields"
      ],
      "relatedFamilies": [
        "categorias",
        "ocasiones",
        "campanas",
        "testimonios"
      ]
    }`,
    titleField: "name",
    summaryField: "seoDescription",
  },
  categorias: {
    list: `*[_type == "category"] | order(coalesce(_updatedAt, _createdAt) desc) {
      "slug": slug.current,
      "title": coalesce(name, "Categoria sin nombre"),
      "summary": coalesce(intro, seoDescription, "Categoria base"),
      "status": "scaffold",
      "focus": [
        "intro",
        "hero",
        "featured products",
        "seo"
      ],
      "relatedFamilies": [
        "productos",
        "ocasiones"
      ]
    }`,
    detail: `*[_type == "category" && slug.current == $slug][0] {
      "slug": slug.current,
      "title": coalesce(name, "Categoria sin nombre"),
      "summary": coalesce(intro, seoDescription, "Categoria base"),
      "status": "scaffold",
      "focus": [
        "intro",
        "hero",
        "featured products",
        "seo"
      ],
      "relatedFamilies": [
        "productos",
        "ocasiones"
      ]
    }`,
    titleField: "name",
    summaryField: "intro",
  },
  ocasiones: {
    list: `*[_type == "occasion"] | order(coalesce(_updatedAt, _createdAt) desc) {
      "slug": slug.current,
      "title": coalesce(name, "Ocasión sin nombre"),
      "summary": coalesce(emotionalCopy, seoDescription, "Ocasión base"),
      "status": "scaffold",
      "focus": [
        "emotionalCopy",
        "featured products",
        "related campaigns",
        "seo"
      ],
      "relatedFamilies": [
        "productos",
        "campanas",
        "faq"
      ]
    }`,
    detail: `*[_type == "occasion" && slug.current == $slug][0] {
      "slug": slug.current,
      "title": coalesce(name, "Ocasión sin nombre"),
      "summary": coalesce(emotionalCopy, seoDescription, "Ocasión base"),
      "status": "scaffold",
      "focus": [
        "emotionalCopy",
        "featured products",
        "related campaigns",
        "seo"
      ],
      "relatedFamilies": [
        "productos",
        "campanas",
        "faq"
      ]
    }`,
    titleField: "name",
    summaryField: "emotionalCopy",
  },
  campanas: {
    list: `*[_type == "campaign"] | order(coalesce(_updatedAt, _createdAt) desc) {
      "slug": slug.current,
      "title": coalesce(name, "Campana sin nombre"),
      "summary": coalesce(hero, cta, "Campana base"),
      "status": select(
        status == "live" => "ready",
        status == "scheduled" => "placeholder",
        status == "draft" => "scaffold",
        true => "placeholder"
      ),
      "focus": [
        "startDate",
        "endDate",
        "status",
        "cta"
      ],
      "relatedFamilies": [
        "productos",
        "categorias",
        "ocasiones"
      ]
    }`,
    detail: `*[_type == "campaign" && slug.current == $slug][0] {
      "slug": slug.current,
      "title": coalesce(name, "Campana sin nombre"),
      "summary": coalesce(hero, cta, "Campana base"),
      "status": select(
        status == "live" => "ready",
        status == "scheduled" => "placeholder",
        status == "draft" => "scaffold",
        true => "placeholder"
      ),
      "focus": [
        "startDate",
        "endDate",
        "status",
        "cta"
      ],
      "relatedFamilies": [
        "productos",
        "categorias",
        "ocasiones"
      ]
    }`,
    titleField: "name",
    summaryField: "hero",
  },
  faq: {
    list: `*[_type == "faq"] | order(coalesce(_updatedAt, _createdAt) desc) {
      "slug": slug.current,
      "title": coalesce(question, "FAQ sin pregunta"),
      "summary": coalesce(answer, "Respuesta por confirmar"),
      "status": "scaffold",
      "focus": [
        "question",
        "answer",
        "scope",
        "related families"
      ],
      "relatedFamilies": [
        "productos",
        "categorias",
        "ocasiones",
        "politicas"
      ]
    }`,
    detail: `*[_type == "faq" && slug.current == $slug][0] {
      "slug": slug.current,
      "title": coalesce(question, "FAQ sin pregunta"),
      "summary": coalesce(answer, "Respuesta por confirmar"),
      "status": "scaffold",
      "focus": [
        "question",
        "answer",
        "scope",
        "related families"
      ],
      "relatedFamilies": [
        "productos",
        "categorias",
        "ocasiones",
        "politicas"
      ]
    }`,
    titleField: "question",
    summaryField: "answer",
  },
  testimonios: {
    list: `*[_type == "testimonial"] | order(coalesce(_updatedAt, _createdAt) desc) {
      "slug": slug.current,
      "title": coalesce(name, "Testimonio sin nombre"),
      "summary": coalesce(comment, "Testimonio por confirmar"),
      "status": "scaffold",
      "focus": [
        "source",
        "rating",
        "sourceUrl",
        "related products"
      ],
      "relatedFamilies": [
        "productos",
        "ocasiones"
      ]
    }`,
    detail: `*[_type == "testimonial" && slug.current == $slug][0] {
      "slug": slug.current,
      "title": coalesce(name, "Testimonio sin nombre"),
      "summary": coalesce(comment, "Testimonio por confirmar"),
      "status": "scaffold",
      "focus": [
        "source",
        "rating",
        "sourceUrl",
        "related products"
      ],
      "relatedFamilies": [
        "productos",
        "ocasiones"
      ]
    }`,
    titleField: "name",
    summaryField: "comment",
  },
  politicas: {
    list: `*[_type == "policyPage"] | order(coalesce(_updatedAt, _createdAt) desc) {
      "slug": slug.current,
      "title": coalesce(name, "Politica sin nombre"),
      "summary": coalesce(summary, body, "Politica por confirmar"),
      "status": "scaffold",
      "focus": [
        "body",
        "policyType",
        "relatedFaq",
        "seo"
      ],
      "relatedFamilies": [
        "faq",
        "productos",
        "eventos"
      ]
    }`,
    detail: `*[_type == "policyPage" && slug.current == $slug][0] {
      "slug": slug.current,
      "title": coalesce(name, "Politica sin nombre"),
      "summary": coalesce(summary, body, "Politica por confirmar"),
      "status": "scaffold",
      "focus": [
        "body",
        "policyType",
        "relatedFaq",
        "seo"
      ],
      "relatedFamilies": [
        "faq",
        "productos",
        "eventos"
      ]
    }`,
    titleField: "name",
    summaryField: "summary",
  },
  eventos: {
    list: `*[_type == "eventPage"] | order(coalesce(_updatedAt, _createdAt) desc) {
      "slug": slug.current,
      "title": coalesce(name, "Evento sin nombre"),
      "summary": coalesce(summary, hero, "Evento por confirmar"),
      "status": "scaffold",
      "focus": [
        "hero",
        "eventType",
        "featuredProducts",
        "relatedOccasions"
      ],
      "relatedFamilies": [
        "productos",
        "ocasiones",
        "empresas"
      ]
    }`,
    detail: `*[_type == "eventPage" && slug.current == $slug][0] {
      "slug": slug.current,
      "title": coalesce(name, "Evento sin nombre"),
      "summary": coalesce(summary, hero, "Evento por confirmar"),
      "status": "scaffold",
      "focus": [
        "hero",
        "eventType",
        "featuredProducts",
        "relatedOccasions"
      ],
      "relatedFamilies": [
        "productos",
        "ocasiones",
        "empresas"
      ]
    }`,
    titleField: "name",
    summaryField: "summary",
  },
  empresas: {
    list: `*[_type == "companyPage"] | order(coalesce(_updatedAt, _createdAt) desc) {
      "slug": slug.current,
      "title": coalesce(name, "Empresa sin nombre"),
      "summary": coalesce(summary, hero, "Pagina corporativa por confirmar"),
      "status": "scaffold",
      "focus": [
        "hero",
        "serviceType",
        "featuredProducts",
        "relatedCampaigns"
      ],
      "relatedFamilies": [
        "productos",
        "campanas",
        "eventos"
      ]
    }`,
    detail: `*[_type == "companyPage" && slug.current == $slug][0] {
      "slug": slug.current,
      "title": coalesce(name, "Empresa sin nombre"),
      "summary": coalesce(summary, hero, "Pagina corporativa por confirmar"),
      "status": "scaffold",
      "focus": [
        "hero",
        "serviceType",
        "featuredProducts",
        "relatedCampaigns"
      ],
      "relatedFamilies": [
        "productos",
        "campanas",
        "eventos"
      ]
    }`,
    titleField: "name",
    summaryField: "summary",
  },
};

function coerceFamilyRecord(record: CmsRecord): CmsRecord {
  return {
    ...record,
    relatedFamilies: record.relatedFamilies,
    focus: record.focus,
  };
}

export function getCmsFamilyOrder() {
  return cmsFamilyOrder;
}

export function getCmsIndexParams() {
  return cmsFamilyOrder.map((section) => ({ section }));
}

export function getCmsDetailParams() {
  return cmsFamilyOrder.flatMap((section) =>
    cmsFamilies[section].records.map((record) => ({
      section,
      slug: record.slug,
    })),
  );
}

export async function getCmsFamilyPage(section: CmsFamilyKey): Promise<CmsFetchResult> {
  const family = cmsFamilies[section];

  if (!sanityIsConfigured) {
    return {
      family,
      records: family.records.map(coerceFamilyRecord),
      source: "scaffold",
    };
  }

  try {
    const response = await sanityClient.fetch<CmsRecord[]>(queries[section].list);
    const records = response.length > 0 ? response : family.records;

    return {
      family,
      records: records.map((record) => ({
        slug: record.slug,
        title: record.title,
        summary: record.summary,
        status: record.status,
        focus: record.focus,
        relatedFamilies: record.relatedFamilies,
      })),
      source: "sanity",
    };
  } catch {
    return {
      family,
      records: family.records.map(coerceFamilyRecord),
      source: "scaffold",
    };
  }
}

export async function getCmsRecordPage(
  section: CmsFamilyKey,
  slug: string,
): Promise<CmsFetchResult & { record: CmsRecord | null }> {
  const family = cmsFamilies[section];

  if (!sanityIsConfigured) {
    return {
      family,
      records: family.records.map(coerceFamilyRecord),
      source: "scaffold",
      record: family.records.find((entry) => entry.slug === slug) ?? null,
    };
  }

  try {
    const record = await sanityClient.fetch<CmsRecord | null>(
      queries[section].detail,
      { slug },
    );

    if (!record) {
      return {
        family,
        records: family.records.map(coerceFamilyRecord),
        source: "scaffold",
        record: null,
      };
    }

    return {
      family,
      records: family.records.map(coerceFamilyRecord),
      source: "sanity",
      record,
    };
  } catch {
    return {
      family,
      records: family.records.map(coerceFamilyRecord),
      source: "scaffold",
      record: family.records.find((entry) => entry.slug === slug) ?? null,
    };
  }
}

export function getCmsQueryMetadata(section: CmsFamilyKey) {
  return queries[section];
}
