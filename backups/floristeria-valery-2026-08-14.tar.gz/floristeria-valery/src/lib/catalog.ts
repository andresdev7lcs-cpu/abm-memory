import {
  buildCatalogMessage,
  catalogFlowDefinitions,
  catalogAvailabilityStates,
  catalogProducts,
  catalogTaxonomy,
  type CatalogFilterState,
  type CatalogProduct,
  type CatalogTaxon,
  type CatalogAvailabilityState,
  type CatalogFlowKey,
} from "@/content/commerce";
import { sanityClient, sanityIsConfigured } from "@/lib/sanity.client";

type SanityTaxon = {
  slug: string;
  title: string;
};

type SanityCatalogProduct = {
  slug: string;
  title: string;
  summary: string;
  category?: SanityTaxon | null;
  occasions?: SanityTaxon[] | null;
  availability?: string | null;
  price?: number | null;
  sizes?: string[] | null;
  composition?: string[] | null;
  colors?: string[] | null;
  prepTime?: string | null;
  deliveryZones?: string[] | null;
  addOns?: string[] | null;
  whatsappMessage?: string | null;
  seoTitle?: string | null;
  seoDescription?: string | null;
  imagesCount?: number | null;
};

export type CatalogPageData = {
  source: "scaffold" | "sanity";
  products: CatalogProduct[];
  filters: {
    categories: CatalogTaxon[];
    occasions: CatalogTaxon[];
    availability: CatalogAvailabilityOption[];
    price: CatalogPriceFilterOption[];
  };
  activeFilters: CatalogFilterState;
  featuredProducts: CatalogProduct[];
  visibleProducts: CatalogProduct[];
  hasProducts: boolean;
};

export type CatalogAvailabilityOption = {
  key: CatalogAvailabilityState;
  label: string;
  description: string;
  tone: "success" | "warning" | "danger" | "accent" | "neutral";
};

export type CatalogPriceFilterOption = {
  key: "all" | "without-price" | "with-price";
  label: string;
  description: string;
};

export const catalogPriceFilterStates: CatalogPriceFilterOption[] = [
  {
    key: "all",
    label: "Todos los rangos",
    description: "Muestra cualquier ficha disponible en base tecnica o CMS.",
  },
  {
    key: "without-price",
    label: "Sin precio final",
    description: "Filtra fichas donde el precio sigue por confirmar.",
  },
  {
    key: "with-price",
    label: "Con precio publicado",
    description: "Solo muestra fichas que ya tengan precio cargado.",
  },
] as const;

function sanitizeTaxon(value: unknown, fallback: CatalogTaxon): CatalogTaxon {
  if (
    value &&
    typeof value === "object" &&
    "slug" in value &&
    "title" in value &&
    typeof (value as { slug?: unknown }).slug === "string" &&
    typeof (value as { title?: unknown }).title === "string"
  ) {
    return value as CatalogTaxon;
  }

  return fallback;
}

function mapAvailability(value: string | null | undefined): CatalogAvailabilityState {
  switch (value) {
    case "available":
      return "available";
    case "sold_out":
    case "limited":
      return "sold_out";
    case "unavailable":
      return "unavailable";
    case "draft":
      return "draft";
    default:
      return "error";
  }
}

function coerceCatalogProduct(
  product: CatalogProduct,
  featured = false,
): CatalogProduct {
  return {
    ...product,
    featured,
  };
}

function normalizeSanityProduct(
  product: SanityCatalogProduct,
  index: number,
): CatalogProduct {
  const category = sanitizeTaxon(product.category, catalogTaxonomy.categories[0]);
  const occasions =
    product.occasions?.map((occasion) =>
      sanitizeTaxon(occasion, catalogTaxonomy.occasions[0]),
    ) ?? [];

  return {
    slug: product.slug,
    title: product.title,
    summary: product.summary,
    category,
    occasions,
    availability: mapAvailability(product.availability),
    price: typeof product.price === "number" ? product.price : null,
    priceLabel:
      typeof product.price === "number" ? `$${product.price}` : "Valor por confirmar",
    sizes: product.sizes ?? ["Tamanos por definir"],
    composition: product.composition ?? ["Composicion por confirmar"],
    colors: product.colors ?? ["Color por confirmar"],
    prepTime: product.prepTime ?? "Tiempo de preparacion por confirmar",
    deliveryZones: product.deliveryZones ?? ["Cobertura por definir"],
    addOns: product.addOns ?? ["Complementos por revisar"],
    whatsappMessage:
      product.whatsappMessage ??
      buildCatalogMessage(
        {
          title: product.title,
          category,
          availability: mapAvailability(product.availability),
        },
        "Mensaje generado desde Sanity.",
      ),
    seoTitle: product.seoTitle ?? product.title,
    seoDescription: product.seoDescription ?? product.summary,
    featured: index < 2,
  };
}

function normalizeScaffoldProducts() {
  return catalogProducts.map((product) => coerceCatalogProduct(product, product.featured));
}

function filterCatalogProducts(
  products: CatalogProduct[],
  activeFilters: CatalogFilterState,
) {
  return products.filter((product) => {
    const matchesCategory = activeFilters.category
      ? product.category.slug === activeFilters.category
      : true;
    const matchesOccasion = activeFilters.occasion
      ? product.occasions.some((occasion) => occasion.slug === activeFilters.occasion)
      : true;
    const matchesAvailability = activeFilters.availability
      ? product.availability === activeFilters.availability
      : true;
    const matchesPrice =
      activeFilters.price === "with-price"
        ? product.price !== null
        : activeFilters.price === "without-price"
          ? product.price === null
          : true;

    return (
      matchesCategory &&
      matchesOccasion &&
      matchesAvailability &&
      matchesPrice
    );
  });
}

function normalizeFilterState(filters: CatalogFilterState): CatalogFilterState {
  const normalizeValue = (value?: string) =>
    !value || value === "all" ? undefined : value;

  return {
    category: normalizeValue(filters.category),
    occasion: normalizeValue(filters.occasion),
    availability: normalizeValue(filters.availability),
    price: normalizeValue(filters.price),
  };
}

const catalogQuery = `*[_type == "product"] | order(coalesce(_updatedAt, _createdAt) desc) {
  "slug": slug.current,
  "title": coalesce(name, "Producto sin nombre"),
  "summary": coalesce(seoDescription, whatsappCta, "Ficha tecnica base"),
  "category": category->{
    "slug": slug.current,
    "title": coalesce(name, "Categoria sin nombre")
  },
  "occasions": occasions[]->{
    "slug": slug.current,
    "title": coalesce(name, "Ocasión sin nombre")
  },
  "availability": availability,
  "price": price,
  "sizes": coalesce(sizes, []),
  "composition": coalesce(composition, []),
  "colors": coalesce(colors, []),
  "prepTime": coalesce(prepTime, "Tiempo de preparacion por confirmar"),
  "deliveryZones": coalesce(deliveryZones, []),
  "addOns": coalesce(addOns, []),
  "whatsappMessage": coalesce(whatsappCta, "Hola, quiero revisar este producto."),
  "seoTitle": coalesce(seoTitle, name),
  "seoDescription": coalesce(seoDescription, whatsappCta, "Ficha tecnica base"),
  "imagesCount": count(images)
}`;

const catalogDetailQuery = `*[_type == "product" && slug.current == $slug][0] {
  "slug": slug.current,
  "title": coalesce(name, "Producto sin nombre"),
  "summary": coalesce(seoDescription, whatsappCta, "Ficha tecnica base"),
  "category": category->{
    "slug": slug.current,
    "title": coalesce(name, "Categoria sin nombre")
  },
  "occasions": occasions[]->{
    "slug": slug.current,
    "title": coalesce(name, "Ocasión sin nombre")
  },
  "availability": availability,
  "price": price,
  "sizes": coalesce(sizes, []),
  "composition": coalesce(composition, []),
  "colors": coalesce(colors, []),
  "prepTime": coalesce(prepTime, "Tiempo de preparacion por confirmar"),
  "deliveryZones": coalesce(deliveryZones, []),
  "addOns": coalesce(addOns, []),
  "whatsappMessage": coalesce(whatsappCta, "Hola, quiero revisar este producto."),
  "seoTitle": coalesce(seoTitle, name),
  "seoDescription": coalesce(seoDescription, whatsappCta, "Ficha tecnica base"),
  "imagesCount": count(images)
}`;

function getFallbackPageData(activeFilters: CatalogFilterState): CatalogPageData {
  const products = normalizeScaffoldProducts();
  const visibleProducts = filterCatalogProducts(products, activeFilters);

  return {
    source: "scaffold",
    products,
    filters: {
      categories: catalogTaxonomy.categories,
      occasions: catalogTaxonomy.occasions,
      availability: catalogAvailabilityStates,
      price: catalogPriceFilterStates,
    },
    activeFilters,
    featuredProducts: products.filter((product) => product.featured),
    visibleProducts,
    hasProducts: products.length > 0,
  };
}

export async function getCatalogPageData(
  filters: CatalogFilterState,
): Promise<CatalogPageData> {
  const activeFilters = normalizeFilterState(filters);

  if (!sanityIsConfigured) {
    return getFallbackPageData(activeFilters);
  }

  try {
    const response = await sanityClient.fetch<SanityCatalogProduct[]>(catalogQuery);

    if (!response.length) {
      return getFallbackPageData(activeFilters);
    }

    const products = response.map((product, index) =>
      normalizeSanityProduct(product, index),
    );
    const visibleProducts = filterCatalogProducts(products, activeFilters);

    return {
      source: "sanity",
      products,
      filters: {
        categories: catalogTaxonomy.categories,
        occasions: catalogTaxonomy.occasions,
        availability: catalogAvailabilityStates,
        price: catalogPriceFilterStates,
      },
      activeFilters,
      featuredProducts: products.filter((product) => product.featured),
      visibleProducts,
      hasProducts: true,
    };
  } catch {
    return getFallbackPageData(activeFilters);
  }
}

export async function getCatalogProductPage(slug: string) {
  const fallbackProducts = normalizeScaffoldProducts();
  const fallback = fallbackProducts.find((product) => product.slug === slug) ?? null;

  if (!sanityIsConfigured) {
    return {
      source: "scaffold" as const,
      product: fallback,
      relatedProducts: fallbackProducts.filter((product) => product.slug !== slug),
    };
  }

  try {
    const response = await sanityClient.fetch<SanityCatalogProduct | null>(
      catalogDetailQuery,
      { slug },
    );

    if (!response) {
      return {
        source: "scaffold" as const,
        product: fallback,
        relatedProducts: fallbackProducts.filter((product) => product.slug !== slug),
      };
    }

    const product = normalizeSanityProduct(response, 0);

    return {
      source: "sanity" as const,
      product,
      relatedProducts: fallbackProducts.filter((entry) => entry.slug !== slug),
    };
  } catch {
    return {
      source: "scaffold" as const,
      product: fallback,
      relatedProducts: fallbackProducts.filter((product) => product.slug !== slug),
    };
  }
}

export function getCatalogStaticParams() {
  return normalizeScaffoldProducts().map((product) => ({
    slug: product.slug,
  }));
}

export function getCatalogFlowDefinition(key: CatalogFlowKey) {
  return catalogFlowDefinitions[key];
}

export function getCatalogFlowKeys() {
  return Object.keys(catalogFlowDefinitions) as CatalogFlowKey[];
}
