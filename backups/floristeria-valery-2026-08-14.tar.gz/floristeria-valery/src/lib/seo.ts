import type { Metadata } from "next";
import { siteConfig, isProductionSite } from "@/content/site";

type SeoOptions = {
  title: string;
  description: string;
  path: string;
  indexable?: boolean;
};

export function buildPageMetadata({
  title,
  description,
  path,
  indexable = true,
}: SeoOptions): Metadata {
  const canonical = `${siteConfig.canonicalDomain}${path}`;

  return {
    title,
    description,
    alternates: {
      canonical,
    },
    openGraph: {
      title,
      description,
      url: canonical,
      siteName: siteConfig.displayName,
      locale: "es_CO",
      type: "website",
    },
    robots: isProductionSite
      ? {
          index: indexable,
          follow: indexable,
          nocache: !indexable,
        }
      : {
          index: false,
          follow: false,
          nocache: true,
        },
  };
}

