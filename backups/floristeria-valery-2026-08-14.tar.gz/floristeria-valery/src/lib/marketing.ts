import { siteConfig } from "@/content/site";

const trimmedValue = (value: string | undefined) => value?.trim() ?? "";

export const marketingConfig = {
  siteUrl: process.env.NEXT_PUBLIC_SITE_URL ?? siteConfig.canonicalDomain,
  ga4Id: trimmedValue(process.env.NEXT_PUBLIC_GA4_ID),
  gtmId: trimmedValue(process.env.NEXT_PUBLIC_GTM_ID),
  metaPixelId: trimmedValue(process.env.NEXT_PUBLIC_META_PIXEL_ID),
  searchConsoleVerification: trimmedValue(
    process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION,
  ),
};

export function hasMarketingIntegrations() {
  return Boolean(
    marketingConfig.ga4Id ||
      marketingConfig.gtmId ||
      marketingConfig.metaPixelId ||
      marketingConfig.searchConsoleVerification,
  );
}
