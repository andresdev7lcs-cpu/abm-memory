import type { Metadata } from "next";
import { Bodoni_Moda, Manrope } from "next/font/google";
import { isProductionSite, siteConfig } from "@/content/site";
import { marketingConfig } from "@/lib/marketing";
import { SiteAnalytics } from "@/components/marketing/site-analytics";
import "./globals.css";

/**
 * Didone italiana (Parma): alto contraste y eje optico que afina los trazos
 * en tamanos grandes — el caracter de la referencia de marca.
 */
const bodoni = Bodoni_Moda({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  style: ["normal", "italic"],
  display: "swap",
  variable: "--font-display-serif",
});

const manrope = Manrope({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
  variable: "--font-manrope",
});

export const metadata: Metadata = {
  metadataBase: new URL("https://floristeriaenneiva.com"),
  title: {
    default: "Floristeria Valery",
    template: "%s | Floristeria Valery",
  },
  description: "Base tecnica, CMS y staging para Floristeria Valery.",
  robots: isProductionSite
    ? {
        index: true,
        follow: true,
      }
    : {
        index: false,
        follow: false,
        nocache: true,
      },
  alternates: {
    canonical: siteConfig.canonicalDomain,
  },
  openGraph: {
    title: "Floristeria Valery",
    description: "Base tecnica, CMS y staging para Floristeria Valery.",
    url: "https://floristeriaenneiva.com",
    siteName: "Floristeria Valery",
    locale: "es_CO",
    type: "website",
  },
  verification: marketingConfig.searchConsoleVerification
    ? {
        google: marketingConfig.searchConsoleVerification,
      }
    : undefined,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="es"
      className={`h-full antialiased ${bodoni.variable} ${manrope.variable}`}
    >
      <body className="min-h-full flex flex-col">
        <SiteAnalytics />
        {children}
      </body>
    </html>
  );
}
