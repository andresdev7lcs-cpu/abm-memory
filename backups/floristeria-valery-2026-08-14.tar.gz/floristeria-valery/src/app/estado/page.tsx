import type { Metadata } from "next";
import Link from "next/link";
import {
  accessChecklist,
  baseComponents,
  cmsModels,
  phaseSummary,
  pendingItems,
  plannedRoutes,
  preservedRoutes,
  siteConfig,
} from "@/content/site";
import { InfoCard } from "@/components/base/info-card";
import { SectionHeading } from "@/components/base/section-heading";
import { StatusPill } from "@/components/base/status-pill";
import { SiteShell } from "@/components/layout/site-shell";
import { buildPageMetadata } from "@/lib/seo";

export const metadata: Metadata = buildPageMetadata({
  title: "Estado tecnico",
  description: "Base tecnica, CMS y staging para Floristeria Valery.",
  path: "/estado/",
  indexable: false,
});

function ColumnList({
  title,
  items,
}: {
  title: string;
  items: string[];
}) {
  return (
    <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
      <h2 className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">
        {title}
      </h2>
      <ul className="mt-4 space-y-3 text-sm leading-6 text-slate-700">
        {items.map((item) => (
          <li key={item} className="flex gap-3">
            <span className="mt-2 h-2 w-2 rounded-full bg-brand-500" />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

export default function EstadoTecnico() {
  return (
    <SiteShell>
      <section className="grid gap-8 rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm lg:grid-cols-[1.2fr_0.8fr] lg:p-8">
        <div className="max-w-3xl">
          <StatusPill tone="accent">Fase 5 activa</StatusPill>
          <h1 className="mt-5 max-w-2xl font-display text-4xl leading-tight tracking-tight text-slate-950 sm:text-5xl">
            Base tecnica y CMS estructural de Floristeria Valery
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-slate-600">
            Este proyecto ya cuenta con estructura inicial, rutas preservadas,
            modelo de CMS propuesto, staging local, esquema de redirecciones,
            familias de contenido conectadas y un catalogo asistido con
            WhatsApp contextual. Todavia no se publica produccion ni se activa
            ecommerce.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              className="rounded-full bg-brand-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700"
              href="/comprar-flores/"
            >
              Abrir hub de rutas
            </Link>
            <Link
              className="rounded-full border border-slate-200 px-5 py-3 text-sm font-medium text-slate-700 transition hover:border-brand-300 hover:text-brand-800"
              href="/studio/"
            >
              Abrir Sanity Studio
            </Link>
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <InfoCard
            title="Dominio"
            value={siteConfig.domain}
            description="Se conserva como dominio canonico."
            tone="success"
            badgeLabel="ok"
          />
          <InfoCard
            title="Staging"
            value="localhost:3000"
            description="Disponible en desarrollo local."
            tone="accent"
            badgeLabel="local"
          />
          <InfoCard
            title="Estado"
            value="Fase 5"
            description="Pre-lanzamiento, integraciones y staging externo protegido."
            tone="warning"
            badgeLabel="activo"
          />
          <InfoCard
            title="Lanzamiento"
            value="Bloqueado"
            description="Hasta completar carga comercial y QA."
            tone="danger"
            badgeLabel="hold"
          />
        </div>
      </section>

      <section className="mt-10 grid gap-6 lg:grid-cols-3">
        {phaseSummary.map((phase) => (
          <article
            key={phase.phase}
            className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm"
          >
            <p className="text-sm font-semibold uppercase tracking-[0.22em] text-brand-700">
              {phase.phase}
            </p>
            <h2 className="mt-3 text-xl font-semibold tracking-tight text-slate-950">
              {phase.status}
            </h2>
            <p className="mt-3 text-sm leading-6 text-slate-600">
              {phase.detail}
            </p>
          </article>
        ))}
      </section>

      <section className="mt-10 grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <ColumnList
          title="URLs preservadas"
          items={preservedRoutes.map((route) => `${route.path} - ${route.description}`)}
        />
        <ColumnList
          title="Rutas planificadas"
          items={plannedRoutes.map((route) => `${route.path} - ${route.description}`)}
        />
      </section>

      <section className="mt-10 grid gap-6 lg:grid-cols-2">
        <ColumnList
          title="Componentes base"
          items={baseComponents}
        />
        <ColumnList
          title="Modelos CMS"
          items={cmsModels.map((model) => `${model.name} - ${model.purpose}`)}
        />
      </section>

      <section className="mt-10 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <ColumnList title="Pendientes detectados" items={pendingItems} />
        <section className="rounded-[2rem] border border-slate-200 bg-white p-6 shadow-sm">
          <SectionHeading
            eyebrow="Accesos"
            title="Datos o credenciales que faltan"
            description="Estos elementos estan documentados para cerrar la fase de preparacion antes de avanzar a contenido comercial."
          />
          <ul className="mt-6 space-y-3 text-sm leading-6 text-slate-700">
            {accessChecklist.map((item) => (
              <li key={item} className="flex gap-3">
                <span className="mt-2 h-2 w-2 rounded-full bg-brand-500" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </section>
      </section>
    </SiteShell>
  );
}
