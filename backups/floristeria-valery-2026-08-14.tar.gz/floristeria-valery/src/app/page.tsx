import type { Metadata } from "next";
import {
  businessHours,
  landingWhatsAppHref,
  valueBlocks,
} from "@/content/landing";
import { siteConfig } from "@/content/site";
import { FaqSection } from "@/components/landing/faq-section";
import { LandingHero } from "@/components/landing/landing-hero";
import { RotatingCategories } from "@/components/landing/rotating-categories";
import { ScrollReveal } from "@/components/landing/scroll-reveal";
import { Testimonials } from "@/components/landing/testimonials";
import { buildPageMetadata } from "@/lib/seo";

export const metadata: Metadata = buildPageMetadata({
  title: "Floristeria Valery | Flores en Neiva, Huila",
  description:
    "Arreglos florales para cada ocasion en Neiva, Huila. Te ayudamos a elegir por WhatsApp y entregamos el mismo dia.",
  path: "/",
});

export default function Home() {
  const whatsappHref = landingWhatsAppHref || "#faq";

  return (
    <div className="fv-landing">
      <LandingHero whatsappHref={whatsappHref} />

      <RotatingCategories whatsappHref={whatsappHref} />

      <Testimonials />

      <FaqSection />

      <section className="fv-brand-story" id="brand">
        <div className="fv-story-inner">
          <div className="fv-story-lead">
            <ScrollReveal>
              <span className="fv-kicker">Por que nosotros</span>
              <h2 className="fv-story-title">
                Nadie recuerda el ramo.
                <br />
                Recuerda como se sintio recibirlo.
              </h2>
            </ScrollReveal>
            <ScrollReveal delay={120}>
              <p className="fv-story-body">
                Por eso no vendemos flores sueltas. Escuchamos que quieres
                decir, lo armamos el mismo dia y te mandamos foto antes de
                salir.
              </p>
            </ScrollReveal>
            <ScrollReveal delay={220}>
              <a
                href={whatsappHref}
                target="_blank"
                rel="noreferrer noopener"
                className="fv-cat-cta"
                data-track-event="whatsapp_cta_clicked"
                data-track-component="BrandStory"
              >
                <span className="fv-cat-cta-label">Cuentanos la ocasion</span>
                <span className="fv-cat-cta-icon" aria-hidden="true">
                  <svg viewBox="0 0 24 24" focusable="false">
                    <path
                      d="M4 12h15M13 6l6 6-6 6"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </span>
              </a>
            </ScrollReveal>
          </div>

          <ol className="fv-story-steps">
            {valueBlocks.map((block, i) => (
              <ScrollReveal
                as="li"
                className="fv-story-step"
                key={block.title}
                delay={i * 130}
              >
                <span className="fv-story-step-num" aria-hidden="true">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div>
                  <h3 className="fv-story-step-title">{block.title}</h3>
                  <p className="fv-story-step-body">{block.body}</p>
                </div>
              </ScrollReveal>
            ))}
          </ol>
        </div>
      </section>

      <footer className="fv-footer" id="footer">
        <div className="fv-footer-grid">
          <div className="fv-footer-col">
            <h2 className="fv-footer-brand">{siteConfig.displayName}</h2>
            <p>Flores elegidas para decir lo que las palabras no alcanzan.</p>
          </div>
          <div className="fv-footer-col">
            <h3>Navegacion</h3>
            <a href="#categorias">Ocasiones</a>
            <a href="#testimonios">Testimonios</a>
            <a href="#faq">Preguntas</a>
            <a href="#brand">Nosotros</a>
          </div>
          <div className="fv-footer-col">
            <h3>Horario</h3>
            {businessHours.map((line) => (
              <p key={line}>{line}</p>
            ))}
          </div>
          <div className="fv-footer-col">
            <h3>Contacto</h3>
            <p>Neiva, Huila</p>
            <a
              href={whatsappHref}
              target="_blank"
              rel="noreferrer noopener"
              className="fv-footer-whats"
              data-track-event="whatsapp_cta_clicked"
              data-track-component="LandingFooter"
            >
              <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                <path
                  fill="currentColor"
                  d="M12.04 2a9.9 9.9 0 00-8.5 14.9L2 22l5.25-1.38A9.9 9.9 0 1012.04 2zm0 1.8a8.1 8.1 0 11-4.13 15.06l-.3-.18-3.11.82.83-3.03-.2-.31A8.1 8.1 0 0112.04 3.8zm4.66 10.32c-.25-.13-1.47-.72-1.7-.8-.23-.09-.4-.13-.56.12-.17.25-.64.8-.79.97-.14.16-.29.18-.54.06a6.6 6.6 0 01-1.95-1.2 7.3 7.3 0 01-1.35-1.68c-.14-.25-.01-.38.11-.5.11-.11.25-.29.37-.44.12-.15.16-.25.25-.42.08-.16.04-.31-.02-.44-.06-.12-.56-1.35-.77-1.85-.2-.48-.4-.41-.55-.42h-.47c-.16 0-.42.06-.64.31-.22.25-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.7 2.6 4.12 3.64.58.25 1.03.4 1.38.51.58.19 1.11.16 1.53.1.47-.07 1.47-.6 1.68-1.18.2-.58.2-1.08.14-1.18-.06-.11-.22-.17-.47-.29z"
                />
              </svg>
              <span>Escribir por WhatsApp</span>
            </a>
          </div>
        </div>
        <div className="fv-footer-bottom">
          <p>
            © {new Date().getFullYear()} {siteConfig.displayName}. Todos los
            derechos reservados.
          </p>
        </div>
      </footer>

      <a
        href={whatsappHref}
        target="_blank"
        rel="noreferrer noopener"
        className="fv-whatsapp-float"
        title="Pedir por WhatsApp"
        aria-label="Pedir por WhatsApp"
        data-track-event="whatsapp_cta_clicked"
        data-track-component="LandingFloat"
      >
        <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
          <path
            fill="currentColor"
            d="M12.04 2a9.9 9.9 0 00-8.5 14.9L2 22l5.25-1.38A9.9 9.9 0 1012.04 2zm0 1.8a8.1 8.1 0 11-4.13 15.06l-.3-.18-3.11.82.83-3.03-.2-.31A8.1 8.1 0 0112.04 3.8zm4.66 10.32c-.25-.13-1.47-.72-1.7-.8-.23-.09-.4-.13-.56.12-.17.25-.64.8-.79.97-.14.16-.29.18-.54.06a6.6 6.6 0 01-1.95-1.2 7.3 7.3 0 01-1.35-1.68c-.14-.25-.01-.38.11-.5.11-.11.25-.29.37-.44.12-.15.16-.25.25-.42.08-.16.04-.31-.02-.44-.06-.12-.56-1.35-.77-1.85-.2-.48-.4-.41-.55-.42h-.47c-.16 0-.42.06-.64.31-.22.25-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.7 2.6 4.12 3.64.58.25 1.03.4 1.38.51.58.19 1.11.16 1.53.1.47-.07 1.47-.6 1.68-1.18.2-.58.2-1.08.14-1.18-.06-.11-.22-.17-.47-.29z"
          />
        </svg>
      </a>
    </div>
  );
}
