import type { MetadataRoute } from "next";
import { preservedRoutes, siteConfig } from "@/content/site";

const publishedRoutes = [
  "/",
  "/comprar-flores/",
  "/comprar-flores/condolencias/",
  "/comprar-flores/personalizados/",
  "/entrega-hoy/",
  "/comprar-desde-lejos/",
  "/contacto/",
  ...preservedRoutes.map((route) => route.path),
];

export default function sitemap(): MetadataRoute.Sitemap {
  return publishedRoutes.map((path) => ({
    url: `${siteConfig.canonicalDomain}${path}`,
    lastModified: new Date("2026-07-30"),
    changeFrequency: path === "/" ? "weekly" : "monthly",
    priority: path === "/" ? 1 : 0.7,
  }));
}
