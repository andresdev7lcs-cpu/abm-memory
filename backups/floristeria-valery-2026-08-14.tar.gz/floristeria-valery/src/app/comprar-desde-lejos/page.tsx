import type { Metadata } from "next";
import { FlowPage } from "@/components/catalog/flow-page";
import { getCatalogFlowDefinition } from "@/lib/catalog";
import { buildPageMetadata } from "@/lib/seo";

export const metadata: Metadata = buildPageMetadata({
  title: "Comprar desde lejos | Floristeria Valery",
  description:
    "Flujo remoto para revisar pedidos a distancia con WhatsApp contextual.",
  path: "/comprar-desde-lejos/",
});

export default function ComprarDesdeLejosPage() {
  return <FlowPage flow={getCatalogFlowDefinition("comprar-desde-lejos")} />;
}
