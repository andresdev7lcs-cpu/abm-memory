import { RouteShell } from "@/components/layout/route-shell";

export default function FruterosPage() {
  return (
    <RouteShell
      path="/fruteros/"
      title="Ruta preservada: fruteros"
      description="Pagina tecnica reservada para conservar el slug indexado actual."
      category="preserved"
    />
  );
}
