import type { Metadata } from "next";
import { FlowPage } from "@/components/catalog/flow-page";
import { getCatalogFlowDefinition } from "@/lib/catalog";
import { buildPageMetadata } from "@/lib/seo";

export const metadata: Metadata = buildPageMetadata({
  title: "Contacto | Floristeria Valery",
  description:
    "Formulario base de contacto con derivacion asistida a WhatsApp.",
  path: "/contacto/",
});

export default function ContactoPage() {
  return <FlowPage flow={getCatalogFlowDefinition("contacto")} />;
}
