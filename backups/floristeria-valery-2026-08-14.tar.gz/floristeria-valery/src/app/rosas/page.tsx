import { RouteShell } from "@/components/layout/route-shell";

export default function RosasPage() {
  return (
    <RouteShell
      path="/rosas/"
      title="Ruta preservada: rosas"
      description="Pagina tecnica reservada para conservar el slug indexado actual."
      category="preserved"
    />
  );
}
