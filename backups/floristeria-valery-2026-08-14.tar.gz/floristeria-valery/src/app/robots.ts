import type { MetadataRoute } from "next";
import { isProductionSite, siteConfig } from "@/content/site";

export default function robots(): MetadataRoute.Robots {
  if (!isProductionSite) {
    return {
      rules: [
        {
          userAgent: "*",
          disallow: "/",
        },
      ],
    };
  }

  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        disallow: ["/studio/"],
      },
    ],
    sitemap: `${siteConfig.canonicalDomain}/sitemap.xml`,
    host: siteConfig.canonicalDomain,
  };
}
