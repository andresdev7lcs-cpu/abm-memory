import { RouteShell } from "@/components/layout/route-shell";

export default function BouquetsPage() {
  return (
    <RouteShell
      path="/bouquets/"
      title="Ruta preservada: bouquets"
      description="Pagina tecnica reservada para conservar el slug indexado actual."
      category="preserved"
    />
  );
}
