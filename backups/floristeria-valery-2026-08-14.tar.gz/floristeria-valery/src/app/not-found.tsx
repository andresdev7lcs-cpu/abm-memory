import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-screen w-full max-w-3xl flex-col justify-center px-4 py-16 text-center sm:px-6 lg:px-8">
      <p className="text-sm font-semibold uppercase tracking-[0.24em] text-brand-700">
        404
      </p>
      <h1 className="mt-4 font-display text-4xl tracking-tight text-slate-950 sm:text-5xl">
        Ruta no encontrada
      </h1>
      <p className="mt-4 text-base leading-7 text-slate-600">
        La pagina solicitada no existe en esta base tecnica, pero el punto de
        entrada principal sigue disponible.
      </p>
      <Link
        className="mx-auto mt-8 inline-flex rounded-full bg-brand-600 px-5 py-3 text-sm font-medium text-white transition hover:bg-brand-700"
        href="/"
      >
        Volver al inicio
      </Link>
    </main>
  );
}
