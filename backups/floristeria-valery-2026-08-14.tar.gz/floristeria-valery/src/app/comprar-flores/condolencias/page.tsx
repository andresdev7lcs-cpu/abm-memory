import type { Metadata } from "next";
import { FlowPage } from "@/components/catalog/flow-page";
import { getCatalogFlowDefinition } from "@/lib/catalog";
import { buildPageMetadata } from "@/lib/seo";

export const metadata: Metadata = buildPageMetadata({
  title: "Condolencias | Floristeria Valery",
  description:
    "Flujo asistido para condolencias con WhatsApp contextual y formulario minimo.",
  path: "/comprar-flores/condolencias/",
});

export default function CondolenciasPage() {
  return <FlowPage flow={getCatalogFlowDefinition("condolencias")} />;
}
