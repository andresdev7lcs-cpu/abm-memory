import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CatalogProductDetail } from "@/components/catalog/catalog-product-detail";
import { getCatalogProductPage, getCatalogStaticParams } from "@/lib/catalog";
import { buildPageMetadata } from "@/lib/seo";

type PageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export const dynamicParams = true;
export const revalidate = 3600;

export function generateStaticParams() {
  return getCatalogStaticParams();
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const { product, source } = await getCatalogProductPage(slug);

  if (!product) {
    return buildPageMetadata({
      title: "Producto no encontrado | Floristeria Valery",
      description: "La ficha solicitada no esta disponible en el catalogo tecnico.",
      path: `/comprar-flores/${slug}/`,
      indexable: false,
    });
  }

  return buildPageMetadata({
    title: product.seoTitle,
    description: product.seoDescription,
    path: `/comprar-flores/${product.slug}/`,
    indexable: source === "sanity" && product.availability === "available",
  });
}

export default async function CatalogProductPage({ params }: PageProps) {
  const { slug } = await params;
  const { product, relatedProducts, source } = await getCatalogProductPage(slug);

  if (!product) {
    notFound();
  }

  return (
    <CatalogProductDetail
      product={product}
      relatedProducts={relatedProducts}
      source={source}
    />
  );
}
