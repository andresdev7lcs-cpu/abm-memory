import type { Metadata } from "next";
import { CatalogBrowser } from "@/components/catalog/catalog-browser";
import { getCatalogPageData } from "@/lib/catalog";
import { buildPageMetadata } from "@/lib/seo";

type PageProps = {
  searchParams: Promise<{
    category?: string;
    occasion?: string;
    availability?: string;
    price?: string;
  }>;
};

export async function generateMetadata({
  searchParams,
}: PageProps): Promise<Metadata> {
  await searchParams;

  return buildPageMetadata({
    title: "Comprar flores | Floristeria Valery",
    description:
      "Catalogo asistido con filtros basicos, fichas conectadas a Sanity y WhatsApp contextual.",
    path: "/comprar-flores/",
  });
}

export default async function ComprarFloresPage({ searchParams }: PageProps) {
  const query = await searchParams;
  const data = await getCatalogPageData({
    category: query.category,
    occasion: query.occasion,
    availability: query.availability,
    price: query.price,
  });

  return <CatalogBrowser data={data} />;
}
