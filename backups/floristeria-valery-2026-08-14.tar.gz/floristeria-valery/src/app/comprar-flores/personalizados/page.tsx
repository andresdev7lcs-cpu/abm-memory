import type { Metadata } from "next";
import { FlowPage } from "@/components/catalog/flow-page";
import { getCatalogFlowDefinition } from "@/lib/catalog";
import { buildPageMetadata } from "@/lib/seo";

export const metadata: Metadata = buildPageMetadata({
  title: "Personalizados | Floristeria Valery",
  description:
    "Formulario minimo para piezas personalizadas con WhatsApp contextual.",
  path: "/comprar-flores/personalizados/",
});

export default function PersonalizadosPage() {
  return <FlowPage flow={getCatalogFlowDefinition("personalizados")} />;
}
