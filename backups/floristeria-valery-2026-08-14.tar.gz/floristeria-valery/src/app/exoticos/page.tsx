import { RouteShell } from "@/components/layout/route-shell";

export default function ExoticosPage() {
  return (
    <RouteShell
      path="/exoticos/"
      title="Ruta preservada: exoticos"
      description="Pagina tecnica reservada para conservar el slug indexado actual."
      category="preserved"
    />
  );
}
