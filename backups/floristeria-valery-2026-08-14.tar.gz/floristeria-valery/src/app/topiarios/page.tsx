import { RouteShell } from "@/components/layout/route-shell";

export default function TopiariosPage() {
  return (
    <RouteShell
      path="/topiarios/"
      title="Ruta preservada: topiarios"
      description="Pagina tecnica reservada para conservar el slug indexado actual."
      category="preserved"
    />
  );
}
