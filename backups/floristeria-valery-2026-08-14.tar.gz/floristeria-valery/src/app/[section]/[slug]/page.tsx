import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CmsFamilyPage } from "@/components/cms/cms-family-page";
import { cmsFamilies, cmsFamilyOrder, getCmsRecord, isCmsFamilyKey } from "@/content/cms";
import { siteConfig } from "@/content/site";
import { getCmsRecordPage } from "@/lib/cms";

type PageParams = {
  params: Promise<{
    section: string;
    slug: string;
  }>;
};

export const dynamicParams = true;
export const revalidate = 3600;

export function generateStaticParams() {
  return cmsFamilyOrder.flatMap((section) =>
    cmsFamilies[section].records.map((record) => ({
      section,
      slug: record.slug,
    })),
  );
}

export async function generateMetadata({
  params,
}: PageParams): Promise<Metadata> {
  const { section, slug } = await params;

  if (!isCmsFamilyKey(section)) {
    return {
      robots: {
        index: false,
        follow: false,
      },
    };
  }

  const family = cmsFamilies[section];
  const scaffoldRecord = getCmsRecord(section, slug);

  return {
    title: scaffoldRecord
      ? `${scaffoldRecord.title} | ${family.title} | Floristeria Valery`
      : `${family.title} | Floristeria Valery`,
    description: scaffoldRecord?.summary ?? family.description,
    alternates: {
      canonical: `${siteConfig.canonicalDomain}${family.path}${slug}/`,
    },
    robots: {
      index: false,
      follow: true,
      nocache: true,
    },
  };
}

export default async function CmsFamilyDetailPage({ params }: PageParams) {
  const { section, slug } = await params;

  if (!isCmsFamilyKey(section)) {
    notFound();
  }

  const { family, records, source, record } = await getCmsRecordPage(
    section,
    slug,
  );

  if (!record) {
    notFound();
  }

  return (
    <CmsFamilyPage
      family={family}
      records={records}
      source={source}
      selectedRecord={record}
    />
  );
}

