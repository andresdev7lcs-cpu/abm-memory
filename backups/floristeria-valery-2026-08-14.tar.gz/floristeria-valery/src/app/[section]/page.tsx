import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CmsFamilyPage } from "@/components/cms/cms-family-page";
import { cmsFamilies, cmsFamilyOrder, isCmsFamilyKey } from "@/content/cms";
import { siteConfig } from "@/content/site";
import { getCmsFamilyPage } from "@/lib/cms";

type PageParams = {
  params: Promise<{
    section: string;
  }>;
};

export const dynamicParams = true;
export const revalidate = 3600;

export function generateStaticParams() {
  return cmsFamilyOrder.map((section) => ({
    section,
  }));
}

export async function generateMetadata({
  params,
}: PageParams): Promise<Metadata> {
  const { section } = await params;

  if (!isCmsFamilyKey(section)) {
    return {
      robots: {
        index: false,
        follow: false,
      },
    };
  }

  const family = cmsFamilies[section];

  return {
    title: `${family.title} | Floristeria Valery`,
    description: family.description,
    alternates: {
      canonical: `${siteConfig.canonicalDomain}${family.path}`,
    },
    robots: {
      index: false,
      follow: true,
      nocache: true,
    },
  };
}

export default async function CmsFamilyIndexPage({ params }: PageParams) {
  const { section } = await params;

  if (!isCmsFamilyKey(section)) {
    notFound();
  }

  const { family, records, source } = await getCmsFamilyPage(section);

  return <CmsFamilyPage family={family} records={records} source={source} />;
}

