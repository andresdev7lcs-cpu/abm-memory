import type { Metadata } from "next";
import { FlowPage } from "@/components/catalog/flow-page";
import { getCatalogFlowDefinition } from "@/lib/catalog";
import { buildPageMetadata } from "@/lib/seo";

export const metadata: Metadata = buildPageMetadata({
  title: "Entrega hoy | Floristeria Valery",
  description:
    "Flujo urgente para confirmar cobertura y tiempos con WhatsApp asistido.",
  path: "/entrega-hoy/",
});

export default function EntregaHoyPage() {
  return <FlowPage flow={getCatalogFlowDefinition("entrega-hoy")} />;
}
