# Fase 0 a Fase 5

## Estado actual

- Fase 0: completada en el alcance local.
- Fase 1: completada en el alcance local.
- Fase 2: completada.
- Fase 3: completada.
- Fase 4: completada.
- Fase 5: en progreso.

## Ya cubierto

- Scaffold de Next.js con TypeScript y Tailwind.
- Estructura base de rutas.
- URLs preservadas como rutas reales.
- Sanity configurado como CMS propuesto.
- Modelo de contenido definido en codigo.
- Rutas genericas para familias CMS estructurales.
- Schemas ampliados con relaciones y modelos de pagina.
- Plantillas por familia conectadas a CMS o scaffolds locales.
- Estados visibles por familia: con contenido, sin contenido, borrador, no disponible y error.
- Campos visibles definidos por familia para revision tecnica.
- Catalogo funcional en `/comprar-flores/` con filtros basicos.
- Fichas de producto en `/comprar-flores/[slug]/`.
- WhatsApp contextual para producto y flujos de compra.
- Formularios minimos en flujos de condolencias, personalizados, entrega hoy, compra desde lejos, eventos, empresas y contacto.
- Staging local preparado via `npm run staging`.
- Preview local verificado via `npm run preview`.
- Sitemap y robots listos para la base tecnica.
- `npm run lint` verificado en fase anterior.
- `npm run build` verificado en fase anterior.

## Pendiente antes de ir a carga comercial

- Conectar projectId y dataset reales de Sanity.
- Cargar contenido final aprobado.
- Revisar precios finales y bandas de precio cuando existan.
- Completar top ventas, ticket promedio, capacidad diaria y contactos B2B.
- Verificar accesos definitivos a analytics, Search Console, Sanity y dominio.
- Definir redirecciones reales si aparece algun cambio adicional de slug.
- Confirmar el staging externo protegido con version salvada.
