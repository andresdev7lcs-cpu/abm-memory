# Accesos y datos faltantes

## Accesos tecnicos

- Repositorio remoto externo creado; falta remoto GitHub si se decide usarlo.
- Proyecto de hosting externo creado; falta version salvada y despliegue.
- `NEXT_PUBLIC_SANITY_PROJECT_ID` faltante.
- `NEXT_PUBLIC_SANITY_DATASET` faltante.
- `NEXT_PUBLIC_SANITY_API_VERSION` a confirmar.
- Google Analytics 4 ID faltante.
- Google Tag Manager ID faltante.
- Search Console por verificar.
- Meta Pixel ID faltante.
- Numero oficial de WhatsApp por confirmar.
- Credenciales de Google Business Profile por confirmar.
- Logo editable o archivo origen por confirmar.
- Banco de imagenes por confirmar.

## Datos comerciales pendientes

- Top ventas.
- Ticket promedio.
- Capacidad diaria.
- Contactos B2B.

## Nota

- Los datos comerciales pendientes no frenan la base tecnica, pero si la carga comercial definitiva y el lanzamiento.
