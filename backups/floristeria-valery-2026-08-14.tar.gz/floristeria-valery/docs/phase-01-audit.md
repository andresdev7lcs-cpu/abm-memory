# Phase 0 / Phase 1 Technical Audit

Date: 2026-07-31

## Scope

Auditoria breve de la base tecnica antes de iniciar Fase 2.

## Verdict

- Fase 0: approved
- Fase 1: approved with observations
- Production release: blocked
- Phase 2 start: only after the corrections listed below are closed

## 1. Preserved routes

Status: approved

Validated routes:

- `/`
- `/comprar-flores/`
- `/bouquets/`
- `/rosas/`
- `/topiarios/`
- `/exoticos/`
- `/fruteros/`

Evidence:

- The routes exist as App Router pages in `src/app/`.
- `next.config.ts` enables `trailingSlash: true`, so the slash-terminated URLs are the canonical forms.
- `npm run build` exposes the routes in the final route table.

Observation:

- The preserved URLs are technically in place and not being moved under a different slug hierarchy.

## 2. sitemap.ts and robots.ts

Status: approved

What is correct:

- `src/app/sitemap.ts` uses `https://floristeriaenneiva.com` as the canonical base.
- `src/app/robots.ts` also points to the canonical domain.
- The public metadata in `src/app/layout.tsx` uses the same canonical domain.

What is now correct:

- `src/app/layout.tsx` adds environment-aware `robots` metadata.
- `src/app/robots.ts` returns a hard `disallow: "/"` policy outside production.
- Production remains canonical on `floristeriaenneiva.com`.
- Staging and local environments are explicitly non-indexable.

Conclusion:

- Production canonicalization is correct.
- Staging noindex is explicit and safe.

## 3. Sanity models

Status: approved

Aligned models present in `src/sanity/schemaTypes/index.ts`:

- `siteSettings`
- `product`
- `category`
- `occasion`
- `campaign`
- `testimonial`
- `faq`
- `leadFormSubmission`
- `redirect`
- `deliveryRule`
- `b2bContact`

Audit notes:

- The schema matches the technical plan.
- No commercial fields were invented beyond the plan.
- The blocked commercial data points remain outside the schema, which is correct for this phase:
  - top sales
  - average ticket
  - daily capacity
  - B2B contacts

## 4. Visible content and CMS/config

Status: partial

What is correct:

- The home screen, route shells, and technical base components clearly function as a scaffold.
- Config-backed values exist in `src/content/site.ts`.
- Sanity is wired as the proposed CMS and the Studio route exists.

What is still hardcoded:

- The dashboard copy on `src/app/page.tsx`.
- The placeholder copy in `src/components/layout/route-shell.tsx`.
- The preserved route placeholder text in the route pages.

Conclusion:

- This is acceptable only because the visible copy is explicitly a technical placeholder.
- If the requirement becomes strict CMS-only public content, this must be migrated in the next phase.

## 5. WhatsAppCTA

Status: approved

Current state:

- `src/components/base/whatsapp-cta.tsx` now reads the number from config by default.
- It accepts a contextual `message` per page or component.
- It exposes prepared tracking data attributes.
- It renders a visible fallback link when available.
- It avoids hardcoding a WhatsApp URL placeholder in the component API.

## 6. Future content architecture

Status: partial

Supported in plan and schema:

- pages by occasion
- campaigns
- products
- FAQ
- testimonials
- policies
- events
- corporate pages

What is still missing:

- Concrete route scaffolding for those page families.
- A uniform content contract that maps each family to an App Router page or dynamic route.

Conclusion:

- The data architecture supports the expansion path.
- The page architecture is not fully built yet.

## 7. Secrets and sensitive values

Status: approved

Findings:

- No real secrets were found in the repository scan.
- `.env.example` contains placeholders only.
- Sanity and analytics IDs are placeholder or empty values only.
- No real private keys, tokens, or API credentials were detected.

Observation:

- `siteConfig.whatsappNumber` is empty, which is a placeholder and not a secret.

## 8. Lint and build

Status: approved

Verified:

- `npm run lint` passed.
- `npm run build` passed.

Build evidence:

- The build output includes the expected application routes.
- The app compiles successfully with TypeScript and static generation.

## Approved

- Preserved routes are present and stable.
- Canonical domain is consistent.
- Staging is explicitly noindex.
- Sanity schema is aligned with the technical plan.
- WhatsAppCTA now supports editable number, contextual message, tracking prep and fallback.
- No secrets were found.
- Lint and build pass.

## Observations

- The current visible UI is still a technical scaffold, not final CMS-driven public content.
- External staging and repository hosting are still not configured.
- Route scaffolding for upcoming content families is still pending.

## Technical debt

- External staging and repository hosting are still not configured.
- Route scaffolding for occasions, campaigns, products, FAQ, testimonials, policies, events, and corporate pages is still pending.
- Migration of visible public copy toward CMS/config remains a next-phase task where content becomes user-facing.

## Blockers

- None from this audit.

## Corrections required before Fase 2

1. No blocker remains from the two audited items.
2. Keep production content in CMS/config instead of hardcoded text once the public-facing phase begins.
