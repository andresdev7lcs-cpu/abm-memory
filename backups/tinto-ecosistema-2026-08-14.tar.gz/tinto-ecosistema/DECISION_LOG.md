# Registro de decisiones — TINTO

## DEC-001 — Construir una sola unidad comercial

- Estado: APPROVED
- Fecha: (andres confirma)
- Decisión: TINTO conservará una visión amplia, pero validará primero una unidad comercial concreta.
- Motivo: reducir complejidad, acelerar aprendizaje y conseguir clientes.

## DEC-002 — Marca personal y TINTO funcionan como dos rieles

- Estado: APPROVED
- Fecha: (andres confirma)
- Decisión: la fundadora genera confianza y cercanía; TINTO organiza activos, productos, embudos y conversión.
- Restricción: no crear dos estrategias desconectadas.

## DEC-003 — No desarrollar una plataforma durante el MVP

- Estado: APPROVED
- Fecha: (andres confirma)
- Decisión: el MVP será un sistema de servicios y acompañamiento operado manualmente con herramientas existentes.

## DEC-004 — Avatar IA como multiplicador

- Estado: APPROVED
- Fecha: (andres confirma)
- Decisión: utilizar la imagen y voz autorizadas de la fundadora para piezas guionizadas y revisadas.
- Restricción: lives, conferencias, diagnósticos y conversaciones sensibles serán realizados directamente por la fundadora.

## DEC-005 — Primer objetivo comercial

- Estado: PROPOSED
- Fecha: (andres confirma)
- Decisión: conseguir los primeros 100 leads, validar mensajes y generar oportunidades comerciales.
- Meta final de clientes y plazo: (andres confirma)