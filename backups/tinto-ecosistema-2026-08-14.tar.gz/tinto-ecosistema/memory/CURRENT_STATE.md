---
document: TINTO Current State
version: 0.2.0
status: active
last_updated: 2026-07-23
updated_by: TINTO Guardian setup
source_of_truth: repository
---

# Estado operativo de TINTO — Snapshot 2026-07-23

## Estado ejecutivo

TINTO Ecosistema está en fase de construcción del núcleo estratégico operativo. Infraestructura base (repositorio, dashboard, documentos) existe. Sistema multiagente (Claude Code, Codex, Auditor) está en construcción. Primera unidad comercial permanece en fase de hipótesis y definición.

**Situación:** Ready para ejecutar tickets de estrategia (STR-001, STR-003, MKT-001 a MKT-005). Bloqueantes: datos de fundadora, decisiones sobre nicho primario, definición de ofertas.

## Stage actual

**GOV — Governance (base):** ✓ Completado
- GOV-001: Validar estructura inicial del repositorio — **COMPLETED**
- GOV-002: Incorporar fuentes originales — **PENDING**

**STR — Strategy (fundacional):** En construcción
- STR-001: Consolidar contexto maestro — **PENDING**
- STR-002: Documentar ecosistema amplio — **PENDING**
- STR-003: Documentar primera unidad comercial — **PENDING**

**MKT y siguientes:** No iniciados

## Objetivo del stage actual

Construir los documentos maestros de gobernanza y estrategia (TINTO_MASTER_CONTEXT.md, primer tomo de unidad comercial) que permitan validar nicho, buyer persona, oferta y embudo.

## Unidad comercial activa

Estado: [HIPÓTESIS]
- Mercado: `(andres confirma)` — asumida orientación a colombianos en exterior
- Nicho: `(andres confirma)` — múltiples opciones propuestas (bienes en Colombia, remesas, seguros)
- Subnicho: `(andres confirma)` — sin priorizar
- Geografía: `(andres confirma)` — país de validación sin definir
- Buyer persona: `(andres confirma)` — sin caracterizar

**Regla:** No se pueden activar verticales adicionales. Única unidad comercial por MVP.

## Qué está aprobado

[APROBADO — DECISION_LOG.md]:
- **DEC-001:** Construir una sola unidad comercial (reduce complejidad, acelera aprendizaje).
- **DEC-002:** Marca personal y TINTO como dos rieles (confianza vs. organización).
- **DEC-003:** MVP sin plataforma propia (servicios + herramientas existentes).
- **DEC-004:** Avatar IA como multiplicador (imagen/voz autorizadas, nunca live/diagnóstico/sensible).
- **DEC-005 (PROPOSED):** Primer objetivo: 100 leads, validación de mensajes, oportunidades comerciales.

## Qué continúa como hipótesis

- Nicho primario (bienes en Colombia, remesas, seguros, etc.)
- Geografía de validación (país específico)
- Buyer persona detallado
- Oferta inicial (precio, entregables, duración)
- Embudo y customer journey
- Stack tecnológico

Todas estas requieren decisión de Andrés o validación con fundadora.

## Qué está pendiente de confirmación

- Datos de fundadora: trayectoria, experiencia, activos (CV, portfolio, histórico).
- Definición de primer país de validación (MKT-002).
- Priorización de nicho entre opciones competidoras (MKT-004).
- Autorización de avatar IA: imagen, voz, guiones (BRD-004).
- Presupuesto y horizonte de inversión (COST-001, PROP-001).
- Plazo objetivo de MVP y lanzamiento (todos los tickets).

**Responsabilidad:** Andrés confirmar o proveer datos faltantes.

## Tickets completados

- **GOV-001:** Validar estructura inicial — revisión, reglas, fuentes de verdad aprobadas.

## Tickets activos

Ninguno está en ejecución activa. Listos para iniciar:
- **GOV-002:** Incorporar fuentes originales (espera dados de fundadora).
- **STR-001:** Consolidar contexto maestro (crítico, desbloquea STR-002, STR-003).

## Tickets bloqueados

- **STR-001, STR-003, MKT-002, MKT-004, BRD-001, BRD-002, etc.:** Esperan decisión de Andrés sobre datos faltantes o confirmación de hipótesis iniciales.

**Razón:** Falta información crítica (fundadora, nicho, geografía, presupuesto).

## Dependencias críticas

```
GOV-001 (completado)
    ↓
GOV-002 (datos fundadora) → STR-001 (contexto maestro)
                              ↓
                          STR-002 (ecosistema amplio)
                          STR-003 (unidad comercial)
                              ↓
                          MKT-001 (entrevistas)
                          MKT-002 (país)
                              ↓
                          MKT-004 (priorizar nicho)
                              ↓
                          MKT-005 (buyer persona)
```

Bloqueante: GOV-002 + STR-001. Sin ambas, no puede haber MKT ni PRD válidos.

## Riesgos actuales

1. **Dispersión de verticales:** Múltiples opciones en conversaciones sin decisión registrada. Riesgo: gastar esfuerzo en diseño sin validación.
2. **Falta de datos de fundadora:** No hay biografía, experiencia, activos públicos registrados. Riesgo: no poder construir narrativa de marca personal.
3. **Ausencia de timeline:** Plazo del MVP no definido. Riesgo: estimaciones incorrectas de presupuesto y recursos.
4. **Avatar IA sin límites claros:** BRD-004 pending. Riesgo: confusión en producción sobre qué es permitido.
5. **Decisiones en conversaciones, no en DECISION_LOG:** Información crítica dispersa. Riesgo: contradiciones y olvido de contexto.

## Próximo gate

**Gate STR (Strategy):** Aprobación de documentos maestros
- Entrada: Contexto maestro consolidado, decisión sobre nicho, geografía, presupuesto.
- Salida: Permiso para iniciar MKT y PRD en paralelo.
- Responsable: Andrés.
- Plazo: `(andres confirma)`

## Restricciones activas

1. **Una sola unidad comercial.** No se pueden activar verticales nuevas sin decisión explícita.
2. **Documentación antes de ejecución.** Toda decisión debe estar en DECISION_LOG.md antes de implementar.
3. **No invención de datos.** Si falta información, escribir `(andres confirma)`. Prohibido adivinar sobre fundadora, nicho, presupuesto.
4. **Avatar IA limitado.** Consentimiento + límites claros. Prohibido reemplazar interacciones sensibles.
5. **Validación con mercado real.** No confundir engagement con validación. Requiere conversaciones de verdad, no supuestos.
6. **Sin plataforma propia en MVP.** Usar herramientas existentes (Google Workspace, Zapier, CRM tercero).

## Próxima acción recomendada

1. **STR-001 (crítica):** Consolidar contexto maestro. Crear versión 0.2 de TINTO_MASTER_CONTEXT.md integrando:
   - Decisiones de DECISION_LOG.md.
   - Restricciones de PROJECT_RULES.md.
   - Cambios pendientes: nicho, geografía, presupuesto.

2. **GOV-002 (bloqueante):** Incorporar y organizar fuentes originales de fundadora (CV, portfolio, materiales).

3. **Andrés:** Confirmar o proveer:
   - Nicho primario (1 elegida entre opciones).
   - País de validación.
   - Presupuesto y horizonte temporal.
   - Trayectoria y activos de fundadora.

4. **Una vez confirmado:** Iniciar MKT-001, MKT-002, MKT-004 en paralelo.

## Regla para actualizar este archivo

- **Cuándo:** Cuando un ticket se complete, cambie de estado o se bloquee.
- **Quién:** Claude Code, Codex o Auditor (al registrar entrega).
- **Cómo:** Append-only. No reescribir secciones previas; agregar cambios con timestamp y ticket que originó.
- **Autorización:** No requiere aprobación, pero cambios críticos (stage, riesgos, próxima acción) deben ser comunicados a Andrés.

Ejemplo de actualización:
```
## Actualización [2026-07-24 - STR-001 completado]
- Stage: STR avanzó a completado (contexto maestro).
- Próxima acción: Iniciar MKT en paralelo.
- Riesgos: reducidos; datos de fundadora incorporados.
```

## Actualización [2026-07-28 - Bloque 1 v0.2.0 cerrado]

**Estado:** CLOSED, merged to main, tagged v0.2.0

- **Bloque 1 v0.2.0:** Pruebas integrales completadas (Pruebas 1-12) con resultado `pass`.
- **Hallazgos:** 0 Critical, 0 Major. 1 Minor sugerencia opcional.
- **Aprobación:** Andrés confirmó explícitamente cierre de Bloque 1 (2026-07-28).
- **Git estado:** Merge commit: 5156e65. Implementation commit: 563aa4f. Baseline commit: 454842c.
- **Rama:** feature/tinto-guardian-core-v0.2.0 (merged to main).
- **Tag:** v0.2.0 creado y confirmado.
- **Operacional:** Sistema manual v0.2.0 operativo. No runtime automatizado (v0.3.0 futuro).

**Cambios formalizados:**
- CHANGELOG.md: [0.2.0] estado final = cerrado, etiquetado, mergeado.
- REVIEW_CHECKLIST.md: Casillas confirmadas (pruebas, resultado pass, aprobación, Git ops).
- roadmap-status.md: Bloque 1 estado = closed.
- memory/: CURRENT_STATE.md actualizado.

## Actualización [2026-07-28 - Bloque 3 formalmente abierto]

```text
Block: 3
Version target: v1.0.0
State: opened
Branch: feature/tinto-offer-strategy-v1.0.0
```

**Estado:** Bloque 3 abierto. Oferta aún no producida.

- **Bloque 1 (v0.2.0):** Closed, merged to main, tagged v0.2.0. Commits: 5156e65 (merge), 563aa4f (impl), 454842c (baseline). Operacional en modo manual (v0.3.0 futuro).
- **Bloque 2:** No está siendo ejecutado dentro de esta rama. Fuera de alcance de `feature/tinto-offer-strategy-v1.0.0`.
- **Bloque 3 (v1.0.0):** Abierto. Objetivo: diagnóstico, unidad comercial, buyer persona, oferta (transformación, mecanismo, elementos, bonos, valor), precio, reversión riesgo, identidad, ecosistema ascensión, evento conversión, script venta, propuesta final, auditoría. Nada producido todavía.
- **Bloque 3:** Formalmente abierto en esta rama. Objetivo: construir, validar y aprobar la primera oferta comercial de TINTO (diagnóstico, unidad comercial, buyer persona, oferta, precio, reversión de riesgo, identidad, ecosistema de ascensión, evento de conversión, script de venta, propuesta comercial, auditoría y cierre).

**Restricciones activas para Bloque 3:**
- Promoción y anuncios continúan bloqueados (Stage Gates 2-3 no superados; ver `orchestration/STAGE_GATES.md`).
- Ninguna oferta, precio, país, buyer persona o nicho debe tratarse como aprobado sin evidencia. Todo dato faltante: `(andres confirma)`.
- La primera unidad comercial debe mantenerse estrecha (DEC-001, PROJECT_RULES.md § "No").
- Cambios estructurales (nicho, país, precio, modelo de negocio) requieren change request (`orchestration/CHANGE_CONTROL.md`) y aprobación de Andrés antes de ejecutar.

**No se declara:** v1.0.0 completada, validada ni publicada. Oferta aún no producida.

**Próxima acción:** Iniciar diagnóstico y consolidación de evidencia existente (entregable 1 de Bloque 3, ver `roadmap-status.md`).
