---
document: TINTO Assumptions
version: 0.1.0
status: active
last_updated: 2026-07-27
---

# Hipótesis activas del proyecto TINTO

## Propósito

Registrar todas hipótesis (supuestos sin validar) que guían decisiones operativas. Regla cardinal: ninguna hipótesis puede presentarse como hecho. Todas requieren validación.

## Regla fundamental

**Ninguna hipótesis puede presentarse como hecho.** Si se quiere usarla como verdad, debe pasar de `open` → `testing` → `supported` → `converted_to_fact`.

## Tipos de hipótesis

- **Mercado:** Tamaño, crecimiento, acceso, saturación.
- **Cliente:** Dolor, disposición pago, geografía, urgencia.
- **Problema:** Validación que personas realmente lo tienen.
- **Oferta:** Promesa, precio, entregables.
- **Precio:** Modelo, rango, sensibilidad.
- **Canal:** Dónde están clientes, cómo llegar.
- **Operación:** Capacidad producción, calidad, timeline.
- **Tecnología:** Stack, integraciones, automatización.
- **Marca:** Posicionamiento, tonalidad, diferenciación.
- **Capacidad fundadora:** Experiencia, activos, autoridad disponible.

## Estados

- **open:** Hipótesis identificada, sin validación iniciada.
- **testing:** Validación en progreso (entrevistas, datos, experimentos).
- **supported:** Validación recolectada, evidencia sustenta. Listo para decisión.
- **rejected:** Validación contradice. Hipótesis falsa.
- **expired:** Plazo pasó, contexto cambió. No relevante.
- **converted_to_fact:** Validación completa. Pasa a VALIDATED_FACTS.md.

## Campos mínimos

1. **ID:** A-001, A-002, etc.
2. **Hipótesis:** Enunciado específico.
3. **Tipo:** mercado | cliente | problema | oferta | precio | canal | operación | tecnología | marca | capacidad-fundadora.
4. **Fuente:** Ticket, conversación, o supuesto implícito.
5. **Evidencia necesaria:** Qué validaría esto.
6. **Riesgo:** Qué pasa si está falsa.
7. **Responsable:** Quién valida.
8. **Estado:** open | testing | supported | rejected | expired | converted_to_fact.
9. **Fecha revisión:** Cuándo se próxima chequea.
10. **Decisión relacionada:** Si guía DEC.

## Reglas de validación

1. **Testing:** Requiere método claro (entrevistas, datos, experimento). No supuestos sobre supuestos.
2. **Supported:** Requiere N ≥ 3 datos convergentes (3 conversaciones reales, 3 datos públicos, combos).
3. **Rejected:** Requiere evidencia contradictoria clara. No ausencia de evidencia.
4. **Converted to fact:** Requiere decisión de Andrés + aprobación DECISION_LOG si afecta estrategia.

## Reglas de actualización

1. **Append-only:** Agrega nuevas hipótesis, no edites previas. Si cambias estado, nota fecha y razón.
2. **Plazo explícito:** Cada hipótesis debe tener fecha de próxima revisión.
3. **No dilatar:** Si hipótesis expira (plazo pasó sin validar), marcar `expired`.
4. **Alternativas:** Si hipótesis rechazada, documentar qué usar en su lugar.

---

# Hipótesis activas

## A-001 — Primera unidad comercial sirve a colombianos en el exterior

- **Hipótesis:** El mercado primario target es colombianos residentes fuera de Colombia (geografía: por confirmar).
- **Tipo:** mercado, cliente
- **Fuente:** CURRENT_STATE.md línea 38: "asumida orientación a colombianos en exterior"; TINTO_MASTER_CONTEXT.md línea 20.
- **Evidencia necesaria:** Mínimo 10 conversaciones exploratorias con colombianos en exterior validando dolor/oportunidad. Datos de tráfico red fundadora en esa geografía.
- **Riesgo:** Mercado disperso geográficamente, múltiples marcos legales por país, diferentes idiomas o acentos. Puede ser ineficiente adquirir.
- **Responsable:** Andrés + Fundadora (datos de red).
- **Estado:** open
- **Fecha revisión:** (andres confirma) — MKT-001, MKT-002 deben resolver esto.
- **Decisión relacionada:** Guía DEC-001 (unidad comercial), pero nicho final pending MKT-004.
- **Nota:** Vigente pero sin confirmar geografía específica.

## A-002 — Oportunidad existe en intersección de finanzas + "estar en exterior"

- **Hipótesis:** Hay oportunidad en seguros, remesas, inversiones, bienes en Colombia, o similar para colombianos en exterior. Opción específica pending decisión.
- **Tipo:** mercado, problema, oferta
- **Fuente:** CURRENT_STATE.md línea 39-40 "múltiples opciones propuestas (bienes en Colombia, remesas, seguros)"; TINTO_MASTER_CONTEXT.md línea 20.
- **Evidencia necesaria:** Para CADA opción: entrevistas de descubrimiento (MKT-001), investigación competitiva (MKT-003), matriz priorización (MKT-004) separando urgencia/acceso/pago/encaje/viabilidad.
- **Riesgo:** Todas las opciones pueden fallar validación. Nicho final puede no ser viable (acceso bajo, poder pago bajo, mercado saturado, solución existente). Requiere preparer hipótesis alternativa.
- **Responsable:** Andrés + Claude Code (investigación MKT).
- **Estado:** open
- **Fecha revisión:** 2026-08-15 (MKT-004 debe estar completed).
- **Decisión relacionada:** Si se rechaza, reabre MKT-004 con nuevo set de opciones. Escalación Andrés.
- **Nota:** Hipótesis plural (multiples nichos siendo testados en paralelo conceptualmente, pero elegir uno).

## A-003 — Fundadora puede ser activo estratégico de confianza/autoridad

- **Hipótesis:** Experiencia de fundadora (biografia, portafolio, resultados previos) permite transferir confianza a cliente. Marca personal puede co-existir con TINTO.
- **Tipo:** marca, capacidad-fundadora
- **Fuente:** DECISION_LOG.md línea 14: "la fundadora genera confianza y cercanía"; PROJECT_RULES.md línea 7 "Usar la experiencia de la fundadora como activo de confianza"; CURRENT_STATE.md línea 68: "Datos de fundadora: trayectoria, experiencia, activos (CV, portfolio, histórico)" pendientes.
- **Evidencia necesaria:** Documento CV/biografía fundadora + portfolio publicable. Validación con Andrés sobre qué datos/activos usar. BRD-002 debe completar biografía marca personal.
- **Riesgo:** Si datos/activos débiles, marca personal no suma. O si conflicto intereses (fondadora tiene otros empleos/proyectos), confusión de dedicación.
- **Responsable:** Fundadora (datos) + Andrés (aprobación) + Claude Code (producción BRD-002).
- **Estado:** open
- **Fecha revisión:** 2026-08-10 (GOV-002 + BRD-002 deben estar en progreso).
- **Decisión relacionada:** DEC-002 (marca dos rieles). Hipótesis necesaria para actuar DEC-002.
- **Nota:** "(andres confirma)" datos fundadora — aún no incorporados.

## A-004 — Avatar IA puede multiplicar contenido bajo protocolo

- **Hipótesis:** Imagen/voz de fundadora autorizada en avatar IA (guiones, videos pre-grabados) puede ampliar reach sin cansar fundadora. Límite explícito: nunca live/diagnóstico/conversación sensible.
- **Tipo:** tecnología, operación
- **Fuente:** DECISION_LOG.md línea 25-28 "DEC-004 — Avatar IA como multiplicador" (APPROVED pero pending BRD-004 consentimiento); PROJECT_RULES.md línea 29 prohibe "Reemplazar interacciones humanas sensibles".
- **Evidencia necesaria:** BRD-004 debe documentar consentimiento fundadora (imagen, voz, tonalidad) + límites explícitos (qué avatar PUEDE hacer, qué NO).
- **Riesgo:** Avatar mal manejado viola confianza (deepfake risk, representación falsa, inautenticidad). O si límites no claros, alguien produce avatar sensibl (conferencia falsa) sin aprobación.
- **Responsable:** Fundadora (consentimiento) + Andrés (aprobación) + Codex (implementación técnica).
- **Estado:** open
- **Fecha revisión:** 2026-08-15 (BRD-004 debe estar completed).
- **Decisión relacionada:** DEC-004 (aprobado, pending ejecución).
- **Nota:** Decisión de usar avatar es aprobada. Ejecución pending BRD-004.

## A-005 — Buyer persona será caracterizado via conversaciones reales, no datos secundarios

- **Hipótesis:** Persona target será definida por entrevistas exploratorias (MKT-001, MKT-003) con prospectos reales, NO por investigación de desk únicamente.
- **Tipo:** cliente, mercado
- **Fuente:** PROJECT_RULES.md línea 6 "Validar problemas con conversaciones"; MKT-005 "Construir buyer persona prioritario" objetivo es conversaciones; STRATEGIC_GUARDRAILS.md línea 320-323 "Indicadores de falta evidencia": "Buyer persona basada en supuestos, no en datos".
- **Evidencia necesaria:** MKT-005 debe documentar N ≥ 5 entrevistas transcripted (o notas detalladas) con personas en segmento target, validando pain points, motivaciones, objeciones, disposición pago.
- **Riesgo:** Si entrevistas superficiales o no reales, buyer persona será fantasía. Contenido y oferta alineados a fantasía fallan.
- **Responsable:** Claude Code (diseño entrevistas MKT-001), Fundadora (ejecución conversaciones), Auditor (validación).
- **Estado:** open
- **Fecha revisión:** 2026-08-20 (MKT-005 debe estar in_progress o agent_review).
- **Decisión relacionada:** Refuerza PROJECT_RULES línea 6.
- **Nota:** Criterio de no-confundir "engagement con validación" de STRATEGIC_GUARDRAILS línea 20.

## A-006 — Primer país de validación será elegido por acceso red fundadora + viabilidad operativa

- **Hipótesis:** Geografía inicial (USA, España, Canadá, otro) será elegida donde: (1) fundadora tiene red real, (2) poder pago suficiente, (3) no requiera stack legal complex.
- **Tipo:** mercado, cliente, operación
- **Fuente:** MKT-002 "Definir primer país de validación"; CURRENT_STATE.md línea 40 "Geografía: (andres confirma)"; STAGE_GATES.md línea 69 "País de validación seleccionado (geografía, acceso, capacidad)".
- **Evidencia necesaria:** MKT-002 debe listar 3+ opciones de países, evaluados por: acceso (¿fundadora o cercanos viven?), poder pago (ingreso, USD/EUR vs COP), complejidad legal/impuestos.
- **Riesgo:** Elegir país sin acceso red = dificultad atraer prospectos primeros. O elegir país poder pago bajo = margen insuficiente.
- **Responsable:** Andrés + Fundadora (datos de red), Claude Code (investigación MKT-002).
- **Estado:** open
- **Fecha revisión:** 2026-08-15 (MKT-002 debe estar completed).
- **Decisión relacionada:** Ninguna formal yet. Pending MKT-002 completion.
- **Nota:** "(andres confirma)" geografía — crítica para inversión, acceso legal, conversaciones.

## A-007 — Oferta inicial será validable sin tech custom

- **Hipótesis:** Promesa/entregables pueden cumplirse con herramientas existentes (sesiones Zoom, Google Docs, auditorías custom, seguimiento email). No requiere app/plataforma MVP.
- **Tipo:** operación, tecnología, oferta
- **Fuente:** DEC-003 "No desarrollar plataforma en MVP"; STAGE_GATES.md línea 129-134 "Evidencia mínima: Entregables concretos (sesiones, auditorías, guías)".
- **Evidencia necesaria:** PRD-001, PRD-002, PRD-003 deben describir entregables muy específicamente (p.e., "4 sesiones 90min Zoom + 2 auditorías async + 1 guía custom"). Cada entregable mapeado a herramienta existente.
- **Riesgo:** Si entregables requieren automation/integraciones custom, va contra DEC-003. Escala operacional rápido.
- **Responsable:** Claude Code (producto), Codex (validación técnica), Andrés (aprobación).
- **Estado:** open
- **Fecha revisión:** 2026-08-31 (PRD-003 debe estar completed).
- **Decisión relacionada:** Refuerza DEC-003.
- **Nota:** Restricción: PRD debe ser satisfacible manual/herramientas terceras.

## A-008 — Marca personal y TINTO coexisten sin confundirse

- **Hipótesis:** Fundadora es cara de confianza (marca personal). TINTO es arquitectura de productos/servicios/embudo. Dos rieles: se refuerzan pero no se mezclan.
- **Tipo:** marca, operación
- **Fuente:** DECISION_LOG.md línea 12-15 "DEC-002 — Marca personal y TINTO funcionan como dos rieles"; PROJECT_RULES.md línea 8 "Separar marca personal y TINTO sin desconectarlas"; STRATEGIC_GUARDRAILS.md línea 305 "Marca personal y TINTO se desconectan" es riesgo.
- **Evidencia necesaria:** BRD-001, BRD-002, BRD-003 deben documentar: (1) Brief marca personal (tono, autoridad, alcance), (2) Brief TINTO (misión, valores, diferenciales), (3) Arquitectura (cómo interactúan, dónde se refuerzan, dónde no se mezclan).
- **Riesgo:** Si confundidas, cliente confundido (¿Estoy comprando a ella o a TINTO?). O si desconectadas, no hay sinergia.
- **Responsable:** Fundadora (validación marca personal), Andrés (aprobación), Claude Code (arquitectura BRD-001).
- **Estado:** open
- **Fecha revisión:** 2026-08-25 (BRD-001 debe estar completed).
- **Decisión relacionada:** DEC-002. Restricción no-negociable.
- **Nota:** Crítica para coherencia marca. Sin claridad, contenido + ventas fallan.

## A-009 — Primer objetivo (100 leads) validará mercado sin certeza de pago

- **Hipótesis:** Conseguir 100 leads + 10+ conversaciones cualisimas valida existencia de oportunidad. Pero pago (3+ clientes) demostrará viabilidad REAL.
- **Tipo:** mercado, cliente
- **Fuente:** DECISION_LOG.md línea 30-35 "DEC-005 — Primer objetivo comercial" (PROPOSED) "conseguir 100 leads, validar mensajes, generar oportunidades comerciales"; STAGE_GATES.md línea 91 "(andres confirma) conversaciones reales o datos de fundadora".
- **Evidencia necesaria:** VAL-001-VAL-004 (ejecución comercial) + SAL-001-SAL-003 (cierre) deben generar: 100+ leads recolectados, 10+ conversaciones con criterios AC, 3+ clientes pagos (dinero recibido).
- **Riesgo:** Si alcanza 100 leads pero 0 pago, hipótesis rechazada (problema no es critical, poder pago bajo, o positioning débil). Requiere pivot.
- **Responsable:** Fundadora (ejecución), Andrés (decisión siguiente pasos), Auditor (validación métrica).
- **Estado:** open
- **Fecha revisión:** 2026-10-31 (VAL stage debe estar en ejecución).
- **Decisión relacionada:** DEC-005. Métrica de viabilidad.
- **Nota:** Hipótesis de mercado. Métrica de GO/NO-GO para expansión.
