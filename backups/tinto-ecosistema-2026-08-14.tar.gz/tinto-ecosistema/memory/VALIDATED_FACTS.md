---
document: TINTO Validated Facts
version: 0.1.0
status: active
last_updated: 2026-07-27
---

# Hechos validados del proyecto TINTO

## Propósito

Registrar únicamente hechos respaldados por evidencia real o decisiones aprobadas. Un hecho validado es comprobable en el repositorio o en documentos controlados.

## Qué califica como hecho validado

- Archivo existe y es accesible en repo.
- Commit está registrado en git.
- Decisión está aprobada en DECISION_LOG.md.
- Documento completado por productor + aprobado por revisor.
- Métrica observada (N leads, N clientes pagos, resultado de test).
- Capacidad demostrada (sistema funciona, comando ejecuta).

## Qué NO califica

- Supuesto sobre datos de fundadora sin documento.
- País elegido sin MKT-002 completado.
- Buyer persona sin entrevistas.
- Oferta sin PRD-003 aprobado.
- Métrica sin registro en roadmap-status.md.
- Capacidad de fundadora sin CV/portfolio.
- Presupuesto "estimado" sin presupuesto formal aprobado.

## Diferencias

| Tipo | Definición | Ejemplo | Dónde va |
|------|-----------|---------|----------|
| **Hecho** | Validado por evidencia repo | "Repositorio Git existe" | VALIDATED_FACTS.md |
| **Decisión** | Aprobada por Andrés | "Una unidad comercial (DEC-001)" | DECISION_LOG.md |
| **Hipótesis** | Supuesto sin validar | "Nicho será bienes" | ASSUMPTIONS.md |
| **Aprendizaje** | Conclusión de trabajo real | "Dashboard manual no controla" | LEARNINGS.md |

## Estados

- **active:** Hecho continúa siendo verdad. Usado en operación.
- **superseded:** Reemplazado por hecho más reciente.
- **revoked:** Probado falso. Se rechaza.

## Campos mínimos

1. **ID:** VF-001, VF-002, etc.
2. **Hecho:** Enunciado específico.
3. **Fuente:** Archivo, commit, ticket completado.
4. **Ticket:** De dónde viene (GOV-001, STR-001, etc).
5. **Fecha:** Cuándo se validó.
6. **Alcance:** A qué se aplica (proyecto total, stage específico, etc).
7. **Decisión relacionada:** Si afecta DEC.
8. **Estado:** active | superseded | revoked.

## Reglas de admisión

1. **Evidencia clara:** Link exacto a archivo/línea/commit donde se ve.
2. **Aprobación:** Si decisión, debe estar en DECISION_LOG.md. Si documento, debe estar completed + aprobado.
3. **No generalizaciones:** "Sistema funciona" no. "Auditoría SCHEMA-AUDIT-FINAL-001 resultado pass" sí.
4. **Fecha exacta:** Cuándo se validó (no hoy si fue antes).

## Reglas de actualización

1. **Append-only:** Agrega nuevos hechos, no edites previos.
2. **Superseded:** Si hecho cambia (p.e., "nicho fue A, ahora es B"), marca anterior superseded, agrega nuevo.
3. **Revoked:** Si se probó falso, marca revoked + razón.

---

# Hechos validados actuales

## VF-001 — Repositorio tinto-ecosistema es Git controlado

- **Hecho:** Repositorio tinto-ecosistema existe, está bajo control git, con commits registrados.
- **Fuente:** Repositorio en `/Users/work945/Documents/Proyectos/ABM/proyectos/tinto-ecosistema/.git`; commits visibles en `git log`.
- **Ticket:** GOV-001
- **Fecha:** 2026-07-23 (GOV-001 completed)
- **Alcance:** Proyecto total. Baseline operativa.
- **Decisión relacionada:** Ninguna (hecho base).
- **Estado:** active

## VF-002 — Rama feature/tinto-guardian-core-v0.2.0 existe y es activa

- **Hecho:** Rama `feature/tinto-guardian-core-v0.2.0` fue creada, tiene commits, está disponible para checkout.
- **Fuente:** Output de `git status` — "Current branch: feature/tinto-guardian-core-v0.2.0".
- **Ticket:** GOV-001
- **Fecha:** 2026-07-23
- **Alcance:** Sistema multiagente v0.2.0 se construye en esta rama.
- **Decisión relacionada:** Ninguna.
- **Estado:** active

## VF-003 — Estructura de carpetas y archivos maestros existen

- **Hecho:** Existen archivos maestros: PROJECT_RULES.md, DECISION_LOG.md, roadmap.md, roadmap-status.md, AGENTS.md, CLAUDE.md.
- **Fuente:** Lectura directa 2026-07-27.
- **Ticket:** GOV-001
- **Fecha:** 2026-07-23
- **Alcance:** Infraestructura base del proyecto.
- **Decisión relacionada:** Ninguna.
- **Estado:** active

## VF-004 — DECISION_LOG.md contiene 5 decisiones aprobadas

- **Hecho:** DECISION_LOG.md registra 5 decisiones: DEC-001 (una unidad comercial), DEC-002 (marca dos rieles), DEC-003 (no plataforma MVP), DEC-004 (avatar IA), DEC-005 (primer objetivo 100 leads, PROPOSED).
- **Fuente:** DECISION_LOG.md línea 3-35.
- **Ticket:** GOV-001
- **Fecha:** 2026-07-23
- **Alcance:** Decisiones estructurales aprobadas o propuestas.
- **Decisión relacionada:** Todas. Son fuente de verdad operativa.
- **Estado:** active

## VF-005 — Dashboard operativo local funciona

- **Hecho:** Dashboard visual (Kanban, tabs, edición local) existe, carga en navegador, botones y visualización funcionan.
- **Fuente:** Capturas de pantalla o verificación manual; descrita en CURRENT_STATE.md línea 14.
- **Ticket:** GOV-001
- **Fecha:** 2026-07-23
- **Alcance:** Interfaz operativa v0.2.0 (manual, local).
- **Decisión relacionada:** Ninguна. Herramienta de soporte.
- **Estado:** active

## VF-006 — Agentes tinto-supervisor y quality-auditor fueron creados e indexados

- **Hecho:** Archivos `.claude/agents/tinto-supervisor.md` y `.claude/agents/quality-auditor.md` existen y definen protocolos de operación.
- **Fuente:** Lectura directa de archivos (vía mención en conversación, no leído completo esta sesión).
- **Ticket:** Descripción en contexto de auditoría SCHEMA-AUDIT-FINAL-001.
- **Fecha:** Antes 2026-07-27 (fecha esta auditoría)
- **Alcance:** Sistema multiagente v0.2.0.
- **Decisión relacionada:** Ninguна. Herramientas operativas.
- **Estado:** active

## VF-007 — Tres skills Codex fueron producidas y auditadas

- **Hecho:** Skills de Codex en `.codex/skills/tinto-business-incubator/` (SKILL.md, TICKET_PROTOCOL.md, TECHNICAL_QA.md) fueron producidas, auditadas contra 13 criterios explícitos, resultado: **pass**.
- **Fuente:** Auditoría SCHEMA-AUDIT-001 (sesión anterior) resultado: pass. Auditoría SCHEMA-AUDIT-FINAL-001 (sesión actual) confirmó: pass.
- **Ticket:** Implícito en setup TINTO Guardian v0.2.0.
- **Fecha:** 2026-07-27
- **Alcance:** Infraestructura de gobernanza v0.2.0.
- **Decisión relacionada:** Ninguна. Son tools de operación.
- **Estado:** active

## VF-008 — Cuatro esquemas JSON fueron producidos, validados con Node, aprobados

- **Hecho:** DELIVERABLE_SCHEMA.json, QA_REPORT_SCHEMA.json, HUMAN_APPROVAL_SCHEMA.json, ticket-router.json fueron producidos, validados contra 17 criterios explícitos, resultado: **pass**.
- **Fuente:** Auditoría SCHEMA-AUDIT-FINAL-001 (sesión actual) resultado: pass.
- **Ticket:** Implícito en setup TINTO Guardian v0.2.0.
- **Fecha:** 2026-07-27
- **Alcance:** Infraestructura de workflow v0.2.0.
- **Decisión relacionada:** Ninguна. Son tools de operación.
- **Estado:** active

## VF-009 — Operación implementada como manual (no automatizada) durante v0.2.0

- **Hecho:** Sistema operativo v0.2.0 es completamente manual: transiciones de estado, aprobaciones, asignaciones todas requieren intervención humana. No existe runtime automatizado. Integración dashboard automatizada corresponde a v0.3.0 (futuro, fuera scope Bloque 1).
- **Fuente:** WORKFLOW_PROTOCOL.md línea 6-9 "Esta protocolo está **diseñado para validación humana**. Durante `v0.2.0`... estados se administran manualmente"; ticket-router.json línea 240-245 "manualOperation enabled=true, dashboardIntegration=false, v020Only=true".
- **Ticket:** GOV-001, implícito en DEC-003.
- **Fecha:** 2026-07-27
- **Alcance:** Operación MVP, Bloque 1 v0.2.0.
- **Decisión relacionada:** Refuerza DEC-003 "No plataforma MVP".
- **Estado:** active

## VF-010 — GOV-001 completado (estado comprobable en roadmap)

- **Hecho:** Ticket GOV-001 (Validar estructura inicial del repositorio) completado según CURRENT_STATE.md y roadmap.md.
- **Fuente:** CURRENT_STATE.md línea 21 "GOV-001: Validar estructura inicial — **COMPLETED**"; roadmap.md línea 7-20.
- **Ticket:** GOV-001
- **Fecha:** 2026-07-23
- **Alcance:** Stage 0 — Gobernanza. Estructura y fuentes de verdad aprobadas.
- **Decisión relacionada:** Hito baseline del proyecto.
- **Estado:** active

## VF-011 — Sistema multiagente esquemas y skills producidos, auditados resultado pass

- **Hecho:** Cuatro esquemas JSON y tres skills Codex fueron producidos, parseados validamente, auditados contra criterios explícitos, resultado final: pass.
- **Fuente:** 
  - Auditoría SCHEMA-AUDIT-FINAL-001 resultado: pass (línea: "RESULTADO CANÓNICO: **pass**").
  - Archivos verificables: DELIVERABLE_SCHEMA.json, QA_REPORT_SCHEMA.json, HUMAN_APPROVAL_SCHEMA.json, ticket-router.json, .codex/skills/tinto-business-incubator/SKILL.md, TICKET_PROTOCOL.md, TECHNICAL_QA.md.
- **Ticket:** Implícito en setup TINTO Guardian v0.2.0.
- **Fecha:** 2026-07-27
- **Alcance:** Infraestructura de gobernanza y workflow v0.2.0.
- **Decisión relacionada:** Ninguna. Son tools de operación.
- **Estado:** active

## VF-012 — DECISION_LOG.md contiene 5 decisiones registradas (4 aprobadas, 1 propuesta)

- **Hecho:** DECISION_LOG.md registra DEC-001 (APPROVED), DEC-002 (APPROVED), DEC-003 (APPROVED), DEC-004 (APPROVED), DEC-005 (PROPOSED).
- **Fuente:** DECISION_LOG.md línea 3-35.
- **Ticket:** GOV-001
- **Fecha:** 2026-07-23
- **Alcance:** Decisiones estructurales. Registro oficial de aprobaciones.
- **Decisión relacionada:** Todas (son fuente de verdad operativa).
- **Estado:** active
