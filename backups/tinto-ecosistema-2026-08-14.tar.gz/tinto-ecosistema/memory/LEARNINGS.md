---
document: TINTO Learnings
version: 0.1.0
status: active
last_updated: 2026-07-27
---

# Aprendizajes del proyecto TINTO

## Propósito

Registrar aprendizajes derivados del trabajo real ejecutado en TINTO. Un aprendizaje es una conclusión derivada de experiencia documentada, no una hipótesis o esperanza.

## Qué sí es aprendizaje

- Conclusión derivada de trabajo real ejecutado.
- Patrón recurrente observado en ejecución.
- Restricción descubierta en práctica.
- Efecto de decisión aprobada después de implementarla.

## Qué no es aprendizaje

- Hipótesis futura.
- Teoría sin evidencia en repo.
- Decisión aprobada (→ DECISION_LOG.md).
- Hecho validado (→ VALIDATED_FACTS.md).
- Supuesto sobre fundadora, mercado, clientes.

## Estructura obligatoria

```
L-XXX — [Título]
- Fecha: ISO-8601
- Fuente: Ticket/Documento
- Aprendizaje: Frase concisa
- Evidencia: Dónde se ve en repo
- Impacto: Cambio operativo
- Decisión relacionada: DEC o guardrail
- Siguiente acción: Qué hacemos
- Estado: active | superseded | invalidated
```

## Estados

- **active:** Vigente, aplicable en operación.
- **superseded:** Reemplazado por aprendizaje más reciente.
- **invalidated:** Probado falso, rechazado.

---

# Aprendizajes actuales

## L-001 — Separación productor ≠ auditor ≠ aprobador es no-negociable

- **Fecha:** 2026-07-27
- **Fuente:** Auditoría SCHEMA-AUDIT-FINAL-001; QA_REPORT_SCHEMA.json; DELIVERABLE_SCHEMA.json; ROLE_MATRIX.md
- **Aprendizaje:** Auto-cierre (productor marca propio trabajo completado) abre puerta a errores. Requiere independencia verificable en schema y proceso.
- **Evidencia:** 
  - DELIVERABLE_SCHEMA.json línea 232-243: productor nunca produce `completed`.
  - QA_REPORT_SCHEMA.json línea 302-313: idem.
  - ROLE_MATRIX.md línea 11-17: "Separación de funciones."
  - ticket-router.json línea 141-146: independenceRules (5 reglas).
- **Impacto:** Todo ticket requiere revisión antes de completado. Productor registra en comments/, espera revisor independiente.
- **Decisión relacionada:** AGENTS.md § "Regla de no auto-aprobación" (línea 168-173).
- **Siguiente acción:** Protocolo obligatorio en WORKFLOW_PROTOCOL.md.
- **Estado:** active

## L-002 — Sin aprobación manual explícita, documentos quedan huérfanos

- **Fecha:** 2026-07-27
- **Fuente:** WORKFLOW_PROTOCOL.md línea 6-9; CURRENT_STATE.md
- **Aprendizaje:** Dashboard visual sin workflow manual es teatro. Documentos existen pero sin decisión en DECISION_LOG o aprobación en human_review quedan en limbo.
- **Evidencia:**
  - WORKFLOW_PROTOCOL.md línea 6-9: "v0.2.0 estados se administran manualmente."
  - CURRENT_STATE.md línea 77-78: "STR-001: PENDING." Documento existe pero ticket pending.
  - roadmap-status.md vacío (solo header), cero registros.
- **Impacto:** Cada ticket requiere: (1) archivo producido, (2) entrada comments/[TICKET-ID].jsonl, (3) entrada roadmap-status.md, (4) aprobación registrada. Sin 4, bloqueado.
- **Decisión relacionada:** Refuerza DEC-003 "MVP sin plataforma" → operación manual explícita.
- **Siguiente acción:** Auditor verifica 4 registros antes de marcar completed.
- **Estado:** active

## L-003 — Datos no confirmados deben marcarse `(andres confirma)` y no continuarse

- **Fecha:** 2026-07-27
- **Fuente:** CURRENT_STATE.md línea 38-42; CLAUDE.md línea 73; PROJECT_RULES.md línea 27
- **Aprendizaje:** Continuar sin confirmación causa desperdicio (documentos incoherentes, retrabajos). Pausa + confirmación es más rápida que retrabajo.
- **Evidencia:**
  - CURRENT_STATE.md línea 38-42: 6 campos marcados "(andres confirma)" (mercado, nicho, geografía, buyer persona).
  - PROJECT_RULES.md línea 27: "Inventar datos de fundadora" → NO.
  - AGENTS.md línea 81: "Si falta información, escribir `(andres confirma)`. No adivinar."
- **Impacto:** Crear entrada comments/[TICKET-ID].jsonl "BLOQUEADO: falta (andres confirma) [datos]" antes de producir documento incierto.
- **Decisión relacionada:** Refuerza guardrail STRATEGIC_GUARDRAILS.md línea 19: "No invención de datos."
- **Siguiente acción:** Auditor rechaza ticket que continúa sin confirmación.
- **Estado:** active

## L-004 — Documentos y decisiones son memoria, no chat

- **Fecha:** 2026-07-27
- **Fuente:** DECISION_LOG.md línea 23-26; AGENTS.md línea 204-223; PROJECT_RULES.md línea 12-13; CLAUDE.md línea 26-27
- **Aprendizaje:** Información crítica debe estar en repo (DECISION_LOG, roadmap, archivos) para ser válida. Chat es efímero. Agentes que leen chat no repo cometen errores.
- **Evidencia:**
  - DECISION_LOG.md línea 23-26: explícito.
  - TINTO_MASTER_CONTEXT.md línea 119: "Decisiones en conversaciones, no en DECISION_LOG.md" es riesgo activo.
- **Impacto:** Protocolo obligatorio lectura (AGENTS.md línea 20-29): antes de cualquier ticket, lee DECISION_LOG, PROJECT_RULES, roadmap, CURRENT_STATE, comments/[TICKET-ID].jsonl. Chat solo escalación.
- **Decisión relacionada:** Refuerza jerarquía de fuentes (AGENTS.md línea 11-18).
- **Siguiente acción:** Entrenamientos agentes: lectura repo-first.
- **Estado:** active

## L-005 — Reglas "No" son restricciones operacionales, no sugerencias

- **Fecha:** 2026-07-27
- **Fuente:** PROJECT_RULES.md § "No" (línea 17-30); STRATEGIC_GUARDRAILS.md § "Acciones prohibidas" (línea 54-66)
- **Aprendizaje:** Reglas marcadas "No" o "Prohibido" son bloqueantes. Violarlas causa rediseño o escalación cliente. No son trade-offs.
- **Evidencia:**
  - PROJECT_RULES.md línea 19: "No construir todas verticales simultaneamente." (DEC-001)
  - PROJECT_RULES.md línea 22: "No prometer rentabilidad."
  - PROJECT_RULES.md línea 29: "No inventar nombres, precios, fechas, datos fundadora."
  - STRATEGIC_GUARDRAILS.md línea 55: "🔴 Rojo automático: Activar nueva vertical sin DEC formal."
- **Impacto:** Auditor rechaza ticket si viola regla "No". Escalación requerida, no discusión.
- **Decisión relacionada:** DEC-001, DEC-003, DEC-004. Refuerza TINTO Guardian línea 13.
- **Siguiente acción:** Agentes verifican "No" list antes de producir.
- **Estado:** active

## L-006 — Git + roadmap-status.md + comments/[TICKET-ID].jsonl = control operativo

- **Fecha:** 2026-07-27
- **Fuente:** WORKFLOW_PROTOCOL.md línea 1-21; roadmap-status.md estructura; AGENTS.md línea 119-122
- **Aprendizaje:** Auditoría visual sin logs = pérdida trazabilidad. Sistema requiere 3 capas: (1) archivo versionado git, (2) entrada evento roadmap-status.md con timestamp, (3) comentario técnico comments/[TICKET-ID].jsonl. Todas obligatorias.
- **Evidencia:**
  - AGENTS.md línea 175-200 "Protocolo entrega": 4 pasos (roadmap-status.md, deliveries/, comments/, no completed).
  - WORKFLOW_PROTOCOL.md línea 79-89: "Crea entrada roadmap-status.md."
  - roadmap-status.md existe, formato definido, vacío (2026-07-27).
- **Impacto:** Auditor verifica 3 capas. Si falta una, rechazado como incompleto.
- **Decisión relacionada:** Refuerza L-002. L-002 decisión humana; L-006 trazabilidad técnica.
- **Siguiente acción:** Validaciones roadmap-status.md reader + comments validator.
- **Estado:** active


## L-008 — Cambios estructurales requieren DECISION_LOG nuevo antes de ejecución, no después

- **Fecha:** 2026-07-27
- **Fuente:** AGENTS.md línea 204-223; CLAUDE.md § "Protocolo contradicciones"
- **Aprendizaje:** Si descubrimiento cambia estrategia (nicho nuevo, precio nuevo, stack nuevo), requiere DECISION_LOG DEC nueva antes de ejecutar. Ejecutar primero, documentar después invita error.
- **Evidencia:**
  - CLAUDE.md línea 59-65: "Protocolo contradicciones" punto 1 "No continuar hasta claridad."
  - AGENTS.md línea 82: "Agente no puede abrir verticales nuevas. Solo Andrés."
  - STRATEGIC_GUARDRAILS.md § "Criterios": punto 1 "¿Existe en roadmap.md?" No → rojo.
- **Impacto:** Auditor rechaza documento propone cambio sin DEC aprobada. Ticket sale in_progress, vuelve ready, requiere Andrés DECISION_LOG antes continuar.
- **Decisión relacionada:** Refuerza DECISION_LOG línea 23-26.
- **Siguiente acción:** Protocolo escalación obligatorio cuando hallazgo sugiere cambio.
- **Estado:** active


## L-010 — Avatar IA requiere consentimiento documentado y límites explícitos

- **Fecha:** 2026-07-27
- **Fuente:** DECISION_LOG.md línea 25-28; BRD-004 pending; STAGE_GATES.md línea 143-147
- **Aprendizaje:** Avatar IA permitido (DEC-004) pero **nunca** reemplaza conversaciones sensibles (lives, diagnósticos, conferencias). Consentimiento image/voz documentado. Sin BRD-004 aprobado, no activable.
- **Evidencia:**
  - DECISION_LOG.md línea 28: "Lives, conferencias, diagnósticos por fundadora directamente."
  - PROJECT_RULES.md línea 29: "Reemplazar interacciones humanas sensibles" → NO.
  - STAGE_GATES.md línea 143-147: BRD-004 fundadora validación antes activación.
  - BRD-004 pending, sin consentimiento documentado.
- **Impacto:** Ticket usa avatar rechazado si BRD-004 no completed. Auditor verifica antes production.
- **Decisión relacionada:** DEC-004. Restricción no-negociable.
- **Siguiente acción:** BRD-004 crítica antes cualquier producción avatar.
- **Estado:** active
