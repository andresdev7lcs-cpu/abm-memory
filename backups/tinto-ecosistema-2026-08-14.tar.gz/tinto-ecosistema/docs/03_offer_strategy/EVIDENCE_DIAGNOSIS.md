---
document: TINTO Bloque 3 — Diagnóstico de evidencia y consolidación
version: 1.0
ticket: STR-001
producer: claude-code
status: agent_review
date: 2026-07-28
---

# Diagnóstico y consolidación de evidencia existente para TINTO Bloque 3

> Resumen ejecutivo para definir la primera oferta comercial de TINTO. Inventario de lo sabido, lo aprobado, lo hipotético, lo faltante.

---

## A. Resumen ejecutivo

**Qué sabemos (aprobado):**
- Una unidad comercial única (DEC-001).
- Marca personal + TINTO como dos rieles (DEC-002).
- MVP sin plataforma propia (DEC-003).
- Avatar IA bajo protocolo y consentimiento (DEC-004).
- Bloque 1 cerrado; operación v0.2.0 manual, sin runtime automatizado.

**Qué está propuesto (pendiente aprobación Andrés):**
- Primer objetivo: validación comercial con leads y clientes reales (DEC-005, PROPOSED).

**Qué fue decidido:**
- Separación productor ≠ auditor ≠ aprobador (LEARNINGS L-001).
- Documentación antes de ejecución (LEARNINGS L-004).
- Datos faltantes marcados (andres confirma), no inventados (LEARNINGS L-003).
- Una sola unidad comercial (no múltiples verticales) (DEC-001).

**Qué sigue siendo hipótesis:**
- Mercado primario: colombianos en exterior (A-001, open).
- Oportunidad en servicios o acompañamiento relacionados con finanzas, patrimonio o activos (A-002, open).
- Fundadora como activo de confianza: experiencia, credenciales, casos, red, capacidad (A-003, open, datos pendientes).
- Avatar IA multiplicará contenido bajo protocolo (A-004, open, pending BRD-004).
- Buyer persona identificado vía conversaciones reales (A-005, open).
- País de validación elegido por acceso y viabilidad (A-006, open).
- Oferta validable manual sin tech custom (A-007, open).
- Marca personal + TINTO coherentes (A-008, open).
- Validación comercial mediante conversaciones reales y pago confirmado (A-009, open).

**Qué evidencia falta:**
- Datos de fundadora: CV, portfolio, trayectoria (GOV-002 pending).
- Conversaciones reales con colombianos en exterior (MKT-001 pending).
- Investigación competitiva (MKT-003 pending).
- Nicho priorizado entre opciones (MKT-004 pending).
- Buyer persona con validación (MKT-005 pending).
- Marca personal definida (BRD-002 pending).
- Marca TINTO definida (BRD-003 pending).
- Avatar IA protocolo y consentimiento (BRD-004 pending).
- Primera oferta (PRD-003 pending).

**Qué podemos producir ahora:**
1. Consolidación de decisiones aprobadas vs hipótesis (este documento).
2. Matriz de evidencia (tema → afirmación → clasificación → fuente → calidad → implicación).
3. Territorios de exploración amplios (basados en hipótesis A-001, A-002, sin nombres específicos).
4. Brechas críticas priorizado (qué bloquea decisiones).
5. Activos existentes documentados (experiencia, reputación, red, capacidad).
6. Preguntas para Andrés de alta influencia (datos + decisiones).
7. Gate recomendado (confirmación de capacidad + decisión unidad comercial).

**Qué no puede aprobarse todavía:**
- País definido (requiere MKT-002).
- Buyer persona validado (requiere MKT-005).
- Nicho final (requiere MKT-004).
- Precio (requiere PRD-003 + validación).
- Primera oferta (requiere PRD-001, PRD-002, PRD-003).
- Promoción o publicidad (requiere Gate 2).
- Anuncios públicos (requiere Gate 2).
- Nuevas verticales (requiere DEC nueva).

---

## B. Matriz de evidencia

Clasificaciones: `[APROBADO]` = DECISION_LOG.md. `[EVIDENCIA]` = dato comprobable. `[HIPÓTESIS]` = supuesto abierto. `(andres confirma)` = información crítica faltante.

| Tema | Afirmación | Clasificación | Fuente | Calidad evidencia | Implicación | Próxima validación |
|------|-----------|----------------|--------|------------------|-------------|-------------------|
| **Propósito de TINTO** | Conservar memoria estratégica; visión amplia, ejecución estrecha; una sola unidad comercial | [APROBADO] | DEC-001, TINTO_MASTER_CONTEXT.md línea 18-20 | Alta | Bloque 3 debe enfocar una unidad, no múltiples verticales | Respetado en roadmap |
| **Colombianos en el exterior** | Mercado primario target asumido | [HIPÓTESIS] | CURRENT_STATE.md línea 38, A-001 | Media | Oportunidad real existe pero no validada | MKT-001, MKT-002 valida acceso y demanda |
| **Experiencia, credenciales, red de fundadora** | Trayectoria, casos, autoridad, activos de confianza, capacidad de entrega | (andres confirma) | Referencia CURRENT_STATE.md línea 68 | Inexistente | Sin datos no puedo construir marca personal | GOV-002: incorporar fuentes; Andrés confirma |
| **Oportunidad en servicios/acompañamiento financiero** | Existe potencial en servicios o asesoría relacionada con finanzas, patrimonio, activos | [HIPÓTESIS] | A-002, CURRENT_STATE.md línea 39 | Media | Requiere priorizar un territorio de exploración | MKT-001, MKT-003, MKT-004 elige uno |
| **Primera unidad comercial** | Una sola unidad validable en MVP | [APROBADO] | DEC-001: "construir una sola unidad comercial" | Alta | No se pueden activar múltiples verticales ahora | Mantener scope estrecho |
| **Foco estrecho** | Énfasis en especificidad, no generalidad | [APROBADO] | PROJECT_RULES.md línea 5, STRATEGIC_GUARDRAILS.md línea 11 | Alta | Buyer, problema, oferta deben ser específicos | QG-02 Especificidad validará |
| **Marca personal** | Fundadora como activo de confianza | [APROBADO] | DEC-002, PROJECT_RULES.md línea 7 | Alta | Narrativa de marca requiere CV/portfolio | BRD-002 requiere GOV-002 |
| **Marca corporativa TINTO** | Identidad separada de marca personal, coherente | [APROBADO] | DEC-002: "dos rieles" | Alta | Messaging, tonalidad, valores requieren definición | BRD-003 define identidad |
| **Avatar IA** | Imagen/voz autorizadas como multiplicador | [APROBADO] | DEC-004, LEARNINGS L-010 | Alta | Límites explícitos: no lives, no sensibles | BRD-004 consentimiento necesario |
| **País inicial** | País de validación por acceso red fundadora | [HIPÓTESIS] | A-006, STAGE_GATES.md línea 69 | Baja | Sin geografía no puedo orientar MKT | MKT-002: elegir país según acceso |
| **Buyer persona** | Persona específica con rol, ingresos, ubicación, dolor | [HIPÓTESIS] | A-005, MKT-005 pending | Baja | Buyer persona es requement critical para todo | MKT-001: conversaciones reales para identificar |
| **Problema prioritario** | Problema específico con urgencia, frecuencia, impacto | [HIPÓTESIS] | SKILL.md § diagnóstico | Baja | Define oferta, pricing, messaging | MKT-001, MKT-005 valida con buyers reales |
| **Capacidad de entrega** | Fundadora puede entregar manualmente sin tech propia | [HIPÓTESIS] | A-007, DEC-003 | Baja | PRD requiere confirmación operativa | PRD-001, PRD-002, PRD-003 especifican entregables |
| **Oferta** | Promesa específica, entregables, precio, transformación | (andres confirma) | Roadmap PRD-001, PRD-002, PRD-003 pending | Inexistente | Sin oferta no hay validación comercial | PRD-003: definir transformación, entregables |
| **Precio** | Modelo y moneda de pago | (andres confirma) | Roadmap PRD-003 pending | Inexistente | Requiere disposición de pago validada + ecuación valor | PRD-003 + validación buyer conversaciones |
| **Canales** | Dónde contactar buyer | [HIPÓTESIS] | FRAMEWORKS.md § trigger events | Media | Trigger events definen timing | MKT-001, MKT-005 identifican canales reales |
| **Evento de conversión** | Cómo iniciar venta (diagnóstico, sesión, conversación, otro) | [HIPÓTESIS] | SKILL.md § eventos conversión, FRAMEWORKS.md | Media | Requiere validación con buyer real | FUN-002 elige evento |
| **Validación comercial** | Conversaciones reales con buyers + pago confirmado | [HIPÓTESIS] | A-009, validación operativa | Inexistente | Métrica viabilidad real | VAL-001 a VAL-004: ejecución |

---

## C. Decisiones ya tomadas

**Decisión estratégica (APROBADO):**

1. **DEC-001 — Una sola unidad comercial** (Bloque 1 validó separación productor/auditor/aprobador; Bloque 3 respeta esto).
   - Implicación: NO se activarán remesas Y bienes Y seguros en paralelo.
   - Restricción: elegir una, validar, luego expandir (Bloque 3 de Gate 2, futuro).

2. **DEC-002 — Marca personal + TINTO como dos rieles**.
   - Implicación: Fundadora es cara de confianza; TINTO es arquitectura operativa.
   - Restricción: BRD-001, BRD-002, BRD-003 deben coherencia sin desconexión.

3. **DEC-003 — No desarrollar plataforma en MVP**.
   - Implicación: Ofertas viables con Google Suite, Zoom, email, CRM tercero.
   - Restricción: PRD no puede exigir tech custom. Viabilidad manual en etapa inicial (hipótesis A-007).

4. **DEC-004 — Avatar IA como multiplicador**.
   - Implicación: Contenido guionizado, revisado; sin lives, diagnósticos, sensible.
   - Restricción: BRD-004 consentimiento documentado antes usar.

5. **DEC-005 — Validación comercial** (PROPOSED, pending aprobación Andrés).
   - Implicación: Requiere conversaciones reales + pago confirmado.
   - Restricción: Metodología, métricas, timeline (andres confirma).

**Estado actual:**
- Conversaciones reales con compradores potenciales: 0.
- Experiencia de fundadora verificada: (andres confirma).
- Competencia mapeada: No.
- Buyer persona específico: Pendiente.

**Hipótesis abiertas sin validar:**
- Colombianos en exterior tienen necesidades en servicios financieros o de patrimonio (A-001, A-002).
- Fundadora puede abordar una de estas necesidades (A-003).
- Hay disposición de pago real para soluciones (A-005, A-009).
- Oferta será validable manualmente (A-007).

---

## D. Hipótesis activas

Todas desde `memory/ASSUMPTIONS.md`, estado: **open** (sin validación iniciada).

| ID | Hipótesis | Tipo | Evidencia necesaria | Riesgo | Responsable | Ticket validación |
|----|-----------|------|-------------------|--------|-------------|-------------------|
| A-001 | Colombianos en exterior = mercado primario | Mercado | Conversaciones validando oportunidad + acceso red fundadora | Mercado disperso, múltiples marcos legales, costo adquisición alto | Andrés + Fundadora | MKT-002 |
| A-002 | Oportunidad en servicios/acompañamiento financiero | Mercado, oferta | MKT-001, MKT-003, MKT-004: explorar un territorio de servicios | Todas opciones fallan validación; solución existente; mercado saturado | Andrés + Claude Code | MKT-004 |
| A-003 | Fundadora es activo estratégico confianza/autoridad | Marca, capacidad | CV/biografía + casos + validación Andrés (GOV-002, BRD-002) | Datos débiles o insuficientes; dedicación limitada | Fundadora + Andrés | GOV-002, BRD-002 |
| A-004 | Avatar IA multiplica contenido bajo protocolo | Tecnología | BRD-004: consentimiento + límites explícitos documentados | Avatar mal manejado; representación falsa; inautenticidad | Fundadora + Andrés | BRD-004 |
| A-005 | Buyer persona identificado vía conversaciones reales | Cliente | MKT-005: conversaciones con compradores potenciales | Entrevistas superficiales; buyer persona incompleto; contenido/oferta no aligned | Claude Code + Fundadora | MKT-005 |
| A-006 | País inicial elegido por acceso + viabilidad | Mercado, operación | MKT-002: evaluación de acceso fundadora, poder pago, legalidad | País sin acceso; poder pago bajo; complejidad regulatoria | Andrés + Fundadora | MKT-002 |
| A-007 | Oferta validable manual sin tech custom | Operación, tecnología | PRD-001, PRD-002, PRD-003: entregables mapeados a herramientas existentes | Requiere automation/integraciones custom; escala operacional rápido | Claude Code + Codex | PRD-003 |
| A-008 | Marca personal + TINTO coexisten sin confundirse | Marca, operación | BRD-001, BRD-002, BRD-003: arquitectura coherente | Confusión buyer sobre marca; desconexión sinergia | Fundadora + Andrés | BRD-001 |
| A-009 | Validación comercial mediante conversaciones + pago | Mercado, cliente | VAL-001 a VAL-004: pago confirmado de compradores reales | Conversaciones sin pago → hipótesis rechazada; pivot requerido | Fundadora + Andrés | VAL-004 |

---

## E. Brechas críticas

Severidad: **critical** (impiden decisión responsable), **major** (afectan dirección), **minor** (mejoran pero no bloquean).

| Brecha | Severidad | Justificación | Bloqueador |
|--------|-----------|---------------|-----------|
| **Datos de fundadora (CV, portfolio, trayectoria)** | CRITICAL | Sin CV/portfolio no puedo construir marca personal (BRD-002). Sin autoridad percibida, confianza no transfiere a cliente. DEC-002 requiere esto. | GOV-002: incorporar fuentes originales |
| **Geografía definida (país inicial)** | CRITICAL | Sin país no puedo orientar MKT. Afecta presupuesto, timeline, regulación. | MKT-002: Andrés + Fundadora elige país |
| **Nicho priorizado entre opciones** | CRITICAL | Bienes/remesas/seguros → diferentes buyers, problemas, precios, competencia. No puedo diseñar oferta sin esto. | MKT-001, MKT-003, MKT-004: investigación + priorización |
| **Buyer persona específico** | CRITICAL | Sin buyer no hay oferta. Messaging, pricing, canales, evento conversión todos dependen de quién es cliente. | MKT-005: conversaciones reales validando perfil |
| **Disposición de pago validada** | CRITICAL | Precio es hipótesis hasta conversación directa sobre disposición. Dinero real requerido. | MKT-005, PRD-003: validar disposición |
| **Marca personal definida** | MAJOR | BRD-002 requiere: trayectoria, autoridad, tono, diferenciadores. Sin esto, narrativa débil. | GOV-002, BRD-002: documentar marca personal |
| **Marca TINTO definida** | MAJOR | BRD-003 requiere: concepto, personalidad, valores, diferenciación. Sin esto, corporativo genérico. | BRD-003: arquitectura identidad |
| **Avatar IA consentimiento** | MAJOR | BRD-004 requiere: aprobación Fundadora image/voz/tonalidad + límites explícitos. Sin esto, no se puede producir contenido avatar. | BRD-004: consentimiento documentado |
| **Competencia mapeada** | MAJOR | MKT-003 requiere: quién se lleva dinero hoy (competencia directa, sustitutos, alternativas). Sin esto, propuesta no diferenciada. | MKT-003: investigación competitiva |
| **Entrevistas de descubrimiento** | MAJOR | MKT-001 requiere: guion, criterios, método registro. Sin esto, MKT no tiene instrumento validar. | MKT-001: diseñar entrevistas |
| **Precio propuesto** | MINOR | PRD-003 requiere: modelo + moneda. Hipótesis inicial (andres confirma) hasta validación buyer. | PRD-003 + MKT-005 |
| **Estructura oferta** | MINOR | PRD-001, PRD-002, PRD-003 requiere: transformación, entregables, duración. Depende de buyer + problema validados. | PRD-003 |
| **Viabilidad regulatoria, profesional, contractual** | CRITICAL | Cualquier servicio financiero, fiscal, inmobiliario o patrimonial puede estar sujeto a regulación profesional, limitaciones contractuales, restricciones legales. Debe verificarse ANTES diseñar o vender oferta. No documentado. | Investigación Andrés + consulta legal según territorio |

**Resumen bloqueantes**: GOV-002, MKT-002, MKT-004, MKT-005, regulación. Sin avance en estos, PRD/BRD no pueden construirse sin riesgo.

---

## F. Inventario de activos existentes

Registro únicamente activos comprobables en repositorio o documentos.

### Experiencia
- Bloque 1 cerrado; operación v0.2.0 manual, sin runtime automatizado (DELIVERABLE_SCHEMA.json, QA_REPORT_SCHEMA.json, HUMAN_APPROVAL_SCHEMA.json, ticket-router.json validados, 3 skills Codex auditadas).
- Auditoría y governance: 12 quality gates definidos, proto

colo de escalación, control de cambios.
- Documentación estratégica: TINTO_MASTER_CONTEXT.md v0.1, 5 decisiones (DEC-001 a DEC-005), 9 hipótesis (A-001 a A-009), guardrails (4 semáforos).

### Reputación
- Fundadora: (andres confirma) — histórico, casos, autoridad.
- TINTO brand: Conceptual (DEC-002 aprobado, BRD-002 + BRD-003 pending).

### Red
- Contactos fundadora: (andres confirma) — cantidad, ubicación, relación, capacidad acceso.

### Contenidos
- No existen hasta ahora. CNT-001, CNT-002, CNT-003 pending.

### Documentos
- Maestros: TINTO_MASTER_CONTEXT.md, DECISION_LOG.md, PROJECT_RULES.md, roadmap.md.
- Estrategia: roadmap-status.md (Bloque 1 cerrado, Bloque 3 abierto), STAGE_GATES.md, STRATEGIC_GUARDRAILS.md.
- Gobernanza: orchestration/ (7 protocolos), .claude/agents/ (2 agentes), skills (3 Codex).

### Procesos
- Workflow manual: WORKFLOW_PROTOCOL.md (9 estados, 5 resultados QA, 3 capas trazabilidad).
- Quality gates: 12 controlesque validan coherencia, especificidad, evidencia, viabilidad, alineación, valor, riesgo, coherencia documental, accionabilidad, trazabilidad, medición, aprobación.

### Tecnología
- Stack MVP: (andres confirma) — no documentado. Asumir herramientas estándar (Google Suite, Zoom, CRM tercero).

### Marcas
- Marca personal: Fundadora (no documentada aún).
- TINTO: Conceptual, DEC-002 aprobado.

### Audiencia
- No existe base de datos. VAL-002: objetivo validar conversaciones reales con mercado.

### Base de datos
- roadmap-status.md (eventos Bloque 1), comments/[TICKET-ID].jsonl (pendiente producir).

### Alianzas
- No documentadas.

### Testimonios
- No existen.

### Casos de éxito
- (andres confirma) — no documentados.

### Capacidades operativas
- Manual: el Bloque 1 aporta protocolos y controles para una operación v0.2.0 manual, sin runtime automatizado. PRD diseñado para modelo manual sin tech custom (hipótesis A-007).

---

## G. Territorios de exploración (amplios, sin decidir)

Derivados de hipótesis A-001 + A-002. Clasificados como [HIPÓTESIS]. No se selecciona ganador. No se recomienda explorar múltiples en paralelo.

### Territorio 1: Acompañamiento en servicios o asesoría financiera/patrimonial

**Descripción**: Servicios relacionados con estructuración, planificación o asesoría en temas financieros o patrimoniales para colombianos en exterior.

**Activos potenciales necesarios**: 
- Experiencia, credenciales, red (andres confirma).
- Capacidad comunicar complejidad con claridad.
- Comprensión de regulación/impuestos dual (pendiente validar).

**Hipótesis por validar**:
- Existe problema real + urgencia en este territorio (MKT-001).
- Fundadora tiene experiencia o acceso para abordar (GOV-002, A-003).
- Buyer específico + disposición pago (MKT-005).

**Riesgos operativos**: 
- Viabilidad regulatoria, profesional, contractual no documentada (pendiente).
- Capacidad de entrega sin plataforma propia (A-007).
- Complejidad legal/fiscal dual.

**Condición para continuar**: 
- Confirmación experiencia/credenciales fundadora.
- Investigación regulatoria preliminar.
- Conversaciones reales validando problema + pago.

**Semáforo**: 🟡 Amarillo — explorable con validación.

---

### Territorio 2: Acompañamiento relacionado con activos inmobiliarios

**Descripción**: Servicios relacionados con estrategia, estructuración o gestión de activos inmobiliarios.

**Activos potenciales necesarios**:
- Red en geografía(s) relevante (andres confirma).
- Experiencia inmobiliaria o acceso a expertos (andres confirma).
- Comprensión regulatoria dual (pendiente).

**Hipótesis por validar**:
- Existe necesidad real de asesoría en este territorio (MKT-001).
- Fundadora acceso + red comprobada (GOV-002, A-003).
- Buyer específico + disposición pago (MKT-005).
- Viabilidad operativa sin team (A-007).

**Riesgos operativos**:
- Requiere partners/alianzas (fuera scope MVP manual).
- Regulación inmobiliaria + impuestos complex.
- Mercado tamaño + saturación.
- Responsabilidad legal alta si recomendación falla.

**Condición para continuar**:
- Confirmación red + acceso fundadora.
- Alianzas preliminares documentadas.
- Validación buyer real.

**Semáforo**: 🟡 Amarillo — viable si red + alianzas existen.

---

### Territorio 3: Educación, orientación o contenido financiero

**Descripción**: Servicios de educación, orientación o contenido en temas financieros, patrimoniales o de planificación.

**Activos potenciales necesarios**:
- Contenido educativo o capacidad desarrollar.
- Marca personal como autoridad (A-003, A-008).
- Avatar IA para escala (A-004).

**Hipótesis por validar**:
- Existe demanda real + urgencia (MKT-001).
- Fundadora credibilidad educativa validada (GOV-002).
- Buyer específico + disposición pago (MKT-005).
- Contenido + asesoría diferenciada de contenido gratis (validación pago).

**Riesgos operativos**:
- Competencia: mucho contenido gratuito.
- Validación pago (educación vs asesoría personalizada).
- Escala de contenido (CNT-001, CNT-002, CNT-003).
- Garantías sobre resultados financieros prohibidas (PROJECT_RULES).

**Condición para continuar**:
- Validación demanda educativa específica.
- Diferenciador claro vs contenido gratuito.
- Conversaciones validando disposición pago por asesoría.

**Semáforo**: 🟡 Amarillo — explorable, validación pago crítica.

---

## Territorios NO explorar en Bloque 3

### Remesas o transferencias

**Por qué no**: Viola DEC-003 (MVP sin plataforma propia). Requiere alianzas, regulación financiera, automatización. Margen incompatible con modelo asesoría manual.

**Cuando reconsiderar**: Bloque 3+ (después validación unidad actual + presupuesto escalamiento).

---

## H. Preguntas para Andrés y fundadora

Separadas en dos grupos: datos + decisiones. Total 14 preguntas.

### Datos que Andrés debe confirmar (7 preguntas)

1. **Experiencia, credenciales, casos documentados de fundadora** (CV, portfolio, casos, industrias).
   - Por qué: Base para marca personal (BRD-002) + credibilidad oferta.
   - Ticket: GOV-002.

2. **Red de fundadora por geografía** (Cuántos contactos reales, qué relación, dónde ubicados).
   - Por qué: Define capacidad acceso + iniciar validación conversaciones.
   - Ticket: MKT-001, MKT-002.

3. **Capacidad operativa de fundadora** (Tiempo dedicable por semana, otros empleos/proyectos, restricciones).
   - Por qué: DEC-003 (manual) requiere verificar viabilidad entrega.
   - Ticket: PRD-001.

4. **Autorización image/voz/datos para avatar IA** (Si sí, límites específicos).
   - Por qué: DEC-004 aprobado, BRD-004 requiere consentimiento explícito.
   - Ticket: BRD-004.

5. **Tono/personalidad marca personal** (Cómo desea presentarse fundadora).
   - Por qué: Define messaging, contenido, diálogo.
   - Ticket: BRD-002, BRD-003.

6. **Presupuesto disponible Bloque 3** (Infraestructura, herramientas, contenido, conversaciones).
   - Por qué: Afecta viabilidad operativa + stack.
   - Ticket: COST-001.

7. **Timeline objetivo para MVP** (Plazo realista en meses/semanas).
   - Por qué: Comprometer expectativas.
   - Ticket: Roadmap.

### Decisiones estratégicas Andrés debe tomar (7 preguntas)

8. **Territorio de exploración elegido** (¿Acompañamiento financiero/patrimonial? ¿Activos inmobiliarios? ¿Educación financiera? ¿Otro?).
   - Por qué: Define buyer, problema, oferta, todo lo que sigue.
   - Ticket: MKT-002, MKT-004.
   - Nota: NO se valida hasta después MKT-001 conversaciones reales.

9. **País inicial de validación** (Cuál elegir según acceso red fundadora).
   - Por qué: Acceso, poder pago, regulación, timeline.
   - Ticket: MKT-002.

10. **¿Es aceptable iniciar con una unidad comercial única?** (Validar comprensión DEC-001).
    - Por qué: Restricción no-negociable. Confirmar alineamiento.
    - Ticket: Roadmap (STR-001 precondición).

11. **¿Aprueba DEC-005 (validación comercial mediante conversaciones reales + pago)?** (Estado: actualmente PROPOSED).
    - Por qué: Define métrica viabilidad unidad comercial.
    - Ticket: DECISION_LOG.

12. **¿Autoriza start conversaciones exploratorias con red fundadora?** (MKT-001 ejecución).
    - Por qué: Iniciar validación mercado sin inventar datos.
    - Ticket: MKT-001.

13. **¿Requiere investigación competitiva preliminar antes elegir territorio?** (MKT-003).
    - Por qué: Inform decisión territorio.
    - Ticket: MKT-003.

14. **¿Próxima reunión para consolidar respuestas (decisiones futuras a registrar)?** (Timeline).
    - Por qué: Operacionalizar decisiones.
    - Ticket: Roadmap.

---

## I. Gate siguiente recomendado

**Qué es**: Reunión Andrés + Fundadora para consolidar datos + decisiones (§ H).

**Qué producir**:
1. Confirmación datos fundadora (GOV-002).
2. Decisión territorio comercial (estratégica futura).
3. Decisión país validación (estratégica futura).
4. Aprobación DEC-005 si aplica (decisión posterior de Andrés).
5. Plan MKT-001 (guion entrevistas, criterios, método).

**Resultado esperado**:
- Datos fundadora documentados.
- Una unidad comercial territorial seleccionada (sin buyer específico aún).
- Desbloqueo: GOV-002, MKT-001, MKT-002, MKT-003, MKT-004.
- Fundadora inicia conversaciones exploratorias.

**Timeline**: 1-2 semanas (reunión + consolidación documentos).

---

## J. Veredicto

**Estado de Bloque 3**:

- ✓ Bloque 1 (v0.2.0) **CLOSED**, operación manual sin runtime automatizado.
- ✓ Protocolos y quality gates del Bloque 1 disponibles para operación manual.
- ✓ Decisiones aprobadas (DEC-001 a DEC-004) **DOCUMENTADAS**.
- ✓ Decisión propuesta (DEC-005) **REGISTRADA**, pendiente aprobación.
- ✓ Hipótesis activas (A-001 a A-009) **LISTADAS** con validación plan.
- ✓ Brechas críticas **IDENTIFICADAS** (GOV-002, MKT-002, MKT-004, MKT-005).
- ✓ Territorios amplios **EXPLORADOS** sin decidir ganador.
- ✓ Activos existentes **DOCUMENTADOS** (limitados).
- ✓ Preguntas Andrés **PRIORIZADAS** (datos + decisiones).

**Capacidad presente**: Diagnóstico, consolidación, exploración. **NO**: validación comercial real, buyer específico, oferta, precio, país, territorio.

**Bloqueadores críticos**:
1. Datos fundadora (GOV-002) → requiere BRD-002.
2. Territorio elegido (Andrés) → requiere MKT-001.
3. País elegido (Andrés) → requiere MKT-002.
4. Conversaciones reales (MKT-001) → requiere validación buyer.

**Veredicto**: `CONDITIONAL_READY` → sólo si Andrés + Fundadora confirman datos + deciden territorio.

- ✓ Diagnóstico completo, supuestos documentados.
- ⚠️ Requiere confirmación datos + decisión territorio antes MKT ejecución.
- ⚠️ Sin confirmaciones, tickets MKT bloqueados.
- ❌ NO: buyer específico, país, oferta, precio, promoción.

**Gate siguiente**: Reunión Andrés + Fundadora (consolidar § H). Luego GOV-002 + MKT-001.

---

## Cambios desde v0

- **Versión 1.0**: Diagnóstico inicial, matriz evidencia, opciones A-D, preguntas 15, veredicto.
- Basado en: DECISION_LOG.md, ASSUMPTIONS.md, VALIDATED_FACTS.md, PROJECT_RULES.md, STRATEGIC_GUARDRAILS.md, roadmap.md, STAGE_GATES.md, FRAMEWORKS.md, QUALITY_GATES.md.
- Pendiente: MKT-001 (entrevistas), MKT-002 (país), MKT-004 (nicho), MKT-005 (buyer persona).

---

## Próxima acción recomendada

1. **Andrés** revisa diagnóstico (este documento) + responde 14 preguntas (§ H).
2. **Andrés** documenta en DECISION_LOG.md: decisiones estratégicas posteriores (datos, país, nicho).
3. **Claude Code** recibe decisiones y diseña MKT-001 (guion entrevistas) + MKT-002 (análisis país).
4. **Fundadora** inicia conversaciones exploración con 5-10 colombianos en exterior (criterios MKT-001).
5. **Auditor** valida diagnóstico (QG-01 a QG-12) antes de pasar MKT.

---

**Documento generado**: 2026-07-28 — STR-001 (Consolidar contexto maestro).  
**Próximo ticket**: MKT-001 (Diseñar entrevistas de descubrimiento).
