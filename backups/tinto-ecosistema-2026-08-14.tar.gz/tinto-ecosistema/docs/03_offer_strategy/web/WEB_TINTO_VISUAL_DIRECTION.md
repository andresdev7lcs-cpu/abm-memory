# WEB TINTO - Dirección visual

**Estado**: Especificación para fase visual Claude Code  
**Productor anterior**: Codex (base funcional)  
**Rama**: `feature/tinto-offer-strategy-v1.0.0`  
**Propósito**: Transformar prototipo funcional en experiencia premium sin romper arquitectura

---

## Sensibilidad visual

**Paleta emocional**: Elegancia moderna, calidez humana, tecnología sin frialdad.

**Materialidad**:
- Cristal (glassmorphism legible)
- Reflejos suaves
- Luz ámbar/café
- Tonos oscuros profundos
- Sombras difusas
- Glow controlado

**Evitar**:
- Estética gamer
- Neón excesivo
- Partículas abundantes
- Animaciones agresivas
- Texto pequeño (<14px body)
- Efectos que distraigan de contenido

---

## Tokens de color (provisionales, reemplazables)

```css
--tinto-ink: #151312;
--tinto-charcoal: #24201e;
--tinto-cream: #f4eee7;
--tinto-coffee: #6e4433;
--tinto-amber: #d79a55;
--tinto-gold-soft: #ddb981;
--tinto-glass: rgba(255,255,255,.08);
--tinto-line: rgba(255,255,255,.16);
--tinto-text: #f7f3ef;
--tinto-muted: #bdb4ad;
```

Actualización en styles.css según dirección ejecutada.

---

## Componentes visuales por sección

### 1. Loader

**Mecánica**:
- Logo aparece con nitidez baja (opacity 0.3)
- Gana nitidez progresivamente (~600ms)
- Respira: escala 1.0 → 1.08 → 1.0 (1200ms)
- Emite glow cálido (radial gradient ámbar suave)
- Mantiene nitidez a media respiración
- Glow se intensifica suavemente
- Logo se desvanece a 0.4 opacity
- Reaparece breve instante a 1.0
- Transición fade-out al hero (~300ms)

**Reduced motion**: Desactiva respiración y glow. Solo fade in/out.

### 2. Hero

**Composición visual** (si no hay video real):
- Fondo: Gradiente oscuro con tonos petrol/forest (suave)
- Capa 1: Rectángulo semi-transparente (cristal) en área superior derecha
- Capa 2: Reflejo horizontal suave (light leak ámbar)
- Capa 3: Línea luminosa horizontal fina (divisor sutil)
- Capa 4: Copy + CTAs (lado izquierdo)
- Efecto parallax leve si disponible (sin JavaScript costoso)

**Copy visual**:
- Eyebrow pequeño, uppercase, muted
- H1 grande (clamp 2.5rem a 4.8rem)
- Body serif-like, muted medium
- Overlay chiquito, muted bajo
- CTAs con hover effect (glow sutil ámbar)

**Reemplazable después por**:
- Héroe real video/imagen
- Retrato fundadora
- Avatar IA
- Logo definitivo
- Poster cinematográfico

### 3. Transición Hero → Home-Átomo

**Flujo sugerido** (si usuario hace clic en "Abrir Home-Átomo"):
1. CTA button responde (hover glow)
2. Click dispara transición
3. Scroll suave al atom section (si es mobile) o fade soft (desktop)
4. Atom core aparece con scale pequeña (0.8)
5. Scale crece a 1.0 (~400ms)
6. Orbitas aparecen (staggered, ~200ms delay c/una)
7. Territorios fade in

**Reduced motion**: Skip a pasos claves. Solo fade + scale.

### 4. Home-Átomo

**Núcleo central**:
- Círculo con ring visible (border 2px, color: muted)
- Pequeño glow radial (--forest o --petrol sutil)
- Hover: Intensifica glow, ring se ilumina
- Click/active: Scale ligero, glow reforzado
- Label legible
- Meta subtext (muted bajo)

**Órbitas**:
- 3 órbitas SVG/CSS círculos concéntricos
- Color línea: rgba(255,255,255, 0.12)
- Animación rotativa suave (36s ciclo) si `prefers-reduced-motion: no`
- Reduced motion: Sin rotación, órbitas estáticas

**Territorios (halos)**:
- Círculo exterior (halo effect, blur)
- Color halo según territory.tone (--forest, --petrol, --copper)
- Posicionadas en órbitas (slot CSS custom property)
- Hover: Halo más brillante, label más opaco
- Active: Scale 1.12, glow intenso, label bold
- Touch: Responde con pulso visual breve

**Tooltips territorio**:
- Aparecen en hover/focus
- Mostrar: title + status + approval
- Posición: arriba del node
- Fade in/out ~150ms

### 5. Gesto de toque

**Visual**:
- Círculo central pequeño (pulse cue)
- Pulso: scale 1.0 → 1.4 → 0 (600ms loop si motion full)
- Línea luminosa opcional (conector visual desde core a territorio)
- Si no hay línea: pulse es suficiente
- Copy explicativa chiquita debajo

**Reduced motion**: Pulse desaparece. Solo tooltip estático.

### 6. Tablero digital

**Estructura visual**:
- Panel semi-transparente (glassmorphism, backdrop-filter)
- Borde sutil línea clara
- Encabezado: territorio title, summary, badges
- Layout: 2 columnas (preguntas izq, preview der)
  - Mobile: Stack vertical
- Preguntas list:
  - Cards reutilizables
  - Hover: Lift ligero (translateY -2px)
  - Active: Background highlight, border-left ámbar
- Preview scenario a derecha
- Botón regresar (top-right)

### 7. Escenario interno

**Tema visual**: Sala de consulta / briefing privado

**Composición**:
- Encabezado (pregunta titulo, breadcrumb)
- Cuerpo: Pregunta → Respuesta provisional → Recursos
- Recursos como cards pequeñas
- Preguntas relacionadas (linked questions)
- Navegación: regresar a tablero / regresar a home

**Transición desde board**: Fade in + scale desde preview (0.95 → 1.0)

### 8. Diagnóstico progresivo

**Pasos visuales** (3 steps):
1. Contacto (nombre, email, país)
2. Contexto (territorio, situación, urgencia)
3. Preferencias (tipo ayuda, contacto, consentimiento)

**Visual por paso**:
- Indicador progreso: Barras 3 pasos (width dinámica)
- Formulario: Fieldsets claros
- Labels elevados o placeholder sutiles
- Botones nav: Anterior / Siguiente
- Errores: Red accent, mensaje claro

**Resumen final**: Recapitulación datos antes submit.

**Confirmación mock**: Mensaje éxito, sin guardar permanentemente.

---

## Animaciones (sistema de movimiento)

### Principios

- Duración estándar: 220ms (--transition)
- Ease: `ease` (cubic-bezier suave)
- Reduced motion: Desactivar todas animaciones no esenciales

### Catálogo

| Efecto | Duración | Cuando |
|--------|----------|--------|
| Fade in/out | 150–220ms | Vistas, tooltips, componentes |
| Scale entrada | 250–400ms | Componentes principales |
| Translate hover | 150ms | Botones, cards |
| Glow intensify | 220ms | Halos, núcleo |
| Loader breathing | 1200ms | Inicio, loop 2x |
| Loader fade | 300ms | Transición a hero |
| Órbita rotación | 36s | Loop continuo (si motion full) |
| Pulso | 600ms | Loop continuo (si motion full) |
| Board emerge | 300ms | Al seleccionar territorio |
| Scenario fade | 220ms | Al seleccionar pregunta |

---

## Responsive breakpoints

- **Desktop**: 1180px+
- **Tablet**: 640px–1179px
- **Mobile**: 320px–639px

### Ajustes por breakpoint

| Componente | Desktop | Tablet | Mobile |
|------------|---------|--------|--------|
| Home-Atom | Layout 2-col | Layout ajustado | Stack vertical |
| Board | 2 columnas lado a lado | 1.5 columnas | Stack |
| Hero | Grid 1.08:0.92 | Grid 1:1 | Stack 100% |
| Atom | Órbitas visibles | Órbitas pequeñas | Órbitas mínimas |

---

## Accesibilidad visual

### Contraste

- Texto body: ≥4.5:1 WCAG AA
- Bordes/divisores: ≥3:1
- Focus visible: Outline ≥3px, contraste alto

### Focus states

- Todos botones: Focus ring visible (outline + inset)
- Tab order: Naturaleza lógica (izq→der, arriba→abajo)
- Skip links: Opcional pero recomendado

### Semantic HTML

- `<button>` para acciones clickeables
- `<section>`, `<article>` para áreas
- `<form>`, `<fieldset>`, `<label>` para formularios
- `<figure>`, `<figcaption>` para media
- `aria-live` en actualizaciones dinámicas

---

## Reduced motion compliance

### Aplicar en CSS

```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

### Mínimo conservado

- Loader: Fade in/out solo
- Órbitas: Estáticas, no rotan
- Pulsos: Desaparecen
- Transiciones: Reducidas a 50ms

---

## Assets reemplazables

Placeholders provisionales:
- `logo-mark.svg`: Reemplazar con logo definitivo
- `hero-poster.svg`: Reemplazar con imagen/video
- `founder-portrait.svg`: Reemplazar con retrato real o avatar
- `founder-avatar.svg`: Reemplazar con avatar IA o icono

**Formato preferido**: SVG para logos/iconos. WEBM/MP4 para video. JPG/PNG optimizado para retratos.

**Ruta**: Mantener en `tools/tinto-web/assets/`.

---

## Performance target

- First Contentful Paint: <1.5s
- Largest Contentful Paint: <2.5s
- Cumulative Layout Shift: <0.1
- No blocking JavaScript
- Animaciones smooth: 60fps target
- No WebGL, no Three.js, no dependencias externas

---

## Testing checklist

- [ ] Loader visible, respira (si motion full), desvanece
- [ ] Hero cargar sin video
- [ ] Transición hero→atom fluida
- [ ] Home-Atom: click territorio → board
- [ ] Board: 2 columnas desktop, stack mobile
- [ ] Scenario: preview derecha, transición smooth
- [ ] Diagnosis: 3 pasos funcionales, botones nav
- [ ] Teclado: Tab through all buttons
- [ ] Reduced motion: Animaciones desactivadas, funcionalidad ok
- [ ] Responsive: Desktop, tablet, mobile sin overflow
- [ ] Accesibilidad: Contraste OK, focus visible, labels claros
- [ ] Performance: Devtools Lighthouse >85

---

## Estado

- Especificación: Completa
- Implementación visual: Pendiente (Claude Code)
- Auditoría: Pendiente (post-implementación)
- Approval: Pendiente (Andrés)
