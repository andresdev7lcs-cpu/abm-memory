# WEB TINTO - Technical Architecture

## Estado

- Ticket operativo: WEB TINTO prototype base
- Estado de entrega: `agent_review`
- Productor: Codex
- Rama: `feature/tinto-offer-strategy-v1.0.0`

## Stack detectado

- Frontend: HTML5 + CSS3 + vanilla JavaScript.
- Runtime del sitio: navegador, sin framework.
- Servidor local de desarrollo: static server simple.
- Dependencias externas: ninguna.
- Persistencia: memoria temporal en la sesion, sin almacenamiento permanente de datos sensibles.

## Decisiones de arquitectura

1. Contenido desacoplado del render.
2. Navegacion por hash routes reversibles.
3. Componentes reutilizables en modulos ESM.
4. Estado explicito para loader, ruta, territorio, pregunta y formulario mock.
5. No se usan modales anidados.
6. No se usan assets remotos.
7. No se usan dependencias nuevas.

## Estructura tecnica

### Sitio

- `tools/tinto-web/index.html`
- `tools/tinto-web/styles.css`
- `tools/tinto-web/app.mjs`
- `tools/tinto-web/content.mjs`
- `tools/tinto-web/router.mjs`
- `tools/tinto-web/state.mjs`
- `tools/tinto-web/components.mjs`
- `tools/tinto-web/server.mjs`
- `tools/tinto-web/assets/*.svg`

### Navegacion

- `#/home`
- `#/territorio/:territoryId`
- `#/territorio/:territoryId/pregunta/:questionId`
- `#/diagnostico/:territoryId/pregunta/:questionId`

## Responsabilidades por capa

### `content.mjs`

- Define logo, hero, core de fundadora, territorios, preguntas, recursos y formulario mock.
- Todo el texto provisional vive aqui.

### `router.mjs`

- Interpreta y genera hashes.
- Detecta reduced motion.

### `state.mjs`

- Guarda ruta actual.
- Guarda territorio seleccionado.
- Guarda pregunta seleccionada.
- Guarda paso del diagnostico.
- Guarda draft del formulario en memoria.

### `components.mjs`

- Renderiza loader, hero, home-atom, tablero digital, escenario interno y diagnostico progresivo.

### `app.mjs`

- Sincroniza hash, estado y render.
- Maneja clicks, input, submit y back/forward del navegador.

## Modelo visual

- Fondo atmosferico con gradientes.
- Loader con logo que aparece, respira, emite glow y se desvanece.
- Hero provisional con poster local.
- Home-Atom con nucleo central, tres territorios y orbitas SVG/CSS.
- Tablero digital como panel no modal.
- Diagnostico en pasos con estado local.

## Accesibilidad base

- Elementos interactivos son botones reales.
- Focus visible.
- Estructura semantica con `main`, `section`, `article`, `figure`, `form`, `fieldset`.
- Contenido leible con teclado.
- `aria-live` en contenedores clave.

## Reduced motion

- CSS media query `prefers-reduced-motion: reduce`.
- Animaciones reducidas a transiciones minimas.
- Loader sin giro.
- Orbitas y pulses se desactivan en modo reducido.

## Handoff tecnico

- La siguiente capa debe reemplazar los placeholders visuales sin tocar el modelo de datos.
- El sitio ya acepta media de hero en formato video o imagen.
- Los territorios estan marcados internamente como `status: hypothesis` y `approval: pending_confirmation`.
- El formulario mock no persiste datos de forma permanente.

