# WEB TINTO v0.3 — Asset Map

- Ticket: WEB-003
- Documento: 5 de 11
- Base: `WEB_TINTO_V0_3_SCENE_COMPOSITIONS.md`

## 1. Principio

Todo asset es **local, provisional y reemplazable sin cambiar la arquitectura**. Ninguna composición puede depender de un asset final que todavía no existe.

Regla de oro (heredada de `VISUAL_REFINEMENT.md` P6): la maqueta debe verse compuesta y premium **con todos los placeholders puestos**. Si una escena solo funciona cuando llega la fotografía final, la composición está mal resuelta.

## 2. Clasificación de prioridad

| Prioridad | Significado | Condición |
|---|---|---|
| **P0** | Necesario para aprobar la maqueta | Sin esto, Andrés no puede evaluar la escena |
| **P1** | Necesario antes de motion | Bloquea la fase de motion, no la aprobación de maqueta |
| **P2** | Mejora posterior | Refinamiento; la experiencia funciona sin ello |

## 3. Estados de asset

| Estado | Significado |
|---|---|
| `placeholder_svg` | Existe un SVG provisional en el repo |
| `pending_production` | No existe; requiere producción |
| `pending_decision` | Requiere decisión de Andrés antes de producir |
| `final` | Aprobado y en su lugar |

**Ningún asset está en estado `final` a la fecha de este documento.**

## 4. Inventario maestro

### IMG-01 — Logo TINTO

| Campo | Valor |
|---|---|
| Nombre | `logo-mark.svg` |
| Escena | 01 `curtain`, chrome de debug |
| Función | Identidad, primer contacto visual |
| Prioridad | **P0** |
| Formato | SVG (vector, obligatorio) |
| Proporción | 1:1 |
| Resolución desktop | 180px de lado |
| Resolución móvil | 100–120px de lado |
| Transparencia | Sí, fondo transparente |
| Fallback | Wordmark tipográfico "TINTO" en serif |
| Estado | `placeholder_svg` → `pending_decision` |
| Dependencia | ¿El logo actual es provisional o definitivo? `(andres confirma)` |
| Reemplazo | Sustituir el archivo conservando `viewBox` y proporción 1:1. Sin cambio de código |

### IMG-02 — Poster de VSL

| Campo | Valor |
|---|---|
| Nombre | `founder-vsl-poster.svg` → `.webp` al producirse |
| Escena | 02 `founder-vsl` |
| Función | Presencia humana; poster del video futuro |
| Prioridad | **P0** |
| Formato | WebP (con JPG de respaldo) |
| Proporción | 4:5 |
| Resolución desktop | 1040×1300px (2x de 520×650) |
| Resolución móvil | 800×1000px |
| Transparencia | No |
| Fallback | `IMG-03` retrato estático → bloque tipográfico con proporción preservada |
| Estado | `placeholder_svg` → `pending_production` |
| Dependencia | Sesión fotográfica de la fundadora `(andres confirma)` |
| Reemplazo | Reemplazar conservando proporción 4:5. Punto focal en el rostro, tercio superior |

### IMG-03 — Retrato de la fundadora

| Campo | Valor |
|---|---|
| Nombre | `founder-portrait.svg` → `.webp` |
| Escena | 02 (fallback), 06 `office-intro` (apoyo) |
| Función | Presencia secundaria, refuerzo de continuidad humana |
| Prioridad | **P0** |
| Formato | WebP |
| Proporción | 1:1 |
| Resolución desktop | 560×560px |
| Resolución móvil | 280×280px |
| Transparencia | Preferible PNG/WebP con alfa para recorte circular |
| Fallback | Se omite (es apoyo, no estructura) |
| Estado | `placeholder_svg` → `pending_production` |
| Dependencia | Misma sesión que `IMG-02` |
| Reemplazo | Recorte cuadrado centrado en el rostro. Debe funcionar en máscara circular |

### IMG-04 — Avatar / silueta de núcleo

| Campo | Valor |
|---|---|
| Nombre | `founder-avatar.svg` |
| Escena | 03 `atom-command-center` |
| Función | Silueta al 22% de opacidad detrás del label del núcleo |
| Prioridad | **P1** |
| Formato | SVG o WebP con alfa |
| Proporción | 1:1 |
| Resolución desktop | 464×464px |
| Resolución móvil | 320×320px |
| Transparencia | Sí, obligatoria |
| Fallback | Núcleo sin silueta: solo glow y label tipográfico |
| Estado | `placeholder_svg` |
| Dependencia | Derivable de `IMG-03` mediante recorte y tratamiento |
| Reemplazo | Silueta de alto contraste, sin detalle facial fino (se ve al 22%) |

### IMG-05 — Gesto de mano y halo

| Campo | Valor |
|---|---|
| Nombre | `halo-hand.svg` → `.webp` |
| Escena | 04 `halo-selection` |
| Función | Materializar la elección como gesto físico |
| Prioridad | **P1** |
| Formato | WebP con alfa, o SVG si es ilustración |
| Proporción | 1:1 |
| Resolución desktop | 800×800px |
| Resolución móvil | 560×560px |
| Transparencia | Sí, obligatoria (se compone sobre glow de tono) |
| Fallback | **Obligatorio y suficiente:** halo abstracto con línea luminosa y pulso, sin mano |
| Estado | `placeholder_svg` |
| Dependencia | Ninguna. El fallback abstracto es P0 y ya existe |
| Reemplazo | El punto de contacto mano-halo debe quedar en el centro óptico y sobrevivir al recorte móvil |

### IMG-06 — Puerta de cristal

| Campo | Valor |
|---|---|
| Nombre | `glass-door.svg` → `.webp` |
| Escena | 06 `office-intro` |
| Función | Umbral; la bienvenida física |
| Prioridad | **P0** |
| Formato | WebP |
| Proporción | 3:4 |
| Resolución desktop | 1200×1600px |
| Resolución móvil | 750×1000px |
| Transparencia | No |
| Fallback | Superficie con gradiente de luz cálida y hairline vertical sugiriendo el umbral |
| Estado | `placeholder_svg` → `pending_production` |
| Dependencia | Ubicación de la sesión `(andres confirma)` |
| Reemplazo | La luz debe atravesar el cristal: es la fuente lumínica de la escena |

### IMG-07 — Taza TINTO

| Campo | Valor |
|---|---|
| Nombre | `tinto-cup.svg` → `.webp` |
| Escena | 06 `office-intro` |
| Función | Detalle de hospitalidad; rompe el marco de la puerta |
| Prioridad | **P2** |
| Formato | WebP con alfa (recorte obligatorio) |
| Proporción | 1:1 |
| Resolución desktop | 480×480px |
| Resolución móvil | Se oculta bajo 480px |
| Transparencia | Sí, obligatoria |
| Fallback | Se omite por completo |
| Estado | `placeholder_svg` |
| Dependencia | Misma sesión que `IMG-06` |
| Reemplazo | Taza real y usada, no producto de catálogo. Sin granos de café alrededor |

### CNV-01 — Canvas de ondas del átomo

| Campo | Valor |
|---|---|
| Nombre | `canvas-atmosphere.mjs` (generativo, no archivo) |
| Escena | 03 `atom-command-center` |
| Función | Atmósfera reactiva; profundidad del escenario |
| Prioridad | **P1** |
| Formato | Canvas 2D generativo |
| Proporción | Fluido, llena el escenario |
| Resolución | Adaptativa a DPR, con límite en móvil |
| Transparencia | Sí, se compone sobre el fondo |
| Fallback | Gradiente radial CSS estático por tono |
| Estado | Implementado en v0.2 |
| Dependencia | Ninguna |
| Reemplazo | No se reemplaza: se ajustan parámetros. Codex no altera la lógica sin ticket |

### CNV-02 — Canvas de atmósfera de territorio

| Campo | Valor |
|---|---|
| Nombre | `canvas-atmosphere.mjs` (misma fuente, tono distinto) |
| Escena | 07 `territory-world` |
| Función | Envolver la escena en el tono del territorio |
| Prioridad | **P1** |
| Formato | Canvas 2D generativo |
| Proporción | Fluido |
| Resolución | Adaptativa |
| Transparencia | Sí, opacidad ≤ 0.16 |
| Fallback | Gradiente radial CSS por tono |
| Estado | Implementado en v0.2 |
| Dependencia | Tono del territorio activo |
| Reemplazo | Igual que `CNV-01` |

### TEX-01 — Textura orgánica de fondo

| Campo | Valor |
|---|---|
| Nombre | `texture-organic.webp` (a producir) |
| Escena | Global (Z1), 07, 08 |
| Función | Grano sutil; evita la planitud digital |
| Prioridad | **P2** |
| Formato | WebP, tileable |
| Proporción | Tile cuadrado 512×512px |
| Resolución desktop | 512×512px, repetida |
| Resolución móvil | Misma, o desactivada por costo |
| Transparencia | Sí, se multiplica sobre el fondo |
| Fallback | Textura punteada CSS existente (`radial-gradient` enmascarado) |
| Estado | `pending_production` |
| Dependencia | Ninguna. El fallback CSS ya funciona |
| Reemplazo | Opacidad máxima 0.05. Grano de papel o textil, nunca ruido digital |

### VID-01 — Mini-VSL de la fundadora

| Campo | Valor |
|---|---|
| Nombre | `founder-vsl.webm` + `.mp4` |
| Escena | 02 `founder-vsl` |
| Función | Presentación breve en voz de la fundadora |
| Prioridad | **P1** |
| Formato | WebM (VP9) + MP4 (H.264) de respaldo |
| Proporción | 4:5 (vertical) o 16:9 con recorte `(andres confirma)` |
| Resolución desktop | 1080×1350px |
| Resolución móvil | 720×900px |
| Transparencia | No |
| Fallback | Poster `IMG-02` + captions |
| Estado | `pending_decision` |
| Dependencia | ¿Se graba video real? Guion: `(andres confirma)` |
| Reemplazo | **Captions obligatorias.** Sin audio autoplay. `muted`, `playsinline` |

### ICO-01..08 — Set de iconos

| Campo | Valor |
|---|---|
| Nombre | `icons.svg` (sprite) o SVG inline |
| Escena | Global, overlay de controles |
| Función | Reemplazar los caracteres tipográficos actuales |
| Prioridad | **P0** |
| Formato | SVG inline, `currentColor` |
| Proporción | 1:1 |
| Resolución | 16 / 20 / 24px |
| Transparencia | Sí |
| Fallback | Ninguno: es requisito de accesibilidad |
| Estado | `pending_production` |
| Dependencia | Ninguna |
| Reemplazo | Stroke 1.5px, terminaciones redondeadas, sin relleno |

Inventario: flecha izquierda, pausa, play, ajustes, chevron abajo, check, alerta, cerrar.

**Este es el asset P0 más urgente y el más barato de producir.** La implementación actual usa `←`, `❙❙`, `▶`, `⚙` como texto, lo que rompe la consistencia entre plataformas y viola la regla de no-emoji del sistema de diseño.

## 5. Resumen por prioridad

### P0 — Bloquean aprobación de maqueta

| ID | Asset | Estado |
|---|---|---|
| IMG-01 | Logo | `pending_decision` |
| IMG-02 | Poster VSL | `pending_production` |
| IMG-03 | Retrato | `pending_production` |
| IMG-06 | Puerta de cristal | `pending_production` |
| ICO-01..08 | Set de iconos | `pending_production` |

**Cinco entradas.** Los iconos son producibles de inmediato. Los cuatro restantes dependen de una sesión fotográfica.

### P1 — Bloquean motion

| ID | Asset | Estado |
|---|---|---|
| IMG-04 | Avatar de núcleo | `placeholder_svg` |
| IMG-05 | Gesto de mano | `placeholder_svg` |
| CNV-01 | Canvas átomo | Implementado |
| CNV-02 | Canvas territorio | Implementado |
| VID-01 | Mini-VSL | `pending_decision` |

### P2 — Mejora posterior

| ID | Asset | Estado |
|---|---|---|
| IMG-07 | Taza TINTO | `placeholder_svg` |
| TEX-01 | Textura orgánica | `pending_production` |

## 6. Ruta de archivos

Todos los assets viven en `tools/tinto-web/assets/`. Sin excepción.

- **Sin assets remotos.** Sin CDN, sin fetch externo, sin Google Fonts.
- Nomenclatura: `<función>-<variante>.<ext>`, minúsculas, guion medio.
- Variantes móviles: sufijo `-mobile` cuando el recorte difiera (`glass-door-mobile.webp`).
- Formatos: WebP como principal, JPG/PNG de respaldo solo si se requiere compatibilidad.

## 7. Reglas de reemplazo

1. **La proporción declarada es contrato.** Reemplazar un asset con otra proporción rompe el layout y produce CLS.
2. **Ancho y alto siempre declarados** en el HTML o vía `aspect-ratio` en CSS. Espacio reservado antes de la carga.
3. **`loading="lazy"`** en todo lo que no sea de la primera escena.
4. **Todo asset con significado lleva `alt` descriptivo.** Los decorativos llevan `alt=""` y `aria-hidden="true"`.
5. **Ningún asset es evidencia.** Una fotografía de oficina no implica que exista esa oficina; un retrato no implica credenciales. Ver §8.
6. **Cada asset cae a poster, imagen, vector o bloque textual.** Sin dependencia de un solo formato.

## 8. Restricción de veracidad

Regla estratégica, no estética.

Ningún asset puede sugerir hechos no aprobados:

- Sin fotografías de equipos, oficinas corporativas o instalaciones que no existan.
- Sin gráficas de rendimiento, cifras ni proyecciones.
- Sin logos de clientes, sellos, certificaciones ni premios.
- Sin imágenes que impliquen escala (edificios, salas llenas, mapas de cobertura).
- El retrato comunica **presencia**, no autoridad declarada. Sin credenciales visuales (diplomas, títulos, placas).

`PROJECT_RULES.md` prohíbe presentar una holding como oferta inicial. Los assets deben sostener la escala real: **una unidad comercial única y validable**.

## 9. Riesgos

| Riesgo | Impacto | Mitigación |
|---|---|---|
| No hay sesión fotográfica de la fundadora | 4 de 5 P0 bloqueados | Los placeholders SVG permiten aprobar composición; se sustituye después sin tocar código |
| El video nunca se graba | Escena 02 pierde su ancla | El poster es fallback suficiente; la escena funciona sin video |
| Los SVG provisionales se confunden con finales | Aprobación sobre base falsa | La guía de revisión declara explícitamente qué es placeholder |
| Assets pesados degradan móvil | Performance | WebP, `srcset`, lazy load, límite de DPR en canvas |
| El recorte móvil pierde el sujeto | Escenas 02, 04, 06 ilegibles | Punto focal declarado por asset; verificación en 375px |

## 10. Confirmaciones pendientes

| # | Tema | Bloquea |
|---|---|---|
| 1 | ¿El logo actual es provisional o definitivo? | IMG-01 |
| 2 | ¿Existe o se produce sesión fotográfica de la fundadora? | IMG-02, IMG-03, IMG-04 |
| 3 | ¿Se graba mini-VSL real? Guion y duración | VID-01 |
| 4 | Ubicación para la puerta de cristal y la oficina | IMG-06, IMG-07 |
| 5 | Proporción del video: 4:5 vertical o 16:9 | VID-01 |
| 6 | ¿Autorización de imagen de la fundadora para uso web? | Todos los de persona |

El punto 6 requiere revisión humana explícita: `AGENTS.md` marca que el uso de imagen y voz de la fundadora necesita autorización.
