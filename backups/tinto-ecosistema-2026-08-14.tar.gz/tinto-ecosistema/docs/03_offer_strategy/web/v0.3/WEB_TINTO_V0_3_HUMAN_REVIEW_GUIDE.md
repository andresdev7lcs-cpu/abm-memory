# WEB TINTO v0.3 — Guía de Revisión Humana

- Ticket: WEB-003
- Documento: 9 de 11
- Para: Andrés
- Decisión requerida: `human_pass` o `human_changes_required`

## 1. Qué estás revisando

Una **especificación visual**, no un sitio funcionando.

Esta fase produjo diez documentos que describen cómo debería verse y comportarse la maqueta predefinitiva. Nada se implementó. `tools/tinto-web/` no fue tocado: el sitio que puedes abrir hoy sigue siendo el de v0.2.

Tu decisión aquí determina si Codex empieza a implementar o si la especificación se corrige primero.

### 1.1 Qué NO estás revisando

- **No estás revisando código.** No hay código nuevo.
- **No estás revisando assets finales.** No se generó ninguna imagen.
- **No estás revisando la oferta.** Esta fase no produjo oferta, precios ni claims. Sigue bloqueado.
- **No estás revisando motion.** El motion está documentado pero bloqueado hasta que apruebes la maqueta.

### 1.2 Cómo revisar sin ver el sitio

Los documentos incluyen diagramas ASCII de composición por escena. Son suficientes para evaluar estructura, jerarquía e intención.

Si prefieres ver algo renderizado antes de decidir, esa es una opción válida: pídeme que Codex construya solo la maqueta estática de 2 o 3 escenas clave (01, 03, 10) antes de comprometer las once. Cuesta menos que corregir once escenas mal especificadas.

## 2. Orden de lectura sugerido

| # | Documento | Tiempo | Por qué |
|---|---|---|---|
| 1 | `WEB_TINTO_V0_3_VISUAL_REFINEMENT.md` | 15 min | La dirección completa. Si esto no te convence, lo demás no importa |
| 2 | `WEB_TINTO_V0_3_SCENE_COMPOSITIONS.md` | 25 min | Las 11 escenas. El grueso de la decisión |
| 3 | `WEB_TINTO_V0_3_ASSET_MAP.md` | 10 min | Qué hay que producir y con qué urgencia |
| 4 | `WEB_TINTO_V0_3_ASSET_PROMPTS.md` | 10 min | Briefs de producción. Revisa especialmente los de la fundadora |
| 5 | `WEB_TINTO_V0_3_COMPONENT_SYSTEM.md` | 10 min | Si te interesa el detalle de componentes |
| 6 | `WEB_TINTO_V0_3_MOTION_MAP.md` | 10 min | Qué se movería después |
| 7 | Resto | — | Consulta técnica; Codex los usa más que tú |

**Ruta rápida (20 minutos):** documento 1 completo, tabla maestra del documento 2 (§2), resumen de prioridades del documento 3 (§5), y las preguntas de decisión de esta guía (§12).

## 3. Claridad

**Pregunta:** ¿se entiende qué es TINTO y qué se propone, sin explicación adicional?

| # | Criterio | Dónde verificar | ☐ |
|---|---|---|---|
| 1 | La secuencia de 11 escenas cuenta una historia coherente | `SCENE_COMPOSITIONS.md` §2 | ☐ |
| 2 | Cada escena tiene una intención declarada y distinguible | `SCENE_COMPOSITIONS.md` §2 | ☐ |
| 3 | El paso de "mirar" a "pensar" en la escena 08 tiene sentido | `VISUAL_REFINEMENT.md` §4.3 | ☐ |
| 4 | El microcopy honesto no promete de más | `SCENE_COMPOSITIONS.md` §12, §13 | ☐ |
| 5 | Los territorios se leen como exploración, no como servicios cerrados | `COMPONENT_SYSTEM.md` §11 | ☐ |

## 4. Jerarquía

**Pregunta:** ¿lo importante se ve primero?

| # | Criterio | Dónde | ☐ |
|---|---|---|---|
| 1 | Cinco niveles (ancla, titular, cuerpo, acción, soporte) son claros | `VISUAL_REFINEMENT.md` §3.1 | ☐ |
| 2 | Un solo CTA primario por pantalla | `VISUAL_REFINEMENT.md` P3 | ☐ |
| 3 | El ancla y el titular dominan (≥60% del peso visual) | `VISUAL_REFINEMENT.md` §3.2 | ☐ |
| 4 | El CTA de la escena 10 es el elemento más fuerte de la experiencia | `SCENE_COMPOSITIONS.md` §12 | ☐ |
| 5 | El tag "Exploración inicial" aparece antes del título que califica | `COMPONENT_SYSTEM.md` §11 | ☐ |

## 5. Narrativa

**Pregunta:** ¿las once escenas se sienten como una pieza o como once páginas?

| # | Criterio | Dónde | ☐ |
|---|---|---|---|
| 1 | Los tres actos (recepción, elección, conversación) tienen sentido | `VISUAL_REFINEMENT.md` §8.2 | ☐ |
| 2 | El tono del territorio persiste tras elegirlo | `VISUAL_REFINEMENT.md` §8.1 | ☐ |
| 3 | El ancla se transforma con lógica escena a escena | `SCENE_COMPOSITIONS.md` §14 | ☐ |
| 4 | La escena 05 (negro) se justifica como bisagra | `SCENE_COMPOSITIONS.md` §7 | ☐ |
| 5 | No hay barra de progreso — ¿te parece bien? | `COMPONENT_SYSTEM.md` §8 | ☐ |

**Punto 5 es una decisión abierta.** La dirección propone no usar indicador numérico porque convierte la experiencia en checkout. Si crees que el visitante se perderá, la alternativa es tres puntos (uno por acto). Tu llamada.

## 6. Comprensión

**Pregunta:** ¿alguien que llega sin contexto entiende qué hacer?

| # | Criterio | Dónde | ☐ |
|---|---|---|---|
| 1 | En la escena 03 se entiende que hay que elegir un territorio | `SCENE_COMPOSITIONS.md` §5 | ☐ |
| 2 | La escena 04 comunica que la elección se confirmó | `SCENE_COMPOSITIONS.md` §6 | ☐ |
| 3 | El formulario de la escena 11 no se lee como checkout | `SCENE_COMPOSITIONS.md` §13 | ☐ |
| 4 | Queda claro que enviar no agenda automáticamente | `SCENE_COMPOSITIONS.md` §12, §13 | ☐ |
| 5 | El regreso está siempre disponible y visible | `VISUAL_REFINEMENT.md` P7 | ☐ |

## 7. Composición

**Pregunta:** ¿se ve compuesto o se ve maquetado?

| # | Criterio | Dónde | ☐ |
|---|---|---|---|
| 1 | Tres encuadres (A/B/C) producen variedad sin caos | `VISUAL_REFINEMENT.md` §4.2 | ☐ |
| 2 | La secuencia A→B→A→B→A→B→B→C→C→C→C tiene lógica | `VISUAL_REFINEMENT.md` §4.3 | ☐ |
| 3 | Las cards genéricas se eliminaron | `COMPONENT_SYSTEM.md` §16 | ☐ |
| 4 | El espacio vacío se usa como recurso, no como sobra | `VISUAL_REFINEMENT.md` P4 | ☐ |
| 5 | El texto no se estira en pantallas anchas | `RESPONSIVE_PLAN.md` §3.6 | ☐ |

**Punto 3 es el cambio más grande respecto a v0.2.** La versión actual repite el patrón panel-con-borde en cinco componentes, lo que produce estética de dashboard. La v0.3 los reemplaza por tipografía, espacio y hairlines. Si prefieres conservar los paneles, dilo: es reversible, pero la dirección premium se debilita.

## 8. Estilo

**Pregunta:** ¿se siente TINTO o se siente genérico?

| # | Criterio | Dónde | ☐ |
|---|---|---|---|
| 1 | Cálido, editorial, reservado — ¿es la voz correcta? | `VISUAL_REFINEMENT.md` §1 | ☐ |
| 2 | "Colombiana sin clichés" está bien resuelto | `VISUAL_REFINEMENT.md` §1.2 | ☐ |
| 3 | La paleta café/marfil/cobre/dorado/vino funciona | `VISUAL_REFINEMENT.md` §5.1 | ☐ |
| 4 | Serif en titulares + sans en cuerpo es la combinación correcta | `VISUAL_REFINEMENT.md` §5.4 | ☐ |
| 5 | Las prohibiciones (dashboard, SaaS, bancario, neón) están bien cubiertas | `VISUAL_REFINEMENT.md` §9.1 | ☐ |
| 6 | El verde profundo solo en confirmación — ¿de acuerdo? | `VISUAL_REFINEMENT.md` §5.2 | ☐ |

## 9. Escenas críticas — revisión detallada

Cuatro escenas concentran el riesgo. Si estas cuatro están bien, el resto sigue.

### 9.1 Atom Command Center (escena 03)

La escena de mayor carga visual y la más difícil en móvil.

| # | Criterio | ☐ |
|---|---|---|
| 1 | Los tres halos se leen como halos, no como tarjetas | ☐ |
| 2 | El núcleo es claramente el centro | ☐ |
| 3 | En móvil el reflujo a columna conserva la sensación orbital | ☐ |
| 4 | El tag "Exploración inicial" es visible sin dominar | ☐ |
| 5 | La silueta de la fundadora al 22% funciona o sobra | ☐ |

**Riesgo declarado:** en móvil la disposición orbital se pierde. La mitigación es conservar el glow de tono por halo. Si al verlo implementado se lee como menú, hay que rediseñar.

### 9.2 Office Intro (escena 06)

La escena que produce la sensación de bienvenida.

| # | Criterio | ☐ |
|---|---|---|
| 1 | La puerta de cristal comunica umbral, no oficina corporativa | ☐ |
| 2 | La taza rompiendo el marco añade o distrae | ☐ |
| 3 | Ocultar taza y retrato bajo 480px es correcto | ☐ |
| 4 | El brief de producción de la puerta es suficiente | ☐ |

### 9.3 Territory World (escena 07)

La escena que valida la elección del visitante.

| # | Criterio | ☐ |
|---|---|---|
| 1 | Las preguntas como líneas (no cards) funcionan | ☐ |
| 2 | La diferenciación de territorios solo por color es suficiente | ☐ |
| 3 | El tag de hipótesis antes del título es correcto | ☐ |

**Decisión relevante:** los tres territorios se diferencian **solo cromáticamente**, sin iconografía. Razón: iconos de sector (casa, escudo, libro) los convertirían en servicios definidos, y están marcados como hipótesis pendientes de confirmación. Si prefieres iconografía, hay que resolver antes el estatus de los territorios.

### 9.4 Booking (escena 11)

Donde el visitante entrega su contexto.

| # | Criterio | ☐ |
|---|---|---|
| 1 | Campos con hairline inferior (no caja completa) se ven editoriales | ☐ |
| 2 | Los labels siempre visibles son correctos | ☐ |
| 3 | El microcopy de mock local es suficientemente claro | ☐ |
| 4 | Los campos actuales son los correctos | ☐ |
| 5 | El verde de confirmación solo aquí es correcto | ☐ |

## 10. Desktop

| # | Criterio | ☐ |
|---|---|---|
| 1 | El contenido no supera 1180px de ancho | ☐ |
| 2 | En 1440px+ crece el margen, no el texto | ☐ |
| 3 | El encuadre 60/40 produce tensión editorial | ☐ |
| 4 | La medida de 56ch en cuerpo es cómoda | ☐ |

## 11. Móvil

| # | Criterio | ☐ |
|---|---|---|
| 1 | Ninguna escena pierde su ancla visual | ☐ |
| 2 | Los CTA son alcanzables sin scroll excesivo | ☐ |
| 3 | Los touch targets de 44px están garantizados | ☐ |
| 4 | En 320px todo sigue funcionando | ☐ |
| 5 | Móvil horizontal está contemplado | ☐ |

**Limitación conocida:** la validación de v0.2 se hizo con Chrome headless emulando viewports, no en dispositivo real. Safari iOS tiene comportamientos propios en `dvh`, safe areas y `backdrop-filter`. Recomiendo una pasada en dispositivo físico antes de publicar — no bloquea aprobar la maqueta.

## 12. Assets pendientes — decisiones que necesito de ti

Esta sección es la que **más te va a costar** y la que más bloquea.

### 12.1 P0 — Bloquean aprobar la maqueta

| # | Asset | Pregunta | Tu respuesta |
|---|---|---|---|
| 1 | Logo | ¿El `logo-mark.svg` actual es provisional o definitivo? | ____________ |
| 2 | Retrato + poster + avatar | ¿Existe sesión fotográfica de la fundadora, o hay que producirla? | ____________ |
| 3 | Puerta de cristal | ¿Hay locación disponible? ¿Cuál? | ____________ |
| 4 | Iconos | Ocho iconos SVG. ¿Los produce Codex o diseño externo? | ____________ |

**El punto 4 es el más barato y el más urgente.** La implementación actual usa `←`, `❙❙`, `▶`, `⚙` como caracteres de texto, lo que se rompe entre plataformas. Codex puede producirlos en la misma fase de implementación.

### 12.2 Decisiones de producción

| # | Pregunta | Tu respuesta |
|---|---|---|
| 5 | ¿Autorizas el uso de imagen de la fundadora para web? | ____________ |
| 6 | ¿Se graba mini-VSL real o el poster es suficiente para la maqueta? | ____________ |
| 7 | Si hay video: ¿4:5 vertical o 16:9? | ____________ |
| 8 | ¿Sesión fotográfica real o avatar IA bajo DEC-004? | ____________ |

**Punto 5 requiere autorización explícita.** `AGENTS.md` marca que el uso de imagen y voz de la fundadora necesita aprobación humana. Sin esto, ningún asset de persona se produce.

### 12.3 Decisiones de sistema

| # | Pregunta | Tu respuesta |
|---|---|---|
| 9 | Verde de confirmación: ¿`#2f4438` o prefieres otro? | ____________ |
| 10 | Tipografía: ¿serif de sistema o licenciar una propia? | ____________ |
| 11 | ¿Indicador de progreso en vista pública: ninguno o tres puntos? | ____________ |
| 12 | Etiqueta del CTA de conversión: ¿"Agendar conversación"? | ____________ |
| 13 | Etiqueta del botón de envío en booking | ____________ |
| 14 | Lista definitiva de países en el selector | ____________ |
| 15 | ¿Se confirman los tres territorios como hipótesis de trabajo? | ____________ |

## 13. Guardrails — verificación

Confirma que la especificación respetó los límites:

| # | Guardrail | Cumple | ☐ |
|---|---|---|---|
| 1 | No se produjo oferta comercial | Sí | ☐ |
| 2 | No hay precios ni planes | Sí | ☐ |
| 3 | No hay claims ni promesas de resultado | Sí | ☐ |
| 4 | No hay testimonios ni pruebas inventadas | Sí | ☐ |
| 5 | No hay garantías | Sí | ☐ |
| 6 | No se definió buyer persona ni país prioritario | Sí | ☐ |
| 7 | No se inventaron credenciales de la fundadora | Sí | ☐ |
| 8 | Territorios siguen como hipótesis | Sí | ☐ |
| 9 | No se generaron imágenes | Sí | ☐ |
| 10 | No se modificó `tools/tinto-web/` | Sí | ☐ |
| 11 | Promoción sigue bloqueada | Sí | ☐ |
| 12 | Escala de unidad comercial única preservada | Sí | ☐ |

## 14. Tu decisión

### Opción A — `human_pass`

La especificación es correcta. Codex puede implementar.

**Implica:** Codex construye la maqueta según los diez documentos, con placeholders donde falten assets. Motion sigue bloqueado hasta revisar la maqueta implementada.

**Requiere:** responder al menos las preguntas 9 a 15 de §12.3 (decisiones de sistema). Las de assets pueden resolverse en paralelo.

### Opción B — `human_changes_required`

Algo debe corregirse antes de implementar.

**Indica:** qué documento, qué sección, qué cambia. Corrijo y vuelvo a `agent_review`.

### Opción C — Maqueta parcial primero

No es una opción formal del protocolo, pero es sensata: pedir que Codex implemente solo 2–3 escenas clave (01, 03, 10) para verlas antes de comprometer las once.

**Ventaja:** valida la dirección visual con costo bajo. **Costo:** una iteración extra.

Si no estás seguro entre A y B, esta es probablemente la mejor ruta.

## 15. Registro de tu decisión

```
DECISIÓN WEB-003: [human_pass | human_changes_required | maqueta_parcial]
Fecha:
Revisor: Andrés

Cambios requeridos (si aplica):
-

Decisiones de sistema (§12.3):
9.  Verde:
10. Tipografía:
11. Progreso:
12. CTA conversión:
13. CTA booking:
14. Países:
15. Territorios:

Decisiones de asset (§12.1, §12.2):
1. Logo:
2. Sesión fotográfica:
3. Locación:
4. Iconos:
5. Autorización de imagen:
6. Video:
7. Proporción:
8. Real o IA:

Próximo paso:
```

Esto se registra en `comments/WEB-003.jsonl` cuando decidas.
