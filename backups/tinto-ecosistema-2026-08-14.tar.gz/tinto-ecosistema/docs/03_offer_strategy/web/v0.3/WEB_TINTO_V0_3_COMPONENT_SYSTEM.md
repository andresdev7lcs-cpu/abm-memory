# WEB TINTO v0.3 — Component System

- Ticket: WEB-003
- Documento: 3 de 11
- Base: `WEB_TINTO_V0_3_VISUAL_REFINEMENT.md`

## 1. Principio del sistema

El sistema tiene **pocos componentes, bien definidos**. Cada componente nuevo es una oportunidad de romper la coherencia, así que la lista es deliberadamente corta.

Regla general: si un elemento puede resolverse con tipografía y espacio, no se convierte en componente con contenedor.

Nomenclatura: `.tinto-<componente>[--<variante>]`. Los nombres de clase existentes de v0.2 se conservan donde la estructura no cambia, para que Codex no tenga que reescribir el render completo. Ver `WEB_TINTO_V0_3_CODEX_IMPLEMENTATION_HANDOFF.md` §4 para el mapeo.

## 2. CTA primario

El elemento de acción de mayor peso. **Uno solo por pantalla** (principio P3).

### Especificación

| Propiedad | Valor |
|---|---|
| Tipografía | Sans, 0.95rem, weight 500, `letter-spacing: 0.01em` |
| Altura | 48px desktop / 52px móvil (mínimo 44px absoluto) |
| Padding | 0 28px |
| Radio | `--radius-pill` (999px) |
| Fondo | Gradiente cobre: `--p-copper-500` → `--p-copper-600`, 135° |
| Texto | `--p-ivory-050` |
| Borde | 1px `rgba(gold, 0.30)` |
| Sombra | `--shadow-depth-1` + glow cobre corto |

### Estados

| Estado | Tratamiento |
|---|---|
| Default | Como arriba |
| Hover | Brillo +6%, `translateY(-1px)`, glow ampliado |
| Focus-visible | Anillo dorado 2px, offset 3px. **Nunca se elimina** |
| Active | `translateY(0)`, brillo -4%, glow reducido |
| Loading | Spinner inline, texto conservado, `aria-busy="true"`, no clickeable |
| Disabled | Opacidad 0.4, sin glow, `cursor: not-allowed`, atributo `disabled` |

### Reglas

- El cobre del CTA es **constante en los tres territorios**. No adopta el tono de territorio: la acción debe ser reconocible sin importar el contexto.
- Nunca dos CTA primarios visibles simultáneamente.
- Aislado por al menos 24px de cualquier otro control.
- El label es un verbo en infinitivo o imperativo. Sin signos de exclamación.

## 3. CTA secundario

Acción alternativa, subordinada visualmente.

| Propiedad | Valor |
|---|---|
| Tipografía | Sans, 0.9rem, weight 400 |
| Altura | 44px |
| Fondo | Transparente |
| Texto | `--text-muted` |
| Borde | Ninguno por defecto |
| Decoración | Subrayado de 1px al hover, en `--text-primary` |

Tratamiento de **texto plano**, no de botón con borde. Esto es un cambio respecto a v0.2, donde los secundarios llevan pill con borde y compiten con el primario.

### Estados

| Estado | Tratamiento |
|---|---|
| Hover | Color a `--text-primary`, subrayado aparece |
| Focus-visible | Anillo dorado 2px, offset 2px |
| Active | Opacidad 0.7 |
| Disabled | Opacidad 0.4, sin subrayado |

## 4. Controles narrativos

Los controles del overlay público: regresar, pausar, omitir, ajustes.

### Especificación

| Propiedad | Valor |
|---|---|
| Forma | Circular 44×44px (icono) o pill (texto) |
| Fondo | `rgba(void, 0.55)` + `backdrop-filter: blur(8px)` |
| Borde | 1px `--line` |
| Icono | SVG 20px, stroke 1.5px, `--text-primary` |
| Posición | Overlay fijo (Z5), respetando safe areas |

### Cambio obligatorio respecto a v0.2

La implementación actual usa caracteres como icono: `←`, `❙❙`, `▶`, `⚙`. **Deben reemplazarse por SVG inline.** Los caracteres tipográficos y emoji dependen de la fuente, se rompen entre plataformas y no responden a tokens de diseño.

| Control | Icono requerido | `aria-label` |
|---|---|---|
| Regresar | Flecha izquierda | "Regresar a la escena anterior" |
| Pausar | Dos barras verticales | "Pausar la experiencia" |
| Reanudar | Triángulo | "Reanudar la experiencia" |
| Ajustes | Deslizadores horizontales | "Ajustes de la experiencia" |
| Omitir | (solo texto) | — |

### Estados

Hover: borde a `--line-strong`, `translateY(-1px)`. Focus-visible: anillo dorado. Active: escala 0.96.

## 5. Controles accesibles

Requisitos que aplican a **todo** control del sistema:

- Touch target ≥ 44×44px, con `hitSlop` implícito por padding si el icono es menor.
- Separación mínima de 8px entre targets adyacentes.
- `aria-label` descriptivo en todo control sin texto visible.
- Foco visible en todos, con el mismo anillo dorado. Nunca `outline: none` sin reemplazo.
- Orden de tabulación coincide con el orden visual.
- Estado activo comunicado por `aria-pressed` o `aria-current`, no solo por color.
- `touch-action: manipulation` para eliminar el retardo de 300ms.

### Skip link

Se conserva el existente. Oculto hasta recibir foco, luego visible en esquina superior izquierda sobre fondo marfil con texto café.

### Anunciador de escena

Región `aria-live="polite"` que anuncia el cambio de escena a lectores de pantalla. Ya existe en v0.2, se conserva.

## 6. Títulos

### Escala

| Nivel | Uso | Tamaño desktop | Tamaño móvil | Familia |
|---|---|---|---|---|
| Display | Titular de escena | `clamp(2.4rem, 5vw, 3.6rem)` | 1.9rem | Serif |
| Title | Título de territorio, pregunta | `clamp(1.6rem, 3vw, 2.2rem)` | 1.5rem | Serif |
| Subtitle | Encabezado de bloque | 1.15rem | 1.05rem | Serif |
| Eyebrow | Rótulo superior | 0.72rem | 0.7rem | Sans, mayúsculas |

### Reglas

- Serif en Display, Title y Subtitle. Sans solo en Eyebrow.
- Peso regular a semibold. **Nunca 700+**.
- `letter-spacing: -0.02em` en Display y Title.
- Máximo 20ch desktop / 17ch móvil en Display.
- `line-height: 1.06` en Display, 1.2 en Title.
- Sin punto final.
- Eyebrow: `letter-spacing: 0.18em`, `--text-faint`.

## 7. Captions

Texto de apoyo bajo imágenes o media.

| Propiedad | Valor |
|---|---|
| Tipografía | Sans, 0.86rem |
| Color | `--text-faint` |
| Alineación | Izquierda, alineada al borde de la media |
| Separación | 10px bajo la imagen |

Para video, las captions de accesibilidad son **obligatorias** cuando exista pista de audio (contrato v0.2). En móvil se colapsan tras un control "Ver transcripción" para no consumir altura.

## 8. Progreso

**No hay barra de progreso numérica.** Decisión de dirección: convierte la experiencia en checkout (`VISUAL_REFINEMENT.md` §8.3).

La orientación se comunica por:

- **Vista pública:** cambio de registro visual entre actos, persistencia del tono de territorio, titular de cada escena. Sin indicador explícito.
- **Vista debug:** el `scene-rail` existente con las 11 pills, más el contador "03 / 11". Se conserva sin cambios.

Si en revisión humana se determina que falta orientación en vista pública, la alternativa preferida es un indicador de **tres puntos** (uno por acto), no de once. `(andres confirma)`.

## 9. Halos

El componente distintivo del sistema. Reemplaza lo que en un template sería una card de selección.

### Especificación

| Propiedad | Valor |
|---|---|
| Forma | Radio 40px, no circular ni rectangular |
| Fondo | Gradiente radial del tono al 16% + gradiente lineal café |
| Borde | Hairline 1px `rgba(ivory, 0.14)` |
| Sombra | `--shadow-depth-2` |
| Blur de fondo | `backdrop-filter: blur(6px)` — uno de los dos usos permitidos |
| Ancho | `min(280px, 30vw)` desktop / `min(100%, 340px)` móvil |
| Padding | 16px 20px |

### Estados

| Estado | Tratamiento |
|---|---|
| Default | Glow de tono al 16% |
| Hover | Glow al 26%, borde al tono 45%, `translateY(-2px)` |
| Focus-visible | Anillo dorado 2px, offset 4px |
| Active (presionado) | Escala 0.98 |
| Selected | Borde al tono 55%, anillo interior 2px al tono 20%, glow permanente |

### Reglas anti-card

- Sin fondo sólido opaco.
- Sin borde de contraste alto.
- Sin sombra dura de caja.
- El glow radial debe ser visible: es lo que produce la lectura de "halo" y no de "botón rectangular".
- No se apilan más de 3 por pantalla.

## 10. Nodos

El núcleo central de `atom-command-center` y el punto de contacto de `halo-selection`.

| Propiedad | Valor |
|---|---|
| Forma | Circular |
| Tamaño | `clamp(160px, 26vw, 232px)` núcleo / 140px pulso |
| Fondo | Gradiente radial: luz superior-izquierda + cobre central + café al borde |
| Borde | 2px `rgba(gold, 0.26)` |
| Sombra | Glow externo 70px cobre 18% + inset 40px vino 14% |
| Contenido | Silueta al 22% de opacidad + label serif + meta sans |

### Estados

Hover/focus: glow externo a 90px al 26%. Focus-visible: anillo dorado con offset 6px, respetando la forma circular.

El nodo es interactivo: `role="button"`, `tabindex="0"`, `aria-label` descriptivo.

## 11. Labels

### Label de formulario

| Propiedad | Valor |
|---|---|
| Tipografía | Sans, 0.9rem, weight 500 |
| Color | `--text-primary` |
| Posición | Sobre el campo, 8px de separación |
| Visibilidad | **Siempre visible.** Nunca placeholder-como-label |

### Tag de hipótesis

Elemento crítico para el cumplimiento de guardrails: comunica que los territorios son exploratorios.

| Propiedad | Valor |
|---|---|
| Texto | "Exploración inicial" |
| Tipografía | Sans, 0.7rem, mayúsculas, `letter-spacing: 0.08em` |
| Color | `--text-faint` |
| Fondo | `rgba(void, 0.6)` |
| Borde | 1px `--line` |
| Forma | Pill |

**Aparece antes del título** que califica, no después. No se elimina en vista pública. Su remoción requiere decisión registrada en `DECISION_LOG.md`.

### Chip de contexto

Rótulo pequeño que nombra territorio o pregunta activa. Mismo tratamiento que el tag de hipótesis pero sin borde, solo color.

## 12. Formularios

### Campo de texto / email

| Propiedad | Valor |
|---|---|
| Altura | 48px (mínimo 44px) |
| Fondo | `rgba(void, 0.4)` |
| Borde | **Solo hairline inferior** 1px `--line` |
| Radio | 0 en los lados, 4px arriba |
| Padding | 12px 4px |
| Fuente | 16px (obligatorio: evita zoom en iOS) |
| Color | `--text-primary` |

Tratamiento editorial: línea bajo el texto, no caja completa. Diferencia el formulario de un panel administrativo.

### Estados

| Estado | Tratamiento |
|---|---|
| Default | Hairline `--line` |
| Hover | Hairline al 24% |
| Focus | Hairline 2px dorado + anillo de foco |
| Filled | Hairline al 20% |
| Error | Hairline `--color-danger`, mensaje bajo el campo con icono |
| Disabled | Opacidad 0.4 |
| Read-only | Sin hairline, color `--text-muted` |

### Select

Mismo tratamiento. Chevron SVG a la derecha, 16px, `--text-faint`.

### Textarea

Mismo tratamiento, altura mínima 120px, `resize: vertical`.

### Checkbox

| Propiedad | Valor |
|---|---|
| Caja | 20×20px, radio 4px, borde 1px `--line` |
| Checked | Fondo cobre, check SVG marfil |
| Touch target | 44×44px vía padding del label |
| Label | A la derecha, alineado arriba, clickeable |

### Reglas de formulario

- Validación al perder foco (`blur`), nunca en cada tecla.
- Error junto al campo, nunca solo agrupado arriba.
- Mensaje de error indica **causa y solución**, no "Campo inválido".
- Campos requeridos marcados con asterisco y `aria-required`.
- Tipos semánticos: `email`, `tel`, `text`.
- `autocomplete` apropiado en cada campo.
- Errores con `role="alert"` o `aria-live`.
- Tras error de envío, foco automático al primer campo inválido.

## 13. Mensajes

### Mensaje de confirmación

Tras envío exitoso. Titular, cuerpo, resumen de datos en texto plano, microcopy honesto sobre lo que ocurre.

Único lugar donde el verde profundo aparece como acento (`VISUAL_REFINEMENT.md` §5.2), en un check SVG de 20px. Nada más.

### Mensaje de error

| Propiedad | Valor |
|---|---|
| Color | `--color-danger` (`#8a3a3a`, dentro de la familia cálida) |
| Icono | SVG de alerta 16px, obligatorio (nunca solo color) |
| Posición | Bajo el campo relacionado |
| Tipografía | Sans, 0.86rem |

### Microcopy honesto

Componente de texto que aparece bajo acciones con consecuencia. Su función es no prometer de más.

Ejemplos ya presentes en el contenido: "Esto no agenda ni confirma automáticamente", "Acepto que este formulario es un mock local".

`--text-faint`, 0.8rem. **No es letra chica:** debe ser legible, con contraste ≥ 3:1.

## 14. Placeholders

Zonas reservadas para assets no producidos.

### Placeholder de imagen

| Propiedad | Valor |
|---|---|
| Fondo | Gradiente café suave |
| Borde | 1px dashed `rgba(gold, 0.26)` |
| Contenido | Texto descriptivo del asset esperado, centrado |
| Proporción | **La declarada para el asset final** — obligatorio |
| Altura mínima | 280px |

La proporción declarada es lo que impide que el layout salte cuando llegue el asset real (CLS = 0).

### Etiqueta de placeholder

En vista debug: badge "Placeholder — reemplazo pendiente" en esquina superior derecha, dorado, borde dashed.

En vista pública: **la etiqueta no aparece**. El placeholder debe verse como una composición intencional, no como un hueco. Esto es lo que permite que Andrés evalúe la maqueta sin distraerse con marcadores técnicos.

### Regla de oro

La maqueta debe verse **compuesta y premium con todos los placeholders puestos**. Si una escena solo funciona cuando llega la fotografía final, la composición está mal resuelta.

## 15. Estados interactivos — tabla maestra

Referencia unificada. Todo componente interactivo implementa estos seis estados.

| Componente | Default | Hover | Focus-visible | Active | Selected | Disabled |
|---|---|---|---|---|---|---|
| CTA primario | Gradiente cobre | +6% brillo, -1px Y | Anillo dorado 2px/3px | 0px Y, -4% | — | Op. 0.4 |
| CTA secundario | Texto muted | Texto primary + subrayado | Anillo dorado 2px/2px | Op. 0.7 | — | Op. 0.4 |
| Control narrativo | Blur + borde line | Borde strong, -1px Y | Anillo dorado 2px/2px | Escala 0.96 | — | Op. 0.4 |
| Halo | Glow 16% | Glow 26%, -2px Y | Anillo dorado 2px/4px | Escala 0.98 | Borde tono 55% + anillo interior | — |
| Nodo | Glow 70px | Glow 90px | Anillo dorado 2px/6px | Escala 0.98 | — | — |
| Pregunta (línea) | Hairline 14% | Hairline al tono, -1px Y | Anillo dorado 2px/2px | Op. 0.8 | Hairline 2px tono | — |
| Campo de texto | Hairline line | Hairline 24% | Hairline 2px dorado + anillo | — | — | Op. 0.4 |
| Checkbox | Borde line | Borde strong | Anillo dorado | Escala 0.95 | Fondo cobre + check | Op. 0.4 |

### Reglas transversales de estado

- **Ninguna transición de estado altera el layout.** Solo `transform`, `opacity`, `color`, `box-shadow`, `border-color`. Nunca `width`, `height`, `padding` ni `margin`.
- Duración 150–200ms, `ease-out` al entrar.
- El foco visible **nunca** se elimina.
- El estado seleccionado se comunica por forma y color, más atributo ARIA. Nunca solo por color.
- En dispositivos táctiles, `hover` no es requisito para ninguna acción.

## 16. Reglas para evitar cards genéricas

La restricción más importante del sistema. La v0.2 actual repite el patrón `padding + borde + radio + fondo` en cinco componentes distintos, lo que produce exactamente la estética de dashboard que la dirección prohíbe.

### Las cinco reglas

**R1 — Máximo un contenedor con borde visible por pantalla.** Todo lo demás se separa con espacio y hairline.

**R2 — La separación por defecto es el espacio.** Antes de agregar un contenedor, se prueba con 32px de separación y una hairline. En la mayoría de los casos alcanza.

**R3 — Hairline en vez de caja.** Para agrupar contenido relacionado: una línea de 1px al 14% arriba o abajo del bloque. No cuatro bordes.

**R4 — Sin radio uniforme repetido.** Si tres bloques consecutivos tienen el mismo `border-radius` y el mismo fondo, se leen como una grilla de cards, sin importar el contenido. Se rompe la repetición variando tamaño, alineación o eliminando el contenedor.

**R5 — El fondo del contenedor no puede ser más claro que el fondo de la escena** salvo en el único contenedor permitido por R1. Los paneles claros apilados son la firma visual del dashboard.

### Mapeo de reemplazo desde v0.2

| Componente actual | Tratamiento v0.3 |
|---|---|
| `.copy-block` | Bloque tipográfico con hairline superior. Sin fondo, sin borde |
| `.summary-card` | Título + cuerpo con espacio. Sin contenedor |
| `.detail-card` | Bloque editorial. En `objection-layer`, barra vertical de tono |
| `.detail-card--split` | Se conserva: la barra vertical es carácter, no caja |
| `.question-card` | Línea con hairline inferior. Sin fondo, sin borde |
| `.confirmation-card` | **Único contenedor permitido** en la escena de confirmación |
| `.event-feed` | Solo vista debug. Se conserva tal cual |

Codex conserva los nombres de clase para no reescribir el render; cambia el tratamiento CSS.

## 17. Iconografía

- **Set único**, stroke 1.5px, terminaciones redondeadas, sin relleno.
- Tamaños por token: 16 / 20 / 24px. Nada intermedio.
- Todos los iconos son SVG inline con `currentColor`, para heredar color y responder a tokens.
- Sin emoji, sin caracteres tipográficos como icono, sin iconos de librería remota.
- Iconos decorativos: `aria-hidden="true"`. Iconos funcionales: dentro de un control con `aria-label`.

### Inventario mínimo requerido

| Icono | Uso | Prioridad |
|---|---|---|
| Flecha izquierda | Regresar | P0 |
| Pausa (dos barras) | Pausar | P0 |
| Play (triángulo) | Reanudar | P0 |
| Deslizadores | Ajustes | P0 |
| Chevron abajo | Select | P0 |
| Check | Checkbox, confirmación | P0 |
| Alerta | Mensaje de error | P1 |
| Cerrar (X) | Cerrar panel | P1 |

Ocho iconos. Nada más. Cada icono adicional requiere justificación en revisión.

## 18. Confirmaciones pendientes

| # | Tema | Estado |
|---|---|---|
| 1 | Indicador de progreso en vista pública: ¿tres puntos por acto o ninguno? | `(andres confirma)` |
| 2 | Valor hex del verde de confirmación | `(andres confirma)` |
| 3 | Etiquetas exactas de CTA primarios en vista pública | `(andres confirma)` |
