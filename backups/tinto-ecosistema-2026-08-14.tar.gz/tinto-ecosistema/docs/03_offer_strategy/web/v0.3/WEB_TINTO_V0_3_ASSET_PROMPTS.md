# WEB TINTO v0.3 — Asset Production Prompts

- Ticket: WEB-003
- Documento: 6 de 11
- Base: `WEB_TINTO_V0_3_ASSET_MAP.md`

## 1. Alcance y advertencia

Este documento contiene **instrucciones de producción en texto**. No se generaron imágenes en esta fase y no debe generarse ninguna a partir de este documento sin aprobación de Andrés.

Los prompts sirven para dos rutas de producción:

- **Ruta fotográfica (preferida para assets de persona):** el prompt funciona como brief de dirección para una sesión real.
- **Ruta sintética (aceptable para fondos, texturas y elementos abstractos):** el prompt funciona como entrada para herramienta generativa.

### 1.1 Restricción crítica sobre la fundadora

Los assets que representan a la fundadora (`IMG-02`, `IMG-03`, `IMG-04`, `VID-01`) **deben producirse fotográficamente con la persona real**, salvo decisión contraria registrada.

No se debe generar sintéticamente el rostro de la fundadora ni usar un modelo de stock que la sustituya. Hacerlo sería presentar como real algo que no lo es, y `CLAUDE.md` prohíbe usar conjeturas sobre la fundadora.

Si Andrés decide usar avatar IA (existe `DEC-004 — Avatar IA como multiplicador`), esa decisión debe registrarse explícitamente para este uso: `(andres confirma)`.

## 2. Parámetros globales de consistencia

Toda pieza comparte estos parámetros. Son lo que hace que las once escenas se lean como una sola producción.

| Parámetro | Valor |
|---|---|
| Temperatura de color | 2700–3200K (cálida) |
| Dirección de luz | Desde arriba, ligeramente a la izquierda (~10–11 en punto) |
| Tipo de luz | Suave, difusa, direccional. Nunca flash frontal duro |
| Paleta | Negro cálido, café profundo, marfil, cobre, dorado, vino |
| Contraste | Medio-alto, con negros que conservan detalle (no aplastados) |
| Saturación | Contenida. Sin colores puros ni sobresaturación |
| Grano | Sutil, tipo película. Sin ruido digital |
| Profundidad de campo | Abierta (f/1.8–f/2.8) en retratos; media en escenarios |
| Estética a evitar | HDR, dientes blanqueados, piel plastificada, viñeteado pesado, filtros de red social |

### 2.1 Prohibiciones transversales

En **ninguna** pieza:

- Granos de café dispersos, sacos de yute, arpillera.
- Mapas de Colombia, banderas, tricolor, sombreros vueltiaos.
- Paisaje cafetero, fincas, mulas.
- Gráficas, cifras, proyecciones, flechas ascendentes.
- Logos de terceros, sellos, certificaciones, diplomas, placas.
- Monedas, billetes, lingotes, cerdos-alcancía, símbolos de dinero.
- Rascacielos corporativos, salas de juntas llenas, equipos numerosos.
- Azul corporativo, verde menta, morado SaaS, neón.

Las tres primeras categorías protegen la regla "colombiana sin clichés". Las siguientes protegen las restricciones de veracidad y escala.

## 3. IMG-02 — Poster de la VSL de la fundadora

**Prioridad P0. Ruta: fotográfica.**

### Brief

> Retrato de medio cuerpo de una mujer profesional sentada en un espacio de trabajo cálido y privado, mirando directamente a cámara con expresión serena y atenta. La luz entra por una ventana a su izquierda, suave y cálida, modelando el rostro con sombra lateral. El fondo es un interior desenfocado en tonos café profundo y madera, con un punto de luz cálida al fondo. Sobre la mesa, apenas visible en el borde inferior del encuadre, una taza de cerámica.

| Parámetro | Especificación |
|---|---|
| **Composición** | Medio cuerpo, sujeto ligeramente descentrado a la izquierda (regla de tercios). Ojos en el tercio superior. Espacio de aire a la derecha para respiración |
| **Cámara** | 85mm equivalente, altura de ojos, ligeramente frontal. Sin picado ni contrapicado |
| **Iluminación** | Luz principal de ventana a 45° por la izquierda; rebote suave a la derecha para abrir sombras. Sin luz de fondo dura |
| **Paleta** | Café profundo y marfil dominantes; cobre en detalles; sin colores fríos |
| **Vestuario** | Sobrio, tonos tierra o marfil. Sin estampados, sin logos, sin joyería llamativa. Textura natural (lino, lana, algodón) |
| **Expresión** | Serena, atenta, receptiva. **No sonrisa comercial amplia.** La expresión de quien escucha, no de quien vende |
| **Fondo** | Interior cálido desenfocado. Sin estantes de libros como señal de autoridad, sin diplomas, sin oficina corporativa |
| **Proporción** | 4:5 vertical |
| **Uso** | Escena 02, ancla del encuadre B |
| **Restricciones** | Sin credenciales visuales. Sin gráficas. Sin elementos que impliquen escala corporativa |
| **Versión móvil** | Recorte 4:5 más cerrado, centrado en rostro y hombros. El rostro debe ocupar ≥30% del área |
| **Consistencia** | Misma persona, vestuario, luz y locación que `IMG-03` y `VID-01`. Producir en la misma sesión |

## 4. IMG-03 — Retrato de la fundadora

**Prioridad P0. Ruta: fotográfica. Misma sesión que IMG-02.**

### Brief

> Retrato cuadrado, plano más cerrado que el poster: cabeza y hombros. Misma luz cálida lateral, misma expresión serena. Fondo café profundo desenfocado, más oscuro que en el poster para permitir recorte circular limpio.

| Parámetro | Especificación |
|---|---|
| **Composición** | Cabeza y hombros, centrado. Debe funcionar dentro de una máscara circular sin cortar la barbilla ni la coronilla |
| **Cámara** | 85–105mm equivalente, altura de ojos |
| **Iluminación** | Idéntica a `IMG-02` |
| **Paleta** | Idéntica a `IMG-02` |
| **Vestuario** | Idéntico a `IMG-02` (misma sesión) |
| **Expresión** | Serena, ligeramente más cercana que en el poster |
| **Fondo** | Café profundo uniforme, desenfocado. Sin elementos identificables |
| **Proporción** | 1:1 |
| **Uso** | Fallback de escena 02; apoyo en escena 06 |
| **Restricciones** | Mismas que `IMG-02` |
| **Versión móvil** | La misma; se usa a 280px |
| **Consistencia** | Obligatoria con `IMG-02` |

## 5. IMG-04 — Silueta de núcleo

**Prioridad P1. Ruta: derivada de IMG-03, no producción nueva.**

### Instrucción de tratamiento

No es una toma nueva: es un tratamiento de `IMG-03`.

1. Recortar a 1:1 centrado en cabeza y hombros.
2. Aumentar contraste hasta que la silueta sea legible como forma.
3. Reducir detalle facial fino (se mostrará al 22% de opacidad; el detalle se pierde igual).
4. Exportar con transparencia; el fondo debe eliminarse por completo.
5. Verificar legibilidad al 22% de opacidad sobre el gradiente del núcleo.

| Parámetro | Especificación |
|---|---|
| **Proporción** | 1:1 |
| **Transparencia** | Obligatoria |
| **Uso** | Escena 03, detrás del label del núcleo |
| **Restricciones** | Al 22% no debe leerse como fantasma inquietante ni como mancha. Si no funciona, el fallback sin silueta es aceptable |
| **Consistencia** | Derivado directo de `IMG-03` |

## 6. IMG-05 — Gesto de mano y halo

**Prioridad P1. Ruta: fotográfica o ilustración vectorial.**

### Brief

> Una mano extendida desde el borde inferior izquierdo del encuadre, con la palma abierta hacia arriba y los dedos relajados, aproximándose a un punto de luz cálida suspendido. El gesto es de ofrecimiento y contacto, no de agarre. La luz del halo ilumina la mano desde arriba, produciendo sombra suave bajo los dedos. Fondo negro cálido, sin elementos.

| Parámetro | Especificación |
|---|---|
| **Composición** | Mano entrando desde el borde inferior izquierdo, punto de contacto en el centro óptico del encuadre. Espacio negro alrededor |
| **Cámara** | 50mm equivalente, ligeramente cenital. Enfoque en el punto de contacto |
| **Iluminación** | El halo es la fuente lumínica: luz cálida desde el punto de contacto hacia la mano. Sin luz ambiente que compita |
| **Paleta** | Negro cálido dominante; cobre y dorado en la luz; piel en tono natural cálido |
| **Vestuario** | Manga sobria en tono tierra o marfil, si aparece. Sin reloj, sin anillos llamativos, sin joyería |
| **Expresión** | (No aplica: no hay rostro.) El gesto debe leerse como calma, no como urgencia |
| **Fondo** | Negro cálido puro, sin textura ni elementos |
| **Proporción** | 1:1 |
| **Uso** | Escena 04, ancla del encuadre B |
| **Restricciones** | Sin manos estrechándose (cliché de negocio). Sin dedo índice apuntando. Sin sostener objetos |
| **Versión móvil** | Recorte cuadrado más cerrado; el punto de contacto debe permanecer en el centro |
| **Consistencia** | El tono del halo se aplica por CSS, no en la imagen. Producir con luz neutra-cálida para que el tono de territorio funcione encima |

**Nota:** el fallback abstracto (halo con línea luminosa y pulso, sin mano) ya existe y es suficiente. Este asset es mejora, no requisito.

## 7. IMG-06 — Puerta de cristal

**Prioridad P0. Ruta: fotográfica.**

### Brief

> Una puerta de cristal entreabierta vista desde el exterior, con luz cálida saliendo del interior. A través del cristal se intuye un espacio de trabajo íntimo y ordenado, sin detalle definido. El marco es de madera o metal oscuro. La luz interior es la fuente lumínica de la imagen: cálida, de tarde. Reflejo suave en el cristal, sin distorsión.

| Parámetro | Especificación |
|---|---|
| **Composición** | Puerta ocupando dos tercios del encuadre, entreabierta hacia la izquierda. Umbral visible en el tercio inferior. Vertical |
| **Cámara** | 35mm equivalente, altura de ojos, frontal ligeramente descentrada. Sin distorsión de gran angular |
| **Iluminación** | Luz cálida desde el interior atravesando el cristal. Exterior en penumbra. Contraste entre dentro y fuera |
| **Paleta** | Negro cálido y café en el exterior; marfil y dorado en la luz interior |
| **Vestuario** | (No aplica.) Sin personas en el encuadre |
| **Expresión** | (No aplica.) La imagen debe sentirse como invitación, no como espacio vacío |
| **Fondo** | El interior desenfocado. Sin logos, sin señalética, sin números de oficina |
| **Proporción** | 3:4 vertical |
| **Uso** | Escena 06, ancla del encuadre B |
| **Restricciones** | Sin lobby corporativo, sin torre de oficinas, sin recepción con mostrador. La escala debe ser de espacio íntimo, no institucional |
| **Versión móvil** | Recorte 3:4 más cerrado centrado en el umbral y la línea de luz |
| **Consistencia** | Misma locación y temperatura de luz que `IMG-07` |

## 8. IMG-07 — Taza TINTO

**Prioridad P2. Ruta: fotográfica. Misma locación que IMG-06.**

### Brief

> Una taza de cerámica pequeña con café negro, sobre una superficie de madera. La taza es de uso cotidiano, no de catálogo: tiene desgaste. Luz cálida lateral que produce brillo suave en la superficie del café y sombra larga sobre la madera. Vapor apenas insinuado, no protagonista.

| Parámetro | Especificación |
|---|---|
| **Composición** | Taza descentrada, con espacio a un lado. Ángulo de tres cuartos, no cenital puro |
| **Cámara** | 50–85mm equivalente, ligeramente por encima del nivel de la mesa. Profundidad de campo abierta |
| **Iluminación** | Lateral cálida desde la izquierda; sombra proyectada larga hacia la derecha |
| **Paleta** | Café profundo, marfil de la cerámica, madera cálida |
| **Vestuario** | (No aplica) |
| **Expresión** | (No aplica.) Debe leerse como hospitalidad, no como producto |
| **Fondo** | Superficie de madera y penumbra. Sin mantel decorativo, sin utilería |
| **Proporción** | 1:1, con recorte transparente |
| **Uso** | Escena 06, superpuesta rompiendo el marco de la puerta |
| **Restricciones** | **Sin granos de café alrededor. Sin saco de yute. Sin cuchara de madera rústica. Sin libro abierto al lado.** Sin latte art (es tinto, café negro) |
| **Versión móvil** | Se oculta bajo 480px; no requiere variante |
| **Consistencia** | Misma luz y locación que `IMG-06` |

## 9. VID-01 — Mini-VSL de la fundadora

**Prioridad P1. Ruta: fotográfica en video. Estado: `pending_decision`.**

### Brief

> Plano medio fijo de la fundadora hablando a cámara, en la misma locación, luz y vestuario que el poster fotográfico. Sin cortes, sin zoom, sin movimiento de cámara. La cámara está quieta; ella habla. Fondo desenfocado cálido.

| Parámetro | Especificación |
|---|---|
| **Composición** | Plano medio, sujeto descentrado a la izquierda, mirada a cámara |
| **Cámara** | Fija sobre trípode. 50–85mm. Sin movimiento, sin gimbal, sin dron |
| **Iluminación** | Idéntica a `IMG-02`. Continua, no flash |
| **Paleta** | Idéntica a `IMG-02` |
| **Vestuario** | Idéntico a `IMG-02` (misma sesión) |
| **Expresión** | Conversacional, pausada. Hablando con alguien, no presentando a una audiencia |
| **Fondo** | Idéntico a `IMG-02` |
| **Proporción** | 4:5 vertical, o 16:9 con recorte seguro `(andres confirma)` |
| **Uso** | Escena 02, reemplaza el poster cuando exista |
| **Restricciones** | Sin música que domine la voz. Sin texto sobreimpreso. Sin llamados a la acción hablados. **Sin claims de resultado, precios, garantías ni credenciales** |
| **Versión móvil** | El mismo archivo; recorte por CSS |
| **Consistencia** | Misma sesión que `IMG-02` e `IMG-03`. El primer fotograma debe poder servir de poster |

### Restricciones de guion

El guion **no se escribe en esta fase**. Cuando se escriba, no puede contener oferta, precios, servicios específicos, garantías, resultados, testimonios ni credenciales inventadas. Guion y duración: `(andres confirma)`.

Captions obligatorias en español. Sin autoplay con audio.

## 10. TEX-01 — Textura orgánica de fondo

**Prioridad P2. Ruta: sintética o escaneo.**

### Brief

> Textura tileable de grano fino, tipo papel de algodón o textil de lino visto de muy cerca. Monocroma, sin patrón reconocible ni dirección dominante. Grano irregular pero uniforme en densidad.

| Parámetro | Especificación |
|---|---|
| **Composición** | Tile de 512×512px, sin costura visible al repetir |
| **Cámara** | (Escaneo plano o generación sintética) |
| **Iluminación** | Plana, sin sombras direccionales que revelen el patrón al repetir |
| **Paleta** | Escala de grises; el color lo aporta el CSS por multiplicación |
| **Proporción** | 1:1 |
| **Uso** | Capa Z1 global, opacidad ≤ 0.05 |
| **Restricciones** | Sin arpillera, sin yute, sin madera, sin patrón geométrico. Sin ruido digital tipo TV |
| **Versión móvil** | La misma; se desactiva si degrada el rendimiento |
| **Consistencia** | Debe ser invisible como textura y perceptible solo como calidez |

## 11. Fondos por territorio

**Prioridad P2. Ruta: sintética (abstracta).**

Los tres territorios se diferencian por **tono de luz**, no por iconografía. No se produce una imagen literal por territorio: eso obligaría a representar servicios que no están aprobados.

### Brief común

> Campo de luz abstracto: gradiente radial suave con grano, sin forma reconocible, sin objeto. Solo profundidad y color.

| Territorio | Tono de luz | Sensación |
|---|---|---|
| Finanzas y patrimonio | Vino profundo con centro cobre | Densidad, contención, autoridad |
| Activos inmobiliarios | Cacao con centro cobre cálido | Materialidad, solidez, tierra |
| Educación y orientación | Dorado con centro marfil | Claridad, apertura, luz |

| Parámetro | Especificación |
|---|---|
| **Composición** | Gradiente radial descentrado, sin borde definido |
| **Paleta** | Ver tabla; valores RGB en `DESIGN_TOKENS.md` §3 |
| **Proporción** | Fluida; se genera por CSS o canvas |
| **Uso** | Escena 07, capa Z1 |
| **Restricciones** | **Sin iconografía de sector.** Sin casas, sin gráficas, sin libros, sin escudos, sin candados. La diferenciación es cromática y nada más |
| **Versión móvil** | Simplificado o estático |
| **Consistencia** | Los tres comparten estructura; solo cambia el tono |

**Nota estratégica:** representar los territorios con iconografía literal los convertiría en servicios definidos. Están marcados como `[HIPÓTESIS]` con `approval: pending_confirmation`. La diferenciación cromática los mantiene como exploración.

## 12. Recursos de escena por territorio

Los "recursos provisionales" del contenido (`Mapa de lectura provisional`, `Checklist provisional`, etc.) **no se producen como assets visuales en esta fase**.

Razón: producir la imagen de un recurso descargable implicaría que el recurso existe. No existe, y su contenido tocaría materia financiera que requiere aprobación.

Tratamiento en la maqueta: bloque tipográfico con hairline, sin imagen, sin icono de documento, sin botón de descarga.

Producción futura: `(andres confirma)`.

## 13. Checklist de producción

Antes de dar por buena cualquier pieza:

- [ ] Temperatura de color entre 2700K y 3200K
- [ ] Luz desde arriba-izquierda, consistente con las demás piezas
- [ ] Paleta dentro de negro cálido / café / marfil / cobre / dorado / vino
- [ ] Sin ninguno de los elementos prohibidos de §2.1
- [ ] Sin implicar hechos no aprobados (escala, credenciales, resultados)
- [ ] Proporción exacta a la declarada en `ASSET_MAP.md`
- [ ] El sujeto sobrevive al recorte móvil
- [ ] Exportado en WebP con respaldo
- [ ] Peso optimizado para móvil
- [ ] `alt` descriptivo redactado

## 14. Confirmaciones pendientes

| # | Tema | Estado |
|---|---|---|
| 1 | Autorización de uso de imagen y voz de la fundadora | `(andres confirma)` — requiere revisión humana |
| 2 | ¿Sesión fotográfica real o avatar IA bajo DEC-004? | `(andres confirma)` |
| 3 | Locación para puerta de cristal y taza | `(andres confirma)` |
| 4 | Guion y duración del mini-VSL | `(andres confirma)` |
| 5 | Proporción del video: 4:5 o 16:9 | `(andres confirma)` |
| 6 | ¿Se producen recursos descargables por territorio? | `(andres confirma)` |

**Ninguna imagen fue generada en esta fase.**
