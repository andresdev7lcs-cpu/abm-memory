# WEB TINTO v0.3 — Codex Implementation Handoff

- Ticket: WEB-003
- Documento: 10 de 11
- De: Claude Code (estratega documental)
- Para: Codex (especialista técnico)

## 0. Condición de arranque — leer primero

**Codex no debe implementar nada de este documento hasta que Andrés emita `human_pass`** sobre `WEB_TINTO_V0_3_HUMAN_REVIEW_GUIDE.md`.

Si la decisión es `human_changes_required`, la especificación se corrige antes. Si la decisión es `maqueta_parcial`, se implementan solo las escenas 01, 03 y 10.

Verificar en `comments/WEB-003.jsonl` que la decisión esté registrada antes de tocar código.

## 1. Qué recibes

Diez documentos de especificación en `docs/03_offer_strategy/web/v0.3/`:

| Documento | Qué te da |
|---|---|
| `VISUAL_REFINEMENT.md` | Dirección, principios, jerarquía, encuadres, profundidad, restricciones |
| `SCENE_COMPOSITIONS.md` | Las 11 escenas: layout desktop/tablet/móvil, zonas de imagen, CTA, fallback |
| `COMPONENT_SYSTEM.md` | Componentes, estados, reglas anti-card |
| `DESIGN_TOKENS.md` | Tokens nombrados y valorados, listos para CSS |
| `ASSET_MAP.md` | Inventario, prioridades, proporciones, fallbacks |
| `ASSET_PROMPTS.md` | Briefs de producción (no los ejecutas tú) |
| `MOTION_MAP.md` | Motion futuro — **bloqueado, no implementar** |
| `RESPONSIVE_PLAN.md` | Breakpoints, colisiones, matriz de verificación |
| `HUMAN_REVIEW_GUIDE.md` | La guía de Andrés (contexto para ti) |
| Este documento | Tu alcance |

## 2. Archivos que PUEDES modificar

```
tools/tinto-web/styles.css              ← el grueso del trabajo
tools/tinto-web/components.mjs          ← solo render/markup, ver §3
tools/tinto-web/index.html              ← meta, título, estructura mínima
tools/tinto-web/assets/*.svg            ← iconos nuevos, placeholders
```

Archivos nuevos permitidos:

```
tools/tinto-web/assets/icons/*.svg      ← set de 8 iconos
tools/tinto-web/styles/*.css            ← si divides el CSS en módulos
```

## 3. Archivos PROHIBIDOS

```
tools/tinto-web/state.mjs               ← state machine
tools/tinto-web/scene-events.mjs        ← 18 eventos
tools/tinto-web/scene-controller.mjs    ← motor de escenas
tools/tinto-web/router.mjs              ← deep links
tools/tinto-web/content.mjs             ← contenido y copy
tools/tinto-web/performance-mode.mjs    ← tiers
tools/tinto-web/view-mode.mjs           ← público/debug
tools/tinto-web/motion-engine.mjs       ← motion (bloqueado)
tools/tinto-web/canvas-atmosphere.mjs   ← solo parámetros, no lógica
tools/tinto-web/analytics-contract.mjs
tools/tinto-web/media-contracts.mjs
tools/tinto-web/app.mjs
tools/tinto-web/server.mjs
```

Fuera de `tools/`:

```
DECISION_LOG.md, PROJECT_RULES.md, AGENTS.md, CLAUDE.md
roadmap.md, roadmap-status.md
docs/03_offer_strategy/web/v0.2/**      ← documentos aprobados
docs/03_offer_strategy/web/v0.3/**      ← esta especificación
memory/**, STR-001, EVIDENCE_DIAGNOSIS
```

### 3.1 Excepción acotada en `components.mjs`

Puedes cambiar **markup y clases**. No puedes cambiar:

- qué escena renderiza qué (el mapa `sceneRenderer`);
- los `data-action` de los controles;
- la lógica de `debugMode`;
- los `data-scene`, `data-phase`, `data-tone`, `data-view-mode`;
- la función `escapeHtml` ni su aplicación (es la defensa contra inyección: **todo valor interpolado sigue pasando por ella**).

Si un cambio de markup exige tocar `state.mjs` o `scene-events.mjs`, **detente y escala**. Significa que la especificación está mal.

## 4. Componentes a construir

### 4.1 Nuevos

| Componente | Spec | Prioridad |
|---|---|---|
| Set de 8 iconos SVG | `COMPONENT_SYSTEM.md` §17 | **P0** |
| CTA secundario como texto plano | §3 | P0 |
| Pregunta como línea con hairline | §16 | P0 |
| Campo con hairline inferior | §12 | P0 |
| Microcopy honesto | §13 | P0 |
| Placeholder con proporción declarada | §14 | P0 |
| Barra vertical de objeción | `SCENE_COMPOSITIONS.md` §11 | P1 |
| Check de confirmación | §13 | P1 |

### 4.2 A restilizar

| Componente actual | Cambio | Spec |
|---|---|---|
| `.copy-block` | Quitar fondo y borde → hairline superior | `COMPONENT_SYSTEM.md` §16 |
| `.summary-card` | Quitar contenedor → tipografía y espacio | §16 |
| `.detail-card` | Quitar contenedor → bloque editorial | §16 |
| `.question-card` | → línea con hairline inferior | §16 |
| `.confirmation-card` | **Conservar** (único contenedor permitido) | §16 |
| `.territory-orbit` | Reforzar glow, quitar apariencia de card | §9 |
| `.scene-action--primary` | Gradiente cobre + glow, estados | §2 |
| `.scene-action` (secundario) | → texto plano con subrayado | §3 |
| `.public-control` | Reemplazar caracteres por SVG | §4 |
| `.booking-field input` | → hairline inferior | §12 |

**Conserva los nombres de clase.** Renombrarlos obliga a reescribir el render sin beneficio.

### 4.3 Reemplazo obligatorio de iconos

La implementación actual usa caracteres como icono en `renderPublicOverlay`:

```
←   →  SVG flecha izquierda
❙❙  →  SVG pausa
▶   →  SVG play
⚙   →  SVG ajustes
```

Motivo: dependen de la fuente, se rompen entre plataformas, no responden a tokens. Viola la regla de no-emoji del sistema.

Cada icono: SVG inline, `currentColor`, stroke 1.5px, `aria-hidden="true"`, dentro de un control con `aria-label`.

## 5. Tokens a implementar

Fuente: `DESIGN_TOKENS.md`. Orden sugerido:

1. **Primitivos** (§2, §2.1) — añadir verde y rojo cálido. El resto ya existe.
2. **Semánticos** (§4) — añadir los `[NUEVO]`.
3. **Tipografía** (§5) — escala, pesos, medidas de línea. Todo nuevo.
4. **Espacio** (§6) — **normalizar a 4/8**. Verifica que nada dependa de 6/10/14/18.
5. **Radios, sombras, glows** (§7, §8).
6. **Opacidad, Z, blur** (§9).
7. **Tamaños, breakpoints, touch** (§11, §12, §13).
8. **Estados** (§14).

### 5.1 Dos cambios con riesgo de regresión

| Cambio | Riesgo | Verificación |
|---|---|---|
| `--space-1..4` de 6/10/14/18 a 4/8/12/16 | Layouts que dependan de los valores previos | Revisar cada escena tras el cambio |
| `--bp-md` de 760px a 768px | Media queries desalineadas | Actualizar todas las de 760px |

### 5.2 Reglas

- Ningún hex crudo en reglas de componente.
- Ningún componente referencia un primitivo directamente.
- Tonos como tripletas RGB, no hex.
- **No renombres los tokens heredados de v0.2.**

## 6. SVG y recursos técnicos

### 6.1 A producir

| Recurso | Detalle |
|---|---|
| 8 iconos | Flecha izq., pausa, play, ajustes, chevron, check, alerta, cerrar |
| Placeholders | Por zona de imagen, con proporción declarada |

### 6.2 A conservar

Los SVG existentes (`logo-mark`, `founder-*`, `halo-hand`, `glass-door`, `tinto-cup`) son placeholders. **No los reemplaces por assets inventados.** Se sustituyen cuando exista producción real.

### 6.3 Zonas de imagen

Cada zona lleva:

- proporción declarada vía `aspect-ratio` (evita CLS);
- `width`/`height` en el HTML cuando sea imagen;
- `loading="lazy"` salvo escena 01;
- `alt` descriptivo, o `alt=""` + `aria-hidden` si es decorativa;
- fallback definido en `ASSET_MAP.md`.

**Criterio:** la maqueta debe verse compuesta con todos los placeholders puestos. En vista pública **no** se muestra la etiqueta "Placeholder"; solo en debug.

## 7. Responsive

Fuente: `RESPONSIVE_PLAN.md`.

| Requisito | Detalle |
|---|---|
| Breakpoints | 320 / 375 / 768 / 1024 / 1180 / 1440 |
| Móvil horizontal | `max-height: 480px and (orientation: landscape)` |
| Pantallas altas | `min-height: 900px` |
| Safe areas | `env(safe-area-inset-*)` en overlay y CTA |
| Altura | `100dvh`, nunca `100vh` |
| Contenido | Máximo 1180px; crece el margen, no el texto |
| Sin scroll horizontal | En ningún breakpoint |

### 7.1 Colisiones a verificar

| # | Colisión | Dónde |
|---|---|---|
| 3 | Halos sobre el núcleo | 768px, altura baja |
| 4 | Overlay sobre CTA | Móvil horizontal |
| 5 | Teclado virtual sobre envío | Móvil, `booking` |
| 6 | Panel de ajustes fuera del viewport | 320px |
| 7 | Titular de 3+ líneas | 320px, escenas 03 y 07 |

Las 1 y 2 ya están resueltas en v0.2. Evidencia en captura para cada una.

## 8. Accesibilidad

Requisitos no negociables:

| # | Requisito |
|---|---|
| 1 | Contraste ≥4.5:1 en texto, ≥3:1 en UI. **Verificar con herramienta real** |
| 2 | Foco visible en todo control. Nunca `outline: none` sin reemplazo |
| 3 | Touch targets ≥44×44px, separación ≥8px |
| 4 | `aria-label` en todo control sin texto |
| 5 | Orden de tabulación = orden visual |
| 6 | Jerarquía de encabezados sin saltos |
| 7 | `prefers-reduced-motion` respetado |
| 8 | Estado por ARIA, no solo color |
| 9 | Labels de formulario visibles |
| 10 | Errores junto al campo, con `role="alert"` |
| 11 | Inputs a 16px en móvil |
| 12 | Skip link y anunciador `aria-live` conservados |
| 13 | `alt` descriptivo o `aria-hidden` en decorativas |
| 14 | Contenido completo con `reduced motion` |

**Punto 1:** los ratios de `DESIGN_TOKENS.md` §10 son estimaciones. Verifícalos y reporta cualquier par bajo mínimo.

## 9. Qué NO debes inventar

| No inventes | Por qué |
|---|---|
| Copy nuevo | El contenido vive en `content.mjs`, aprobado. No lo cambies |
| Precios, planes, comparativas | Prohibido por guardrails |
| Testimonios, logos, cifras, sellos | Prohibido |
| Claims de resultado | Prohibido |
| Credenciales de la fundadora | Prohibido |
| Assets finales | Los placeholders se conservan hasta producción real |
| Territorios nuevos | Los tres son hipótesis pendientes |
| Campos de formulario | Los de `content.mjs` son los aprobados |
| Etiquetas de CTA | Las pendientes están como `(andres confirma)` |
| Integraciones | Booking es mock local: sin calendario, sin scoring, sin persistencia |
| Analytics | Sin proveedor conectado |
| Dependencias remotas | Sin CDN, sin Google Fonts, sin fetch externo |

Si algo falta para implementar, **para y escala**. No rellenes con supuestos.

## 10. Qué NO debes cambiar

| No cambies | Dónde |
|---|---|
| Orden canónico de 11 escenas | `content.mjs` `sceneOrder` |
| State machine | `state.mjs` |
| 18 eventos | `scene-events.mjs` |
| Navegación reversible | Puente `territory-world → office-intro` |
| Deep links | `router.mjs` |
| Performance tiers | `performance-mode.mjs` |
| Separación público/debug | `view-mode.mjs` |
| Booking mock | Los tres `disabled` |
| Nombres de tono | `forest`/`petrol`/`copper` — romperían `content.mjs` y el canvas |
| `escapeHtml` | Defensa contra inyección |
| Stack | HTML modular + CSS modular + ES modules. **Sin framework** |

## 11. Criterios de aceptación

### 11.1 Visual

- [ ] Tokens implementados según `DESIGN_TOKENS.md`
- [ ] Sin hex crudo en reglas de componente
- [ ] Las 11 escenas siguen su encuadre asignado
- [ ] Máximo un contenedor con borde por pantalla
- [ ] Un solo CTA primario por pantalla
- [ ] Texto ≤56ch desktop / 40ch móvil
- [ ] Contenido ≤1180px
- [ ] Paleta respetada; sin azul, morado ni neón
- [ ] Verde solo en confirmación, ≤2% del área
- [ ] `backdrop-filter` solo en overlay y halos

### 11.2 Componentes

- [ ] 8 iconos SVG reemplazan los caracteres
- [ ] Sin emoji ni caracteres como icono
- [ ] Seis estados en cada componente interactivo
- [ ] Ninguna transición de estado altera el layout
- [ ] Halos se leen como halos
- [ ] Preguntas como líneas, no cards
- [ ] Campos con hairline inferior
- [ ] Tag "Exploración inicial" presente y antes del título

### 11.3 Responsive

- [ ] Sin scroll horizontal en 320/375/768/1024/1180/1440
- [ ] Móvil horizontal verificado
- [ ] Safe areas respetadas
- [ ] `100dvh` en vez de `100vh`
- [ ] Touch targets ≥44px
- [ ] Colisiones 3–7 verificadas con captura
- [ ] Ancla visual presente en las 11 escenas en móvil

### 11.4 Accesibilidad

- [ ] Contraste verificado con herramienta, reportado
- [ ] Foco visible en todos los controles
- [ ] Recorrido completo por teclado
- [ ] `reduced motion` conserva todo el contenido
- [ ] Labels visibles en formulario
- [ ] Inputs a 16px en móvil

### 11.5 Integridad

- [ ] Ningún archivo prohibido modificado
- [ ] `git diff --stat` limitado a los permitidos
- [ ] 11 escenas y orden intactos
- [ ] 18 eventos intactos
- [ ] Navegación reversible funcionando
- [ ] Booking sigue mock local
- [ ] Sin dependencias remotas
- [ ] Sin migración de framework
- [ ] Motion avanzado **no implementado**

## 12. Pruebas obligatorias

### 12.1 Recorrido funcional

1. Las 11 escenas en orden, adelante.
2. Regreso completo, verificando el puente `territory-world → office-intro`.
3. Los tres territorios, uno por uno.
4. Las tres preguntas de un territorio.
5. Envío del booking mock y confirmación.
6. `skip-intro` desde cada escena donde aplique.
7. `abort-transition` durante el blackout.
8. Deep links de `router.mjs`.

### 12.2 Responsive

Captura de las 11 escenas en 320, 375, 768, 1024, 1440 y móvil horizontal. **66 capturas mínimo.** Matriz en `RESPONSIVE_PLAN.md` §17.

### 12.3 Accesibilidad

1. Recorrido completo solo con teclado.
2. Contraste de todos los pares de `DESIGN_TOKENS.md` §10.
3. Con `prefers-reduced-motion: reduce` activo, recorrido completo.
4. Lector de pantalla en al menos 3 escenas.
5. Verificación de touch targets.

### 12.4 Performance

1. Los tres tiers.
2. Canvas desactivado.
3. Sin imágenes (fallback).
4. Sin JavaScript (`noscript`).

### 12.5 Integridad

```bash
git status --short
git diff --stat
git diff --check
```

Confirmar que solo aparecen archivos permitidos.

## 13. Condición para `agent_review`

Codex marca `agent_review` cuando:

1. Todos los criterios de §11 se cumplen o tienen gap explícito.
2. Las pruebas de §12 se ejecutaron con evidencia.
3. Ningún archivo prohibido fue modificado.
4. Motion avanzado no fue implementado.
5. Los hallazgos quedan registrados en `comments/WEB-003.jsonl`.

**Codex no puede marcar su propio trabajo como `completed`** (`AGENTS.md`). Queda en `agent_review` esperando auditoría independiente y revisión de Andrés.

### 13.1 Formato de registro

```json
{
  "timestamp": "ISO-8601",
  "author": "codex",
  "type": "delivery",
  "ticket": "WEB-003",
  "message": "Implementación visual v0.3. Estado: agent_review. Archivos modificados: [...]. Pruebas: [...]. Gaps: [...]. Pendientes: [...]"
}
```

## 14. Escalación

Detente y escala si:

1. Un cambio visual exige tocar `state.mjs`, `scene-events.mjs` o `scene-controller.mjs`.
2. La especificación contradice el comportamiento implementado.
3. Falta una decisión marcada `(andres confirma)` y bloquea.
4. Un criterio de accesibilidad choca con uno estético.
5. Un cambio de token produce regresión no prevista.
6. Falta un asset y el fallback no alcanza.

Formato: `BLOQUEADO: [razón]. Falta: (andres confirma)` en `comments/WEB-003.jsonl`.

## 15. Orden de trabajo sugerido

| Fase | Contenido | Verificación |
|---|---|---|
| **C1** | Tokens en CSS. Sin cambios visuales aún | Nada roto |
| **C2** | 8 iconos SVG, reemplazo en overlay | Iconos correctos en todas las plataformas |
| **C3** | Componentes base: CTA, campos, estados | Estados completos |
| **C4** | Reglas anti-card: quitar contenedores | Máximo uno con borde |
| **C5** | Composición escenas 01–05 | Capturas |
| **C6** | Composición escenas 06–11 | Capturas |
| **C7** | Responsive y colisiones | Matriz completa |
| **C8** | Accesibilidad y contraste | Reporte |
| **C9** | Pruebas finales y registro | `agent_review` |

Cada fase se verifica antes de la siguiente. C1 y C4 son las de mayor riesgo de regresión.

## 16. Handoff

```
HANDOFF: WEB-003 especificación visual → Codex
Qué se entrega: 10 documentos de especificación en docs/03_offer_strategy/web/v0.3/
Qué se necesita próximo: implementación tras human_pass de Andrés
Bloqueos identificados:
  - human_pass pendiente (bloqueante)
  - 15 decisiones (andres confirma) en HUMAN_REVIEW_GUIDE.md §12
  - 5 assets P0 pendientes de producción (los placeholders permiten avanzar)
  - Autorización de imagen de la fundadora (bloquea assets de persona)
Recomendación: implementar C1–C4 (tokens, iconos, componentes, anti-card) incluso
  con assets pendientes; el grueso de la mejora visual no depende de fotografía.
```
