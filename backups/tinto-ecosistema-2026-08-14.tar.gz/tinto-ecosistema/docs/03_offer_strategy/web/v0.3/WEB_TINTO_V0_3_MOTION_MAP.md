# WEB TINTO v0.3 — Motion Map

- Ticket: WEB-003
- Documento: 7 de 11
- Base: `WEB_TINTO_V0_3_SCENE_COMPOSITIONS.md`

## 1. Estado: bloqueado

**Motion avanzado permanece bloqueado hasta que Andrés apruebe la maqueta visual predefinitiva.**

Este documento es un **mapa**, no una implementación. Especifica qué debería moverse, por qué, cuánto y bajo qué condiciones, para que la fase de motion tenga un plan en lugar de improvisación.

Codex **no implementa nada de este documento** en la fase actual. Lo único que permanece activo es el motion ya existente en v0.2, listado en §3.

## 2. Principios

Heredados de `WEB_TINTO_V0_2_MOTION_ARCHITECTURE.md`, sin cambio:

1. El movimiento expresa causa y efecto. Nunca decoración.
2. Nada animado bloquea la interacción.
3. Toda transición es reversible y abortable.
4. `reduced motion` conserva el contenido completo.
5. El presupuesto de motion depende del tier.
6. La continuidad espacial debe sentirse, no distraer.

### 2.1 Principios añadidos en v0.3

7. **Máximo dos elementos animados por escena.** Más de dos produce ruido, no cine.
8. **Solo `transform` y `opacity`.** Nunca `width`, `height`, `top`, `left`, `padding` ni `margin`.
9. **La salida es más rápida que la entrada** (~60–70% de la duración).
10. **Todo motion es interrumpible.** Un toque del usuario cancela la animación en curso.

## 3. Motion existente — se conserva

Ya implementado en v0.2 y auditado. No se toca en esta fase.

| Elemento | Escena | Comportamiento | Estado |
|---|---|---|---|
| Transición de fase de escena | Todas | `entering` / `exiting` con opacidad, `translateY` y blur | Activo |
| Respiración de logo | 01 | Escala 1↔1.03, 2.4s, infinito | Activo |
| Apertura de telón | 01 | Opacidad 1→0.2 sobre `--motion-wave` | Activo |
| Pulso de halo | 04 | Escala 0.98↔1.02, infinito | Activo |
| Línea luminosa | 04 | Opacidad 0.3↔0.8, infinito | Activo |
| Pulso de transición | 05 | Escala 0.94↔1.06, infinito | Activo |
| Revelación de detalle | 08 | `translateY(10px)` → 0 con fade | Activo |
| Ondas de canvas | 03, 07 | Generativo reactivo | Activo |

## 4. Clasificación

| Clase | Significado |
|---|---|
| `motion_required` | La escena pierde sentido narrativo sin este movimiento |
| `motion_optional` | Mejora la percepción; la escena funciona sin él |
| `motion_avoid` | Explícitamente prohibido; documentado para que no se implemente |

## 5. Mapa por escena

### Escena 01 — `curtain`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Logo | Carga | Fade + escala 0.96→1 | Fade | Centro | 600ms | `--ease-enter` | Aparición | Estático, visible | IMG-01 | `motion_required` |
| Respiración de logo | Post-entrada | Escala 1↔1.03 | — | — | 2400ms loop | `--ease-standard` | Presencia viva | Sin loop | IMG-01 | `motion_optional` |
| Telón | Carga | Opacidad 1→0.2 | — | — | `--motion-wave` | `--ease-enter` | Apertura de sala | Sin animación | — | `motion_optional` |
| Titular | Tras logo | Fade + `translateY(8px)`→0 | Fade | Desde abajo | 400ms, delay 200ms | `--ease-enter` | Secuencia de lectura | Visible directo | — | `motion_optional` |

**`motion_avoid`:** rotación del logo, partículas, tipografía animada letra por letra, contador de carga.

### Escena 02 — `founder-vsl`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Retrato / video | Entrada de escena | Fade + escala 1.02→1 | Fade | Centro | 500ms | `--ease-enter` | Aparición de persona | Estático | IMG-02, VID-01 | `motion_required` |
| Marcas de encuadre | Tras retrato | Fade | Fade | — | 300ms, delay 300ms | `--ease-enter` | Registro cinematográfico | Visibles directo | — | `motion_optional` |
| Bloque de texto | Tras retrato | Fade + `translateY(12px)`→0 | Fade | Desde abajo | 400ms, delay 150ms | `--ease-enter` | Lectura secuenciada | Visible directo | — | `motion_optional` |

**`motion_avoid`:** Ken Burns sobre el retrato, autoplay con audio, subtítulos animados palabra por palabra.

### Escena 03 — `atom-command-center`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Núcleo | Entrada | Fade + escala 0.94→1 | Fade + escala 0.98 | Centro | 600ms | `--ease-enter` | El centro aparece primero | Estático | IMG-04 | `motion_required` |
| Halos | Tras núcleo | Fade + `translateY(12px)`→0, **escalonado 60ms** | Fade | Hacia afuera del núcleo | 450ms | `--ease-enter` | Los territorios orbitan el centro | Visibles directo | — | `motion_required` |
| Ondas de canvas | Continuo | Movimiento generativo | — | Radial | Continuo | — | Atmósfera viva | Congelado / oculto | CNV-01 | `motion_optional` |
| Onda reactiva | Hover / touch en halo | Expansión radial desde el punto | Desvanece | Radial | 800ms | `--ease-standard` | Respuesta física al gesto | Sin onda | CNV-01 | `motion_optional` |
| Glow de halo | Hover / focus | Opacidad 0.16→0.26 | Reversa | — | 180ms | `--ease-standard` | Feedback de selección | Cambio instantáneo | — | `motion_required` |

**Escalonado:** los tres halos entran con 60ms de diferencia. Comunica que orbitan alrededor del núcleo en lugar de aparecer como lista.

**`motion_avoid`:** rotación orbital continua de los halos (mareante y obliga a perseguir un objetivo móvil), parallax con el mouse, halos que se reorganizan solos.

### Escena 04 — `halo-selection`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Gesto de mano | Entrada | Fade + `translateX(-12px)`→0 | Fade | Desde la izquierda | 600ms | `--ease-enter` | La mano se aproxima | Estático | IMG-05 | `motion_required` |
| Halo | Entrada | Fade + escala 0.9→1 | Fade | Centro | 500ms | `--ease-enter` | El punto de contacto aparece | Estático | — | `motion_required` |
| Pulso de halo | Continuo | Escala 0.98↔1.02 | — | — | `--motion-wave` | `ease-in-out` | Espera activa | Sin pulso | — | `motion_optional` |
| Línea luminosa | Continuo | Opacidad 0.3↔0.8 | — | Horizontal | `--motion-wave` | `ease-in-out` | Conexión | Estática al 0.5 | — | `motion_optional` |
| Confirmación de contacto | Clic en confirmar | Destello radial + escala 1→1.06→1 | — | Radial | 400ms | `--ease-enter` | El contacto ocurrió | Cambio de estado sin destello | — | `motion_required` |

**`motion_avoid`:** la mano moviéndose sola en bucle, animación de "escribiendo", cursor personalizado.

### Escena 05 — `black-transition`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Blackout | Entrada | Fade a negro | Fade desde negro | — | 400ms in / 280ms out | `--ease-standard` | Corte narrativo | Fade corto 150ms | — | `motion_required` |
| Pulso | Durante | Escala 0.94↔1.06 | Fade | Centro | `--motion-wave` | `ease-in-out` | Algo sigue latiendo | Sin pulso, punto estático | — | `motion_optional` |

**Duración total máxima:** 1.2s en `cinematic`, 800ms en `balanced`, ~150ms en `reduced`.

**`motion_avoid`:** blackout superior a 1.5s (se lee como error de carga), efectos de glitch, barrido de escaneo.

### Escena 06 — `office-intro`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Puerta | Entrada | Fade + escala 1.03→1 | Fade | Centro | 700ms | `--ease-enter` | Aproximación al umbral | Estática | IMG-06 | `motion_required` |
| Luz a través del cristal | Tras puerta | Opacidad 0→1 | Fade | Desde el interior | 900ms, delay 200ms | `--ease-enter` | La luz invita | Visible directo | IMG-06 | `motion_optional` |
| Taza | Tras puerta | Fade + `translateY(10px)`→0 | Fade | Desde abajo | 400ms, delay 400ms | `--ease-enter` | Detalle de hospitalidad | Visible directo | IMG-07 | `motion_optional` |
| Texto | Tras puerta | Fade + `translateY(12px)`→0 | Fade | Desde abajo | 400ms, delay 300ms | `--ease-enter` | Lectura secuenciada | Visible directo | — | `motion_optional` |

**`motion_avoid`:** la puerta abriéndose literalmente (obliga a producir una secuencia de video costosa y añade poco), vapor animado en la taza, sonido ambiente.

### Escena 07 — `territory-world`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Atmósfera de tono | Entrada | Fade de opacidad 0→0.16 | Fade | Radial | 800ms | `--ease-enter` | El territorio envuelve | Estática al 0.10 | CNV-02 | `motion_required` |
| Título de territorio | Entrada | Fade + `translateY(10px)`→0 | Fade | Desde abajo | 400ms | `--ease-enter` | Nombrar el lugar | Visible directo | — | `motion_optional` |
| Preguntas | Tras título | Fade + `translateY(8px)`→0, **escalonado 40ms** | Fade | Desde abajo | 350ms | `--ease-enter` | Aparecen como lista viva | Visibles directo | — | `motion_optional` |
| Hairline de pregunta | Hover / focus | Color a tono, ancho 100% | Reversa | Izq→der | 200ms | `--ease-standard` | Feedback de selección | Cambio instantáneo | — | `motion_required` |

**`motion_avoid`:** cambio de tono animado entre territorios (confunde sobre cuál está activo), fondo en movimiento constante que compita con la lectura.

### Escena 08 — `question-layer`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Pregunta (titular) | Entrada | Fade + `translateY(12px)`→0 | Fade | Desde abajo | 450ms | `--ease-enter` | Cambio de acto: entra el texto | Visible directo | — | `motion_required` |
| Respuesta provisional | Tras titular | Fade | Fade | — | 350ms, delay 150ms | `--ease-enter` | Secuencia de lectura | Visible directo | — | `motion_optional` |
| Cambio de pregunta | Clic en otra pregunta | Crossfade del contenido | — | En el mismo lugar | 250ms | `--ease-standard` | Reemplazo, no navegación | Cambio instantáneo | — | `motion_required` |

**Crossfade y no deslizamiento:** cambiar de pregunta no es avanzar de escena. El contenido se reemplaza en su lugar para que no se lea como un paso adelante.

**`motion_avoid`:** carrusel horizontal entre preguntas, acordeón que oculte contenido, texto que se escriba letra por letra.

### Escena 09 — `objection-layer`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Barra vertical de tono | Entrada | `scaleY(0)`→1, origen arriba | Fade | De arriba abajo | 400ms | `--ease-enter` | La objeción se traza | Visible directo | — | `motion_optional` |
| Cita | Tras barra | Fade + `translateX(-8px)`→0 | Fade | Desde la izquierda | 400ms, delay 120ms | `--ease-enter` | Entra una voz distinta | Visible directo | — | `motion_optional` |
| Contexto | Tras cita | Fade | Fade | — | 350ms, delay 250ms | `--ease-enter` | Respuesta posterior | Visible directo | — | `motion_optional` |

**`motion_avoid`:** revelación por scroll, contenido oculto tras "leer más".

### Escena 10 — `conversion-layer`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Síntesis | Entrada | Fade + `translateY(12px)`→0 | Fade | Desde abajo | 450ms | `--ease-enter` | Cierre de la conversación | Visible directo | — | `motion_optional` |
| CTA | Tras síntesis | Fade + escala 0.96→1 | Fade | Centro | 500ms, delay 300ms | `--ease-enter` | El destino aparece | **Visible directo, sin delay** | — | `motion_required` |
| Glow del CTA | Tras CTA | Opacidad 0→1 | — | Radial | 600ms | `--ease-enter` | Calor de la invitación | Estático | — | `motion_optional` |

**Regla crítica:** el CTA **nunca** depende del motion para ser visible ni alcanzable. Con `reduced motion` aparece de inmediato, sin retardo. Un CTA que tarda en revelarse es un CTA que algunos usuarios no verán.

**`motion_avoid`:** CTA que aparece solo tras scroll, botón que late o rebota, temporizador de urgencia, glow pulsante permanente.

### Escena 11 — `booking`

| Elemento | Trigger | Entrada | Salida | Dirección | Duración | Easing | Objetivo narrativo | Reduced motion | Dependencia | Clase |
|---|---|---|---|---|---|---|---|---|---|---|
| Formulario | Entrada | Fade + `translateY(10px)`→0 | Fade | Desde abajo | 400ms | `--ease-enter` | Llegada al paso concreto | Visible directo | — | `motion_optional` |
| Hairline de campo | Focus | Color a dorado, grosor 1→2px | Reversa | — | 180ms | `--ease-standard` | Feedback de foco | Cambio instantáneo | — | `motion_required` |
| Botón de envío | Submit | Estado de carga con spinner | — | — | Mientras dure | — | Acción en curso | Igual, sin giro | — | `motion_required` |
| Confirmación | Envío completo | Crossfade del formulario a confirmación | — | En el mismo lugar | 350ms | `--ease-standard` | Cierre del ciclo | Cambio instantáneo | — | `motion_required` |
| Check de confirmación | Tras confirmación | `scale(0.8)`→1 con fade | — | Centro | 300ms, delay 100ms | `--ease-enter` | Reconocimiento | Visible directo | ICO-06 | `motion_optional` |

**`motion_avoid`:** confeti, sonido de éxito, campos que se validen en cada tecla, barra de progreso de formulario.

## 6. Transiciones entre escenas

| Transición | Tipo | Dirección | Duración | Notas |
|---|---|---|---|---|
| 01 → 02 | Crossfade | — | 400ms | Suave; el logo cede a la persona |
| 02 → 03 | Fade + escala | Hacia adentro | 500ms | Se entra al mapa |
| 03 → 04 | Continuidad de elemento | Halo → punto de contacto | 600ms | El halo elegido se convierte en el destino |
| 04 → 05 | Fade a negro | — | 400ms | Corte de acto |
| 05 → 06 | Fade desde negro | — | 280ms | La luz vuelve |
| 06 → 07 | Fade + escala | Hacia adentro | 500ms | Se cruza el umbral |
| 07 → 08 | Crossfade | — | 400ms | **Cambio de acto: imagen a texto** |
| 08 → 09 | Deslizamiento suave | Desde la derecha | 350ms | Avance lineal |
| 09 → 10 | Deslizamiento suave | Desde la derecha | 350ms | Avance lineal |
| 10 → 11 | Fade + escala | Hacia adentro | 400ms | Llegada |
| Regreso (cualquiera) | Inversa | Desde la izquierda | 60–70% de la entrada | Dirección opuesta, obligatorio |

### 6.1 Continuidad de elemento — escena 03 → 04

La transición más ambiciosa del mapa: el halo seleccionado en el átomo se transforma en el punto de contacto de la escena 04, conservando posición y tono.

Clase: `motion_optional`. Es costosa de implementar y la experiencia funciona sin ella. Se evalúa después de aprobar la maqueta.

### 6.2 Dirección de navegación

Avance: entra desde la derecha o hacia adentro. Regreso: entra desde la izquierda o hacia afuera. **La dirección nunca se invierte**: es lo que permite al visitante saber si avanza o retrocede sin leer.

## 7. Presupuesto por tier

| Tier | Elementos animados por escena | Loops continuos | Blur | Canvas | Escalonado |
|---|---|---|---|---|---|
| `cinematic` | Hasta 2 | Sí | Hasta 10px | Completo | Sí |
| `balanced` | Hasta 2 | Reducidos | Hasta 5px | Simplificado | Sí |
| `reduced` | 0 | No | 0 | Congelado u oculto | No |

## 8. Reduced motion — contrato

Con `prefers-reduced-motion: reduce` o tier `reduced`:

- Ningún loop infinito.
- Ninguna transición supera 150ms.
- Sin parallax, sin blur costoso, sin escalonado.
- **Todo el contenido permanece visible y alcanzable.** El motion nunca es el mecanismo de revelación.
- El CTA de cada escena es visible de inmediato, sin retardo.
- Las transiciones entre escenas se reducen a crossfade corto.

Regla de verificación: la experiencia completa debe ser recorrible de principio a fin con `reduced motion` activo, sin perder información ni acción.

## 9. Prohibiciones globales

| Prohibido | Razón |
|---|---|
| Animar `width`, `height`, `top`, `left` | Provoca reflujo y CLS |
| Bloquear input durante animación | Viola el principio 2 |
| Motion como único mecanismo de revelación | Contenido inalcanzable con reduced motion |
| Loops infinitos en elementos primarios | Distrae de la lectura |
| Parallax con scroll | La experiencia es por escenas, no por scroll |
| Cursor personalizado o efectos de seguimiento | Estética gamer, fuera de dirección |
| Animación tipográfica letra por letra | Retrasa la lectura sin aportar |
| Confeti, rebotes, elásticos exagerados | Fuera de registro |
| Temporizadores de urgencia | Prohibido por guardrails estratégicos |
| Autoplay con audio | Accesibilidad y respeto |

## 10. Dependencias de asset

| Motion | Requiere | Prioridad del asset |
|---|---|---|
| Entrada de retrato (02) | IMG-02 | P0 |
| Silueta de núcleo (03) | IMG-04 | P1 |
| Ondas reactivas (03, 07) | CNV-01, CNV-02 | P1 |
| Aproximación de mano (04) | IMG-05 | P1 |
| Luz de puerta (06) | IMG-06 | P0 |
| Aparición de taza (06) | IMG-07 | P2 |
| Check de confirmación (11) | ICO-06 | P0 |
| Continuidad de elemento (03→04) | IMG-05 + posición del halo | P1 |

## 11. Orden de implementación sugerido

Para cuando el motion se desbloquee:

1. **Fase M1 — Base.** Transiciones entre escenas y estados interactivos. Todo `motion_required` que no dependa de assets pendientes.
2. **Fase M2 — Entradas.** Entradas de elemento por escena, con escalonado.
3. **Fase M3 — Atmósfera.** Ajuste de canvas, ondas reactivas, glows.
4. **Fase M4 — Continuidad.** Transición de elemento compartido 03→04, si se aprueba.

Cada fase se verifica en los tres tiers antes de pasar a la siguiente.

## 12. Confirmaciones pendientes

| # | Tema | Estado |
|---|---|---|
| 1 | ¿Se aprueba la continuidad de elemento 03→04 (costosa)? | `(andres confirma)` |
| 2 | Duración máxima aceptable del blackout de la escena 05 | `(andres confirma)` |
| 3 | ¿Se implementa motion antes o después de los assets finales? | `(andres confirma)` |

**No se implementó motion en esta fase.**
