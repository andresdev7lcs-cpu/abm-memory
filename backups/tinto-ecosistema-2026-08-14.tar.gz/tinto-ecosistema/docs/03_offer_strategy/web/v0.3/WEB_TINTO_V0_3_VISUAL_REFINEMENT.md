# WEB TINTO v0.3 — Visual Refinement & Asset Direction

- Ticket: WEB-003
- Tipo: specification
- Responsable documental: Claude Code
- Responsable de implementación: Codex (fase posterior)
- Estado: `in_progress` → `agent_review`
- Fecha: 2026-08-03

## 0. Qué es este documento y qué no es

Este documento define la **dirección visual** de la maqueta predefinitiva de WEB TINTO. Es una especificación: describe intención, composición y criterio. No contiene código, no modifica implementación y no aprueba nada por sí mismo.

**No define:** oferta, servicios, precios, garantías, resultados, claims, testimonios, buyer persona definitivo, país prioritario ni recomendaciones financieras. Todo lo que toque esos campos aparece como `(andres confirma)`.

**Hereda sin discutir** (de v0.2, auditado en PASS):

- las 11 escenas y su orden canónico;
- la máquina de estados y los 18 eventos;
- la navegación reversible y el puente narrativo `territory-world → office-intro`;
- la separación vista pública / vista debug;
- los tres performance tiers (`cinematic`, `balanced`, `reduced`);
- el booking mock local sin persistencia.

El refinamiento visual **no puede alterar ninguno de esos contratos**. Si una decisión visual de este documento exigiera cambiarlos, la decisión está mal y se descarta.

## 1. Visión visual

TINTO no es una landing. Es **una conversación filmada**.

La referencia mental no es un sitio web de servicios financieros: es el momento en que alguien te recibe en su oficina, te sirve un tinto, se sienta y te pregunta qué está pasando. Todo el sistema visual existe para sostener esa sensación durante once escenas.

Tres palabras gobiernan cada decisión:

**Cálido.** La luz viene de una fuente física —una lámpara, una ventana, un reflejo en cristal— no de un gradiente decorativo. El negro es negro cálido, nunca azulado. La temperatura de color se mantiene entre 2700K y 3200K en todo asset fotográfico.

**Editorial.** La jerarquía se construye con tipografía, espacio y silencio, no con cajas. Un titular serif grande sobre marfil, mucho aire alrededor, y un solo punto de acción. Más cerca de una revista impresa que de un dashboard.

**Reservado.** El sistema nunca grita. No hay badges de urgencia, no hay contadores, no hay confeti. La autoridad se comunica con precisión y calma. Si un elemento necesita brillar para ser visto, está mal compuesto.

### 1.1 Lo que la experiencia debe sentirse

| Debe sentirse | No debe sentirse |
|---|---|
| Cinematográfica: hay tiempo, hay ritmo, hay corte | Apurada, densa, saturada de información |
| Editorial: leída, compuesta, con aire | Maquetada en grilla de cards |
| Premium: por precisión, no por ornamento | Lujosa por acumulación de efectos |
| Cálida y humana: hay una persona detrás | Corporativa, institucional, anónima |
| Estratégica: cada escena tiene un propósito | Decorativa, "bonita porque sí" |
| Confiable: sobria, sin exageración | Vendedora, promocional, ansiosa |
| Colombiana sin clichés | Folclórica, con café-como-souvenir |

### 1.2 Colombiana sin clichés — regla explícita

El tinto es un **gesto de hospitalidad**, no un producto ni un souvenir turístico.

**Permitido:** la taza como objeto cotidiano y usado; luz de tarde tropical; materiales reales (madera, cerámica, vidrio, textil); el gesto de servir o recibir.

**Prohibido:** granos de café dispersos como decoración; sacos de yute; mapas de Colombia; banderas o tricolor; sombreros vueltiaos; mulas, fincas cafeteras, paisaje cafetero como fondo; tipografía "artesanal"; texturas de arpillera.

El criterio: si el elemento funcionaría igual en una oficina de Bogotá que en una de Ciudad de México, y sigue sintiéndose cálido, está bien. Si necesita señalar "esto es Colombia", está mal.

## 2. Principios de diseño

Ocho principios. Orden de prioridad: si dos entran en conflicto, gana el de número menor.

**P1 — La claridad antes que la atmósfera.** Ninguna capa atmosférica (glow, blur, textura, canvas) puede reducir el contraste del texto por debajo de 4.5:1 ni ocultar un control. La atmósfera es fondo; el contenido es figura. Cuando compiten, se baja la atmósfera.

**P2 — Una intención por escena.** Cada una de las 11 escenas responde a una sola pregunta del visitante. Si una escena intenta responder dos, se parte o se recorta. Ver `WEB_TINTO_V0_3_SCENE_COMPOSITIONS.md` §2 para la intención declarada de cada una.

**P3 — Un CTA primario por pantalla.** Un solo botón `--primary` visible a la vez. Todo lo demás es secundario, terciario o navegación. Esto es una regla dura, no una preferencia.

**P4 — El silencio es composición.** El espacio vacío no es espacio desperdiciado: es el que produce la sensación premium. Ante la duda entre agregar un elemento o ampliar el margen, se amplía el margen.

**P5 — La profundidad se construye con luz, no con bordes.** Las capas se separan por gradiente, sombra y desenfoque atmosférico. Los bordes visibles (`1px solid`) son excepción, no norma. Nada de contornos duros alrededor de cada bloque.

**P6 — Toda imagen es reemplazable.** Cada zona de imagen tiene proporción declarada, fallback definido y estado. Ningún layout puede depender de un asset final que todavía no existe. El sistema debe verse compuesto incluso con todos los placeholders puestos.

**P7 — Reversible y sin callejones.** Toda escena ofrece regreso visible. Ningún estado atrapa. Esto ya está resuelto funcionalmente en v0.2; el refinamiento visual no puede romperlo escondiendo el control de regreso por estética.

**P8 — Accesible por construcción.** Contraste, foco visible, touch target de 44px, `prefers-reduced-motion` y orden de lectura lógico no son una capa de corrección posterior: son parte de la composición desde el primer boceto.

## 3. Jerarquía

### 3.1 Los cinco niveles

Cada escena distribuye su contenido en cinco niveles. No todos aparecen siempre, pero el orden nunca se invierte.

| Nivel | Rol | Tratamiento |
|---|---|---|
| **N1 — Ancla** | El elemento que sostiene la escena: retrato, núcleo, puerta, halo | Mayor masa visual, luz propia, ocupa la zona óptica dominante |
| **N2 — Titular** | La frase que nombra el momento | Serif, `clamp()` grande, máximo 20ch, marfil puro |
| **N3 — Cuerpo** | Una a tres frases de contexto | Sans, 56ch máximo, `--text-muted` |
| **N4 — Acción** | El CTA primario, más el secundario si existe | Contraste alto, aislado por espacio, nunca junto a otros botones de igual peso |
| **N5 — Soporte** | Microcopy, caption, tag de hipótesis, progreso | `--text-faint`, pequeño, nunca compite |

### 3.2 Regla de masa visual

En cualquier composición, **N1 y N2 juntos ocupan al menos el 60% del peso visual percibido**. Si el cuerpo de texto y los controles dominan la pantalla, la escena se lee como formulario y pierde la cualidad cinematográfica.

### 3.3 Recorrido óptico

Desktop: la lectura entra por el ancla (izquierda o centro según escena), sube al titular, baja al cuerpo y termina en la acción. Es una **Z aplanada**, no una F de landing.

Móvil: el recorrido es vertical estricto — ancla, titular, cuerpo, acción. El ancla nunca se elimina en móvil; se reduce y se recorta, pero permanece, porque es lo que sostiene la narrativa.

## 4. Composición

### 4.1 La grilla

Doce columnas conceptuales. No es una grilla de cards: es una grilla de **encuadre**.

| Breakpoint | Columnas activas | Margen lateral | Ancho de contenido |
|---|---|---|---|
| 320–374 | 4 | 16px | fluido |
| 375–767 | 4 | 20px | fluido |
| 768–1023 | 8 | 32px | máx. 720px |
| 1024–1179 | 12 | 48px | máx. 960px |
| 1180–1439 | 12 | 64px | máx. 1100px |
| ≥1440 | 12 | 80px | máx. 1180px |

El contenido **no se estira** más allá de 1180px. En pantallas anchas crece el margen, no el texto.

### 4.2 Los tres encuadres canónicos

Toda escena usa uno de tres encuadres. Esta restricción es deliberada: produce continuidad y evita que cada escena invente su propio layout.

**Encuadre A — Centrado (plano frontal).**
Ancla al centro, titular debajo, acción al pie. Se usa cuando la escena es un momento, no una lectura: `curtain`, `black-transition`, `atom-command-center`.

```
        [ ancla ]
       [ titular ]
        [ cuerpo ]
        [ acción ]
```

**Encuadre B — Asimétrico 60/40 (plano medio).**
Ancla visual a un lado, texto y acción al otro. Es el encuadre de conversación: hay alguien de un lado y contenido del otro. Se usa en `founder-vsl`, `halo-selection`, `office-intro`, `territory-world`.

```
[    ancla    ] [ titular  ]
[   imagen    ] [ cuerpo   ]
[             ] [ acción   ]
```

La proporción es 60/40 o 55/45 —nunca 50/50, porque el equilibrio exacto mata la tensión editorial.

**Encuadre C — Editorial textual (plano de lectura).**
El texto es el protagonista; la imagen es apoyo lateral o ausente. Se usa en `question-layer`, `objection-layer`, `conversion-layer`, `booking`.

```
[ eyebrow           ]
[ TITULAR GRANDE    ]
[ cuerpo, 56ch      ]
[ ——————————        ]
[ acción            ]   [ apoyo visual ]
```

### 4.3 Asignación de encuadre por escena

| # | Escena | Encuadre | Ancla |
|---|---|---|---|
| 01 | `curtain` | A | Logo |
| 02 | `founder-vsl` | B | Poster/video fundadora |
| 03 | `atom-command-center` | A | Núcleo + 3 halos |
| 04 | `halo-selection` | B | Gesto de mano |
| 05 | `black-transition` | A | Pulso mínimo |
| 06 | `office-intro` | B | Puerta de cristal |
| 07 | `territory-world` | B | Atmósfera de territorio |
| 08 | `question-layer` | C | Tipografía |
| 09 | `objection-layer` | C | Tipografía |
| 10 | `conversion-layer` | C | Tipografía + acento |
| 11 | `booking` | C | Formulario |

El patrón A→B→A→B→A→B→B→C→C→C→C tiene lógica narrativa: la experiencia empieza cinematográfica (encuadres de imagen) y aterriza en conversación concreta (encuadres de lectura). El cambio a C en la escena 08 marca el momento en que el visitante pasa de mirar a pensar.

## 5. Tono visual

### 5.1 Paleta y su significado

La paleta ya está fijada en v0.2 y **no se altera**. Este documento define cómo se usa.

| Color | Rol narrativo | Dónde |
|---|---|---|
| Negro cálido (`--p-void`) | El silencio, el corte, el espacio entre actos | Fondo base, `black-transition` |
| Café profundo (`--p-espresso-*`) | La materia, la sustancia, el suelo | Superficies, paneles, profundidad media |
| Marfil (`--p-ivory-*`) | La claridad, lo que se entiende | Todo el texto principal, titulares |
| Cobre (`--p-copper-*`) | La acción, el calor, lo que invita | CTA primario, acentos de interacción |
| Dorado sobrio (`--p-gold-*`) | La precisión, el detalle, el foco | Focus ring, hairlines, microdetalle |
| Vino oscuro (`--p-wine-*`) | La profundidad emocional, lo íntimo | Glow atmosférico, territorio finanzas |
| Verde profundo | **Acento limitado** — ver §5.2 | Confirmación puntual únicamente |

### 5.2 Verde profundo — regla de contención

El verde profundo entra como acento **limitado y excepcional**. Se permite en un solo caso: la confirmación de estado completado (`booking` enviado, contacto de halo confirmado).

No se usa para: territorios, fondos, texto, bordes generales ni acentos decorativos. No supera el 2% del área visible de ninguna pantalla. Valor sugerido: `#2f4438` (`(andres confirma)` si se desea otro).

Razón: el verde es el único color de la paleta que no pertenece a la familia café/cobre/vino. Su escasez es lo que lo hace legible como señal.

### 5.3 Los tres tonos de territorio

Heredados de v0.2, sin cambio de valores RGB:

| Territorio | Tono | RGB | Lectura |
|---|---|---|---|
| Finanzas y patrimonio | `forest` | `158, 74, 92` | Vino — autoridad, protección |
| Activos inmobiliarios | `petrol` | `196, 138, 79` | Cacao/cobre — materialidad |
| Educación y orientación | `copper` | `217, 174, 108` | Dorado/marfil — claridad |

Los nombres (`forest`, `petrol`) son etiquetas heredadas del código y **no describen el color real**. Se conservan para no romper `content.mjs` y `canvas-atmosphere.mjs`. Codex no debe renombrarlos.

El tono de territorio se manifiesta en: glow atmosférico de fondo, hairline de acento, halo del canvas. **Nunca** en el color del texto ni del CTA primario —el CTA es siempre cobre, en los tres territorios, para que la acción sea reconocible sin importar el contexto.

### 5.4 Tipografía como tono

Serif para titulares: autoridad editorial, tiempo, permanencia. Sans humanista para cuerpo: claridad, cercanía, presente.

La combinación produce la voz: **alguien con criterio hablándote en lenguaje simple**. Un titular sans lo volvería una startup; un cuerpo serif lo volvería un bufete. La mezcla es la posición.

## 6. Sistema de profundidad

Cinco planos. Toda la experiencia se construye apilando estos cinco y nada más.

| Plano | Nombre | Contenido | Tratamiento |
|---|---|---|---|
| **Z0** | Vacío | Fondo base, negro cálido | Sin sombra, sin borde |
| **Z1** | Atmósfera | Glow radial por tono, textura punteada, canvas | Opacidad ≤ 0.16, `pointer-events: none` |
| **Z2** | Escenario | Superficie de la escena, plano de composición | Gradiente suave, sin borde duro |
| **Z3** | Figura | Ancla: retrato, puerta, núcleo, halo | Luz propia, sombra proyectada `--shadow-depth-3` |
| **Z4** | Interfaz | Titular, cuerpo, CTA, controles | Máximo contraste, siempre legible |
| **Z5** | Overlay | Controles públicos flotantes, panel de ajustes | `backdrop-filter`, elevado sobre todo |

### 6.1 Reglas de profundidad

- La luz siempre cae **desde arriba y ligeramente a la izquierda** (aprox. 10–11 en punto). Consistente en todos los assets fotográficos y en todas las sombras CSS.
- Las sombras son **cálidas**, nunca neutras: llevan componente café/vino, no gris puro.
- El desenfoque atmosférico (`blur`) es puente narrativo, nunca barrera. Ningún contenido de Z4 se muestra desenfocado en estado de reposo.
- Z1 se **congela o desaparece** en `reduced motion`. No se elimina el contenido, solo el movimiento.
- Ningún plano usa `glassmorphism` como estética general. El cristal aparece **solo** donde hay cristal narrativo real: la puerta de `office-intro` y el overlay de controles (Z5), donde cumple la función de dejar ver el fondo sin competir.

### 6.2 Contra el glassmorphism excesivo

Restricción explícita: `backdrop-filter` se usa en **dos lugares únicamente** —overlay público (Z5) y halos de territorio en `atom-command-center`. Cualquier otro uso debe justificarse en revisión. El blur repetido en cada panel es precisamente lo que convierte una interfaz premium en un template.

## 7. Tratamiento editorial

### 7.1 Titulares

- Serif, peso regular a semibold. **Nunca bold pesado** —la autoridad no necesita grosor.
- `letter-spacing` negativo leve (`-0.02em`) en tamaños grandes.
- Máximo 20ch en desktop, 17ch en móvil. Los titulares largos se parten en dos líneas intencionalmente, no por accidente de ancho.
- Sin punto final. Un titular no es una oración terminada; es un rótulo.
- Sin mayúsculas completas, salvo eyebrows.

### 7.2 Eyebrow

Microcopy en mayúsculas sobre el titular, `letter-spacing: 0.18em`, `--text-faint`. Nombra el momento sin explicarlo. En vista pública aparece solo donde aporta orientación narrativa; en debug muestra el número de escena.

### 7.3 Cuerpo

- Máximo **56ch** en desktop, 40ch en móvil.
- `line-height: 1.6`.
- Una a tres frases. Si necesita cuatro, la escena está haciendo demasiado (viola P2).
- Sin negritas dentro del párrafo salvo un único término clave por escena.

### 7.4 Ritmo vertical

El espacio entre bloques comunica relación. Escala de separación:

| Separación | Uso |
|---|---|
| 8px | Elementos del mismo objeto (label + input) |
| 16px | Elementos relacionados (titular + cuerpo) |
| 32px | Bloques distintos dentro de la escena |
| 64px | Separación de zonas narrativas |
| 96px+ | Respiración de escena completa (desktop) |

### 7.5 Contra las cards repetitivas

Regla explícita: **no más de un contenedor con borde visible por pantalla**.

La v0.2 actual repite el patrón `panel con borde + fondo + radius` en `copy-block`, `summary-card`, `detail-card`, `question-card` y `confirmation-card`. Visualmente eso produce exactamente la estética de dashboard que la dirección prohíbe.

En v0.3 la separación se logra con **espacio y hairline**, no con cajas. Ver `WEB_TINTO_V0_3_COMPONENT_SYSTEM.md` §9 para el detalle de reemplazo.

## 8. Continuidad narrativa

### 8.1 El hilo visual

Las once escenas deben leerse como una sola pieza. Tres mecanismos sostienen la continuidad:

**El tono persiste.** Una vez seleccionado el territorio en la escena 03, su tono acompaña todas las escenas siguientes (04–11) en el glow atmosférico. El visitante no vuelve a un estado neutro: lleva su contexto encima.

**La luz no salta.** La dirección de luz (10–11 en punto), su temperatura (2700–3200K) y su intensidad relativa se mantienen entre escenas consecutivas. Un corte de luz solo ocurre deliberadamente en `black-transition`.

**El ancla se transforma, no desaparece.** El elemento visual dominante evoluciona con lógica: logo → fundadora → núcleo → mano → negro → puerta → mundo → texto. Cada uno prepara al siguiente.

### 8.2 Los tres actos

| Acto | Escenas | Función | Registro visual |
|---|---|---|---|
| **I — Recepción** | 01–03 | Quién eres, quién soy, qué hay aquí | Cinematográfico, amplio, imagen dominante |
| **II — Elección** | 04–07 | Elegiste, entramos, este es tu contexto | Íntimo, transición, tono de territorio |
| **III — Conversación** | 08–11 | Tu pregunta, tu duda, tu siguiente paso | Editorial, textual, foco en claridad |

`black-transition` (05) es la bisagra entre acto I y II. Es la única escena sin contenido: su trabajo es producir el silencio que hace que lo siguiente se sienta distinto.

### 8.3 Progreso

El visitante debe poder ubicarse sin que se le muestre un stepper de formulario. La orientación se da por:

- cambio de registro visual entre actos (composición, no indicador);
- persistencia del tono de territorio (le confirma que su elección se respetó);
- el titular de cada escena, que nombra el momento.

No se usa: barra de progreso numérica, "paso 3 de 11", breadcrumb. Todos ellos convierten la experiencia en un flujo de checkout.

## 9. Restricciones

### 9.1 Prohibiciones estéticas

| Prohibido | Por qué |
|---|---|
| Dashboards | Contradice la conversación; convierte al visitante en operador |
| Templates SaaS | Grilla de cards + hero + features + pricing = anonimato |
| Landing convencional | Scroll largo con secciones apiladas; TINTO es escenas, no scroll |
| Estética bancaria | Azul, iconos de escudo, tablas: comunica institución, no persona |
| Interfaces gamer | HUD, barras, contadores, tipografía técnica |
| Cyberpunk / neón | Fuera de paleta, temperatura fría, ruido visual |
| Fintech azul | Fuera de paleta por completo |
| Cards repetitivas | Ver §7.5 |
| Iconografía genérica | Ver §9.2 |
| Glassmorphism excesivo | Ver §6.2 |

### 9.2 Iconografía

- Sin emoji como icono estructural, en ninguna circunstancia. La v0.2 actual usa `←`, `❙❙`, `▶`, `⚙` en el overlay público: **deben reemplazarse por SVG**.
- Un solo set, stroke uniforme de 1.5px, terminaciones redondeadas.
- Tamaños por token: 16 / 20 / 24px. Nada intermedio.
- Sin iconos decorativos junto a títulos. Un icono aparece solo cuando reemplaza una palabra en un control.
- Sin ilustraciones de stock, sin isométricos, sin blobs.

### 9.3 Restricciones de contenido

Ningún elemento visual puede implicar lo que no está aprobado:

- **Sin precios, planes ni comparativas.** Ninguna zona reservada para ellos.
- **Sin testimonios, logos de clientes, cifras de resultados ni sellos.** No hay componente que los soporte, deliberadamente.
- **Sin claims de resultado** en titulares ni microcopy.
- **Sin credenciales inventadas** de la fundadora: ni títulos, ni años de experiencia, ni cargos. El retrato comunica presencia, no autoridad declarada.
- **Los tres territorios son `[HIPÓTESIS]`** con `approval: pending_confirmation`. El tratamiento visual no puede presentarlos como oferta consolidada. El tag "Exploración inicial" se conserva.

### 9.4 Restricciones técnicas heredadas

- Stack: HTML modular, CSS modular, JavaScript ES modules. **Sin migración de framework.**
- Sin dependencias remotas: sin CDN, sin Google Fonts, sin fetch externo. Tipografía de sistema.
- Sin assets remotos. Todo local en `tools/tinto-web/assets/`.
- El motor de escenas, la state machine, los 18 eventos, el router y el booking mock **no se tocan**.

### 9.5 Motion

Motion avanzado permanece **bloqueado** hasta que Andrés apruebe la maqueta. Esta fase produce el mapa de motion (`WEB_TINTO_V0_3_MOTION_MAP.md`) como especificación, no como implementación.

Lo único que se conserva activo es lo que ya existe en v0.2: transiciones de fase de escena, pulsos de halo y respiración de logo. Nada nuevo se añade en esta fase.

## 10. Confirmaciones pendientes

| # | Tema | Estado |
|---|---|---|
| 1 | Verde profundo: valor hex exacto para confirmación | `(andres confirma)` |
| 2 | Retrato real de la fundadora: ¿existe sesión fotográfica o se produce? | `(andres confirma)` |
| 3 | Mini-VSL: ¿se graba video real o el poster es definitivo para la maqueta? | `(andres confirma)` |
| 4 | Tipografía: ¿se acepta la familia de sistema o se licencia una serif propia? | `(andres confirma)` |
| 5 | Los tres territorios: ¿se confirman como hipótesis de trabajo para la maqueta? | `(andres confirma)` |
| 6 | Logo: ¿el `logo-mark.svg` actual es provisional o definitivo? | `(andres confirma)` |

Ninguna de estas confirmaciones bloquea la especificación: todas tienen fallback definido en `WEB_TINTO_V0_3_ASSET_MAP.md`. Bloquean la **producción de assets finales**, no la maqueta.

## 11. Documentos relacionados

- `WEB_TINTO_V0_3_SCENE_COMPOSITIONS.md` — las 11 escenas en detalle
- `WEB_TINTO_V0_3_COMPONENT_SYSTEM.md` — componentes y estados
- `WEB_TINTO_V0_3_DESIGN_TOKENS.md` — tokens listos para CSS
- `WEB_TINTO_V0_3_ASSET_MAP.md` — inventario y prioridades
- `WEB_TINTO_V0_3_ASSET_PROMPTS.md` — producción de assets
- `WEB_TINTO_V0_3_MOTION_MAP.md` — motion futuro
- `WEB_TINTO_V0_3_RESPONSIVE_PLAN.md` — comportamiento por breakpoint
- `WEB_TINTO_V0_3_HUMAN_REVIEW_GUIDE.md` — guía de revisión para Andrés
- `WEB_TINTO_V0_3_CODEX_IMPLEMENTATION_HANDOFF.md` — alcance de implementación
