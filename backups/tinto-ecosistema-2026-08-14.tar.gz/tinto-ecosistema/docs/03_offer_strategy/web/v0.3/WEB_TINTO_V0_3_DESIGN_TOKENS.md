# WEB TINTO v0.3 — Design Tokens

- Ticket: WEB-003
- Documento: 4 de 11
- Base: `WEB_TINTO_V0_3_VISUAL_REFINEMENT.md`

## 1. Arquitectura

Tres capas: **primitivo → semántico → componente**. Ningún componente referencia un primitivo directamente; siempre pasa por la capa semántica. Esto permite cambiar la paleta sin tocar componentes.

```
--p-copper-500: #b3763f;        /* primitivo: valor crudo */
--action-primary-bg: var(--p-copper-500);   /* semántico: propósito */
--cta-primary-bg: var(--action-primary-bg); /* componente: uso */
```

**Estado de este documento:** especificación. Los tokens están nombrados y valorados, listos para que Codex los escriba en CSS. Ningún token se ha implementado en esta fase.

**Herencia:** los primitivos de color y las tres tripletas de tono vienen de v0.2 sin alteración de valor. Los tokens nuevos de v0.3 están marcados con **`[NUEVO]`**.

## 2. Primitivos de color

Heredados de v0.2, sin cambio.

```css
/* Negro cálido */
--p-void: #050403;

/* Café profundo */
--p-espresso-950: #0a0705;
--p-espresso-900: #120d09;
--p-espresso-800: #1c140e;
--p-espresso-700: #291d14;

/* Cacao */
--p-cacao-600: #3a2a1c;
--p-cacao-500: #4d3826;

/* Vino oscuro */
--p-wine-900: #1c0a0f;
--p-wine-700: #3f1a24;
--p-wine-500: #6b2c3c;

/* Cobre */
--p-copper-600: #8a5530;
--p-copper-500: #b3763f;
--p-copper-400: #c98f57;

/* Dorado sobrio */
--p-gold-500: #c99a4e;
--p-gold-400: #d9ae6c;
--p-gold-300: #f0d58a;

/* Marfil */
--p-ivory-200: #e9ddc8;
--p-ivory-100: #f4ecdf;
--p-ivory-050: #faf5ec;
```

### 2.1 Primitivos nuevos

```css
/* Verde profundo — acento limitado, solo confirmación [NUEVO] */
--p-forest-700: #2f4438;    /* (andres confirma) */
--p-forest-500: #456253;    /* (andres confirma) */

/* Rojo cálido — solo error, dentro de familia cálida [NUEVO] */
--p-danger-600: #8a3a3a;
--p-danger-400: #b55b5b;
```

El rojo de error es **cálido y desaturado** deliberadamente: un rojo puro de sistema rompería la paleta.

## 3. Tonos de territorio

Heredados sin cambio de valor. Los nombres son etiquetas del código y no describen el color real; Codex **no debe renombrarlos** (romperían `content.mjs` y `canvas-atmosphere.mjs`).

```css
--tone-forest-rgb: 158, 74, 92;    /* Finanzas y patrimonio — vino */
--tone-petrol-rgb: 196, 138, 79;   /* Activos inmobiliarios — cacao/cobre */
--tone-copper-rgb: 217, 174, 108;  /* Educación y orientación — dorado */
--tone-default-rgb: 217, 174, 108;
--tone-active-rgb: var(--tone-default-rgb);
```

Se declaran como tripletas RGB (no hex) para permitir `rgba(var(--tone-active-rgb), 0.16)` en glows.

## 4. Semánticos de color

```css
/* Fondos */
--bg-void: var(--p-void);
--bg-base: var(--p-espresso-950);
--bg-surface: rgba(28, 20, 14, 0.92);
--bg-surface-strong: rgba(34, 24, 17, 0.97);
--bg-surface-soft: rgba(18, 13, 9, 0.86);
--bg-field: rgba(5, 4, 3, 0.40);              /* [NUEVO] campo de formulario */
--bg-overlay: rgba(10, 7, 5, 0.55);           /* [NUEVO] controles Z5 */

/* Líneas */
--line: rgba(233, 221, 200, 0.14);
--line-strong: rgba(240, 213, 138, 0.28);
--line-hairline: rgba(233, 221, 200, 0.10);   /* [NUEVO] separador editorial */
--line-tone: rgba(var(--tone-active-rgb), 0.34);

/* Texto */
--text-primary: var(--p-ivory-100);
--text-muted: rgba(244, 236, 223, 0.66);
--text-faint: rgba(244, 236, 223, 0.44);
--text-on-action: var(--p-ivory-050);         /* [NUEVO] */

/* Acción */
--action-primary-bg-from: var(--p-copper-500);   /* [NUEVO] */
--action-primary-bg-to: var(--p-copper-600);     /* [NUEVO] */
--action-primary-border: rgba(240, 213, 138, 0.30); /* [NUEVO] */

/* Estado */
--color-success: var(--p-forest-700);         /* [NUEVO] uso ≤2% del área */
--color-danger: var(--p-danger-600);          /* [NUEVO] */
--color-danger-text: var(--p-danger-400);     /* [NUEVO] */

/* Foco */
--focus-ring: var(--p-gold-300);
--focus-ring-width: 2px;                      /* [NUEVO] */
--focus-ring-offset: 3px;                     /* [NUEVO] */
```

## 5. Tipografía

### 5.1 Familias

```css
--font-serif: "Iowan Old Style", "Palatino Linotype", "Book Antiqua", Georgia, serif;
--font-sans: "Avenir Next", "Segoe UI", "Helvetica Neue", sans-serif;
```

Fuentes de sistema. Sin carga remota, sin Google Fonts, sin licencia adicional. Si se decide licenciar una serif propia: `(andres confirma)`.

### 5.2 Escala

```css
--text-display: clamp(2.4rem, 5vw, 3.6rem);   /* [NUEVO] titular de escena */
--text-title: clamp(1.6rem, 3vw, 2.2rem);     /* [NUEVO] territorio, pregunta */
--text-subtitle: 1.15rem;                      /* [NUEVO] */
--text-body-lg: clamp(1rem, 1.6vw, 1.2rem);   /* [NUEVO] cuerpo en público */
--text-body: 1rem;
--text-small: 0.9rem;                          /* [NUEVO] */
--text-caption: 0.86rem;                       /* [NUEVO] */
--text-micro: 0.8rem;                          /* [NUEVO] microcopy honesto */
--text-eyebrow: 0.72rem;
```

Base 16px. Ningún texto de cuerpo baja de 0.8rem (12.8px). Los inputs son 16px fijos en móvil: evita el zoom automático de iOS.

### 5.3 Pesos

```css
--weight-regular: 400;
--weight-medium: 500;     /* [NUEVO] labels, CTA */
--weight-semibold: 600;   /* [NUEVO] máximo permitido */
```

Nunca 700+. La autoridad no se comunica con grosor.

### 5.4 Altura de línea

```css
--leading-display: 1.06;   /* [NUEVO] */
--leading-title: 1.2;      /* [NUEVO] */
--leading-body: 1.6;
--leading-tight: 1.35;     /* [NUEVO] */
```

### 5.5 Tracking

```css
--tracking-display: -0.02em;
--tracking-eyebrow: 0.18em;
--tracking-tag: 0.08em;    /* [NUEVO] */
--tracking-normal: 0;      /* [NUEVO] */
```

### 5.6 Medida de línea

```css
--measure-body: 56ch;      /* [NUEVO] cuerpo desktop */
--measure-body-mobile: 40ch; /* [NUEVO] */
--measure-display: 20ch;   /* [NUEVO] titular desktop */
--measure-display-mobile: 17ch; /* [NUEVO] */
```

Restricción dura: el texto **no se estira** en pantallas anchas. Crece el margen, no la medida.

## 6. Escala espacial

Base de 4px. Toda separación es múltiplo.

```css
--space-1: 4px;    /* [MODIFICADO] era 6px */
--space-2: 8px;    /* [MODIFICADO] era 10px */
--space-3: 12px;   /* [MODIFICADO] era 14px */
--space-4: 16px;   /* [MODIFICADO] era 18px */
--space-5: 24px;
--space-6: 32px;
--space-7: 48px;   /* [NUEVO] */
--space-8: 64px;   /* [NUEVO] */
--space-9: 96px;   /* [NUEVO] respiración de escena */
```

**Nota de cambio:** v0.2 usa 6/10/14/18, que no es una escala de 4/8 limpia. v0.3 la normaliza. El impacto visual es mínimo (2px por token) pero produce ritmo consistente. Codex debe verificar que ningún layout dependa de los valores antiguos.

### 6.1 Semánticos de separación

```css
--gap-inline: var(--space-2);      /* [NUEVO] label + input */
--gap-related: var(--space-4);     /* [NUEVO] titular + cuerpo */
--gap-block: var(--space-6);       /* [NUEVO] bloques distintos */
--gap-zone: var(--space-8);        /* [NUEVO] zonas narrativas */
--gap-scene: var(--space-9);       /* [NUEVO] respiración de escena */
```

## 7. Radios

```css
--radius-xs: 4px;      /* [NUEVO] checkbox, campo */
--radius-sm: 12px;
--radius-md: 16px;
--radius-lg: 22px;
--radius-xl: 30px;
--radius-halo: 40px;   /* [NUEVO] exclusivo de halos */
--radius-pill: 999px;
--radius-circle: 50%;  /* [NUEVO] */
```

Regla anti-card (`COMPONENT_SYSTEM.md` §16 R4): tres bloques consecutivos con el mismo radio y fondo se leen como grilla de cards. El radio se varía o el contenedor se elimina.

## 8. Sombras

Todas las sombras son **cálidas**: llevan componente café/vino, nunca gris neutro.

```css
--shadow-depth-1: 0 8px 24px rgba(0, 0, 0, 0.28);
--shadow-depth-2: 0 20px 56px rgba(0, 0, 0, 0.34);
--shadow-depth-3: 0 32px 96px rgba(0, 0, 0, 0.42);
--shadow-inset-hairline: inset 0 0 0 1px rgba(244, 236, 223, 0.06);

/* Glows [NUEVO] */
--glow-action: 0 12px 32px rgba(179, 118, 63, 0.24);
--glow-action-hover: 0 16px 44px rgba(179, 118, 63, 0.32);
--glow-tone: 0 0 48px rgba(var(--tone-active-rgb), 0.20);
--glow-node: 0 0 70px rgba(179, 118, 63, 0.18);
--glow-node-hover: 0 0 90px rgba(217, 174, 108, 0.26);
```

Dirección de luz constante: desde arriba y ligeramente a la izquierda (~10–11 en punto). Todas las sombras proyectan hacia abajo y a la derecha.

## 9. Transparencia y capas

### 9.1 Opacidades semánticas

```css
--opacity-atmosphere: 0.16;    /* [NUEVO] máximo de capa Z1 */
--opacity-texture: 0.05;       /* [NUEVO] textura punteada */
--opacity-silhouette: 0.22;    /* [NUEVO] silueta en núcleo */
--opacity-disabled: 0.4;       /* [NUEVO] */
--opacity-placeholder: 0.26;   /* [NUEVO] borde dashed */
```

### 9.2 Escala Z

```css
--z-base: 0;         /* [NUEVO] Z0 vacío */
--z-atmosphere: 1;   /* [NUEVO] Z1 glow, canvas, textura */
--z-stage: 2;        /* [NUEVO] Z2 escenario */
--z-figure: 3;       /* [NUEVO] Z3 ancla visual */
--z-interface: 10;   /* [NUEVO] Z4 texto, CTA */
--z-overlay: 20;     /* [NUEVO] Z5 controles públicos */
--z-modal: 40;       /* [NUEVO] */
--z-skiplink: 100;   /* [NUEVO] */
```

### 9.3 Desenfoque

```css
--blur-overlay: 8px;      /* [NUEVO] controles Z5 */
--blur-halo: 6px;         /* [NUEVO] halos */
--blur-depth: 4px;        /* atmosférico, por tier */
```

`backdrop-filter` permitido **solo** en overlay y halos (`VISUAL_REFINEMENT.md` §6.2). Cualquier otro uso requiere justificación.

## 10. Contraste

Objetivo: **WCAG AA como piso**, AAA donde sea alcanzable sin romper la estética.

| Par | Ratio requerido | Ratio estimado | Cumple |
|---|---|---|---|
| `--text-primary` sobre `--bg-base` | 4.5:1 | ~15.8:1 | AAA |
| `--text-muted` sobre `--bg-base` | 4.5:1 | ~9.7:1 | AAA |
| `--text-faint` sobre `--bg-base` | 4.5:1 | ~6.1:1 | AA |
| `--text-faint` sobre `--bg-surface` | 4.5:1 | ~5.4:1 | AA |
| `--text-on-action` sobre cobre | 4.5:1 | ~5.2:1 | AA |
| `--focus-ring` sobre `--bg-base` | 3:1 | ~11.2:1 | AAA |
| `--color-danger-text` sobre `--bg-base` | 4.5:1 | ~5.1:1 | AA |
| Hairline sobre fondo | 3:1 (UI) | ~2.1:1 | **No aplica** |

**Nota sobre hairlines:** las líneas decorativas de separación no transportan información y quedan exentas del mínimo de 3:1. Toda línea que **sí** comunique estado (borde de campo con foco, borde de halo seleccionado) debe alcanzar 3:1.

**Verificación pendiente:** los ratios son estimaciones calculadas sobre los valores hex. Codex debe verificarlos con herramienta real durante la implementación y reportar cualquier par bajo mínimo.

### 10.1 Regla de atmósfera y contraste

Ninguna capa Z1 puede reducir el contraste de texto bajo 4.5:1. Cuando un glow o textura pase por detrás de texto, se verifica el contraste **en el punto más desfavorable**, no en promedio.

## 11. Tamaños

```css
/* Iconos */
--icon-sm: 16px;   /* [NUEVO] */
--icon-md: 20px;   /* [NUEVO] */
--icon-lg: 24px;   /* [NUEVO] */

/* Controles */
--control-height: 44px;         /* [NUEVO] mínimo absoluto */
--control-height-cta: 48px;     /* [NUEVO] */
--control-height-cta-mobile: 52px; /* [NUEVO] */
--field-height: 48px;           /* [NUEVO] */

/* Anclas */
--node-core: clamp(160px, 26vw, 232px);  /* [NUEVO] */
--node-pulse: 140px;                      /* [NUEVO] */
--halo-width: min(280px, 30vw);           /* [NUEVO] */
--halo-width-mobile: min(100%, 340px);    /* [NUEVO] */
--logo-curtain: clamp(100px, 14vw, 180px);/* [NUEVO] */

/* Contenido */
--content-max: 1180px;      /* [NUEVO] */
--media-portrait-max: 520px;/* [NUEVO] */
```

## 12. Breakpoints

```css
--bp-xs: 320px;   /* [NUEVO] */
--bp-sm: 375px;
--bp-md: 768px;   /* [MODIFICADO] v0.2 usa 760px */
--bp-lg: 1024px;
--bp-xl: 1180px;
--bp-2xl: 1440px;
```

**Nota de cambio:** v0.2 usa 760px; v0.3 normaliza a 768px (estándar de tablet). Codex debe actualizar las media queries correspondientes. El impacto es de 8px en el punto de reflujo.

Breakpoints adicionales de condición, no de ancho:

```css
/* Móvil horizontal */
@media (max-height: 480px) and (orientation: landscape)

/* Pantallas altas */
@media (min-height: 900px)
```

## 13. Touch targets

| Elemento | Mínimo | Recomendado |
|---|---|---|
| Botón / control | 44×44px | 48×48px |
| CTA primario móvil | 48px alto | 52px alto |
| Campo de formulario | 44px alto | 48px alto |
| Checkbox (área) | 44×44px | 44×44px |
| Halo | 44px alto | 64px alto |
| Pregunta (línea) | 44px alto | 56px alto |
| Separación entre targets | 8px | 12px |

```css
--touch-min: 44px;      /* [NUEVO] */
--touch-gap-min: 8px;   /* [NUEVO] */
```

Cuando el icono es menor al target, el área se extiende por padding, sin alterar el tamaño visual.

## 14. Estados — tokens

```css
/* Elevación por transform [NUEVO] */
--lift-hover: -1px;
--lift-halo: -2px;
--press-scale: 0.98;
--press-scale-control: 0.96;

/* Brillo [NUEVO] */
--brightness-hover: 1.06;
--brightness-active: 0.96;
```

### 14.1 Matriz de estado

| Token | hover | focus-visible | active | selected |
|---|---|---|---|---|
| CTA primario | `brightness(1.06)` + `translateY(-1px)` + `--glow-action-hover` | anillo `--focus-ring` 2px/3px | `translateY(0)` + `brightness(0.96)` | — |
| CTA secundario | color `--text-primary` + subrayado | anillo 2px/2px | `opacity: 0.7` | — |
| Control | borde `--line-strong` + `translateY(-1px)` | anillo 2px/2px | `scale(0.96)` | — |
| Halo | glow 26% + borde tono 45% + `translateY(-2px)` | anillo 2px/4px | `scale(0.98)` | borde tono 55% + anillo interior |
| Nodo | `--glow-node-hover` | anillo 2px/6px | `scale(0.98)` | — |
| Campo | hairline 24% | hairline 2px `--focus-ring` + anillo | — | — |
| Pregunta | hairline al tono + `translateY(-1px)` | anillo 2px/2px | `opacity: 0.8` | hairline 2px tono |

**Regla dura:** ninguna transición de estado modifica `width`, `height`, `padding`, `margin` ni cualquier propiedad que dispare reflujo. Solo `transform`, `opacity`, `color`, `box-shadow`, `border-color`, `filter`.

## 15. Motion — tokens

Los tokens existen; el motion avanzado **no se implementa** en esta fase.

```css
/* Duración */
--motion-fast: 180ms;
--motion-enter: 220ms;
--motion-exit: 220ms;
--motion-auto: 800ms;
--motion-wave: 1800ms;

/* Easing */
--ease-standard: cubic-bezier(0.22, 0.61, 0.36, 1);
--ease-enter: cubic-bezier(0.16, 1, 0.3, 1);
--ease-exit: cubic-bezier(0.4, 0, 1, 1);   /* [NUEVO] */
```

### 15.1 Por tier

| Token | cinematic | balanced | reduced |
|---|---|---|---|
| `--motion-enter` | 360ms | 220ms | 120ms |
| `--motion-exit` | 360ms | 220ms | 120ms |
| `--motion-auto` | 1200ms | 800ms | 0ms |
| `--motion-wave` | 2400ms | 1800ms | 0ms |
| `--blur-depth` | 10px | 5px | 0px |

Heredado de v0.2 sin cambio.

## 16. Convención de nombres

```
--<capa>-<propiedad>[-<variante>][-<estado>]
```

| Prefijo | Capa |
|---|---|
| `--p-*` | Primitivo |
| `--bg-*`, `--text-*`, `--line-*`, `--action-*`, `--color-*` | Semántico |
| `--cta-*`, `--halo-*`, `--node-*`, `--field-*` | Componente |
| `--space-*`, `--gap-*` | Espacio |
| `--radius-*`, `--shadow-*`, `--glow-*` | Forma |
| `--motion-*`, `--ease-*` | Movimiento |
| `--z-*` | Capa Z |
| `--bp-*` | Breakpoint |

### 16.1 Reglas

- Ningún componente usa un primitivo directamente.
- Ningún valor hex crudo aparece en una regla de componente.
- Los tokens de tono se declaran como tripletas RGB, no hex.
- Los nombres heredados de v0.2 **se conservan**: renombrarlos obliga a reescribir el CSS completo sin beneficio.

## 17. Resumen de cambios respecto a v0.2

| Tipo | Detalle | Impacto para Codex |
|---|---|---|
| Sin cambio | Primitivos de color, tonos, familias tipográficas, sombras base, motion por tier | Ninguno |
| **Modificado** | `--space-1..4` normalizados a escala 4/8 | Verificar layouts dependientes |
| **Modificado** | `--bp-md` de 760px a 768px | Actualizar media queries |
| **Nuevo** | Escala tipográfica completa, medidas de línea, pesos | Aplicar en titulares y cuerpo |
| **Nuevo** | Tokens de estado, glow, touch, Z, iconos, tamaños de ancla | Implementar |
| **Nuevo** | `--color-success`, `--color-danger` | Implementar, uso restringido |

## 18. Confirmaciones pendientes

| # | Token | Estado |
|---|---|---|
| 1 | `--p-forest-700` / `--p-forest-500`: valores hex del verde | `(andres confirma)` |
| 2 | Familia serif: ¿sistema o licenciada? | `(andres confirma)` |
| 3 | Ratios de contraste: verificación con herramienta real | Pendiente — Codex en implementación |
