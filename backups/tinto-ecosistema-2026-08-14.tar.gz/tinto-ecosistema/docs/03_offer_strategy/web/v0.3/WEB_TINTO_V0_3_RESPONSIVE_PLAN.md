# WEB TINTO v0.3 — Responsive Plan

- Ticket: WEB-003
- Documento: 8 de 11
- Base: `WEB_TINTO_V0_3_SCENE_COMPOSITIONS.md`, `WEB_TINTO_V0_3_DESIGN_TOKENS.md`

## 1. Principio

**Mobile-first en construcción, cinematográfico en ambas.** La versión móvil no es una reducción de la de escritorio: es una composición propia que conserva la misma intención narrativa.

Regla dura: **ninguna escena pierde su ancla visual en móvil.** El ancla se reduce y se recorta, pero nunca se elimina. Eliminarla convierte la experiencia en una lista de texto.

## 2. Breakpoints

| Token | Ancho | Nombre | Columnas | Margen | Contenido máx. |
|---|---|---|---|---|---|
| `--bp-xs` | 320px | Móvil pequeño | 4 | 16px | fluido |
| `--bp-sm` | 375px | Móvil estándar | 4 | 20px | fluido |
| `--bp-md` | 768px | Tablet | 8 | 32px | 720px |
| `--bp-lg` | 1024px | Escritorio | 12 | 48px | 960px |
| `--bp-xl` | 1180px | Escritorio amplio | 12 | 64px | 1100px |
| `--bp-2xl` | 1440px | Escritorio grande | 12 | 80px | 1180px |

Condicionales adicionales:

```css
@media (max-height: 480px) and (orientation: landscape)  /* móvil horizontal */
@media (min-height: 900px)                                /* pantallas altas */
```

**Cambio respecto a v0.2:** el punto de reflujo pasa de 760px a 768px. Codex debe actualizar las media queries correspondientes.

## 3. Comportamiento por breakpoint

### 3.1 — 320px (móvil pequeño)

El caso más restrictivo. Todo debe funcionar aquí.

| Aspecto | Comportamiento |
|---|---|
| Encuadre | Todos colapsan a vertical, una columna |
| Margen lateral | 16px |
| Titular | 1.75rem, máximo 17ch |
| Cuerpo | 0.95rem, máximo 40ch |
| Ancla visual | Reducida al mínimo legible, nunca eliminada |
| CTA | Ancho completo menos márgenes, 52px de alto |
| Touch targets | 44px mínimo, sin excepción |
| Canvas | Desactivado (costo de render) |
| Textura | Desactivada |

**Riesgos específicos:** el titular de la escena 03 y las etiquetas de territorio son los textos más largos. Verificar que "Educación y orientación financiera" no desborde ni parta mal.

### 3.2 — 375px (móvil estándar)

Objetivo principal de verificación.

| Aspecto | Comportamiento |
|---|---|
| Margen lateral | 20px |
| Titular | 1.9rem, máximo 17ch |
| Cuerpo | 1rem, máximo 40ch |
| Núcleo (esc. 03) | 160px |
| Halos (esc. 03) | Columna, ancho completo, 64px de alto |
| Media (esc. 02) | 4:5, máximo 400px de alto |
| Canvas | Simplificado |

### 3.3 — 768px (tablet)

Punto de reflujo a estructuras de dos columnas.

| Aspecto | Comportamiento |
|---|---|
| Encuadre B | Se activa a 50/50 (no 60/40 todavía) |
| Encuadre C | Una columna, texto a 56ch |
| `booking` | Dos columnas |
| Halos (esc. 03) | Triangular si hay ≥620px de altura; si no, columna |
| Núcleo | 180px |
| Canvas | Activo |

**Condición de altura:** en tablet vertical (768×1024) la disposición triangular funciona. En tablet horizontal (1024×768) el espacio vertical es ajustado; se verifica y si no cabe se colapsa a columna.

### 3.4 — 1024px (escritorio)

| Aspecto | Comportamiento |
|---|---|
| Encuadre B | 60/40 completo |
| Escenario (esc. 03) | Altura mínima 560px |
| Núcleo | Hasta 232px |
| Halos | Disposición triangular |
| Contenido | Máximo 960px |

### 3.5 — 1180px (escritorio amplio)

| Aspecto | Comportamiento |
|---|---|
| Contenido | Máximo 1100px |
| Margen | 64px |
| Titular | Hasta 3.2rem |
| Escenario | Hasta 72vh |

### 3.6 — 1440px y superior

| Aspecto | Comportamiento |
|---|---|
| Contenido | **Máximo 1180px — no crece más** |
| Margen | 80px, y crece con la pantalla |
| Texto | Medida fija en ch; no se estira |

**Regla crítica:** en pantallas anchas crece el **margen**, nunca la medida de lectura. Un párrafo de 120 caracteres por línea es ilegible sin importar el tamaño del monitor.

## 4. Móvil horizontal

```css
@media (max-height: 480px) and (orientation: landscape)
```

El caso más problemático: poco alto, mucho ancho.

| Escena | Adaptación |
|---|---|
| 01 `curtain` | Logo a 80px, titular en línea, CTA al lado |
| 02 `founder-vsl` | Encuadre B a 50/50; imagen recortada a 1:1 |
| 03 `atom-command-center` | Escenario a 320px; halos en fila horizontal con scroll si es necesario |
| 04 `halo-selection` | 50/50; gesto recortado a 1:1 |
| 05 `black-transition` | Sin cambio |
| 06 `office-intro` | 50/50; puerta recortada; taza oculta |
| 07 `territory-world` | Dos columnas: título/resumen y preguntas |
| 08–10 | Una columna, padding vertical reducido |
| 11 `booking` | Dos columnas de campos |

**Reglas generales:** padding vertical reducido a `--space-3`, titulares un escalón menor, CTA siempre visible sin scroll.

## 5. Pantallas altas

```css
@media (min-height: 900px)
```

Con altura sobrante, la experiencia **respira**; no se estira el contenido.

- Padding vertical aumenta a `--space-9` (96px).
- El escenario de la escena 03 crece hasta 72vh.
- El contenido permanece centrado verticalmente.
- **El texto no crece.** La medida se mantiene.

## 6. Safe areas

Obligatorio en móvil con notch, Dynamic Island o barra de gestos.

```css
padding-top: max(var(--space-4), env(safe-area-inset-top));
padding-bottom: max(var(--space-4), env(safe-area-inset-bottom));
padding-left: max(var(--space-4), env(safe-area-inset-left));
padding-right: max(var(--space-4), env(safe-area-inset-right));
```

| Elemento | Requisito |
|---|---|
| Overlay de controles (Z5) | Respeta `safe-area-inset-top` y los laterales |
| CTA al pie | Respeta `safe-area-inset-bottom` |
| Escena a pantalla completa | `min-height: 100dvh`, no `100vh` |
| Contenido scrollable | Insets superior e inferior para no quedar bajo barras fijas |

**`100dvh` en vez de `100vh`:** en móvil, `100vh` no considera la barra de direcciones dinámica y produce corte de contenido. Ya corregido parcialmente en v0.2; se verifica en todas las escenas.

## 7. Halos

El componente con mayor riesgo de romperse.

| Breakpoint | Disposición | Ancho | Alto mín. |
|---|---|---|---|
| 320–479 | Columna vertical | `min(100%, 340px)` | 56px |
| 480–767 | Columna vertical | `min(100%, 340px)` | 64px |
| 768–1023 | Triangular si altura ≥620px; si no, columna | `min(260px, 34vw)` | 64px |
| ≥1024 | Triangular | `min(280px, 30vw)` | 72px |

### Reglas

- **La disposición orbital no funciona bajo 640px.** El reflujo a columna es obligatorio, no opcional.
- Cada halo conserva su glow de tono en todos los breakpoints: es lo que impide que se lea como lista de menú.
- Separación mínima entre halos: 12px.
- En disposición triangular, ningún halo puede solaparse con el núcleo. Verificar en 768px y 1024px.
- El `transform` de hover se ajusta por disposición: en columna es `translateY(-2px)`; en triangular debe respetar el `translate` de posicionamiento (bug conocido de v0.2, ya resuelto con selectores `nth-child`).

## 8. Núcleo

| Breakpoint | Tamaño |
|---|---|
| 320–374 | 140px |
| 375–767 | 160px |
| 768–1023 | 180px |
| ≥1024 | `clamp(180px, 26vw, 232px)` |

El label del núcleo escala con él. Si el texto no cabe, se reduce el label antes que el núcleo: el círculo es la forma reconocible.

## 9. Títulos

| Breakpoint | Display | Medida |
|---|---|---|
| 320 | 1.75rem | 17ch |
| 375 | 1.9rem | 17ch |
| 768 | 2.2rem | 20ch |
| 1024 | 2.8rem | 20ch |
| ≥1180 | `clamp()` hasta 3.6rem | 20ch |

- Nunca más de 3 líneas en móvil.
- Partición controlada: si un titular parte mal, se usa `<br>` intencional o `text-wrap: balance`.
- Sin guionado automático (`hyphens: none`): parte palabras de forma antiestética en español.

## 10. Captions

| Breakpoint | Comportamiento |
|---|---|
| <768px | Colapsadas tras control "Ver transcripción" |
| ≥768px | Visibles bajo la media |

Las captions de accesibilidad de video son **siempre** disponibles, aunque estén colapsadas visualmente. El colapso es de presentación, no de disponibilidad.

## 11. Overlays

El overlay de controles públicos (Z5) es fijo y flota sobre todo.

| Breakpoint | Comportamiento |
|---|---|
| <480px | Padding 12px; controles a 44px; "Omitir" abreviado si no cabe |
| 480–767 | Padding 16px |
| ≥768px | Padding `clamp(14px, 3vw, 28px)` |

### Reglas

- El overlay nunca cubre el CTA primario. Si hay riesgo de colisión, el contenido de la escena añade padding superior.
- El panel de ajustes se abre hacia abajo-izquierda desde su control; en móvil verifica no salirse del viewport.
- `pointer-events: none` en el contenedor; `auto` solo en los controles. Ya implementado en v0.2.
- Respeta safe areas en todos los lados.

## 12. Booking

| Breakpoint | Columnas | Alto de campo |
|---|---|---|
| <768px | 1 | 48px |
| ≥768px | 2 | 48px |

### Reglas móviles

- `font-size: 16px` en todos los inputs. **Obligatorio:** por debajo, iOS hace zoom automático al enfocar y rompe el layout.
- Tipos semánticos (`email`, `tel`, `text`) para el teclado correcto.
- Textarea y checkbox siempre a ancho completo.
- El CTA de envío nunca queda oculto tras el teclado virtual: se ubica al final del flujo, alcanzable por scroll.
- `autocomplete` apropiado en cada campo.

## 13. Touch targets

| Elemento | Mínimo | Verificado en |
|---|---|---|
| Control de overlay | 44×44px | Todos |
| CTA primario | 48px (52px móvil) | Todos |
| CTA secundario | 44px | Todos |
| Halo | 56px (móvil) / 64px | Todos |
| Pregunta (línea) | 44px (56px recomendado) | Todos |
| Campo | 48px | Todos |
| Checkbox (área) | 44×44px | Todos |
| Separación entre targets | 8px mínimo | Todos |

## 14. Overflow

### Reglas anti-desbordamiento

```css
html, body { overflow-x: hidden; }   /* red de seguridad global */
```

| Elemento | Riesgo | Mitigación |
|---|---|---|
| Glow de tono | Desborda el contenedor | `overflow: clip` en `.app-shell` |
| Halos en triangular | Se salen a 768px | `width: min()` y verificación de posición |
| Titulares largos | Rompen el contenedor | `max-width` en ch, `overflow-wrap: break-word` |
| Etiquetas de territorio | "Educación y orientación financiera" | Verificar en 320px |
| Scene rail (debug) | Horizontal por diseño | `overflow-x: auto` deliberado |
| Canvas | Excede su contenedor | `position: absolute; inset: 0` |
| Panel de ajustes | Se sale por la derecha | Anclado a la derecha, verificado en 320px |

**Ningún scroll horizontal en ningún breakpoint.** Es criterio de aceptación, no aspiración.

## 15. Colisiones conocidas

| # | Colisión | Breakpoint | Estado | Mitigación |
|---|---|---|---|---|
| 1 | `.control-mode` fuera del viewport | <640px, vista debug | **Resuelto en v0.2** | `margin-left: 0; width: 100%` |
| 2 | Taza sobre la puerta | <480px | **Resuelto en v0.2** | Taza y retrato ocultos |
| 3 | Halos sobre el núcleo | 768px, altura baja | **A verificar** | Colapso a columna si altura <620px |
| 4 | Overlay sobre CTA | Móvil horizontal | **A verificar** | Padding superior en la escena |
| 5 | Teclado virtual sobre envío | Móvil, `booking` | **A verificar** | CTA al final del flujo scrollable |
| 6 | Panel de ajustes fuera del viewport | 320px | **A verificar** | Anclaje derecho con margen |
| 7 | Titular de 3+ líneas | 320px, escenas 03 y 07 | **A verificar** | Medida en ch y verificación |

Las marcadas "A verificar" son responsabilidad de Codex durante la implementación, con evidencia en captura.

## 16. Fallback estructurado

Cadena de degradación. Cada nivel conserva la funcionalidad completa.

### Nivel 1 — Experiencia completa
Todos los assets, canvas activo, motion según tier.

### Nivel 2 — Sin canvas
Gradiente radial CSS por tono. Sin ondas reactivas. **Sin pérdida de contenido ni de navegación.**

### Nivel 3 — Sin imágenes
Placeholders con proporción declarada, gradiente cálido, texto descriptivo. La composición se mantiene; no hay saltos de layout.

### Nivel 4 — Reduced motion
Sin loops, sin blur, transiciones ≤150ms. **Todo el contenido visible y alcanzable de inmediato.**

### Nivel 5 — Sin JavaScript
Bloque `noscript` con la secuencia canónica descrita. Ya implementado en v0.2.

### Nivel 6 — Solo texto (lector de pantalla)
Orden de lectura lógico, encabezados jerárquicos, `alt` descriptivos, `aria-label` en controles, anunciador de escena `aria-live`.

**Criterio:** en los niveles 1 a 4 el visitante puede completar el recorrido de las once escenas y llegar a `booking`. En el nivel 5 entiende qué es el sitio. En el nivel 6 puede recorrerlo completo.

## 17. Matriz de verificación

| Escena | 320 | 375 | 768 | 1024 | 1180 | 1440 | Landscape | Alta |
|---|---|---|---|---|---|---|---|---|
| 01 `curtain` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| 02 `founder-vsl` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| 03 `atom-command-center` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| 04 `halo-selection` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| 05 `black-transition` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| 06 `office-intro` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| 07 `territory-world` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| 08 `question-layer` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| 09 `objection-layer` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| 10 `conversion-layer` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |
| 11 `booking` | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ |

Por celda: sin scroll horizontal, sin solapamiento, ancla visible, CTA alcanzable, touch targets ≥44px, texto legible.

## 18. Limitación heredada

La validación de v0.2 se hizo con **Chrome headless emulando viewports**, no en dispositivo físico. No se probó en iOS ni Android reales, ni en Safari real.

Safari en iOS tiene comportamientos propios en `dvh`, `env(safe-area-inset-*)`, `backdrop-filter` y zoom de inputs que la emulación no reproduce con fidelidad.

**Recomendación:** antes de considerar el responsive cerrado, una pasada manual en dispositivo real, mínimo un iPhone y un Android. Esto no bloquea la aprobación de la maqueta, pero sí debería bloquear una publicación.
