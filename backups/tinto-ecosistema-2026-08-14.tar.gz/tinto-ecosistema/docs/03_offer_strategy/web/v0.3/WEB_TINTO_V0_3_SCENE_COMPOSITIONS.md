# WEB TINTO v0.3 — Scene Compositions

- Ticket: WEB-003
- Documento: 2 de 11
- Base: `WEB_TINTO_V0_3_VISUAL_REFINEMENT.md`

## 1. Cómo leer este documento

Once escenas, una por sección. Cada una especifica composición para desktop, tablet y móvil, zonas de imagen, jerarquía, CTA, navegación, fallback, dependencias y criterios visuales de aceptación.

**Notación de encuadre** (definida en `VISUAL_REFINEMENT.md` §4.2): A = centrado, B = asimétrico 60/40, C = editorial textual.

**Notación de zona de imagen:** `IMG-XX` referencia el ID en `WEB_TINTO_V0_3_ASSET_MAP.md`.

**Regla transversal:** los eventos y transiciones citados son los ya existentes en v0.2. Este documento los referencia para ubicar la composición, **no los redefine**. Codex no debe alterar `scene-events.mjs` ni `state.mjs`.

## 2. Tabla maestra

| # | Escena | Intención (P2) | Encuadre | Ancla | CTA primario |
|---|---|---|---|---|---|
| 01 | `curtain` | "Algo empieza" | A | Logo | Entrar |
| 02 | `founder-vsl` | "Hay una persona" | B | Poster fundadora | Continuar |
| 03 | `atom-command-center` | "Esto es lo que hay" | A | Núcleo + 3 halos | Seleccionar territorio |
| 04 | `halo-selection` | "Elegiste" | B | Gesto de mano | Confirmar |
| 05 | `black-transition` | "Cambio de acto" | A | Pulso | (automático) |
| 06 | `office-intro` | "Pasa, siéntate" | B | Puerta de cristal | Entrar |
| 07 | `territory-world` | "Este es tu contexto" | B | Atmósfera | Abrir preguntas |
| 08 | `question-layer` | "Tu pregunta" | C | Tipografía | Ver objeción |
| 09 | `objection-layer` | "Tu duda" | C | Tipografía | Continuar |
| 10 | `conversion-layer` | "El siguiente paso" | C | Tipografía + acento | Agendar |
| 11 | `booking` | "Cuéntame" | C | Formulario | Enviar |

## 3. Escena 01 — `curtain`

**Objetivo narrativo.** Abrir. Producir la sensación de que algo comienza, no de que una página cargó. Es el equivalente al oscurecimiento de la sala antes de la película.

**Foco principal.** El logo, respirando, sobre negro cálido casi total.

### Composición desktop (≥1024px)

Encuadre A, plano frontal, verticalmente centrado en viewport completo.

```
              ·  ·  ·  ·  ·           ← Z1 textura punteada, opacidad 0.05
        ·                    ·
                 ┌────┐
                 │LOGO│                ← IMG-01, 180px, centrado óptico
                 └────┘                   (52% de altura, no 50%)
        ·                    ·
              Se abre el telón          ← N2, serif, clamp 2.4–3.2rem
        ·  ·  ·  ·  ·  ·  ·  ·

           [ Entrar ]  Omitir           ← N4, cobre + texto plano
```

- Logo a 180px, centro óptico al 52% de altura (no 50%: el centro geométrico se percibe bajo).
- Titular a 48px bajo el logo.
- CTA a 64px bajo el titular.
- Sin panel, sin borde, sin card. El fondo es el escenario.
- Glow radial cálido detrás del logo, radio 40% del viewport, opacidad ≤ 0.10.

### Composición tablet (768–1023px)

Idéntica estructura. Logo a 150px, titular `clamp` a 2.2rem, separaciones reducidas a 40/56px.

### Composición móvil (320–767px)

Idéntica estructura vertical, sin cambio de encuadre.

- Logo a 120px (100px bajo 375px).
- Titular a 1.9rem, máximo 17ch.
- CTA de ancho completo menos márgenes, mínimo 48px de alto.
- "Omitir" debajo del CTA, no al lado, con 16px de separación.

### Zonas de imagen

| Zona | Asset | Proporción | Fallback |
|---|---|---|---|
| Ancla central | `IMG-01` logo-mark | 1:1 | Wordmark tipográfico "TINTO" en serif |

### Jerarquía

N1 logo → N2 titular → N4 acción. Sin N3 (no hay cuerpo de texto: la escena dura segundos).

### CTA

- Primario: "Entrar" → `advance-scene`.
- Secundario: "Omitir introducción" → `skip-intro`, tratamiento de texto plano subrayado en hover, sin peso de botón.

### Navegación

Sin regreso (es la primera escena). Auto-advance según tier: cinematic 1100ms, balanced 800ms, reduced 0 (manual). Ya implementado en `content.mjs`; no se altera.

### Fallback

Sin JS: bloque `noscript` existente. Sin el SVG del logo: wordmark tipográfico. Con `reduced motion`: sin respiración, logo estático, sin animación de telón.

### Dependencias

`IMG-01` (P0). Ninguna otra.

### Criterios visuales de aceptación

- [ ] El logo se percibe centrado, no alto ni bajo.
- [ ] No hay ningún borde ni panel visible en la escena.
- [ ] El titular no supera 2 líneas en 375px.
- [ ] El CTA es el único elemento con color cobre.
- [ ] Con `reduced motion` la escena es completamente estática y legible.

## 4. Escena 02 — `founder-vsl`

**Objetivo narrativo.** Presentar a la persona. Pasar de marca a humano. El visitante debe registrar que hay alguien concreto del otro lado antes de que se le pida nada.

**Foco principal.** El retrato o video de la fundadora.

### Composición desktop

Encuadre B, 55/45, imagen a la izquierda.

```
┌─────────────────┐   Un momento con
│                 │   la fundadora           ← N2 serif
│    RETRATO      │
│    4:5          │   Una a dos frases de    ← N3, 56ch
│    IMG-02       │   contexto, sin claim.
│                 │
│                 │   [ Continuar ]  Omitir  ← N4
└─────────────────┘
  ▸ captions                                 ← N5
```

- Imagen en 4:5, ancho 55% de la columna de contenido, máximo 520px.
- Sin borde. Sombra proyectada cálida `--shadow-depth-3`.
- Marcas de encuadre de cámara (esquinas) en dorado a opacidad 0.4: refuerzan el registro cinematográfico. Se conservan de v0.2.
- Texto alineado al eje óptico superior de la imagen, no centrado verticalmente.

### Composición tablet

Encuadre B se mantiene pero a 50/50, con imagen reducida a máximo 380px. Si el titular supera 3 líneas, se colapsa a vertical (imagen arriba, texto abajo).

### Composición móvil

Vertical. Imagen primero, texto después.

- Imagen 4:5, ancho completo menos márgenes, máximo 400px de alto (recorte centrado en el rostro).
- Titular debajo, 1.8rem.
- Cuerpo a 40ch.
- CTA ancho completo.
- Captions colapsadas tras un control "Ver transcripción" (no ocupan altura por defecto).

### Zonas de imagen

| Zona | Asset | Proporción | Fallback |
|---|---|---|---|
| Ancla lateral | `IMG-02` founder-vsl-poster | 4:5 | Retrato estático `IMG-03` |
| Video futuro | `VID-01` mini-VSL | 4:5 | Poster + captions |

### Jerarquía

N1 imagen → N2 titular → N3 cuerpo → N4 acción → N5 captions.

### CTA

- Primario: "Continuar" → `advance-scene`.
- Secundario: "Omitir introducción" → `skip-intro`.

### Navegación

Regreso visible a `curtain`. Auto-advance activo.

### Fallback

Sin video: poster estático. Sin poster: retrato. Sin ninguno: bloque tipográfico con el titular sobre superficie café, proporción preservada para no romper layout. Captions obligatorias cuando exista video (heredado de v0.2).

### Dependencias

`IMG-02` (P0), `IMG-03` (P0), `VID-01` (P1). Confirmación pendiente sobre si se graba video real: `(andres confirma)`.

### Criterios visuales de aceptación

- [ ] El rostro es legible y ocupa al menos 30% del área de la imagen.
- [ ] La imagen no está enmarcada en una card con borde.
- [ ] La proporción 4:5 se preserva en los tres breakpoints.
- [ ] Sin video, la escena no se ve rota ni vacía.
- [ ] Las captions no ocupan altura en móvil por defecto.

## 5. Escena 03 — `atom-command-center`

**Objetivo narrativo.** Mostrar el mapa. El visitante ve las tres áreas y entiende que debe elegir una. Es la escena de mayor carga visual de la experiencia.

**Foco principal.** El núcleo central con tres halos orbitando.

### Composición desktop

Encuadre A. Escenario a pantalla casi completa.

```
   ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·
              ┌──────────┐
              │ Finanzas │              ← halo superior
              └──────────┘
   ·                                ·
        ╭─────────╮
┌───────┤ NÚCLEO  ├───────┐             ← núcleo 232px, glow cobre
│Activos│ Fundadora│      │Educación│
└───────┤         ├───────┘
        ╰─────────╯
   ·                                ·
   ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·

        Elige por dónde empezar         ← N2 bajo el escenario
          [ Ver territorio ]            ← N4
```

- Escenario de altura mínima 560px, máximo 72vh.
- Núcleo circular `clamp(180px, 26vw, 232px)`, silueta de la fundadora al 22% de opacidad detrás del label.
- Tres halos en disposición triangular: uno arriba centrado, dos abajo a los lados. Ancho `min(280px, 30vw)`.
- Canvas de atmósfera (Z1) con ondas reactivas, opacidad ≤ 0.16.
- Tag "Exploración inicial" arriba a la izquierda, `--text-faint`, pequeño.

**Los halos no son cards.** Sin borde rectangular, sin fondo sólido. Son formas de radio 40px con glow radial por tono y hairline de 1px al 14%. Su presencia se construye con luz.

### Composición tablet

Disposición triangular se mantiene si hay ≥ 620px de altura. Si no, los tres halos pasan a columna bajo el núcleo, con el núcleo reducido a 180px.

### Composición móvil

Reflujo obligatorio a vertical. La disposición orbital no funciona bajo 640px.

```
   [tag exploración inicial]
        ╭─────────╮
        │ NÚCLEO  │          ← 160px
        ╰─────────╯
   ┌───────────────────┐
   │ Finanzas          │      ← halos apilados
   └───────────────────┘
   ┌───────────────────┐
   │ Activos           │
   └───────────────────┘
   ┌───────────────────┐
   │ Educación         │
   └───────────────────┘
      Elige por dónde empezar
      [ Ver territorio ]
```

- Núcleo 160px, arriba.
- Halos en columna, ancho `min(100%, 340px)`, alto mínimo 64px, separación 12px.
- Cada halo conserva su glow de tono: es lo que impide que se lea como lista de menú.
- El canvas se simplifica o desactiva bajo 480px por costo de render.

### Zonas de imagen

| Zona | Asset | Proporción | Fallback |
|---|---|---|---|
| Núcleo | `IMG-04` founder-avatar | 1:1 | Núcleo sin silueta, solo glow y label |
| Atmósfera | `CNV-01` canvas ondas | fluido | Gradiente radial CSS estático |

### Jerarquía

N1 núcleo + halos → N2 titular → N4 acción. El escenario domina; el texto es orientación.

### CTA

- Primario: "Ver territorio" → `select-territory` con el territorio activo.
- Los halos son en sí mismos targets de selección: `select-territory` por halo.
- Sin CTA secundario en vista pública (el regreso vive en el overlay).

### Navegación

Regreso a `founder-vsl`. Sin auto-advance: la escena espera decisión.

### Fallback

Sin canvas: glow radial CSS estático, sin ondas. Sin `IMG-04`: núcleo con label tipográfico. Sin JS de selección: los tres halos son enlaces con `href` a deep link `#/territorio/<id>`.

### Dependencias

`IMG-04` (P1), `CNV-01` (P1). Los tres territorios como hipótesis: `(andres confirma)`.

### Criterios visuales de aceptación

- [ ] Los tres halos se leen como halos, no como tarjetas.
- [ ] Cada halo tiene su tono de territorio distinguible.
- [ ] El núcleo es el elemento de mayor peso visual.
- [ ] En 375px no hay scroll horizontal ni solapamiento.
- [ ] El tag "Exploración inicial" es visible pero no dominante.
- [ ] Con `reduced motion` las ondas se congelan; los halos siguen seleccionables.
- [ ] Touch target de cada halo ≥ 44px en todos los breakpoints.

## 6. Escena 04 — `halo-selection`

**Objetivo narrativo.** Materializar la elección. La selección deja de ser un clic y se vuelve un gesto físico: una mano que toca. Es el momento de compromiso.

**Foco principal.** El gesto de contacto entre mano y halo.

### Composición desktop

Encuadre B, 60/40, gesto a la izquierda.

```
┌──────────────────┐   Un contacto            ← N2
│                  │
│   ╭──────╮       │   El territorio que      ← N3
│   │ halo │       │   elegiste, en una
│   ╰──┬───╯       │   frase de contexto.
│      │           │
│    ╱─┘           │   [ Confirmar ]  Volver  ← N4
│   MANO IMG-05    │
└──────────────────┘
```

- Zona de gesto en 1:1 o 4:5, ancho 60%.
- Halo con pulso lento y línea luminosa horizontal cruzando.
- El glow adopta el tono del territorio seleccionado.
- Sin borde en la zona de gesto.

### Composición tablet

60/40 se mantiene. Si la altura es menor a 700px, colapsa a vertical con el gesto reducido a 280px de alto.

### Composición móvil

Vertical. Gesto arriba (240px de alto, recorte centrado en el punto de contacto), texto y acción abajo.

El punto de contacto mano-halo debe permanecer visible tras el recorte: es el sujeto de la imagen.

### Zonas de imagen

| Zona | Asset | Proporción | Fallback |
|---|---|---|---|
| Gesto | `IMG-05` halo-hand | 1:1 | Halo abstracto con pulso, sin mano |

### Jerarquía

N1 gesto → N2 titular → N3 contexto de territorio → N4 acción.

### CTA

- Primario: "Confirmar contacto" → `confirm-halo`.
- Secundario: "Volver" → `go-back`.

### Navegación

Regreso a `atom-command-center`. Sin auto-advance.

### Fallback

Obligatorio y ya definido en v0.2: sin la mano, la escena muestra halo con línea luminosa, pulso y confirmación de nodo. La escena **nunca** depende del asset de mano para ser funcional.

### Dependencias

`IMG-05` (P1). El fallback abstracto es P0.

### Criterios visuales de aceptación

- [ ] El punto de contacto es visualmente identificable.
- [ ] El tono del territorio seleccionado es evidente en el glow.
- [ ] El fallback sin mano se ve intencional, no roto.
- [ ] En móvil el punto de contacto sobrevive al recorte.
- [ ] Con `reduced motion` no hay pulso, pero el halo permanece.

## 7. Escena 05 — `black-transition`

**Objetivo narrativo.** Silencio. Separar acto I de acto II. No comunica información: produce la pausa que hace que lo siguiente se sienta distinto.

**Foco principal.** El vacío. Un pulso mínimo como único elemento.

### Composición desktop / tablet / móvil

Encuadre A, idéntico en los tres breakpoints. Es la única escena sin variación responsive.

```



              ╭───╮
              │ ∘ │          ← pulso 140px, hairline dorado 0.2
              ╰───╯



```

- Negro casi absoluto (`--p-void` a 98–99%).
- Pulso circular de 140px, borde 1px dorado a opacidad 0.2, sin relleno.
- Sin titular, sin cuerpo, sin CTA en vista pública.
- Duración corta. Auto-advance activo.

### Zonas de imagen

Ninguna. Deliberadamente.

### Jerarquía

Solo N1 (pulso). La ausencia de jerarquía es el punto.

### CTA

Ninguno visible en vista pública. En debug: "Continuar" y "Abortar transición".

### Navegación

Auto-advance a `office-intro`. Transición abortable (contrato v0.2). Interacción bloqueada mientras corre. El overlay de controles permanece accesible: nunca se atrapa al visitante.

### Fallback

Con `reduced motion`: fade oscuro corto, sin pulso, sin bloqueo prolongado. Nunca un blackout que parezca error de carga.

### Dependencias

Ninguna. Es la única escena sin dependencia de asset.

### Criterios visuales de aceptación

- [ ] No se percibe como pantalla rota o error de carga.
- [ ] La duración no supera 1.2s en `cinematic`.
- [ ] El control de regreso sigue accesible en el overlay.
- [ ] Con `reduced motion` la escena casi no se percibe: es un fade.
- [ ] No hay texto visible en vista pública.

## 8. Escena 06 — `office-intro`

**Objetivo narrativo.** La bienvenida física. El visitante cruza un umbral. Es la escena que produce la sensación de "pasa, siéntate".

**Foco principal.** La puerta de cristal, con la taza como detalle de hospitalidad.

### Composición desktop

Encuadre B, 60/40, puerta a la izquierda.

```
┌──────────────────┐   Bienvenida             ← N2
│ ░░░░░░░░░░░░░░░  │
│ ░  PUERTA     ░  │   El contexto del        ← N3
│ ░  IMG-06     ░  │   territorio elegido.
│ ░             ░  │
│ ░░░░░░░░░░░ ╭─╮  │   [ Entrar ]  Volver     ← N4
└─────────────┤☕├──┘
              ╰─╯       ← taza IMG-07, superpuesta
```

- Puerta en 3:4 o 4:5, ancho 60%.
- Taza superpuesta en la esquina inferior derecha, 34% del ancho de la puerta, máximo 120px. Rompe el marco deliberadamente: produce profundidad y evita la lectura de "imagen dentro de caja".
- Retrato secundario opcional arriba a la izquierda, circular, opacidad 0.7, como presencia de fondo.
- Luz cálida atravesando el cristal: es la fuente lumínica de la escena.

### Composición tablet

60/40 se mantiene. La taza se reduce a 90px. El retrato secundario se elimina si el ancho es menor a 900px (evita amontonamiento).

### Composición móvil

Vertical. Puerta arriba, texto abajo.

- **Taza y retrato secundario se ocultan bajo 480px** (heredado de v0.2, correcto: compiten con la puerta en pantallas angostas).
- Puerta a ancho completo, máximo 320px de alto, recorte centrado en el umbral.

### Zonas de imagen

| Zona | Asset | Proporción | Fallback |
|---|---|---|---|
| Puerta | `IMG-06` glass-door | 3:4 | Superficie con gradiente de luz cálida y hairline vertical |
| Taza | `IMG-07` tinto-cup | 1:1 | Se omite (es detalle, no estructura) |
| Retrato apoyo | `IMG-03` founder-portrait | 1:1 | Se omite |

### Jerarquía

N1 puerta → N2 titular → N3 contexto → N4 acción. La taza es N5: detalle, nunca protagonista.

### CTA

- Primario: "Entrar al territorio" → `advance-scene`.
- Secundario: "Regresar" → `go-back` (vuelve a `black-transition`).

### Navegación

**Punto crítico heredado:** `territory-world` regresa a `office-intro`, no salta el puente narrativo. Ya corregido en v0.2. El refinamiento visual no puede romperlo.

### Fallback

Sin puerta: superficie con gradiente de luz cálida y hairline vertical sugiriendo el umbral. La escena sigue leyéndose como umbral aunque no haya fotografía.

### Dependencias

`IMG-06` (P0), `IMG-07` (P2), `IMG-03` (P2).

### Criterios visuales de aceptación

- [ ] La taza rompe el marco de la puerta, no queda contenida.
- [ ] La luz de la escena parece venir del cristal.
- [ ] Bajo 480px no hay elementos superpuestos amontonados.
- [ ] El tono del territorio persiste en el glow de fondo.
- [ ] El regreso lleva a `black-transition`, no a `atom-command-center`.

## 9. Escena 07 — `territory-world`

**Objetivo narrativo.** Situar. El visitante entiende en qué territorio está y qué preguntas viven ahí. Es la escena que hace que su elección se sienta respetada.

**Foco principal.** La atmósfera del territorio y sus tres preguntas.

### Composición desktop

Encuadre B, 55/45. Atmósfera envolvente de fondo, contenido en dos columnas.

```
  ░░░░░ atmósfera de tono, canvas ░░░░░
  [ Exploración inicial ]                  ← N5 tag hipótesis

  Finanzas y patrimonio                    ← N2 título de territorio

  Resumen del territorio en una a       │  ← N3
  dos frases de contexto.               │
                                        │
  ┌ Flujo de caja ────────────────┐     │  ← 3 preguntas
  ┌ Protección ───────────────────┐     │
  ┌ Decisiones ───────────────────┐     │
                                        │
  [ Abrir preguntas ]  Volver           │  ← N4
```

- Canvas de atmósfera de fondo, opacidad ≤ 0.16, con el tono del territorio.
- Las tres preguntas se listan como **líneas con hairline**, no como cards. Cada una: título + hairline inferior de 1px al 14%, separación 20px.
- Al hover/focus: la hairline se ilumina al tono del territorio y el título sube 1px.

### Composición tablet

Una columna. Atmósfera de fondo se mantiene. Las preguntas conservan el tratamiento de línea.

### Composición móvil

Vertical, una columna, atmósfera simplificada.

- Tag de hipótesis arriba.
- Título de territorio 1.8rem.
- Resumen a 40ch.
- Preguntas como líneas de altura mínima 56px (touch target).
- CTA ancho completo al pie.

### Zonas de imagen

| Zona | Asset | Proporción | Fallback |
|---|---|---|---|
| Atmósfera | `CNV-02` canvas territorio | fluido | Gradiente radial CSS por tono |
| Textura | `TEX-01` textura orgánica | fluido | Textura punteada CSS existente |

### Jerarquía

N5 tag → N2 título → N3 resumen → lista de preguntas → N4 acción.

Nota: el tag de hipótesis va **arriba** del título deliberadamente. Debe leerse antes que la afirmación que califica.

### CTA

- Primario: "Abrir preguntas" → `advance-scene`.
- Secundario: "Regresar" → `go-back` (a `office-intro`).
- Cada pregunta: `select-question`.

### Navegación

Regreso obligatorio a `office-intro`. Sin auto-advance.

### Fallback

Sin canvas: gradiente radial CSS por tono. La escena es completamente funcional sin canvas.

### Dependencias

`CNV-02` (P1), `TEX-01` (P2). Territorios como hipótesis: `(andres confirma)`.

### Criterios visuales de aceptación

- [ ] Las preguntas se leen como lista editorial, no como cards.
- [ ] El tono del territorio es evidente sin leer el título.
- [ ] El tag "Exploración inicial" precede al título.
- [ ] La atmósfera nunca reduce el contraste del texto bajo 4.5:1.
- [ ] Cada pregunta tiene touch target ≥ 44px en móvil.

## 10. Escena 08 — `question-layer`

**Objetivo narrativo.** Nombrar la pregunta del visitante. Es el primer momento en que el contenido habla de él, no de TINTO.

**Foco principal.** La pregunta, en tipografía grande.

### Composición desktop

Encuadre C, editorial textual. Cambio de registro visible respecto a las escenas anteriores.

```
PREGUNTA ACTIVA                          ← N5 eyebrow

¿Qué te está apretando                   ← N2, serif grande
más hoy?                                    máx 20ch

Respuesta provisional en una a dos       ← N3, 56ch
frases, sin claim ni promesa.

────────────────────────────             ← hairline

Recurso                                  ← N5
Mapa de lectura provisional              ← apoyo
Marco de conversación.

  [ Ver objeción ]   Cambiar pregunta    ← N4

  Flujo de caja · Protección · Decisiones ← navegación entre preguntas
```

- El titular es la pregunta, no un rótulo. Ocupa el mayor peso visual.
- Ancho de lectura máximo 56ch. En pantallas anchas el texto **no se estira**.
- El recurso se presenta como bloque tipográfico con hairline, sin card.
- Las otras preguntas del territorio quedan accesibles como línea de navegación inferior, tratamiento de texto plano.

### Composición tablet

Una columna, mismo tratamiento. Titular a 2.2rem.

### Composición móvil

Una columna.

- Titular 1.9rem, máximo 17ch.
- Cuerpo 40ch.
- Recurso debajo, mismo tratamiento tipográfico.
- Navegación entre preguntas: scroll horizontal controlado o menú desplegable, con targets de 44px.

### Zonas de imagen

Ninguna obligatoria. Opcionalmente `TEX-01` como textura de fondo a opacidad ≤ 0.04.

Esta escena es deliberadamente sin imagen: el cambio a registro textual es lo que marca el paso al acto III.

### Jerarquía

N5 eyebrow → N2 pregunta → N3 respuesta provisional → apoyo → N4 acción.

### CTA

- Primario: "Ver objeción" → `advance-scene`.
- Secundario: "Cambiar pregunta" → `select-question`.

### Navegación

Regreso a `territory-world`. Evento `question_opened` al abrir.

### Fallback

Sin JS de selección: las tres preguntas como enlaces a deep link. Contenido completo siempre visible; nada colapsado que oculte información esencial.

### Dependencias

Ninguna de asset. Copy provisional heredado de `content.mjs`: no se altera.

### Criterios visuales de aceptación

- [ ] El cambio de registro respecto a la escena 07 es perceptible.
- [ ] El texto nunca supera 56ch en desktop.
- [ ] No hay ninguna card con borde en la escena.
- [ ] La respuesta provisional se lee como provisional, no como promesa.
- [ ] Las otras preguntas siguen alcanzables sin volver atrás.

## 11. Escena 09 — `objection-layer`

**Objetivo narrativo.** Nombrar la duda antes de que el visitante la formule. Producir la sensación de "esto ya lo pensaron".

**Foco principal.** La objeción, tratada como cita.

### Composición desktop

Encuadre C, con tratamiento de cita editorial.

```
OBJECIÓN                                 ← N5

│ La objeción común es pensar            ← N2 tratada como cita
│ que ordenar también significa             barra vertical de tono
│ vender algo.                              serif, 1.4rem

Contexto                                 ← N5
Respuesta educativa, sin testimonio      ← N3
ni prueba inventada.

  [ Continuar ]   Volver                 ← N4
```

- La objeción lleva **barra vertical de 2px** en el tono del territorio, a la izquierda, con 24px de padding.
- Tipografía serif a 1.4rem: menor que un titular, mayor que el cuerpo. Es una voz distinta.
- El contexto va debajo, en sans, claramente separado como respuesta.

### Composición tablet / móvil

Idéntica estructura. La barra vertical se mantiene (es el elemento que da carácter). Padding izquierdo reducido a 16px en móvil.

### Zonas de imagen

Ninguna. Escena puramente textual.

### Jerarquía

N5 eyebrow → N2 objeción (cita) → N5 "Contexto" → N3 respuesta → N4 acción.

### CTA

- Primario: "Continuar" → `advance-scene`.
- Secundario: "Volver" → `go-back`.

### Navegación

Regreso a `question-layer`. Evento `objection_viewed`.

### Fallback

Texto plano. La escena no depende de nada visual más allá de la barra de tono.

### Dependencias

Ninguna.

### Criterios visuales de aceptación

- [ ] La objeción se lee como cita, con voz distinta al cuerpo.
- [ ] La barra vertical lleva el tono del territorio activo.
- [ ] No hay testimonios, cifras ni pruebas de ningún tipo.
- [ ] La respuesta se distingue tipográficamente de la objeción.

## 12. Escena 10 — `conversion-layer`

**Objetivo narrativo.** Sintetizar y proponer el siguiente paso. Sin presión, sin urgencia fabricada, sin precio.

**Foco principal.** La síntesis y el CTA, que aquí alcanza su máximo peso visual de toda la experiencia.

### Composición desktop

Encuadre C, con el CTA tratado como destino.

```
SÍNTESIS                                 ← N5

Finanzas y patrimonio                    ← N2

La pregunta que trajiste, devuelta       ← N3
en una frase de reconocimiento.

────────────────────────────             ← hairline

     [  Agendar conversación  ]          ← N4, máximo peso
                                            cobre, aislado
     Volver                              ← secundario, texto plano

Esto no agenda ni confirma               ← N5, microcopy honesto
automáticamente.
```

- El CTA primario es el elemento de mayor contraste de toda la experiencia. Aislado por 48px de espacio arriba y abajo.
- Glow cobre sutil detrás del botón, radio corto.
- El microcopy bajo el CTA es honesto sobre lo que ocurre: no promete agenda confirmada.

### Composición tablet / móvil

Una columna. CTA ancho completo menos márgenes en móvil, mínimo 52px de alto.

El microcopy permanece visible: no se colapsa ni se reduce a un asterisco.

### Zonas de imagen

Ninguna obligatoria. Opcional: glow de tono intensificado como cierre visual del acto.

### Jerarquía

N5 eyebrow → N2 territorio → N3 síntesis → N4 CTA (peso máximo) → N5 microcopy.

### CTA

- Primario: "Agendar conversación" → `advance-scene` hacia `booking`. Etiqueta exacta `(andres confirma)`.
- Secundario: "Volver" → `go-back`.

### Navegación

Regreso a `objection-layer`. Evento `cta_revealed`.

### Fallback

CTA siempre visible, nunca dependiente de scroll ni de motion de revelación.

### Dependencias

Ninguna de asset. Etiqueta del CTA: `(andres confirma)`.

### Criterios visuales de aceptación

- [ ] El CTA es inequívocamente el elemento dominante.
- [ ] No hay precio, plan, garantía ni urgencia en ninguna forma.
- [ ] El microcopy honesto es legible, no letra chica.
- [ ] El CTA está aislado por espacio, no rodeado de otros botones.

## 13. Escena 11 — `booking`

**Objetivo narrativo.** Recoger contexto. No es un checkout: es el formulario de "cuéntame qué está pasando".

**Foco principal.** El formulario, tratado con calma editorial.

### Composición desktop

Encuadre C, formulario en dos columnas.

```
Agenda una conversación inicial          ← N2

Cuéntanos brevemente tu situación.       ← N3

Nombre              Email                ← campos, 2 col
[__________]        [__________]

País                Territorio
[__________]        [__________]

Situación
[________________________________]       ← textarea, ancho completo

Urgencia            Tipo de ayuda
[__________]        [__________]

Preferencia de contacto
[__________]

☐ Consentimiento — texto del mock        ← checkbox

  [ Enviar ]   Volver                    ← N4
```

- Labels **visibles siempre**, sobre el campo. Nunca placeholder-como-label.
- Campos sin borde completo: hairline inferior de 1px, que se ilumina en dorado al foco. Tratamiento editorial, no de formulario administrativo.
- Altura mínima de campo 48px.
- Textarea y checkbox ocupan ancho completo.

### Composición tablet

Dos columnas se mantienen sobre 760px. Bajo eso, una columna.

### Composición móvil

Una columna estricta.

- Todos los campos a ancho completo, altura mínima 48px.
- `font-size: 16px` en inputs (evita el zoom automático de iOS).
- Tipos semánticos: `email`, `tel`, `text` para disparar el teclado correcto.
- CTA de envío fijo al pie de la escena o al final del scroll, nunca oculto.

### Estado de confirmación

Tras enviar, la escena se reemplaza por confirmación:

```
Recibido                                 ← N2
Gracias por compartir tu contexto.       ← N3

[nombre] · [email] · [territorio]        ← resumen, texto plano

Esto no agenda ni confirma               ← N5, honesto
automáticamente.

  [ Continuar ]   Regresar
```

Único lugar donde el verde profundo de confirmación puede aparecer, como acento mínimo (ver `VISUAL_REFINEMENT.md` §5.2).

### Zonas de imagen

Ninguna. Opcional: glow de tono al fondo, muy bajo.

### Jerarquía

N2 titular → N3 contexto → formulario → N4 envío → N5 microcopy de mock.

### CTA

- Primario: "Enviar" → `submit-booking`. Etiqueta pública `(andres confirma)`.
- Secundario: "Volver" → `go-back`.

### Navegación

Regreso a `conversion-layer`. Eventos `booking_started` y `booking_completed`.

### Fallback

Formulario simple sin persistencia. **Contrato heredado no negociable:** `external_calendar: disabled`, `lead_scoring: disabled`, `persistent_storage: disabled`. Sin JS: el formulario debe seguir siendo legible y navegable aunque no envíe.

### Dependencias

Ninguna de asset. Campos heredados de `content.mjs` sin alteración. Opción de país `(andres confirma)` ya presente en el contenido.

### Criterios visuales de aceptación

- [ ] Todos los campos tienen label visible.
- [ ] Ningún campo usa solo placeholder como etiqueta.
- [ ] Los inputs tienen 16px de fuente en móvil.
- [ ] El foco es visible y usa el dorado del sistema.
- [ ] El microcopy de mock local es explícito.
- [ ] El formulario no se lee como checkout ni como panel administrativo.
- [ ] Errores, si existen, aparecen junto al campo, no agrupados arriba.

## 14. Continuidad entre escenas — verificación

Tabla de control para revisar que el hilo visual no se rompe:

| Transición | Elemento que persiste | Elemento que cambia |
|---|---|---|
| 01 → 02 | Negro cálido, luz central | Logo → persona |
| 02 → 03 | Persona (silueta en núcleo) | Retrato → mapa |
| 03 → 04 | Tono de territorio elegido | Mapa → gesto |
| 04 → 05 | Tono en el pulso | Todo se apaga |
| 05 → 06 | Negro → luz de puerta | Vacío → umbral |
| 06 → 07 | Tono, luz cálida | Puerta → mundo |
| 07 → 08 | Tono en hairlines | Imagen → texto (cambio de acto) |
| 08 → 09 | Registro editorial | Pregunta → objeción |
| 09 → 10 | Registro editorial | Objeción → síntesis |
| 10 → 11 | CTA cumplido | Propuesta → formulario |

## 15. Confirmaciones pendientes de este documento

| # | Escena | Tema | Estado |
|---|---|---|---|
| 1 | 10 | Etiqueta exacta del CTA de conversión | `(andres confirma)` |
| 2 | 11 | Etiqueta del botón de envío en vista pública | `(andres confirma)` |
| 3 | 02 | ¿Video real o poster definitivo para la maqueta? | `(andres confirma)` |
| 4 | 03, 07 | Confirmación de los tres territorios como hipótesis de trabajo | `(andres confirma)` |
| 5 | 11 | Lista definitiva de países en el selector | `(andres confirma)` |
