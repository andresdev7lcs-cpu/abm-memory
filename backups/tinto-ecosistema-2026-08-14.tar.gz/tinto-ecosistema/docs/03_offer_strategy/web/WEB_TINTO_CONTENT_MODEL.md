# WEB TINTO - Content Model

## Principio

Todo el contenido vive fuera del render. La UI solo consume datos.

## Fuentes de contenido

- `tools/tinto-web/content.mjs`
- Assets locales en `tools/tinto-web/assets/`

## Modelo general

```text
siteContent
  brand
  assets
  loader
  hero
  founderCore
  touchGesture
  territories[]
  diagnosis
```

## Reglas

1. El contenido debe ser reemplazable sin reconstruir la web.
2. Nada estrategico se escribe dentro de componentes visuales.
3. Los territorios permanecen en estado de hipotesis.
4. Los datos de diagnostico son mock local.
5. No se guardan datos sensibles de manera permanente.

## Territorios provisionales

Cada territorio contiene:

- `id`
- `title`
- `status: hypothesis`
- `approval: pending_confirmation`
- `summary`
- `questions[]`

Territorios permitidos:

1. Finanzas y patrimonio.
2. Activos inmobiliarios.
3. Educacion y orientacion financiera.

## Preguntas

Cada pregunta contiene:

- `id`
- `title`
- `prompt`
- `provisionalAnswer`
- `resource`
- `cta`
- `relatedQuestionIds`

## Hero

- `eyebrow`
- `title`
- `body`
- `overlay`
- `ctas[]`
- `media`

## Formularios

Campos del diagnostico:

- nombre
- email
- pais
- territorio
- situacion
- urgencia cualitativa
- tipo de ayuda
- preferencia de contacto
- consentimiento

Modo del prototipo:

- `submission_mode: local_mock`
- `lead_scoring: disabled`
- `automatic_approval: disabled`
- `automatic_rejection: disabled`

## Assets reemplazables

- logo
- retrato
- avatar
- hero poster
- colores
- tipografia
- territorios
- preguntas
- respuestas
- CTA
- textos
- recursos

