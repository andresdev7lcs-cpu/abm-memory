# WEB TINTO - Motion System

**Estado**: Especificación de animaciones y transiciones  
**Productor**: Claude Code  
**Rama**: `feature/tinto-offer-strategy-v1.0.0`  
**Fecha**: 2026-07-30

---

## Principios de movimiento

### Duración estándar
- Transiciones rápidas: 150ms (tooltips, hovers)
- Transiciones estándar: 220ms (navegación, cambios de estado)
- Transiciones lentas: 300–600ms (composiciones, animaciones de entrada)
- Animaciones continuas: 36s+ (órbitas rotantes, loops infinitos)

### Easing
- Estándar: `ease` (cubic-bezier suave)
- Entrada rápida: `ease-in-out`
- Loops infinitos: `linear` (para rotaciones constantes)

### Reduced motion compliance
Todas las animaciones que no sean transiciones esenciales se desactivan con:
```css
@media (prefers-reduced-motion: reduce)
```

---

## Animaciones implementadas

### 1. Loader breathing (`breath`)

**Duración**: 2.2s  
**Iteración**: Infinita  
**Easing**: ease-in-out

**Mecánica**:
- 0%: scale(0.96), saturate(0.92), brightness(0.88)
- 25%: scale(0.99), saturate(0.98), brightness(0.96)
- 50%: scale(1.04), saturate(1.08), brightness(1.06) ← Pico
- 75%: scale(1.01), saturate(1.02), brightness(1.02)
- 100%: Vuelve a 0%

**Efecto visual**: Logo respira suavemente, gana luminosidad al expandirse.

**Reduced motion**: Desactivado.

### 2. Logo reveal (`reveal`)

**Duración**: 2.2s  
**Iteración**: Infinita  
**Easing**: ease-in-out

**Mecánica**:
- 0%: opacity(0.32), scale(0.96), blur(5px), brightness(0.78)
- 30%: opacity(0.92), scale(0.998), blur(0px), brightness(1.02) ← Limpieza
- 50%: opacity(1), scale(1.01), blur(0.2px), brightness(1.08) ← Máxima claridad
- 65%: opacity(0.48), scale(1.005), blur(1.2px), brightness(0.96) ← Desvanecimiento
- 100%: opacity(0.88), scale(1), blur(0.4px), brightness(1.06)

**Efecto visual**: Logo inicia borroso, se enfoca, aclara, se desvanece brevemente, reaparece.

**Reduced motion**: Desactivado (filter: none).

### 3. Pulse (`pulse`)

**Duración**: 2.8s  
**Iteración**: Infinita  
**Easing**: ease-in-out

**Mecánica**:
- 0%, 100%: scale(0.96), opacity(0.88)
- 50%: scale(1.1), opacity(1) ← Expansión máxima

**Efecto visual**: Pulso suave en touch cue, expande y contrae.

**Elemento**: `.touch-cue__pulse`

**Reduced motion**: Desactivado.

### 4. Orbit rotation (`orbit-rotate`)

**Duración**: 36s  
**Iteración**: Infinita  
**Easing**: linear

**Mecánica**:
- 0%: rotate(0deg)
- 100%: rotate(360deg)

**Efecto visual**: Las órbitas del átomo rotan lentamente, creando sensación de movimiento cósmico.

**Elemento**: `.atom-orbits`

**Reduced motion**: Desactivado (animation: none).

---

## Transiciones CSS

Aplicadas a elementos interactivos con duración 220ms y easing `ease`:

```css
transition:
  transform 220ms ease,
  border-color 220ms ease,
  background 220ms ease,
  box-shadow 220ms ease,
  opacity 220ms ease;
```

### Elementos con transiciones

- `.cta-button`
- `.ghost-button`
- `.related-pill`
- `.territory-node`
- `.atom-core`
- `.question-card`

### Efectos en hover/active

| Estado | Efecto |
|--------|--------|
| Hover | `transform: translateY(-1px)` (elevación) |
| Active | `border-color` + `box-shadow` intensificados |
| Focus | `outline: 2px solid var(--focus), outline-offset: 3px` |

---

## Transiciones de vista

### Hero → Home-Átomo
- Fade suave entre vistas: 220ms
- Scale entrada del núcleo: 0.8 → 1.0 (300ms)
- Órbitas aparecen staggered: cada 100ms

### Territorio → Tablero
- Tablero emerge: 220ms fade-in + scale(0.95 → 1.0)
- Preguntas list anima en staggered: 100ms entre cards

### Pregunta → Escenario
- Scenario fade-in: 220ms
- Preview expande: scale(0.95 → 1.0)

### Paso diagnóstico
- Fieldset entra: 220ms fade
- Botones nav disponibles sin delay

---

## Performance target

- Animaciones a 60fps
- No block main thread
- GPU-accelerated transforms (scale, translate, rotate)
- Evitar animaciones de propiedades costosas (width, height, top, left)

### Propiedades seguras para animar

✓ transform (scale, translate, rotate)  
✓ opacity  
✓ box-shadow (con cuidado)  
✓ border-color  
✓ background (gradients lentos)

✗ width / height  
✗ top / bottom / left / right  
✗ font-size  
✗ padding / margin

---

## Testing animaciones

Verificar:
- [ ] Loader: Respira 2 ciclos completos antes de fade
- [ ] Logo: Inicia borroso, se enfoca, desvanece
- [ ] Órbitas: Rotan suavemente (si motion full)
- [ ] Hover buttons: Elevación visible sin lag
- [ ] Fade transiciones: Suave entre vistas
- [ ] Reduced motion: Sin animaciones, funcionalidad ok
- [ ] Lighthouse: Performance >85

---

## Reduced motion implementation

```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }

  /* Excepciones si es necesaria transición mínima */
  button:focus {
    outline-offset: 2px;
  }
}
```

**Resultado**: Todas animaciones se cumplen instantáneamente (0.01ms), transiciones quedan imperceptibles pero presentes.

---

## Assets visuales que suportarán movimiento futuro

- Video hero: Autoplay muted loop
- Avatar IA: Puede animar con expresiones
- Transiciones página: Scroll smooth opcional
- Loader alternativo: Spinner si lo requiere

---

## Notas de implementación

1. **Loader timing**: 900ms en motion full, 250ms en reduced. Fade-out a los 1600ms (motion full) o 450ms (reduced).
2. **Orbit speed**: 36s permite órbita visual sin distracción (velocidad sutil).
3. **Pulse**: 2.8s es ciclo lento que llama atención sin agresividad.
4. **Stagger**: Usar CSS `animation-delay` o JavaScript para efecto cascada.
5. **Bounce**: Evitar en esta versión. Mantener elegancia sin juguetería.

---

## Testing reduced-motion

```bash
# macOS
defaults write com.apple.universalaccessibility preferredMotionIsReduced 1

# Linux / DevTools Chrome
Emulate CSS media feature prefers-reduced-motion: reduce
```

**Verificar**: Loader desaparece rápido, órbitas estáticas, hovers sin delay.

---

## Estado

- Especificación: Completa
- Implementación CSS: Completada
- Pruebas manuales: Pendiente (en fase visual)
- Lighthouse performance: Pendiente
