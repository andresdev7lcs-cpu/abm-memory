# WEB TINTO - Codex Handoff

## Que deja Codex

- Sitio base funcional.
- Arquitectura modular.
- Contenido desacoplado.
- Navegacion reversible.
- Loader funcional.
- Hero provisional.
- Home-Atom.
- Tablero digital.
- Escenario interno.
- Diagnostico progresivo mock.

## Que NO deja Codex

- Direccion de arte final.
- Motion design final.
- Microanimaciones finalizadas.
- Hero cinematografico final.
- Gesto de toque final.
- Acabado premium final.
- Oferta aprobada.

## Instrucciones para Claude Code

1. No tocar la separacion entre contenido y render.
2. No hardcodear texto estrategico dentro de componentes.
3. Sustituir assets y copy desde `content.mjs`.
4. Mantener territorios como hipotesis hasta aprobacion humana.
5. Preservar rutas reversibles.
6. Mejorar estetica sin romper el mapa de componentes.

## Puntos de extension

- Sustituir `heroPoster`.
- Reemplazar `founderPortrait` y `founderAvatar`.
- Afinar tono, color y tipografia.
- Agregar motion premium.
- Sustituir recursos provisionales por recursos aprobados.

## Riesgos a vigilar

- Inventar experiencia o credenciales.
- Presentar territorios como servicios aprobados.
- Guardar datos sensibles de forma permanente.
- Romper navegacion por hash.
- Introducir dependencias innecesarias.

## Estado requerido antes de avanzar

- Auditoria tecnica independiente.
- Handoff validado.
- Sin uso de `completed` en esta entrega.

