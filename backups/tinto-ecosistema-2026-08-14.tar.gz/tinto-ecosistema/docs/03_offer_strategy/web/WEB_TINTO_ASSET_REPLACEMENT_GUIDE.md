# WEB TINTO - Asset Replacement Guide

**Estado**: Guía para reemplazo de placeholders  
**Productor**: Claude Code  
**Rama**: `feature/tinto-offer-strategy-v1.0.0`  
**Objetivo**: Facilitar sustitución de assets provisionales sin modificar código

---

## Assets provisionales actuales

Ubicados en `tools/tinto-web/assets/`:

| Archivo | Referencia | Tipo | Dimensiones | Próximo paso |
|---------|-----------|------|------------|--------------|
| `logo-mark.svg` | `content.mjs` line 8 | SVG | 200×200px | Logo definitivo Andrés/diseño |
| `hero-poster.svg` | `content.mjs` line 9 | SVG | 800×1000px | Fotografía hero o video |
| `founder-portrait.svg` | `content.mjs` line 10 | SVG | 400×500px | Retrato real fundadora |
| `founder-avatar.svg` | `content.mjs` line 11 | SVG | 150×150px | Avatar IA o mini-portrait |

---

## Proceso de reemplazo sin modificar código

### Paso 1: Preparar nuevo asset

**Opción A - Logo**:
- Formato preferido: SVG (escalable, sin pérdida)
- Alternativa: PNG de 256×256px+ con transparencia
- Colocar en: `tools/tinto-web/assets/logo-mark.*`

**Opción B - Hero media**:
- Formato preferido: WEBM (VP8/VP9 codec) o MP4 (H.264)
- Dimensión: 800×1000px (vertical) o responsive
- Poster (fallback): JPG optimizado, 800×1000px
- Colocar en: `tools/tinto-web/assets/hero-*` (video + poster)

**Opción C - Retratos**:
- Formato: JPG (fotos reales) o PNG (avatares)
- Dimensiones:
  - Portrait: 400×500px
  - Avatar: 150×150px (o 2x para retina: 300×300px)
- Colocar en: `tools/tinto-web/assets/founder-*`

### Paso 2: Actualizar `content.mjs`

**Logo**:
```javascript
// Línea 8
logo: "./assets/logo-mark.svg", // o .png / .jpg
```

**Hero media**:
```javascript
// Líneas 34-39
media: {
  poster: "./assets/hero-poster.jpg",
  webm: "./assets/hero.webm", // Opcional
  mp4: "./assets/hero.mp4",   // Opcional
  image: "./assets/hero-poster.jpg", // Fallback si sin video
  alt: "Hero cinematográfico de TINTO"
}
```

**Founder portrait**:
```javascript
// Línea 47
portrait: "./assets/founder-portrait.jpg",
```

**Founder avatar**:
```javascript
// Línea 48
avatar: "./assets/founder-avatar.jpg",
```

### Paso 3: Verificar en navegador

```bash
# En tool root
python3 -m http.server 8080

# Abrir http://localhost:8080
# Verificar:
# - Logo carga y se ve en loader
# - Hero media visible
# - Portraits se ven en Home-Atom
# - Sin errores en console
```

---

## Especificaciones técnicas

### Logo

**SVG recomendado**:
```svg
<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
  <!-- Logo marca TINTO -->
  <!-- Usar colores en paleta: #f4eee7, #d79a55, #6e4433 -->
</svg>
```

**PNG alternativo**:
- 256×256px mín
- Fondo transparente
- Anti-alias suave

**NO hacer**: Texto ancho, detalles microscópicos, colores muy oscuros en fondo oscuro.

### Hero media

**Video WEBM/MP4**:
- Resolución: 800×1000px (vertical)
- Duración: 8–15s recomendado
- Autoplay: muted loop playsinline (en HTML)
- Bitrate: 1.5–2.5 Mbps (balance calidad/tamaño)
- Codec video: VP8/VP9 (WEBM) o H.264 (MP4)

**Poster fallback**:
- JPG optimizado
- 800×1000px
- <200kb preferible
- Calidad 85% JPEG

**Video sugerido**:
- Oficina contemporánea
- Puerta/ventana con luz
- Profundidad cinematográfica
- Reflejos suaves
- Fundadora o actriz (si autorizado)
- Gesto bienvenida, sonrisa, mirada a cámara
- Sin cortes abruptos

### Founder portrait

**Fotografía real**:
- Resolución: 400×500px (vertical)
- Formato: JPG con calidad 90%
- Estilo: Retrato profesional, iluminación cálida
- Fondo: Desenfocado o gradient suave
- Expresión: Confiable, accesible, confianza

**Avatar IA alternativo**:
- Si fundadora no está disponible para foto
- Usar herramienta avatar (Midjourney, Stable Diffusion, etc.)
- Estilo: Profesional, cálido, similar a hero

### Founder avatar

**Mini-avatar**:
- 150×150px (o 300×300px retina)
- Circular o cuadrado redondeado
- Recorte de portrait o generado
- Formato: PNG/JPG
- Uso: Junto a "(andres confirma)" en Home-Atom

---

## Compatibilidad navegadores

| Formato | Chrome | Firefox | Safari | Edge | Mobile |
|---------|--------|---------|--------|------|--------|
| SVG | ✓ | ✓ | ✓ | ✓ | ✓ |
| PNG | ✓ | ✓ | ✓ | ✓ | ✓ |
| JPG | ✓ | ✓ | ✓ | ✓ | ✓ |
| WEBM | ✓ | ✓ | ✗ | ✓ | Variable |
| MP4 | ✓ | ✓ | ✓ | ✓ | ✓ |

**Recomendación**: MP4 + fallback JPG. WEBM opcional para navegadores que lo soporten.

---

## Optimización de assets

### Reducir tamaño sin perder calidad

**SVG**:
```bash
# Usar SVGO (node package)
npm install -g svgo
svgo logo-mark.svg -o logo-mark.min.svg
```

**JPG**:
```bash
# macOS (imagemagick)
convert hero-poster.jpg -quality 85 -strip hero-poster.jpg

# Linux
mogrify -quality 85 -strip hero-poster.jpg

# Online: tinypng.com, jpegmini.com
```

**MP4**:
```bash
# Reducir bitrate
ffmpeg -i hero.mp4 -b:v 1.5M hero.mp4

# Convertir a WEBM
ffmpeg -i hero.mp4 -c:v libvpx-vp9 -crf 30 -b:v 1.5M hero.webm
```

### Webp (opcional, soporte moderno)

```bash
# Convertir a webp
cwebp hero-poster.jpg -o hero-poster.webp -q 85
```

Luego actualizar `content.mjs`:
```javascript
// HTML5 picture con srcset
image: "./assets/hero-poster.webp", // Moderno
fallback: "./assets/hero-poster.jpg" // Antiguo
```

---

## Checklist de reemplazo

- [ ] Asset nuevo preparado y optimizado
- [ ] `content.mjs` actualizado con ruta correcta
- [ ] Servidor local corriendo
- [ ] Asset carga sin 404 en console
- [ ] Visual correcto en todas vistas (loader, hero, atom, etc.)
- [ ] Responsive: desktop, tablet, mobile
- [ ] Reduced motion: Asset sigue visible
- [ ] Performance: LCP <2.5s en página completa
- [ ] Alternativas (fallback) funcionan si asset principal falla

---

## Problemas comunes

### Logo no aparece en loader
- ✓ Verificar ruta en `content.mjs` línea 8
- ✓ Archivo existe en `tools/tinto-web/assets/`
- ✓ Formato SVG/PNG válido
- ✓ Permisos de archivo (644 mín)
- ✓ No está bloqueado por CORS (local server ok)

### Video hero no reproduce
- ✓ Formato: MP4 es más compatible que WEBM
- ✓ Codec: H.264 para MP4, VP9 para WEBM
- ✓ Poster: JPG fallback definido
- ✓ Autoplay: `muted` requerido (navegador policy)
- ✓ Tamaño: <10MB recomendado

### Retratos no aparecen en Home-Atom
- ✓ Rutas: `founder-portrait.svg` y `founder-avatar.svg` correctas
- ✓ Dimensiones: JPG aceptado, PNG aceptado
- ✓ Aspect ratio: Portrait 4:5, avatar 1:1

### Performance degradado con assets nuevos
- ✓ Comprimir JPG/PNG con herramientas de optimización
- ✓ Usar WEBM en lugar de MP4 si tamaño problema
- ✓ Reducir resolución video si >15MB
- ✓ Lazy load si muchos assets

---

## Estado

- Guía: Completa
- Proceso: Documentado
- Validación: Manual en navegador
- Testing: Post-reemplazo recomendado
