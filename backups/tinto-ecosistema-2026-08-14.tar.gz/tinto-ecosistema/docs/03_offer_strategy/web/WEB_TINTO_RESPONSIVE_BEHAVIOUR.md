# WEB TINTO - Responsive Behavior

**Estado**: Especificación responsive final  
**Productor**: Claude Code  
**Rama**: `feature/tinto-offer-strategy-v1.0.0`

---

## Breakpoints

| Dispositivo | Ancho mín. | Ancho máx. | Contexto |
|-------------|-----------|-----------|----------|
| Mobile | 320px | 639px | Teléfono, pantalla vertical |
| Tablet | 640px | 1179px | iPad, pantalla horizontal pequeña |
| Desktop | 1180px | ∞ | Monitor, laptop |

---

## Grid layouts por breakpoint

### Desktop (1180px+)

**Hero**:
- Grid 2 columnas: 1.08fr (copy) + 0.92fr (media)
- Gap: 24px
- Padding: 32px

**Home-Átomo**:
- Atom-stage: min-height 480px
- Órbitas visibles, territorios posicionados en órbitas
- Atom-support: 2 columnas (founder-core + touch-cue lado a lado)

**Tablero**:
- Board-layout: 2 columnas (0.8fr preguntas + 1.2fr preview)
- Gap: 18px
- Preguntas list: vertical scroll si necesario

**Diagnosis**:
- 1 columna
- Fieldsets apilados
- Botones navegación en fila

### Tablet (640px - 1179px)

**Hero**:
- Stack vertical (copy arriba, media abajo)
- Padding: 18px
- Gap: 20px

**Home-Átomo**:
- Atom-stage: min-height 700px
- Territorios: Grid stack vertical, centrados
- Atom-core: Posición relativa en grid
- Atom-orbits: Presentes pero más pequeños

**Tablero**:
- Board-layout: 1 columna (preguntas arriba, preview abajo)
- Question-stack: 100% width
- Question-preview: 100% width

**Diagnosis**:
- Igual a desktop (1 columna)

### Mobile (320px - 639px)

**Topbar**:
- Stack vertical
- Align items: flex-start
- Gap: 8px

**Hero**:
- Stack vertical
- H1: `clamp(2.1rem, 11vw, 3.2rem)`
- Media: aspect-ratio 1:1 (cuadrado)
- Padding: 14px

**Home-Átomo**:
- Atom-stage: 100% viewport width, min-height 60vh
- Atom-core: margin-bottom 16px
- Territories: Grid 1 columna, full width, 88vw max
- Atom-orbits: Desaparecen o muy mínimas

**Tablero**:
- Board-header: Stack vertical
- Board-layout: 1 columna
- Badges: Flex wrap

**Founder-core**:
- Grid 1 columna (portrait arriba, content abajo)
- Portrait: 100px width

**Diagnosis**:
- Fieldsets: Padding 14px
- Inputs: 100% width
- Botones: Stack vertical o 100% width

---

## Ajustes de tipografía

### H1 (hero)
```css
font-size: clamp(2.1rem, 11vw, 4.8rem);
```
- Mobile: ~2.1rem
- Tablet: ~2.8rem
- Desktop: ~4.8rem

### H2, H3
```css
font-size: clamp(1.6rem, 3vw, 2.3rem);
```

### Body
```css
font-size: 1.05rem; /* Constante */
line-height: 1.55;
```

---

## Elementos adaptables

### Logo / Brand lockup
- Desktop: 44px
- Tablet: 38px
- Mobile: 32px

### Botones
- Desktop: 44px min-height
- Tablet: 44px min-height
- Mobile: 44px min-height (toque cómodo)

### Padding / Margins
- Desktop: 24px
- Tablet: 18px
- Mobile: 14px

### Radius
- Desktop: 28px (--radius-xl)
- Tablet: 22px (--radius-lg)
- Mobile: 18px (--radius-lg)

---

## Comportamientos específicos

### Atom en mobile
- Territorios: Stack vertical, no órbitas visibles
- Core: Posición relativa (no absoluta)
- Touch pulse: Visible pero menos agresivo
- Halos: Reducidos o desaparecen

### Board en mobile
- Preguntas y preview: Stack vertical
- Question-card: Full width
- Scenario: Puede expandir full screen

### Diagnosis en mobile
- Fieldsets: Uno por "pantalla"
- Step indicator: Progress bar horizontal
- Botones nav: Full width o paired a 50%+50%

### Hero media en mobile
- Aspect ratio: 1:1 (cuadrado) en mobile
- 4:5 (vertical) en tablet/desktop
- Image fill: cover, no distorsión

---

## Scroll behavior

- Vertical scroll permitido siempre
- Horizontal scroll: **Prohibido en cualquier breakpoint**
- Overflow: Auto en contenedores específicos (question-list, scenario content)
- No fixed/sticky excepto loader

---

## Touch targets

Mínimo: 44px × 44px en mobile (WCAG AAA)

Verificar:
- [ ] Botones: 44px+ height
- [ ] Links: 44px+ hit area
- [ ] Checkboxes: 18px+ size
- [ ] Gap entre targets: ≥8px

---

## Validación responsive

Ejecutar en cada breakpoint:

**Mobile (375px × 667px)**:
- [ ] No overflow horizontal
- [ ] Texto legible (14px+)
- [ ] Botones tocables (44px+)
- [ ] Imagen fit dentro viewport
- [ ] Form fields accesibles
- [ ] Navigation funciona

**Tablet (768px × 1024px)**:
- [ ] Layout 2-columnas si aplica
- [ ] Media visible completa
- [ ] Órbitas visibles
- [ ] Territorio nodes posicionados
- [ ] Preguntas y preview lado a lado o stack claro

**Desktop (1920px)**:
- [ ] Content no > 1180px (container max-width)
- [ ] Hero 2-col visible completo
- [ ] Atom con órbitas rotando
- [ ] Board 2-col clara separación
- [ ] Sin scroll horizontal

---

## CSS media queries (orden de especificidad)

```css
/* Base: Mobile first */
.component { /* Mobile styles */ }

/* Tablet */
@media (min-width: 640px) { }

/* Desktop */
@media (min-width: 1180px) { }

/* Reduced motion (cualquier breakpoint) */
@media (prefers-reduced-motion: reduce) { }
```

---

## Performance en mobile

- Animations: Más lentas (~3s en mobile, ~2.2s en desktop)
- Reduced motion: Crítico en mobile
- Image optimization: WEBP con fallback PNG/JPG
- CSS-only effects: Prefiere CSS > JavaScript

---

## Testing checklist

- [ ] 320px: iPhone 12 mini
- [ ] 375px: iPhone 12 / 13
- [ ] 414px: iPhone 12 Pro Max
- [ ] 480px: Algunos Androids
- [ ] 600px: Tablets pequeños
- [ ] 768px: iPad mini
- [ ] 1024px: iPad regular
- [ ] 1366px: Laptop
- [ ] 1920px: Desktop wide

---

## Herramientas de testing

```bash
# Chrome DevTools
- Toggle device toolbar (Cmd+Shift+M)
- Set custom dimensions
- Network throttle para mobile

# Firefox DevTools
- Responsive Design Mode (Cmd+Shift+M)

# Real devices si posible
```

---

## Estado

- Especificación: Completa
- Implementación CSS: En construcción (breakpoints base completos)
- Testing: Pendiente (post-visual)
