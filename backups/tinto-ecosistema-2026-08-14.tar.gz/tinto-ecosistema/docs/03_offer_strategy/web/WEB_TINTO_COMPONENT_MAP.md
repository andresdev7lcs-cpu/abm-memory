# WEB TINTO - Component Map

## Objetivo

Mapear la base funcional del sitio para que Claude Code complete direccion de arte, motion y acabado premium sin rehacer la arquitectura.

## Componentes

### 1. LoaderSplash

- Archivo logico: `components.mjs`
- Funcion: `renderLoader()`
- Entrada: logo, copy, CTA, reduced motion.
- Salida: overlay de entrada breve.
- Estado: visible solo al inicio.

### 2. HeroStage

- Funcion: `renderHero()`
- Entrada: poster, copy, overlay, CTA, media optional.
- Salida: hero provisional funcional.
- Soporta: `webm`, `mp4`, `poster`, imagen estatica.

### 3. FounderCore

- Funcion: `renderFounderCore()`
- Entrada: retrato provisional, avatar provisional, note.
- Salida: bloque de confianza reservado para la fundadora.
- Regla: no inventar experiencia ni credenciales.

### 4. TouchGestureCue

- Funcion: `renderTouchGesture()`
- Entrada: copy y fallback.
- Salida: cue visual de pulso, glow y linea de conexion.
- Punto de integracion: tactilidad del Home-Atom y acceso al tablero.

### 5. HomeAtom

- Funcion: `renderHomeAtom()`
- Entrada: territorios, core, selected territory.
- Salida: nucleo + tres territorios + orbitas + nodos.
- Interaccion: mouse, touch, teclado.

### 6. DigitalBoard

- Funcion: `renderDigitalBoard()`
- Entrada: territorio seleccionado.
- Salida: panel de preguntas sin modal.
- Regla: preserva estado y permite regreso.

### 7. InternalScenario

- Funcion: `renderScenario()`
- Entrada: territorio y pregunta.
- Salida: pregunta, respuesta provisional, recurso, CTA, preguntas relacionadas.

### 8. ProgressiveDiagnosis

- Funcion: `renderDiagnosis()`
- Entrada: territory/question y draft local.
- Salida: wizard en pasos con consentimiento.
- Modo: `local_mock`.

## Relaciones

```text
LoaderSplash -> HeroStage -> HomeAtom -> DigitalBoard -> InternalScenario -> ProgressiveDiagnosis
```

## Reglas de uso

- No hay modal nested.
- No hay hardcode de contenido estrategico dentro de funciones de render.
- Los botones y rutas son reversibles.
- Los datos sensibles no se guardan de forma permanente.

