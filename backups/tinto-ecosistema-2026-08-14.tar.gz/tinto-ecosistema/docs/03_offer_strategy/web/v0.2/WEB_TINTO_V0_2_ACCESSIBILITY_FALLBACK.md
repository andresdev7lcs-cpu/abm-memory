# WEB TINTO v0.2 - Accessibility & Fallback

## 1. Accesibilidad obligatoria

- omitir introduccion;
- pausa;
- reduced motion;
- navegacion por teclado;
- foco visible;
- captions;
- control de audio;
- alternativa a drag;
- alternativa a hover;
- fallback lineal;
- fallback sin media;
- fallback sin JavaScript;
- modo movil;
- no atrapar al usuario en timelines.

## 2. Reglas de interaccion

- cualquier accion importante debe tener boton visible;
- hover nunca debe ser el unico gesto;
- drag siempre necesita alternativa de teclado o click;
- el foco debe ser visible y consistente;
- la salida debe ser inmediata y comprensible.

## 3. Reduced motion

- desactivar loops;
- sustituir movimientos continuos por fades;
- conservar jerarquia de contenido;
- mantener la ruta narrativa sin animacion costosa.

## 4. Fallback lineal

Cuando el dispositivo no soporte la experiencia completa:

```text
curtain -> founder-vsl -> atom-command-center -> halo-selection -> black-transition -> office-intro -> territory-world -> question-layer -> objection-layer -> conversion-layer -> booking
```

Sin perder la logica de escenas, pero en forma convencional.

- `halo-selection` se resuelve como seleccion explicita con boton o lista.
- `black-transition` se reduce a un fade o corte breve.
- `office-intro` se resuelve con poster, texto, caption o video opcional.
- Ninguna de estas escenas se elimina del flujo.
- La accesibilidad simplifica el motion, no elimina el contexto narrativo.

## 5. Fallback sin media

- si no carga video, usar poster o imagen;
- si no hay imagen, usar bloque textual;
- si no hay avatar, usar silueta o placeholder editorial;
- si no hay brazo/mano, usar pulso abstracto;
- si no hay puerta, usar corte negro y copy.

## 6. Fallback sin JavaScript

- home legible;
- territorios accesibles como enlaces;
- preguntas listadas;
- CTA visible;
- contenido completo sin timeline interactivo.

## 7. Modo movil

- mantener targets de 44px o mas;
- evitar precision extrema;
- reducir densidad visual;
- priorizar stack accesible;
- no esconder acciones criticas dentro de hover.

## 8. No atrapamiento

- siempre existir un retorno a la escena anterior;
- siempre existir un skip;
- siempre existir una salida al contenido lineal;
- la experiencia cinematica no puede convertirse en un laberinto.
