# WEB TINTO v0.2 - State Machine

## 1. Estado canónico

```typescript
type SceneId =
  | "curtain"
  | "founder-vsl"
  | "atom-command-center"
  | "halo-selection"
  | "black-transition"
  | "office-intro"
  | "territory-world"
  | "question-layer"
  | "objection-layer"
  | "conversion-layer"
  | "booking";

type SceneState = {
  activeScene: SceneId;
  previousScene?: SceneId;
  pendingScene?: SceneId | null;
  transitionOriginScene?: SceneId | null;
  sceneHistory: SceneId[];
  transitionPhase: "idle" | "entering" | "active" | "exiting";
  interactionLocked: boolean;
  paused: boolean;
  reducedMotion: boolean;
  performanceMode: "cinematic" | "balanced" | "reduced";
  mediaReady: boolean;
  activeTerritoryId?: string | null;
  activeQuestionId?: string | null;
};
```

## 2. Reglas

- `interactionLocked` se activa durante `entering` y `exiting`;
- el historial conserva navegación reversible;
- `abort` vuelve al origen de transición;
- `pause` detiene timers auto y bloquea interacciones;
- `resume` reanuda autoadvance si la escena lo permite;
- `reducedMotion` conserva contenido completo;
- `mediaReady` refleja que la escena ya puede mostrarse sin ruptura.

## 3. Secuencia canónica

```text
curtain
→ founder-vsl
→ atom-command-center
→ halo-selection
→ black-transition
→ office-intro
→ territory-world
→ question-layer
→ objection-layer
→ conversion-layer
→ booking
```

## 4. Navegación de regreso

La navegación de regreso debe conservar el puente narrativo:

```text
territory-world
→ office-intro
→ black-transition
→ halo-selection
→ atom-command-center
```

## 5. Eventos por escena

### curtain

- `intro_started`

### founder-vsl

- `intro_completed`

### atom-command-center

- `atom_viewed`
- `territory_hovered`
- `territory_selected`

### halo-selection

- `halo_interaction_started`
- `halo_contact_completed`

### black-transition

- `black_transition_started`
- `black_transition_completed`

### office-intro

- `office_intro_started`
- `office_intro_completed`

### territory-world

- `territory_world_entered`

### question-layer

- `question_opened`

### objection-layer

- `objection_viewed`

### conversion-layer

- `cta_revealed`

### booking

- `booking_started`
- `booking_completed`

## 6. Estado de territorio y pregunta

- `activeTerritoryId` conserva la hipótesis activa;
- `activeQuestionId` conserva la pregunta dentro del territorio;
- `question-layer`, `objection-layer`, `conversion-layer` y `booking` trabajan con ese contexto;
- `atom-command-center` puede seleccionar territorio sin perder el contexto;
- `territory-world` no duplica arquitectura por territorio.

## 7. Abort y reanudación

- `startTransition`: fija el origen y activa bloqueo;
- `finishExit`: confirma el destino y mueve la escena a `entering`;
- `finishEnter`: libera la interacción si no hay pausa;
- `abortTransition`: vuelve al origen de transición;
- `goBack`: utiliza historial o fallback de orden canónico.

## 8. Deep links

Rutas soportadas:

- `#/scene/<sceneId>`
- `#/scene/<sceneId>/<territoryId>/<questionId>`
- `#/territorio/<territoryId>`
- `#/territorio/<territoryId>/pregunta/<questionId>`
- `#/diagnostico/<territoryId>/pregunta/<questionId>`

## 9. Condiciones de aceptación

- no hay callejones sin salida;
- no hay doble interacción;
- los estados y eventos no se contradicen;
- `territory-world` regresa a `office-intro`;
- el flujo accesible conserva el puente narrativo;
- `booking` es mock local y no produce persistencia real.

