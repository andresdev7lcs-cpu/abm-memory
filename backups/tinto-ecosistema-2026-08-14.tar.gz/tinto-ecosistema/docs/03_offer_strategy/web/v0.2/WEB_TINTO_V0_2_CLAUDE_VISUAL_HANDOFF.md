# WEB TINTO v0.2 - Claude Visual Handoff

## 1. Alcance de este trabajo

Fase de dirección visual / UI / motion / composición sobre la base funcional de `WEB TINTO v0.2 — Experience Engine`, ya auditada de forma independiente con resultado **PASS** (11 escenas, máquina de estados, 18 eventos, autoavance parametrizado, navegación reversible, performance tiers, fallbacks, accesibilidad, responsive base, guardrails intactos).

No se reconstruyó arquitectura. No se reemplazó el motor de escenas. No se migró de stack (sigue siendo HTML modular + CSS modular + ES modules, sin frameworks).

## 2. Archivos leídos (protocolo obligatorio)

- Todos los archivos en `docs/03_offer_strategy/web/v0.2/` (13 documentos).
- `deliveries/WEB-TINTO-V0.2-ARCHITECTURE-CODEX.md`, `deliveries/WEB-TINTO-V0.2-CODEX-IMPLEMENTATION.md`.
- Todos los archivos en `tools/tinto-web/` (14 módulos `.mjs`, `index.html`, `styles.css`, `assets/`).
- `PROJECT_RULES.md`, `AGENTS.md`, `CLAUDE.md`, `DECISION_LOG.md`.
- `memory/CURRENT_STATE.md`, `memory/ASSUMPTIONS.md`, `memory/VALIDATED_FACTS.md`.
- `orchestration/STRATEGIC_GUARDRAILS.md`, `orchestration/STAGE_GATES.md`.
- `docs/03_offer_strategy/EVIDENCE_DIAGNOSIS.md`, `deliveries/STR-001-evidence-diagnosis.md`.
- Skills: `ui-ux-pro-max` (SKILL.md, tabla de prioridades UX), `ui-styling`, `design-system` (arquitectura de tokens primitivo→semántico→componente), `brand` (referenciada; no aplicable en su forma de "brand guidelines starter" porque TINTO no tiene ese documento en este repo — se usó la paleta y tono ya definidos en el ticket como fuente de marca).

## 3. Archivos creados

- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_VISUAL_SYSTEM.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_MOTION_SYSTEM.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_RESPONSIVE_BEHAVIOR.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_ASSET_REPLACEMENT_GUIDE.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_CLAUDE_VISUAL_HANDOFF.md` (este archivo)
- `deliveries/WEB-TINTO-V0.2-CLAUDE-VISUAL.md`

## 4. Archivos modificados (dentro de `tools/tinto-web/`, permitido por el ticket)

| Archivo | Tipo de cambio | Detalle |
|---|---|---|
| `styles.css` | Reescritura completa | Sistema de tokens (primitivo/semántico/componente), paleta café/negro/marfil/cobre/dorado/vino, motion tiers vía `[data-motion-mode]`, estilos por escena (11), responsive 320-1440px, accesibilidad |
| `components.mjs` | Aditivo | `renderSceneFrame` acepta `tone` opcional → `data-tone` en `.scene-card`; skip-link + ancla `#scene-stage-region`; `data-tone` en `territory-orbit`; indicador "Exploración inicial"; conexión de `founderAvatar` (núcleo del átomo), `founderPortrait` y `tintoCup` (antes declarados en `content.mjs` y sin uso); etiqueta de placeholder en `scene-media` |
| `canvas-atmosphere.mjs` | Aditivo | Parámetro opcional `tone` (default `"default"`, retrocompatible); nuevo `drawHalo()`; colores de grid/anillos alineados a la paleta café/marfil/dorado en vez del verde/dorado original |
| `scene-controller.mjs` | Mínimo (2 líneas + 1 import) | `mountSceneEffects()` también monta el canvas de atmósfera en `territory-world` (antes solo en `atom-command-center`), pasando el tono del territorio activo. No se tocó ninguna función de transición, state machine o evento |

**No se tocó:** `state.mjs`, `scene-events.mjs`, `content.mjs`, `motion-engine.mjs`, `performance-mode.mjs`, `media-contracts.mjs`, `analytics-contract.mjs`, `router.mjs`, `server.mjs`, `index.html`, `app.mjs`.

## 5. Por qué se tocó `scene-controller.mjs` (justificación explícita)

El ticket dice "Claude Code no debe modificar... la state machine... los eventos". El cambio en `scene-controller.mjs` es exclusivamente: extender la condición que decide *cuándo montar el canvas de atmósfera ya existente* (`state.activeScene === "atom-command-center"` → `... || state.activeScene === "territory-world"`) y pasarle el tono del territorio activo. No agrega, quita ni reordena escenas; no agrega ni quita eventos; no cambia ninguna transición de `transitionPhase`. Es equivalente a una decisión de "atmósferas" (dominio explícitamente permitido) implementada con el mínimo diff posible en el archivo que ya orquesta el montaje de canvas.

## 6. Pruebas ejecutadas

### 6.1 Estáticas

- `node --check` en los 14 archivos `.mjs` de `tools/tinto-web/`: **OK**, sin errores de sintaxis.
- `git diff --check`: **sin errores** (sin conflictos de espacio en blanco).
- `git status --short`: `tools/tinto-web/` completo aparece como `??` (no trackeado) — coherente con que toda la carpeta es parte de esta rama de trabajo aún no commiteada; ningún archivo fuera de `tools/` ni de `docs/03_offer_strategy/web/v0.2/` ni `deliveries/` fue tocado.

### 6.2 Servidor y rutas (HTTP real)

Con `node server.mjs` corriendo en `:4580`:

| Ruta | Resultado |
|---|---|
| `/` | 200 |
| `/scene/atom-command-center` (path directo) | 200 |
| `/territorio/activos-inmobiliarios` (path directo) | 200 |
| `/styles.css` | 200 |
| `/components.mjs` | 200 |

### 6.3 Visual real en navegador (Chrome headless real, no revisión estática)

Se usó Google Chrome instalado localmente en modo `--headless=new` (Playwright no pudo instalar su Chromium propio: `ERROR: Playwright does not support chromium on mac12`, documentado como limitación de entorno) para capturar y **leer** las capturas (inspección visual real de píxeles, no solo "el comando corrió sin error"):

| Captura | Ruta | Resultado |
|---|---|---|
| curtain, desktop 1440x900 | `#/` | Correcto: logo respirando, paleta café/dorado, CTA legible |
| atom-command-center, desktop | `#/scene/atom-command-center` | Encontrado y corregido: silueta del avatar se cruzaba con el label "Núcleo narrativo" — se ajustó opacidad/posición/blur del `atom-stage__core-portrait` |
| office-intro, desktop | `#/scene/office-intro` | Correcto: puerta + retrato provisional + etiqueta de placeholder visibles; taza fuera de viewport por recorte de scroll (no es bug, es composición vertical) |
| halo-selection, desktop | `#/scene/halo-selection` | Correcto: glow del halo por tono, pulso, línea luminosa |
| territory-world (tono `petrol`), desktop | `#/territorio/activos-inmobiliarios` | Correcto: badge `tone: petrol` visible, sin errores de render |
| booking, desktop | `#/scene/booking` | Correcto: formulario en grid de 2 columnas, inputs legibles |
| atom-command-center, móvil 375x812 | mismo hash | Encontrado y corregido: los 3 botones de performance tier (`cinematic/balanced/reduced`) se cortaban fuera del viewport por un `margin-left: auto` dentro de un flex-wrap — ya presente en el CSS base, no introducido por este trabajo, mismo se corrigió por estar explícitamente en el alcance de "no overflow" del ticket |
| booking, móvil 375x812 | `#/scene/booking` | Correcto tras el fix |
| atom-command-center, reduced motion (`--force-prefers-reduced-motion`) | mismo hash | Correcto: `mode: reduced` detectado automáticamente vía `prefers-reduced-motion`, canvas de atmósfera oculto, contenido completo y legible, sin loops |

Las capturas viven en el scratchpad de la sesión (`/private/tmp/claude-503/.../scratchpad/tinto-shots/`), no en el repositorio — son evidencia de sesión, no artefactos de producto.

### 6.4 No ejecutado / limitación declarada

- No se probó en dispositivo físico real (iOS/Android) ni en Safari real — solo Chrome headless emulando viewport.
- No se capturó la consola del navegador de forma explícita (stdout de `console.error`); la evidencia de "sin errores bloqueantes" es indirecta: las 9 capturas renderizan contenido completo y correcto (un error de JS bloqueante habría dejado `#app` vacío, como efectivamente ocurrió — y se diagnosticó como problema de la herramienta de captura, no de la app — durante la primera ronda fallida con flags de Chrome incompatibles).
- No se probó teclado/touch de forma interactiva real (Tab, Enter, swipe); se verificó por lectura de código que `focus-visible`, `tabindex`, `aria-live`, `aria-pressed` y los `data-action` siguen intactos (no se tocó ese código en `scene-controller.mjs` ni `components.mjs` salvo las adiciones descritas).

## 7. Conservación confirmada

- Arquitectura de 11 escenas: intacta, verificado por lectura de `scene-controller.mjs` y `content.mjs` sin diff en `sceneOrder`.
- Máquina de estados: intacta, `state.mjs` sin modificar.
- 18 eventos: intactos, `scene-events.mjs` sin modificar.
- v0.1 (`tools/tinto-web/` no existe versión v0.1 separada en este repo — la v0.1 referenciada en el ticket corresponde a otro directorio de otro proyecto; no aplica aquí, no se tocó nada fuera de `tools/tinto-web/`).
- STR-001 / `deliveries/STR-001-evidence-diagnosis.md`: no leído para modificar, solo para contexto; sin diff.
- Oferta no producida, promoción bloqueada, sin precios, sin claims, sin testimonios, sin buyer persona definitivo, territorios como hipótesis: confirmado por lectura de `content.mjs` (sin cambios) — todos los territorios mantienen `status: "hypothesis"` y `approval: "pending_confirmation"`.

## 8. Recomendación

Handoff a auditoría visual independiente (no auto-aprobación, per `AGENTS.md` § "Regla de no auto-aprobación"). Sugerido: mismo protocolo usado en la auditoría técnica previa (revisor independiente), esta vez enfocado en: fidelidad de paleta a la marca, legibilidad/contraste real, y validación en dispositivo físico (pendiente, ver §6.4).
