# WEB TINTO v0.2 - Asset Contracts

## 1. Principio

Todos los assets son locales, provisionales y reemplazables sin cambiar la arquitectura.

## 2. Assets base

### Logo

- `tools/tinto-web/assets/logo-mark.svg`
- Uso: identidad, topbar, primer contacto visual.

### VSL poster

- `tools/tinto-web/assets/founder-vsl-poster.svg`
- Uso: `founder-vsl`.
- Estado: provisional.

### Retrato de la fundadora

- `tools/tinto-web/assets/founder-portrait.svg`
- Uso: `office-intro`, `founder-vsl` y núcleo de confianza.
- Estado: provisional.

### Avatar de la fundadora

- `tools/tinto-web/assets/founder-avatar.svg`
- Uso: apoyo editorial y núcleo.
- Estado: provisional.

### Brazo y mano

- `tools/tinto-web/assets/halo-hand.svg`
- Uso: `halo-selection`.
- Estado: fallback visual provisional.

### Puerta de cristal

- `tools/tinto-web/assets/glass-door.svg`
- Uso: `office-intro`.
- Estado: puente narrativo provisional.

### Taza TINTO

- `tools/tinto-web/assets/tinto-cup.svg`
- Uso: refuerzo narrativo del mundo.
- Estado: simbólico, no producto final.

## 3. Contrato de media por escena

### curtain

- poster/image: `logo-mark.svg`
- fallback: logo estático

### founder-vsl

- poster/image: `founder-vsl-poster.svg`
- webm/mp4 futuro: soportado en contrato
- captions: previstos

### atom-command-center

- media principal: canvas 2D + DOM
- fallback: CSS y botones accesibles

### halo-selection

- media principal: `halo-hand.svg`
- fallback: línea luminosa, pulso y contacto visual

### black-transition

- media principal: pantalla negra / fade
- fallback: corte simple

### office-intro

- media principal: `glass-door.svg`
- soporte adicional: `tinto-cup.svg`, retrato y captions

### territory-world

- media principal: tema por territorio
- fallback: tarjeta editorial

### question-layer

- media principal: cards y copy
- fallback: lista lineal

### objection-layer

- media principal: copy y contexto
- fallback: accordion textual

### conversion-layer

- media principal: CTA y síntesis
- fallback: botón visible permanente

### booking

- media principal: formulario local
- fallback: formulario simple sin persistencia

## 4. Reglas de reemplazo

- no usar activos remotos;
- no inventar media final como si fuera evidencia real;
- no depender de un solo formato;
- cada asset debe poder caer a poster, imagen, vector simple o bloque textual;
- mobile variants siguen el mismo contrato.

## 5. Campos de contrato

Todo asset debe poder describirse con:

- `id`
- `type`
- `path`
- `poster`
- `fallback`
- `mobileVariant`
- `captions`
- `status`

