# WEB TINTO v0.2 - Experience Engine

**Estado**: documentación canónica para auditoria independiente  
**Rama**: `feature/tinto-offer-strategy-v1.0.0`  
**Stack aprobado**: HTML/CSS/JavaScript modular  
**Nivel de experiencia**: cinematic  
**Territorios**: `hypothesis`  
**Promocion**: blocked  
**Oferta comercial**: not produced

## 1. Vision

WEB TINTO v0.2 no debe sentirse como una landing page. Debe comportarse como un motor narrativo por escenas, con una secuencia de entrada, descubrimiento, confianza, objeciones y conversion.

La experiencia no vende por acumulacion de secciones. Vende por progresion:

```text
sorpresa -> curiosidad -> descubrimiento -> educacion -> identificacion -> reduccion de objeciones -> intencion -> agendamiento
```

## 2. Diferencia entre pagina y motor de escenas

### Pagina

- estructura vertical o apilada;
- lectura lineal;
- experiencia estatica;
- CTA visible al final o repetido;
- movimiento accesorio.

### Motor de escenas

- secuencia de estados explicitos;
- transiciones con inicio, permanencia y salida;
- reversibilidad;
- control de tiempo y bloqueo de interaccion;
- media y motion desacoplados del contenido;
- fallback por capacidades.

La unidad correcta no es una pagina larga. La unidad correcta es una escena con estado.

## 3. Secuencia narrativa

```text
Telon de entrada
-> logo vivo
-> apertura del telon
-> mini VSL de la fundadora
-> elevator pitch de 3-4 segundos
-> aparicion del Home-Atom
-> seleccion de halo
-> movimiento fisico del avatar
-> mano toca el halo
-> corte a negro
-> microvideo de transicion
-> fundadora abre puerta de cristal
-> invita a tomar un TINTO
-> nuevo escenario
-> preguntas persuasivas
-> capas educativas
-> objeciones
-> contenido progresivo
-> CTA agendar cita
```

## 4. Funnel dentro de la experiencia

El funnel no va al final. Vive dentro del recorrido.

```text
curiosidad -> educacion -> objecion -> relevancia -> decision -> conversion
```

Cada capa debe poder regresar a la anterior sin perder contexto.

## 5. Principios

- narrativa;
- impredecible;
- fluida;
- espacial;
- interactiva;
- cinematografica;
- persuasiva;
- no convencional;
- reversible;
- accesible;
- adaptable a movil.

## 6. Performance tiers

### cinematic

- motion completo;
- microinteracciones;
- fondos fluidos;
- ondas;
- halos;
- blur controlado;
- videos breves;
- transiciones con continuidad espacial.

### balanced

- menos blur;
- menos loops;
- videos limitados;
- transiciones simplificadas;
- misma arquitectura, menos densidad visual.

### reduced

- sin movimiento continuo;
- fades simples;
- navegacion convencional;
- contenido completo;
- accesibilidad prioritaria.

## 7. Limites

- No inventar oferta final.
- No inventar credenciales ni testimonios.
- No presentar territorios como servicios aprobados.
- No depender solo de hashes o cambios instantaneos de vista.
- No atrapar al usuario en timelines.
- No ocultar la salida ni el retroceso.

## 8. Criterios de aceptacion

- La experiencia se entiende como secuencia de escenas y no como landing vertical.
- Existe control explicito de escenas, transiciones y fallback.
- El Home-Atom funciona como command center.
- La seleccion de halo cambia de escena.
- La puerta de cristal ocurre despues de la seleccion de halo.
- Reduced motion conserva todo el contenido.
- La arquitectura permite reversibilidad completa.
- La oferta comercial definitiva sigue sin producirse.
- Promocion permanece bloqueada.

