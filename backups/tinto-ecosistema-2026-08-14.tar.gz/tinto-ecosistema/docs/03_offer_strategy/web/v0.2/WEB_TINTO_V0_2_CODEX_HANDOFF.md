# WEB TINTO v0.2 - Codex Handoff

## 1. Arquitectura aprobada

- motor de escenas explicito;
- stack canonicamente modular HTML/CSS/JavaScript;
- contenido desacoplado del render;
- territorios como hipotesis;
- promotion_status: blocked;
- commercial_offer_status: not_produced.

## 2. Stack

- HTML/CSS/JavaScript modular;
- no migracion obligatoria en v0.2;
- no dependencias nuevas para la fase de documentacion;
- media local y contratos reemplazables.

## 3. Scene state

Usar y respetar:

```typescript
type SceneId =
  | "curtain"
  | "founder-vsl"
  | "atom-command-center"
  | "halo-selection"
  | "black-transition"
  | "office-intro"
  | "territory-world"
  | "question-layer"
  | "objection-layer"
  | "conversion-layer"
  | "booking";

type SceneState = {
  activeScene: SceneId;
  activeTerritoryId?: string;
  activeQuestionId?: string;
  previousScene?: SceneId;
  transitionPhase:
    | "idle"
    | "entering"
    | "active"
    | "exiting";
  interactionLocked: boolean;
  reducedMotion: boolean;
  mediaReady: boolean;
};
```

## 4. Event contracts

```text
intro_started
intro_completed
intro_skipped
atom_viewed
territory_hovered
territory_selected
territory_intro_completed
question_opened
objection_viewed
cta_revealed
booking_started
booking_completed
```

No conectar analytics todavia.

## 5. Media contracts

- logo;
- mini VSL;
- retrato;
- avatar;
- brazo y mano;
- puerta de cristal;
- taza TINTO;
- audio;
- captions;
- posters;
- mobile variants;
- transparent media;
- fallbacks.

## 6. Motion modes

- cinematic;
- balanced;
- reduced.

## 7. Archivos autorizados

En la fase siguiente Claude Code puede tocar:

- `tools/tinto-web/styles.css`
- `tools/tinto-web/app.mjs`
- `tools/tinto-web/components.mjs`
- `tools/tinto-web/state.mjs`
- `tools/tinto-web/router.mjs`
- `tools/tinto-web/content.mjs`
- `tools/tinto-web/index.html`
- `tools/tinto-web/assets/*`
- `docs/03_offer_strategy/web/v0.2/*`

## 8. Limites para Claude Code

- no inventar oferta;
- no inventar credenciales;
- no inventar territorios nuevos;
- no romper la separacion contenido/render;
- no cambiar la direccion de la experiencia a landing tradicional;
- no introducir dependencias innecesarias;
- no eliminar reversibilidad.

## 9. Skills a usar

### ui-ux-pro-max

- usarlo para recomendar composicion, jerarquia, motion budget, responsive behavior y accesibilidad;
- no usarlo como productor visual final;
- no usarlo para inventar contenido o oferta.

### ui-styling

- usarlo para tokens, componentes y consistencia visual;
- traducir la arquitectura aprobada a estilo implementable.

### design-system

- usarlo para tokens, estados y reglas de sistema;
- mantener claridad entre primitive, semantic y component tokens.

### brand

- usarlo para consistencia de tono y uso de activos;
- respetar la voz aprobada y los limites de marca.

## 10. Condiciones de inicio

- documentos v0.2 creados;
- delivery formal creado;
- auditoria independiente posible;
- no cambios en prototipo v0.1;
- no promociones;
- no oferta comercial final.

## 11. Criterios de salida

- scene architecture documentada;
- motion architecture documentada;
- media pipeline documentada;
- content funnel documentado;
- accessibility fallback documentado;
- migration plan documentado;
- handoff listo para Claude Code.

## 12. Lo que Claude Code no debe inventar

- oferta final;
- claims;
- precios;
- promesas de conversion;
- territorios aprobados;
- testimonios reales;
- media final que no exista;
- objetivos de promocion.

