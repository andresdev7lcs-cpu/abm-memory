# WEB TINTO v0.2 - Scene Architecture

## 1. State machine canonica

```typescript
type SceneId =
  | "curtain"
  | "founder-vsl"
  | "atom-command-center"
  | "halo-selection"
  | "black-transition"
  | "office-intro"
  | "territory-world"
  | "question-layer"
  | "objection-layer"
  | "conversion-layer"
  | "booking";

type SceneState = {
  activeScene: SceneId;
  activeTerritoryId?: string;
  activeQuestionId?: string;
  previousScene?: SceneId;
  transitionPhase:
    | "idle"
    | "entering"
    | "active"
    | "exiting";
  interactionLocked: boolean;
  reducedMotion: boolean;
  mediaReady: boolean;
};
```

## 2. Reglas comunes de escena

- cada escena tiene objetivo, entrada, permanencia, salida, evento, media y fallback;
- la transicion siempre conoce su escena anterior;
- la interaccion se bloquea mientras corre una transicion critica;
- el usuario puede volver si la escena no esta en `interactionLocked`;
- reduced motion sustituye motion por fades y navegacion convencional.

## 3. Escenas

### curtain

- Objetivo: abrir el telon y preparar la llegada de la fundadora.
- Entrada: logo vivo, respiracion visual, opacidad baja.
- Estado activo: identidad, expectativa, foco.
- Salida: apertura del telon.
- Eventos: `intro_started`.
- Media: logo animado, fondo atmosferico.
- Fallback: fade simple.
- Reduced motion: sin respiracion, solo aparicion.
- Regreso: vuelve al inicio.

### founder-vsl

- Objetivo: mini VSL y elevator pitch.
- Entrada: telon abierto, fundadora en cuadro.
- Estado activo: atencion, mensaje breve, autoridad.
- Salida: disolucion hacia el átomo.
- Eventos: `intro_completed`.
- Media: video breve, poster, captions.
- Fallback: imagen + copy.
- Reduced motion: bloque editorial estatico.
- Regreso: vuelve a `curtain`.

### atom-command-center

- Objetivo: exponer el Home-Atom como interfaz principal.
- Entrada: aparicion del nucleo.
- Estado activo: exploracion de territorios.
- Salida: seleccion de halo.
- Eventos: `atom_viewed`, `territory_hovered`, `territory_selected`.
- Media: dotted surface, halos, avatares, overlays.
- Fallback: grid accesible de territorios.
- Reduced motion: core estatica, halos sin rotacion.
- Regreso: vuelve a `founder-vsl`.

### Event contracts by scene

- `atom-command-center`: `atom_viewed`, `territory_hovered`, `territory_selected`
- `halo-selection`: `halo_interaction_started`, `halo_contact_completed`
- `black-transition`: `black_transition_started`, `black_transition_completed`
- `office-intro`: `office_intro_started`, `office_intro_completed`
- `territory-world`: `territory_world_entered`
- `question-layer`: `question_opened`
- `objection-layer`: `objection_viewed`
- `conversion-layer`: `cta_revealed`
- `booking`: `booking_started`, `booking_completed`

### halo-selection

- Objetivo: convertir la eleccion del halo en acto narrativo.
- Entrada: hover/focus/touch sobre territorio.
- Estado activo: reconocimiento, respuesta del avatar.
- Salida: mano toca el nodo.
- Eventos: `halo_interaction_started`, `halo_contact_completed`.
- Media: gesto del brazo/mano, pulso, highlight.
- Fallback: pulso abstracto y boton visible.
- Reduced motion: sin tracking, solo confirmacion visual.
- Regreso: vuelve a `office-intro`.

### black-transition

- Objetivo: separar escenas con corte narrativo.
- Entrada: contacto confirmado.
- Estado activo: apagado temporal.
- Salida: blackout breve.
- Eventos: `black_transition_started`, `black_transition_completed`.
- Media: pantalla negra, audio futuro opcional.
- Fallback: crossfade oscuro.
- Reduced motion: fade corto.
- Regreso: vuelve a la escena anterior.

### office-intro

- Objetivo: abrir la puerta de cristal e invitar a entrar.
- Entrada: blackout + microvideo de puerta.
- Estado activo: bienvenida, contexto, entrada al mundo.
- Salida: transicion al territorio.
- Eventos: `office_intro_started`, `office_intro_completed`.
- Media: puerta de cristal, retrato, ambiente.
- Fallback: imagen + copy.
- Reduced motion: entrada editorial simple.
- Regreso: vuelve a `black-transition`.

### territory-world

- Objetivo: establecer el mundo del territorio.
- Entrada: titulo contextual y atmosfera del territorio.
- Estado activo: mundo tematico.
- Salida: apertura de preguntas.
- Eventos: `territory_world_entered`.
- Media: intro media, atmosphere config.
- Fallback: tarjeta de territorio + notas.
- Reduced motion: layout convencional.
- Regreso: vuelve a `office-intro`.

### question-layer

- Objetivo: desplegar preguntas persuasivas.
- Entrada: territorio activo.
- Estado activo: curiosidad y relevancia.
- Salida: apertura de objeciones o recurso.
- Eventos: `question_opened`.
- Media: cards, preguntas, recursos.
- Fallback: lista lineal de preguntas.
- Reduced motion: stack accesible.
- Regreso: vuelve a `territory-world`.

### objection-layer

- Objetivo: reducir objeciones sin inventar oferta.
- Entrada: pregunta seleccionada.
- Estado activo: claridad y contraste.
- Salida: consolidacion de intencion.
- Eventos: `objection_viewed`.
- Media: proof elements, microcopy, recursos.
- Fallback: accordion convencional.
- Reduced motion: bloque textual.
- Regreso: vuelve a `question-layer`.

### conversion-layer

- Objetivo: convertir intencion en llamada a agendamiento.
- Entrada: objecion resuelta.
- Estado activo: decision y CTA.
- Salida: booking.
- Eventos: `cta_revealed`.
- Media: resumen, CTA, prueba de continuidad.
- Fallback: boton visible permanente.
- Reduced motion: CTA editorial.
- Regreso: vuelve a `objection-layer`.

### booking

- Objetivo: agendamiento o registro de interes.
- Entrada: CTA activo.
- Estado activo: confirmacion de siguiente paso.
- Salida: fin del flujo o retorno.
- Eventos: `booking_started`, `booking_completed`.
- Media: formulario, confirmacion, resumen.
- Fallback: contacto simple.
- Reduced motion: formulario convencional.
- Regreso: vuelve a `conversion-layer`.

## 4. Navegacion de regreso

- curtain <- founder-vsl
- founder-vsl <- atom-command-center
- atom-command-center <- halo-selection
- halo-selection <- black-transition
- black-transition <- office-intro
- office-intro <- territory-world
- territory-world <- question-layer
- question-layer <- objection-layer
- objection-layer <- conversion-layer
- conversion-layer <- booking

## 5. Eventos por escena

- `intro_started`
- `intro_completed`
- `intro_skipped`
- `atom_viewed`
- `territory_hovered`
- `territory_selected`
- `halo_interaction_started`
- `halo_contact_completed`
- `black_transition_started`
- `black_transition_completed`
- `office_intro_started`
- `office_intro_completed`
- `territory_world_entered`
- `question_opened`
- `objection_viewed`
- `cta_revealed`
- `booking_started`
- `booking_completed`
