# WEB TINTO v0.2 - Event Contracts

## 1. Objetivo

Contrato canónico de eventos locales para el motor de escenas. No conecta analytics real.

## 2. Catálogo canónico

```text
intro_started
intro_completed
intro_skipped
atom_viewed
territory_hovered
territory_selected
halo_interaction_started
halo_contact_completed
black_transition_started
black_transition_completed
office_intro_started
office_intro_completed
territory_world_entered
question_opened
objection_viewed
cta_revealed
booking_started
booking_completed
```

## 3. Emisión por escena

### curtain

- `intro_started`

### founder-vsl

- `intro_completed`

### atom-command-center

- `atom_viewed`
- `territory_hovered`
- `territory_selected`

### halo-selection

- `halo_interaction_started`
- `halo_contact_completed`

### black-transition

- `black_transition_started`
- `black_transition_completed`

### office-intro

- `office_intro_started`
- `office_intro_completed`

### territory-world

- `territory_world_entered`

### question-layer

- `question_opened`

### objection-layer

- `objection_viewed`

### conversion-layer

- `cta_revealed`

### booking

- `booking_started`
- `booking_completed`

## 4. Reglas

- los eventos se guardan en `state.eventLog`;
- el log es local y recortado a un máximo práctico;
- no hay proveedor de analytics conectado;
- los eventos no deben reutilizarse para dos etapas distintas con el mismo significado;
- `territory_selected` sólo describe la selección inicial del territorio;
- `office-intro` nunca emite `territory_hovered`;
- `black-transition` y `office-intro` separan inicio y fin para conservar lectura narrativa.

## 5. Payload mínimo sugerido

- `territoryId`
- `questionId`
- `sceneId`
- `mode`
- `trigger`

## 6. Uso

Los eventos alimentan:

- `eventLog` visible en UI;
- depuración local;
- validación de la secuencia canónica;
- handoff para analytics futuro.

