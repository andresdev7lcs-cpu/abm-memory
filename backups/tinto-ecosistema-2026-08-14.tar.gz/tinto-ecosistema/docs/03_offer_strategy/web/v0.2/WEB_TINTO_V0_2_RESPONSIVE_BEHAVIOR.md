# WEB TINTO v0.2 - Responsive Behavior (visual)

## 1. Breakpoints implementados

| Breakpoint | Uso |
|---|---|
| Base (320-374px) | Layout de una columna, scene-rail y control-rail con scroll/wrap horizontal controlado |
| 375px | `scene-card__header h1` gana `max-width: 17ch` (evita títulos demasiado angostos) |
| 480px (max-width) | `territory-orbit` pasa a `min(78vw, 260px)`; `office-composition__cup` y `__portrait` se ocultan (evitan amontonarse sobre la puerta en pantallas muy chicas) |
| 640px (max-width) | `.control-mode` (cinematic/balanced/reduced) pasa a ancho completo, sin `margin-left:auto` — evita que los 3 botones de performance se corten fuera del viewport |
| 760px (min-width) | `.site-chrome` pasa a 2 columnas; `.scene-grid--split` pasa a 2 columnas; `.booking-grid` a 2 columnas |
| 1024px (min-width) | `.atom-stage` gana altura mínima 500px (más espacio para los 3 halos de territorio) |
| 1100px (min-width) | Padding de `.scene-card` aumenta a 26px; `.event-feed` se alinea a la derecha con ancho máximo |
| 1180px (min-width) | Ajuste de padding superior del frame |
| 1440px (min-width) | `.site-frame` amplía a `min(1360px, 100vw-32px)` |
| Landscape móvil (max-height 480px) | `.atom-stage` reduce a 320px de alto, `.scene-card` reduce padding — prioriza que el CTA quede visible sin scroll excesivo |

## 2. Reglas anti-overflow

- `html, body { overflow-x: hidden; }` como red de seguridad global (ninguna capa de atmósfera, halo o glow puede generar scroll horizontal accidental).
- `.scene-rail` usa `overflow-x: auto` deliberado (rail de escenas es horizontal por diseño, con `scrollbar-width: thin`).
- `.territory-orbit` usa `width: min(...)` en vez de valores fijos en px para no romper en pantallas angostas.
- Ningún texto usa unidades fijas menores a las que produce el `clamp()` de `h1`; el cuerpo se mantiene en 16px base con `line-height: 1.5`.

## 3. Bug real encontrado y corregido durante validación

Al capturar la escena `atom-command-center` en 375x812 (Chrome headless real, ver handoff), `.control-mode` (los 3 botones de performance tier) se cortaban fuera del viewport: `margin-left: auto` dentro de un contenedor `flex-wrap: wrap` fuerza a Chrome a calcular el ancho por `max-content` antes de decidir el wrap, y el grupo completo terminaba empujado más allá del borde derecho. Este comportamiento ya existía en el CSS base (no es una regresión introducida por este trabajo), pero como el ticket pide explícitamente "no overflow" en 320-1440px, se corrigió con:

```css
@media (max-width: 640px) {
  .control-mode {
    margin-left: 0;
    width: 100%;
    justify-content: flex-start;
  }
}
```

Verificado con screenshot antes/después (ver handoff).

## 4. Mobile — prioridades

- El átomo (`atom-stage`) nunca se comprime a un tamaño ilegible: `clamp(160px, 26vw, 232px)` en el núcleo, halos con ancho mínimo garantizado (`min(78vw, 260px)` bajo 480px).
- Touch targets: todos los botones/controles mantienen `min-height: 44px` (ya presente en la base, preservado).
- La taza y el retrato secundario en `office-intro` se ocultan bajo 480px para no competir visualmente con la puerta (elemento principal) en pantallas angostas — no se pierde narrativa, solo densidad decorativa.
- El formulario de `booking` es una columna en móvil, dos en `min-width: 760px`.

## 5. No verificado con dispositivo físico

Esta validación se hizo con Chrome headless en macOS emulando viewports (375x812, 1440x900). No se probó en un dispositivo iOS/Android real ni en Safari real. Se recomienda una pasada manual en dispositivo antes de considerar el responsive "cerrado" para producción.
