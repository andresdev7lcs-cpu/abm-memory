# WEB TINTO v0.2 - Media Pipeline

## 1. Contratos de media

La arquitectura acepta media reemplazable sin cambiar el sistema de escenas.

### Logo

- Formatos: SVG, PNG.
- Uso: loader, marca, estado inicial.
- Reglas: legible, sin detalles microscópicos.

### Mini VSL

- Formatos: WebM, MP4, poster WebP o AVIF.
- Uso: `founder-vsl`.
- Reglas: breve, con captions.

### Retrato

- Formatos: WebP, AVIF, PNG, JPG.
- Uso: `office-intro`, `territory-world`, founder core.
- Reglas: retrato real si existe, sinonimo visual si no.

### Avatar

- Formatos: SVG, PNG, WebP, secuencia o canvas si aplica.
- Uso: gesto, reconocimiento, nucleus support.
- Reglas: no inventar una identidad que parezca testimonio real.

### Brazo y mano

- Formatos: video transparente, sprite, secuencia de imagenes, Rive, Lottie, canvas.
- Uso: `halo-selection`.
- Reglas: debe tener evento de inicio, contacto y finalizacion.

### Puerta de cristal

- Formatos: video, sprite, secuencia, Lottie.
- Uso: `office-intro`.
- Reglas: corta, atmosferica, legible en mobile.

### Taza TINTO

- Formatos: SVG, WebP, PNG sequence.
- Uso: refuerzo narrativo del mundo.
- Reglas: simbolica, no producto final de catalogo.

### Audio

- Formatos: MP3, AAC, OGG.
- Uso: narracion futura o apoyo atmosferico.
- Reglas: siempre controlable y opcional.

### Captions

- Formatos: VTT, SRT, texto incrustado accesible.
- Uso: VSL y escenas con voz.
- Reglas: obligatorias cuando hay audio.

### Posters

- Formatos: WebP, AVIF, JPG.
- Uso: hero, fallback, preview.
- Reglas: reservar dimension y aspecto.

### Mobile variants

- Formatos: versiones ligeras, posters verticales, recortes optimizados.
- Uso: mobile-first.
- Reglas: menos peso, menos densidad visual.

### Transparent media

- Formatos: WebM con alpha, PNG sequence, sprites.
- Uso: mano, avatar, overlays.
- Reglas: siempre con fallback opaco.

## 2. Fallbacks

Orden recomendado:

```text
video/transparency -> poster -> imagen estatica -> vector simple -> bloque textual
```

## 3. Versiones por capacidad

- cinematic: media completa.
- balanced: media principal + fallback ligero.
- reduced: assets estaticos y texto equivalente.

## 4. Reglas de seguridad

- no usar activos remotos;
- no usar media falsa como si fuera evidencia real;
- no guardar media pesada dentro de componentes;
- no depender de un solo formato.

