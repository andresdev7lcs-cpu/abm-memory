# WEB TINTO v0.2 - Migration Plan

## 1. Clasificacion general

### Conservar

- separacion de contenido y render;
- estado explicito;
- navegacion reversible;
- assets locales;
- fallback reduced motion;
- accesibilidad base;
- territorios como hipotesis.

### Adaptar

- loader;
- hero provisional;
- Home-Atom;
- tablero digital;
- escenario interno;
- diagnostico progresivo;
- responsive behavior;
- microinteracciones;
- motion timings.

### Reemplazar

- vista unica por controlador de escenas;
- hash routes como unica logica de navegacion;
- diagnostico mock como final;
- hero placeholder por secuencia narrativa real;
- feedback decorativo por contrato de escena.

### Eliminar

- dependencia mental de landing vertical;
- hover-only como mecanismo critico;
- cualquier promesa final prematura;
- scroll como unica columna vertebral.

## 2. Clasificacion por archivo

### index.html

- conservar estructura base;
- adaptar para soporte de escenas y accesibilidad;
- no convertirlo en landing clasica;
- no eliminar fallback no-JS.

### app.mjs

- conservar orquestacion central;
- adaptar a scene controller;
- reemplazar logica lineal por transiciones explicitas.

### components.mjs

- conservar modularidad;
- adaptar a escenas y a nuevos contratos de media;
- reemplazar renders simples por composiciones por escena.

### content.mjs

- conservar desacople;
- adaptar a scene content, motion content y media contracts;
- reemplazar textos puntuales por bloques por escena.

### state.mjs

- conservar estado explicito;
- adaptar a `SceneState`;
- reemplazar route-centric state por scene-centric state.

### router.mjs

- conservar deep links y fallback;
- adaptar para scene URLs y restore state;
- reemplazar hash-only como fuente unica de verdad.

### styles.css

- conservar tokenizacion base;
- adaptar a cinematic system;
- reemplazar visuales de prototipo por escala final.

### assets

- conservar ubicacion local;
- adaptar por contratos de media;
- reemplazar placeholders por assets aprobados.

### documentacion

- conservar la base;
- adaptar a v0.2;
- reemplazar entregables previos con esta arquitectura canonica.

## 3. Regla de migracion

- no borrar ni modificar todavia los archivos v0.1;
- no mover la carpeta del prototipo;
- no instalar nuevas dependencias;
- no introducir framework nuevo por moda;
- no cambiar STR-001;
- no tocar `tools/tinto-web/` en esta etapa.

