# WEB TINTO v0.2 - Motion Architecture

## 1. Principios

- el movimiento expresa causa y efecto;
- nada animado debe bloquear interaccion;
- las transiciones deben ser reversibles;
- reduced motion siempre conserva contenido;
- el motion budget depende del tier;
- la continuidad espacial debe sentirse, no distraer.

## 2. Timelines

### Curtain timeline

- logo aparece;
- respira;
- se enfoca;
- abre el telon;
- entra la fundadora.

### Halo selection timeline

- halo reacciona;
- fundadora reconoce seleccion;
- brazo se mueve;
- mano toca el nodo;
- pulso;
- corte a negro.

### Office intro timeline

- pantalla negra;
- microvideo de puerta de cristal;
- invitacion;
- entrada al nuevo escenario.

### Conversion timeline

- pregunta;
- contexto;
- objecion;
- claridad;
- reconocimiento personal;
- CTA agendar.

## 3. Bloqueo de interaccion

- Durante `entering` y `exiting`, la interaccion critica se bloquea.
- El bloqueo evita doble seleccion, doble submit y saltos concurrentes.
- La UI puede mostrar feedback de carga, pero no debe perder foco.

## 4. Aborts y reanudacion

- toda transicion critica debe poder abortarse;
- el abort devuelve al ultimo estado seguro;
- la reanudacion recupera la escena y el contexto;
- si media no llega a tiempo, se entra en fallback.

## 5. Skip intro

- el usuario puede omitir la introduccion;
- el skip salta a `atom-command-center` o al modo accesible equivalente;
- el evento `intro_skipped` debe quedar registrado conceptualmente;
- reduced motion puede activar skip por defecto.

## 6. Dotted surface

- fondo de puntos animados leves;
- uso de profundidad, no de ruido;
- debe ser subtitulo visual del Home-Atom;
- en reduced motion se congela o simplifica.

## 7. Ondas

- ondas reactivas al hover/touch;
- el radio responde a la seleccion;
- la intensidad baja en balanced;
- en reduced motion se reemplaza por halo estatico.

## 8. Halos

- halos con profundidad y capas;
- estado hover, focus y active diferentes;
- el halo es target y feedback al mismo tiempo;
- el halo no debe volverse un menu oculto.

## 9. Blur-to-focus

- blur inicial para entrada narrativa;
- foco progresivo para revelar informacion;
- blur solo como puente, nunca como barrera;
- el contenido clave no puede permanecer borroso.

## 10. Transiciones negras

- el negro es pausa narrativa;
- el blackout separa escenas;
- la duracion debe ser corta y expresiva;
- reduced motion usa fade oscuro, no bloqueo.

## 11. Navegacion horizontal

- se permite como timeline espacial;
- debe coexistir con teclado y touch;
- no puede ser la unica forma de avanzar;
- no debe romper scroll convencional en fallback.

## 12. Motion budgets

### cinematic

- timeline completo;
- 3 capas visuales minimo;
- media cinematica;
- overlays, blur, glow y transiciones espaciales.

### balanced

- misma secuencia narrativa;
- menos capas;
- menos loops;
- media mas ligera;
- foco en claridad.

### reduced

- sin loops;
- sin parallax;
- sin blur costoso;
- transiciones simples;
- contenido completo.

## 13. Reglas de seguridad

- no animar width/height/top/left como mecanismo principal;
- no depender de hover para acciones criticas;
- no bloquear input durante animacion;
- no usar motion para esconder informacion;
- no usar loops infinitos en elementos primarios si el usuario solicita reduced motion.

