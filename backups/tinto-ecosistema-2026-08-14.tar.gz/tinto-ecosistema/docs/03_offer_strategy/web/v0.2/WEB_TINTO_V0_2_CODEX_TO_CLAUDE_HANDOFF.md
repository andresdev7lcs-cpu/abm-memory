# WEB TINTO v0.2 - Codex to Claude Handoff

## 1. Qué entregó Codex

- motor de escenas funcional;
- state machine explícita;
- navegación hash y deep links;
- transiciones base con bloqueo, abort y reanudación;
- performance tiers;
- fallback sin JavaScript, sin media y reduced motion;
- booking mock local;
- media provisional local;
- event log local desacoplado;
- base técnica lista para que Claude Code haga la capa visual final.

## 2. Qué no debe reconstruir Claude Code

- router;
- controller;
- state machine;
- performance mode detection;
- booking mock;
- event contracts;
- secuencia canónica de escenas;
- fallbacks base;
- contratos de assets;
- lógica de hash/deep link.

## 3. Qué sí puede refinar Claude Code

- dirección visual;
- dirección de arte;
- motion refinado;
- composición cinematográfica;
- microinteracciones avanzadas;
- copy final de interfaz;
- polish responsive;
- assets definitivos.

## 4. Componentes disponibles

- scene rail;
- control rail;
- scene cards;
- media figures;
- summary cards;
- detail cards;
- question pills;
- booking grid;
- event feed;
- atmosphere canvas.

## 5. Contratos que debe respetar

### Escenas

```text
curtain
→ founder-vsl
→ atom-command-center
→ halo-selection
→ black-transition
→ office-intro
→ territory-world
→ question-layer
→ objection-layer
→ conversion-layer
→ booking
```

### Eventos

Usar el catálogo de `WEB_TINTO_V0_2_EVENT_CONTRACTS.md`.

### Assets

Usar el catálogo de `WEB_TINTO_V0_2_ASSET_CONTRACTS.md`.

### Performance modes

- cinematic;
- balanced;
- reduced.

## 6. Archivos autorizados para la siguiente fase

Claude Code puede refinar:

- `tools/tinto-web/styles.css`
- `tools/tinto-web/components.mjs`
- `tools/tinto-web/content.mjs`
- `tools/tinto-web/assets/*`
- `docs/03_offer_strategy/web/v0.2/*`

## 7. Restricciones estratégicas

- no inventar oferta;
- no inventar precios;
- no inventar claims;
- no inventar testimonios;
- no activar calendario real;
- no activar pagos;
- no activar analytics real;
- no romper reversibilidad;
- no convertir la experiencia en un scroll vertical disfrazado.

## 8. Skills que Claude Code debe usar después

- `ui-ux-pro-max`
- `ui-styling`
- `design-system`
- `brand`

No usarlas como productor visual final automático. Usarlas como capa de recomendación y coherencia.

