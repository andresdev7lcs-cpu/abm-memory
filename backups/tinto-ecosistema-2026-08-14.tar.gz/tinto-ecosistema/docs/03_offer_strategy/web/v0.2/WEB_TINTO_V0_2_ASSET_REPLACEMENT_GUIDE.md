# WEB TINTO v0.2 - Asset Replacement Guide (visual)

Complementa `WEB_TINTO_V0_2_ASSET_CONTRACTS.md` (arquitectura, no modificado). Este documento describe el estado visual actual de cada placeholder y cómo reemplazarlo sin tocar código.

## 1. Principio

Todos los assets viven en `tools/tinto-web/assets/*.svg`, son locales, y cada `<figure class="scene-media">` los marca visualmente con una etiqueta `PLACEHOLDER — REEMPLAZO PENDIENTE` (`.scene-media__tag`, agregada en este trabajo). Reemplazar un asset es: sustituir el archivo SVG/PNG/JPG en `assets/` manteniendo el mismo nombre de archivo referenciado en `content.mjs`, o cambiar la ruta en `content.mjs` (`assets` object) — ninguna de las dos acciones requiere tocar `components.mjs`, `styles.css` ni el motor de escenas.

## 2. Inventario actual

| Asset | Archivo | Usado en | Estado visual actual |
|---|---|---|---|
| Logo | `logo-mark.svg` | curtain, brand-lockup (chrome) | Respira (`logoBreathe`), sin rotación, glow dorado |
| VSL poster | `founder-vsl-poster.svg` | founder-vsl | Marco editorial con marcas de esquina |
| Retrato de la fundadora | `founder-portrait.svg` | office-intro (nuevo: antes declarado, no usado) | Círculo secundario, 40% ancho, opacidad 0.7, se oculta bajo 480px |
| Avatar de la fundadora | `founder-avatar.svg` | atom-command-center (nuevo: antes declarado, no usado) | Silueta detrás del label "Fundadora", opacidad 0.22, sin blur en reduced |
| Brazo y mano (halo) | `halo-hand.svg` | halo-selection | Glow radial por tono de territorio activo |
| Puerta de cristal | `glass-door.svg` | office-intro | Elemento principal de la composición |
| Taza TINTO | `tinto-cup.svg` | office-intro (nuevo: antes declarado, no usado) | Esquina inferior derecha de la puerta, se oculta bajo 480px |
| `hero-poster.svg` | — | **Ninguno.** Archivo presente en `assets/` pero no referenciado en `content.mjs`. No se inventó su uso: se deja documentado como huérfano para que Andrés/fundadora decidan si tiene destino (p.ej. Open Graph / meta imagen) o si se elimina. |

## 3. Cómo reemplazar

1. Producir el asset final (foto, video, ilustración) según la escena de destino.
2. Guardar en `tools/tinto-web/assets/` con el mismo nombre de archivo que ya usa `content.mjs` (evita tocar código), o actualizar la ruta en el objeto `assets` de `content.mjs` si el nombre cambia.
3. Formato recomendado por tipo:
   - Logo: SVG vectorial (mantiene nitidez en cualquier tamaño, ya usado así).
   - Retrato / avatar / poster VSL: SVG como placeholder es aceptable para wireframe; el reemplazo final debería ser JPG/WEBP optimizado o video (`webm`/`mp4` ya soportado por `media-contracts.mjs` sin cambios).
   - Puerta / taza: SVG o PNG con transparencia (se componen en capas sobre la escena).
4. Proporción esperada: `scene-media__image` fuerza `aspect-ratio: 4/5` (retrato). Si el asset final tiene otra proporción, ajustar en CSS (`object-fit: cover` ya evita distorsión, pero puede recortar).
5. Versión móvil: no existe `mobileVariant` por archivo separado todavía (el contrato en `media-contracts.mjs` lo soporta a nivel de dato; no se generaron variantes móviles en este trabajo por no inventar assets). El layout responsive ya oculta los elementos secundarios (taza, retrato) bajo 480px en vez de requerir una imagen distinta.
6. Al reemplazar, quitar manualmente el texto interno "provisional" si el propio SVG lo trae dibujado (varios de los placeholders actuales, por ejemplo `founder-portrait.svg` y `founder-avatar.svg`, ya incluyen un rótulo de texto vectorial visible como "Retrato provisional" / "Avatar provisional" — se confirmó en captura real, ver handoff).
7. La etiqueta `.scene-media__tag` ("Placeholder — reemplazo pendiente") es generada por CSS/HTML, no por el asset: desaparece sola si se elimina la clase en `components.mjs`, o puede dejarse hasta que Andrés confirme el asset como final.

## 4. Qué NO se hizo

- No se generaron imágenes ni videos nuevos.
- No se descargaron assets remotos.
- No se usó ninguna imagen de una persona real como si fuera la fundadora.
- No se inventó el uso de `hero-poster.svg` (queda documentado como huérfano, `(andres confirma)`).
