# WEB TINTO v0.2 - Implementation

## 1. Propósito

Base técnica funcional del motor de escenas para `WEB TINTO v0.2`, construida sobre el stack aprobado:

```yaml
stack:
  html: modular
  css: modular
  javascript: es_modules
framework_migration: false
```

La implementación preserva el prototipo v0.1 como referencia de base, pero ya ejecuta la secuencia canónica de escenas, navegación hash, performance tiers, fallbacks y booking mock local.

## 2. Resultado técnico

- motor de escenas funcional;
- state machine explícita;
- navegación por hash con deep links;
- transiciones base con bloqueo, abort y reanudación;
- performance tiers `cinematic`, `balanced`, `reduced`;
- media provisional local;
- booking mock local sin persistencia ni calendario real;
- experiencia móvil, tablet y desktop;
- eventos locales desacoplados de analytics.

## 3. Estructura creada o actualizada

### Implementación

- `tools/tinto-web/app.mjs`
- `tools/tinto-web/content.mjs`
- `tools/tinto-web/state.mjs`
- `tools/tinto-web/router.mjs`
- `tools/tinto-web/components.mjs`
- `tools/tinto-web/styles.css`
- `tools/tinto-web/index.html`
- `tools/tinto-web/scene-controller.mjs`
- `tools/tinto-web/scene-events.mjs`
- `tools/tinto-web/performance-mode.mjs`
- `tools/tinto-web/motion-engine.mjs`
- `tools/tinto-web/analytics-contract.mjs`
- `tools/tinto-web/media-contracts.mjs`
- `tools/tinto-web/canvas-atmosphere.mjs`

### Media local provisional

- `tools/tinto-web/assets/founder-vsl-poster.svg`
- `tools/tinto-web/assets/halo-hand.svg`
- `tools/tinto-web/assets/glass-door.svg`
- `tools/tinto-web/assets/tinto-cup.svg`

## 4. Secuencia canónica implementada

```text
curtain
→ founder-vsl
→ atom-command-center
→ halo-selection
→ black-transition
→ office-intro
→ territory-world
→ question-layer
→ objection-layer
→ conversion-layer
→ booking
```

## 5. Router y navegación

La aplicación usa hash routes como fallback y como mecanismo de restauración:

- `#/scene/<sceneId>`
- `#/scene/<sceneId>/<territoryId>/<questionId>`
- `#/territorio/<territoryId>`
- `#/territorio/<territoryId>/pregunta/<questionId>`
- `#/diagnostico/<territoryId>/pregunta/<questionId>`
- `#/board/...` como alias de la base anterior

La navegación es reversible y el regreso desde `territory-world` apunta a `office-intro`.

## 6. State machine

La `SceneState` activa conserva:

- `activeScene`
- `previousScene`
- `pendingScene`
- `transitionOriginScene`
- `sceneHistory`
- `transitionPhase`
- `interactionLocked`
- `paused`
- `reducedMotion`
- `performanceMode`
- `mediaReady`
- `activeTerritoryId`
- `activeQuestionId`
- `bookingDraft`
- `bookingSubmitted`
- `eventLog`

La implementación soporta:

- iniciar escena;
- salir;
- avanzar;
- regresar;
- omitir introducción;
- pausar;
- reanudar;
- abortar transición;
- impedir doble interacción;
- conservar contexto;
- cambiar modo de performance;
- gestionar media no disponible;
- recuperar navegación desde hash o deep link.

## 7. Eventos locales

Se registran en memoria, desacoplados de analytics:

```text
intro_started
intro_completed
intro_skipped
atom_viewed
territory_hovered
territory_selected
halo_interaction_started
halo_contact_completed
black_transition_started
black_transition_completed
office_intro_started
office_intro_completed
territory_world_entered
question_opened
objection_viewed
cta_revealed
booking_started
booking_completed
```

## 8. Performance tiers

- `cinematic`: motion completo, canvas, blur suave y capas atmosféricas.
- `balanced`: menos densidad visual, menos loops y media más ligera.
- `reduced`: sin movimiento continuo y con contenido completo.

La detección usa:

- `prefers-reduced-motion`;
- `prefers-reduced-data` cuando existe;
- `navigator.connection.saveData`;
- presupuesto básico del dispositivo;
- cambio manual desde la UI.

## 9. Media provisional

La base usa contratos locales y reemplazables:

- logo;
- poster de VSL;
- retrato;
- avatar;
- brazo y mano;
- puerta de cristal;
- taza TINTO;
- captions para VSL;
- fallbacks opacos;
- versiones móviles.

## 10. Booking mock

El booking es local, sin persistencia y sin integraciones externas.

Campos:

- nombre;
- email;
- país;
- territorio;
- situación;
- urgencia;
- tipo de ayuda;
- preferencia de contacto;
- consentimiento.

Estados:

```yaml
booking_mode: local_mock
external_calendar: disabled
lead_scoring: disabled
automatic_approval: disabled
automatic_rejection: disabled
persistent_storage: disabled
```

## 11. Fallbacks

- sin video: poster o imagen;
- sin retrato: bloque textual / placeholder editorial;
- sin canvas: escena funcional con CSS;
- sin JavaScript: fallback lineal explicado en `index.html`;
- reduced motion: fades simples y contenido completo.

## 12. Verificación ejecutada

- `node --check` en todos los `.mjs` de `tools/tinto-web/`
- `git diff --check`

Ambas verificaciones pasaron sin errores.

## 13. Restricciones respetadas

- no se instaló dependencias;
- no se migró a React, Vite o Next.js;
- no se conectó analytics real;
- no se conectó calendario real;
- no se conectó pagos;
- no se produjo oferta final;
- no se tocó `tools/tinto-web/` fuera de la base técnica;
- no se modificó `STR-001`;
- no se borró el prototipo v0.1.

## 14. Resultado

- `pass`
- `agent_review`
