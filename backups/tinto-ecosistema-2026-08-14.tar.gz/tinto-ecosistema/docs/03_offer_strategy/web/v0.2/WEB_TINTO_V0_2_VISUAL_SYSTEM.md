# WEB TINTO v0.2 - Visual System

## 1. Principio

El sistema visual traduce la arquitectura funcional (11 escenas, máquina de estados, eventos) ya auditada en PASS hacia una experiencia cinematográfica, premium y de conversión. No se tocó `scene-controller.mjs` en su lógica de transición, `state.mjs`, `scene-events.mjs`, ni el orden canónico de escenas. El trabajo vive en `tools/tinto-web/styles.css` (reescritura completa), con enganches mínimos y aditivos en `components.mjs`, `canvas-atmosphere.mjs` y `scene-controller.mjs` (una sola línea de mount, ver `WEB_TINTO_V0_2_CLAUDE_VISUAL_HANDOFF.md`).

## 2. Arquitectura de tokens (primitivo -> semántico -> componente)

### 2.1 Primitivos de color

```css
--p-void: #050403;            /* negro cálido base */
--p-espresso-950 / 900 / 800 / 700;  /* café profundo, escalera de profundidad */
--p-cacao-600 / 500;
--p-wine-900 / 700 / 500;     /* vino oscuro */
--p-copper-600 / 500 / 400;   /* cobre */
--p-gold-500 / 400 / 300;     /* dorado sobrio */
--p-ivory-200 / 100 / 050;    /* marfil */
```

Sin morado SaaS, sin azul fintech, sin neón. La paleta se mantiene dentro de café / negro cálido / marfil / cobre / dorado / vino en las 11 escenas.

### 2.2 Semánticos

`--bg-void`, `--bg-base`, `--bg-surface`, `--bg-surface-strong`, `--bg-surface-soft`, `--bg-glass`, `--line`, `--line-strong`, `--text-primary`, `--text-muted`, `--text-faint`, `--accent-copper`, `--accent-gold`, `--focus-ring`, `--shadow-depth-1/2/3`, `--shadow-inset-hairline`.

### 2.3 Componente / tono por territorio

Los 3 territorios (`finanzas-patrimonio`, `activos-inmobiliarios`, `educacion-orientacion-financiera`) tienen `tone: forest | petrol | copper` en `content.mjs` (dato existente, no modificado). El sistema visual mapea esos nombres a una variable RGB dentro de la paleta aprobada — no a verde/teal como en la v0.1:

```css
--tone-forest-rgb: 158, 74, 92;    /* vino/cobre — Finanzas y patrimonio: autoridad, protección */
--tone-petrol-rgb: 196, 138, 79;   /* cacao/cobre — Activos inmobiliarios: materialidad */
--tone-copper-rgb: 217, 174, 108;  /* dorado/marfil — Educación y orientación: claridad */
```

Estas mismas tripletas RGB se usan en `canvas-atmosphere.mjs` (`TONE_RGB`) para que el halo de canvas y el CSS respiren el mismo color. `[data-tone]` se aplica en `.scene-card`, `.territory-orbit` y controla el glow radial de fondo (`--tone-active-rgb`) en cada escena que muestra un territorio activo (atom-command-center, halo-selection, office-intro, territory-world, question-layer, objection-layer, conversion-layer, booking).

## 3. Tipografía

- `--font-serif`: "Iowan Old Style", "Palatino Linotype", "Book Antiqua", Georgia, serif — títulos, autoridad editorial cálida.
- `--font-sans`: "Avenir Next", "Segoe UI", "Helvetica Neue", sans-serif — cuerpo, claridad humanista.

Fuentes locales/del sistema, sin paquetes de fuentes nuevos ni fetch remoto. Escala fluida con `clamp()` en `h1` (2rem a 3.4rem). `--tracking-eyebrow: 0.18em` para microcopy en mayúsculas, `--tracking-display: -0.02em` para titulares.

## 4. Profundidad

Tres niveles: `--shadow-depth-1` (chips/botones), `--shadow-depth-2` (paneles), `--shadow-depth-3` (scene-card). Los fondos usan gradientes radiales superpuestos (vino, cobre, dorado) sobre una base café/negro en `.app-shell`, más una textura punteada sutil (`background-image: radial-gradient(...)` enmascarada con `mask-image`) que evoca la "dotted surface" de `atom-command-center` en todo el shell, no solo en esa escena.

## 5. Componentes clave restyleados

- **Chrome** (`brand-lockup`, `scene-rail`, `control-rail`): pills translúcidas, texto marfil, acento dorado en estado activo.
- **scene-card**: panel con gradiente vino/café, sombra profunda, transición de fase (`entering`/`exiting`) ligada a `--motion-enter/exit` por tier.
- **atom-stage__core**: núcleo circular con glow cobre/vino, silueta de `founder-avatar.svg` detrás del label a opacidad 0.22 (no reemplaza autoridad real, es huella visual).
- **territory-orbit**: halos de 40px de radio con glow radial por tono, sin apariencia de tarjeta corporativa plana.
- **halo-contact / transition-stage**: glow por tono, pulso, línea luminosa.
- **office-composition**: puerta de cristal + taza TINTO + retrato provisional en capas (antes la taza y el retrato existían como asset declarado pero no se usaban en ninguna escena; quedaron conectados aquí).
- **booking-form**: grid de dos columnas en desktop, foco dorado en inputs.

## 6. Qué se preservó explícitamente

- 11 escenas, orden canónico, navegación de regreso (`office-intro <- territory-world`, ya corregido en auditoría previa).
- Máquina de estados y los 18 eventos: cero cambios en `state.mjs` / `scene-events.mjs`.
- Contenido, copy y hipótesis de territorio: cero cambios en `content.mjs`.
- Booking mock local: sin integración externa.
