# WEB TINTO v0.2 - Motion System (visual)

## 1. Relación con el motor existente

`motion-engine.mjs` y `performance-mode.mjs` (no modificados) ya definían los presupuestos por tier:

| Tier | enterMs | exitMs | autoMs | waveMs |
|---|---|---|---|---|
| cinematic | 360 | 360 | 1200 | 2400 |
| balanced | 220 | 220 | 800 | 1800 |
| reduced | 120 | 120 | 0 | 0 |

El sistema visual expone esos mismos números en CSS mediante `[data-motion-mode]` (atributo que `scene-controller.mjs` ya escribía en `document.documentElement.dataset.motionMode` y `components.mjs` ya escribía en `.app-shell[data-motion-mode]`; no fue necesario tocar JS para esto):

```css
[data-motion-mode="cinematic"] { --motion-enter: 360ms; --motion-exit: 360ms; --motion-auto: 1200ms; --motion-wave: 2400ms; --blur-depth: 10px; }
[data-motion-mode="balanced"]  { --motion-enter: 220ms; --motion-exit: 220ms; --motion-auto: 800ms;  --motion-wave: 1800ms; --blur-depth: 5px; }
[data-motion-mode="reduced"]   { --motion-enter: 120ms; --motion-exit: 120ms; --motion-auto: 0ms;    --motion-wave: 0ms;   --blur-depth: 0px; }
```

`--motion-wave` alimenta las animaciones continuas (`curtainOpen`, `logoBreathe`, `haloPulse`, `transitionPulse`, `pulseLine`): en reduced, `--motion-wave: 0ms` detiene esas animaciones vía duración cero (equivalente a `animation: none`, reforzado explícitamente abajo).

## 2. Principios aplicados

- **Motion con significado:** el logo respira en curtain (indica "vivo", no loader); el core del átomo emite glow al hover/focus (indica interactividad); el halo pulsa hacia el territorio activo (indica selección).
- **Continuidad espacial:** `scene-card[data-phase="entering"|"exiting"]` anima opacidad + transform + blur usando `--motion-enter`/`--motion-exit`, nunca timelines fijas independientes del tier.
- **Reversibilidad:** ninguna animación bloquea el DOM; los controles (`Abortar transición`, `Regresar`, `Pausar`) siguen operando durante cualquier fase (lógica ya existente en `scene-controller.mjs`, no tocada).
- **Sin parallax agresivo, sin timelines imposibles de interrumpir.**

## 3. Escena por escena

| Escena | Motion propio | Reduced |
|---|---|---|
| curtain | `logoBreathe` (2.4s), barrido `curtainOpen` ligado a `--motion-wave` | sin respiración, aparición directa |
| founder-vsl | marcas de esquina estáticas (sin motion propio) | igual |
| atom-command-center | glow hover/focus del núcleo (`--motion-fast`), canvas con dots+anillos+halo por tono | canvas oculto (`opacity:0`), núcleo estático |
| halo-selection | `haloPulse` + `pulseLine` en `--motion-wave` | sin loops, contacto visual fijo |
| black-transition | `transitionPulse` en `--motion-wave` | fade corto vía `--motion-enter/exit` reducidos |
| office-intro | sin loops; entrada vía `data-phase` | igual |
| territory-world | canvas de atmósfera por tono (mismo mecanismo que atom-command-center, montado ahora también aquí) | canvas oculto |
| question-layer | `revealUp` al entrar en fase `active` (una vez, no loop) | duración 1ms por media query `prefers-reduced-motion` |
| objection-layer | sin loops; énfasis vía borde de tono | igual |
| conversion-layer | glow estático en CTA primario | igual |
| booking | transición de foco en inputs (`--transition`, 180ms, independiente de tier: es feedback de UI, no motion narrativo) | igual |

## 4. Reduced motion — dos capas de seguridad

1. `[data-motion-mode="reduced"]`: aplicado cuando el usuario elige el tier manualmente o cuando `performance-mode.mjs` detecta `prefers-reduced-motion` y lo autoselecciona (`detectPerformanceMode()`, sin cambios).
2. `@media (prefers-reduced-motion: reduce)`: red de seguridad a nivel de sistema operativo, independiente del estado de la app — cubre el caso de un usuario cuyo SO pide reducir motion pero cuyo `performanceMode` en memoria todavía no se sincronizó.

Ambas capas fuerzan `animation-duration: 1ms`/`animation: none` y ocultan los canvases de atmósfera. Se verificó con `--force-prefers-reduced-motion` en Chrome headless (ver handoff, sección de pruebas visuales) que el layout permanece completo y legible, sin pérdida de jerarquía narrativa.

## 5. Micro-interacciones (no ligadas a tier)

Hover/focus de botones, pills y campos usa `--motion-fast: 180ms` con `--ease-standard`, dentro del rango 150-300ms recomendado para feedback de UI. Esto es intencionalmente independiente de `--motion-enter/exit` (que son para transición narrativa de escena) — un cambio de tier no debe hacer que un botón tarde 1.2s en responder al hover.
