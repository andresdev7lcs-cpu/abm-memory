# WEB TINTO v0.2 - Component Map

## 1. Propósito

Mapa de módulos y responsabilidades de la base técnica funcional.

## 2. Núcleo de ejecución

### `tools/tinto-web/app.mjs`

- arranque de la app;
- instancia del controlador;
- export de referencia de depuración en `window.tintoSceneController`.

### `tools/tinto-web/scene-controller.mjs`

- orquestación de escenas;
- transiciones;
- hash routing;
- pausas, abortos y reanudación;
- autoavance;
- navegación reversible;
- eventos locales;
- gestión de booking mock.

### `tools/tinto-web/state.mjs`

- contrato de estado;
- `SceneState`;
- contexto territorial y de pregunta;
- historial de escenas;
- booking draft;
- flags de transición y pausa.

### `tools/tinto-web/router.mjs`

- parseo de hash;
- serialización de hash;
- detección de `prefers-reduced-motion`;
- soporte para rutas heredadas.

### `tools/tinto-web/components.mjs`

- render de layout global;
- render de escenas;
- render del rail de escenas;
- render de booking mock;
- render de feed de eventos locales.

### `tools/tinto-web/content.mjs`

- contrato de contenido;
- escenas canónicas;
- territorios;
- preguntas;
- booking fields;
- assets locales;
- performance modes.

## 3. Soporte

### `tools/tinto-web/performance-mode.mjs`

- detección de modo;
- normalización de modo;
- presupuesto visual base.

### `tools/tinto-web/motion-engine.mjs`

- budgets de transición;
- autoadvance por escena;
- helpers de duración.

### `tools/tinto-web/scene-events.mjs`

- catálogo canónico de eventos;
- append local a `state.eventLog`;
- records con timestamp y contexto.

### `tools/tinto-web/media-contracts.mjs`

- contratos de media;
- resolución de fallback;
- helpers de soporte.

### `tools/tinto-web/analytics-contract.mjs`

- contrato local desacoplado;
- no-op para analytics real.

### `tools/tinto-web/canvas-atmosphere.mjs`

- fondo atmosférico canvas 2D;
- dots y anillos;
- fallback sin animación en reduced motion.

## 4. Assets locales

- `assets/logo-mark.svg`
- `assets/founder-vsl-poster.svg`
- `assets/founder-portrait.svg`
- `assets/founder-avatar.svg`
- `assets/halo-hand.svg`
- `assets/glass-door.svg`
- `assets/tinto-cup.svg`

## 5. Capas reutilizables

- brand lockup;
- scene rail;
- control rail;
- scene card;
- media figure;
- summary card;
- detail card;
- question pills;
- booking grid;
- event feed;
- atmosphere canvas;
- global announcer.

## 6. Qué no debe reconstruir Claude Code

- router hash;
- state machine;
- performance tiers;
- booking mock;
- event contracts;
- fallbacks base;
- navigation history;
- scene order canónico.

## 7. Qué sí puede refinar Claude Code

- dirección visual;
- composición cinematográfica;
- microinteracciones avanzadas;
- motion polish;
- copy final de interfaz;
- acabado premium;
- assets definitivos.

