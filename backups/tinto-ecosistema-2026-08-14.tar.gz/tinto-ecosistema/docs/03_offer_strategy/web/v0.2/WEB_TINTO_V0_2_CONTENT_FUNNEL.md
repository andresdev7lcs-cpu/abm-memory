# WEB TINTO v0.2 - Content Funnel

## 1. Capas

```text
curiosity
education
objection
relevance
decision
conversion
```

La capa no define oferta final. Define progresion narrativa.

## 2. curiosity

- Pregunta: que hace esta experiencia y por que se siente distinta.
- Microcopy: breve, intrigante, no promocional.
- Contenido: telon, logo vivo, presentacion de la fundadora.
- Recurso: opener visual.
- Objecion: "esto parece solo estetica".
- Siguiente interaccion: seleccion de halo.
- CTA: abrir o avanzar.
- Evento conceptual: `intro_started`.

## 3. education

- Pregunta: que significa este territorio y que tipo de ayuda representa.
- Microcopy: claro, simple, sin promesa.
- Contenido: preguntas, contexto, recursos explicativos.
- Recurso: capas educativas progresivas.
- Objecion: "no entiendo si esto es para mi".
- Siguiente interaccion: abrir detalle del territorio.
- CTA: ver mas.
- Evento conceptual: `question_opened`.

## 4. objection

- Pregunta: que me impide seguir.
- Microcopy: resuelve friccion sin exagerar.
- Contenido: objeciones, limites, contexto, reversibilidad.
- Recurso: prueba, claridad, contraste.
- Objecion: precio, tiempo, credibilidad, ambiguedad.
- Siguiente interaccion: avanzar a claridad.
- CTA: continuar.
- Evento conceptual: `objection_viewed`.

## 5. relevance

- Pregunta: por que esto importa ahora.
- Microcopy: situa la necesidad en el presente.
- Contenido: sintesis, ejemplo, lectura del problema.
- Recurso: framing contextual.
- Objecion: "lo dejo para despues".
- Siguiente interaccion: reconocer prioridad.
- CTA: seguir.
- Evento conceptual: `cta_revealed`.

## 6. decision

- Pregunta: que siguiente paso tiene sentido.
- Microcopy: orienta sin forzar.
- Contenido: resumen, opcion, continuidad.
- Recurso: confirmacion.
- Objecion: "no quiero comprometerme aun".
- Siguiente interaccion: booking o retorno.
- CTA: agendar.
- Evento conceptual: `booking_started`.

## 7. conversion

- Pregunta: como cierro la interaccion.
- Microcopy: accion clara y concreta.
- Contenido: CTA, formulario, contacto.
- Recurso: booking o registro.
- Objecion: dudas finales.
- Siguiente interaccion: confirmar.
- CTA: completar.
- Evento conceptual: `booking_completed`.

## 8. Reglas

- no inventar oferta;
- no inventar claims;
- no prometer resultados;
- no esconder salida;
- no convertir cada capa en una landing separada.
