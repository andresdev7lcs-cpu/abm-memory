# WEB TINTO - Navigation Flow

## Objetivo

Dejar la navegacion explicita, reversible y accesible.

## Flujo principal

1. Loader aparece.
2. Hero provisional entra sin retraso artificial.
3. Home-Atom muestra el nucleo y tres territorios.
4. Seleccion de territorio abre el tablero digital.
5. Seleccion de pregunta abre el escenario interno.
6. CTA del escenario abre el diagnostico progresivo.
7. El usuario regresa al territorio o al Home-Atom.

## Hash routes

- `#/home`
- `#/territorio/finanzas-patrimonio`
- `#/territorio/activos-inmobiliarios`
- `#/territorio/educacion-orientacion-financiera`
- `#/territorio/:territoryId/pregunta/:questionId`
- `#/diagnostico/:territoryId/pregunta/:questionId`

## Reglas de reversibilidad

- El back del navegador debe funcionar.
- El boton de regreso del tablero vuelve al Home-Atom.
- El boton de regreso del escenario vuelve al territorio.
- El diagnostico vuelve al tablero sin perder el draft en memoria.

## Estado de navegacion

- `view`
- `territoryId`
- `questionId`
- `diagnosisStep`
- `diagnosisSubmitted`

## Fallback mobile

- Si no cabe el orbit layout, los territorios se apilan.
- El boton sigue siendo el punto principal de interaccion.
- El tablero conserva la estructura sin modales.

