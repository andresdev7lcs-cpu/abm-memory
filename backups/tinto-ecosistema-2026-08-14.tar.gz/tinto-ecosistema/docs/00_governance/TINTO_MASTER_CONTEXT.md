---
document: TINTO_MASTER_CONTEXT
version: 0.1.0
status: HYPOTHESIS
owner: (andres confirma)
last_updated: (andres confirma)
source_of_truth: true
---

# TINTO — Contexto maestro

## Propósito

Conservar la memoria estratégica del proyecto TINTO y definir los principios, límites, decisiones y lineamientos que deben respetar los demás documentos.

## Principio rector

> Visión amplia, ejecución estrecha.

TINTO puede evolucionar hacia un ecosistema de soluciones para colombianos en el exterior, pero la primera etapa debe construir y validar una sola unidad comercial capaz de atraer, convertir y atender clientes.

## Regla de gobernanza

Nada se considera aprobado únicamente porque haya aparecido en una conversación.

Toda decisión estructural debe registrarse en `DECISION_LOG.md`.

## Estado actual

La primera unidad comercial está en fase de hipótesis y definición.

Todo dato pendiente debe marcarse como:

```text
(andres confirma)