# Protocolo de escalación — TINTO

## Propósito

Definir cuándo un agente debe detenerse, esperar decisión humana, y cuál es la prioridad operativa. Escala clara evita bloqueos indefinidos y tomas de decisión impulsivas.

## Estado de implementación

Este protocolo está **diseñado para validación humana**. Durante `v0.2.0` (Bloque 1 de TINTO Guardian), escalaciones se administran manualmente. La integración al dashboard corresponde a `v0.3.0`. **Requiere aprobación de Andrés antes de cierre de Bloque 1.**

## Principio de escalamiento

Escalar cuanto antes cuando hay riesgo estratégico, falta de autoridad o información crítica. No usar escalamiento como excusa para evitar trabajo que sí puede avanzar. Separar bloqueos críticos de dudas menores.

## Tipos de escalación

### E0 — Informativo (sin bloqueo)

**Descripción:** Agente notifica a Andrés de hallazgo interesante, pero continúa trabajando.

**Ejemplos:**
- Descubrimiento de oportunidad adicional.
- Feedback positivo del mercado.
- Eficiencia operativa sugerida.
- Noticia que afecta contexto pero no decisiones actuales.

**Urgencia:** Comunicar en próxima revisión operativa (no es crítica).

**Quién decide:** Andrés (informativo; no requiere decisión urgente antes de continuar trabajo).

**Trabajo que puede continuar:** Todo relacionado con ticket actual.

**Trabajo que debe detenerse:** Ninguno.

### E1 — Consulta (bloqueante menor)

**Descripción:** Agente encuentra información faltante o ambigüedad, requiere confirmación antes de continuar.

**Ejemplos:**
- Dato de fundadora no confirmado (usar `(andres confirma)`).
- Dos interpretaciones válidas del acceptance criteria (requiere aclaración).
- Herramienta sugerida no está en TECH-001 (¿usar o no?).
- Plazo ambiguo en ticket.

**Urgencia:** Esperar respuesta antes de continuar implementación afectada; clarificar en próxima revisión operativa.

**Quién decide:** Andrés (en mayoría). Fundadora si toca datos de ella.

**Trabajo que puede continuar:**
- Otros tickets no bloqueados.
- Investigación preparatoria.
- Documentación preliminar (sin decisiones finales).

**Trabajo que debe detenerse:**
- Implementación del ticket bloqueado.
- Decisiones estratégicas basadas en supuesto.

### E2 — Bloqueo (escalación crítica)

**Descripción:** Agente detecta contradicción, riesgo estratégico o brecha irreconciliable.

**Ejemplos:**
- Ticket pide cambio que contradice DECISION_LOG.md.
- Información faltante impide continuar (no es clarificación, es dato esencial).
- Descubierto riesgo legal o reputacional.
- Dependencia crítica falla o está más atrasada de lo previsto.
- Tecnología base no funciona como esperado.
- Presupuesto insuficiente para scope aprobado.

**Urgencia:** Detener ejecución del ticket afectado. Escalar en la próxima operación (antes de reanudar).

**Quién decide:** Andrés (+ fundadora si toca marca/experiencia).

**Trabajo que puede continuar:**
- Tickets no relacionados.
- Investigación que no depende del bloqueo.

**Trabajo que debe detenerse:**
- Ticket bloqueado completamente.
- Tickets dependientes (si tienen este como dependencia).

### E3 — Crítico (escalada estratégica)

**Descripción:** Situación que amenaza dirección del proyecto, requiere cambio de decisión o renegociación con cliente.

**Ejemplos:**
- Mercado cambió dramáticamente (oportunidad o amenaza).
- Cliente quiere cambiar radicalmente scope/presupuesto.
- Fundadora rechaza dirección estratégica aprobada.
- Error crítico en decisión aprobada (debe revisarse).
- Recurso crítico no disponible (Andrés, fundadora, herramienta).

**Urgencia:** Escalación crítica. Prioridad máxima en la próxima revisión Andrés + Fundadora + Cliente.

**Quién decide:** Andrés + Fundadora + Cliente (si aplica).

**Trabajo que puede continuar:**
- Nada hasta que se resuelva (todo cuelga de esto).

**Trabajo que debe detenerse:**
- Todas las fases en progreso o planeadas.
- Posible "pause" en roadmap.

## Niveles: guía de clasificación

| Nivel | Urgencia | Criticidad | Quién | Reunión requerida |
|-------|----------|-----------|-------|------------------|
| E0 | Próxima revisión | Baja | Andrés | No |
| E1 | Antes de continuar ticket | Media | Andrés/Fundadora | Caso a caso |
| E2 | Antes de reanudar trabajo | Alta | Andrés + | Sí |
| E3 | Máxima prioridad en próxima operación | Crítica | Andrés + Fundadora + | Sí |

## A quién escalar

| Tipo de escalación | Destinatario | Alternativa |
|-------------------|-------------|------------|
| Dato de fundadora | Andrés + Fundadora | Andrés |
| Decisión estratégica | Andrés | Fundadora (si solo marca) |
| Presupuesto / Cliente | Andrés + Cliente | Andrés |
| Marca personal / representación | Fundadora | Andrés |
| Contradicción DECISION_LOG | Andrés | Ninguno (requiere Andrés) |
| Error técnico crítico | Codex + Andrés | Codex |
| Riesgo reputacional | Andrés + Fundadora | Andrés |

## Qué información debe incluir la alerta

**Formato obligatorio:**

```text
═══════════════════════════════════════════════════════════════
ESCALATION ID: [ESC-YYYY-MM-DD-NNN]
TICKET: [TICKET-ID o "Ad-hoc"]
LEVEL: [E0 / E1 / E2 / E3]
TRIGGER: [Qué disparó]
═══════════════════════════════════════════════════════════════

CONTEXT:
[2-3 párrafos: situación actual, por qué escalación es necesaria]

CONFLICT:
[Qué contradice o falta. Qué decisión se requiere.]

OPTIONS:
1. [Opción A + pros/contras]
2. [Opción B + pros/contras]
3. [Opción C + pros/contras]

RECOMMENDATION:
[Si agente tiene recomendación técnica, expresarla aquí]

WORK PAUSED:
- [Ticket-ID]: parado en [fase]
- [Ticket-ID]: parado en [fase]
- (o "ninguno" si E0)

WORK THAT MAY CONTINUE:
- [Ticket-ID]: puede continuar
- [Ticket-ID]: puede continuar
- (o "nada" si E3)

DECISION REQUIRED FROM:
- Andrés: [qué específico]
- Fundadora: [qué específico]
- Cliente: [qué específico, si aplica]

TIMELINE (operacional, sin SLA numérico):
- E0: Próxima revisión
- E1: Antes de continuar implementación del ticket
- E2: Antes de reanudar trabajo en tickets bloqueados
- E3: Máxima prioridad en próxima reunión Andrés + Fundadora + Cliente

═══════════════════════════════════════════════════════════════
```

## Qué puede continuar mientras se espera

**Regla general:** Trabajo que no depende de la decisión escalada.

**E0 (Informativo):**
- Todo como de costumbre.

**E1 (Consulta):**
- Otros tickets no relacionados.
- Investigación que no requiere decisión.
- Documentación preliminar marcada "(pendiente confirmación)".

**E2 (Bloqueo):**
- Tickets no relacionados.
- Tareas preparatorias.
- No: implementación del ticket bloqueado ni dependientes.

**E3 (Crítico):**
- Pausa completa. Esperar.

## Qué debe detenerse

**E0:** Nada.

**E1:** 
- Implementación del ticket en cuestión.
- Decisiones que requieran el dato faltante.

**E2:**
- Ticket completamente.
- Tickets que lo tienen como dependencia (si existen).
- Cualquier trabajo que requiera decisión contradictoria.

**E3:**
- Proyecto. Pausa total hasta resolución.

## Registro en comentarios, ledger y timeline

**Entrada en comments/[TICKET-ID].jsonl:**
```json
{
  "timestamp": "ISO-8601",
  "author": "quién-escala",
  "type": "blocked",
  "message": "ESCALATION ID: ESC-2026-07-23-001\nLEVEL: E2\nMOTIVO: Contradicción entre ticket (cambiar nicho) y DEC-001 (una unidad comercial)\nESCALADO A: Andrés"
}
```

**Entrada en roadmap-status.md:**
```json
{
  "timestamp": "ISO-8601",
  "ticket": "[TICKET-ID]",
  "event": "blocked",
  "runner": "quién-escala",
  "model": "escalation",
  "message": "Escalado a Andrés. ESC-2026-07-23-001.",
  "blockerType": "escalation-E2"
}
```

**Archivo en timeline/ (si E2 o E3):**
- Crear `ESCALATION_ESC-YYYY-MM-DD-NNN.md` con formato arriba.

## Resolución

Cuando Andrés (o quien decide) responde:

1. Registrar decisión en DECISION_LOG.md (si es decisión estratégica) o comments.
2. Actualizar roadmap-status.md: evento "note" con resultingState (pending, in_progress, etc).
3. Comunicar a agente y equipo.
4. Desbloquear ticket (status → ready o in_progress).

**Ejemplo entrada roadmap-status.md (resolución):**
```json
{
  "timestamp": "ISO-8601",
  "ticket": "[TICKET-ID]",
  "event": "note",
  "runner": "andrés",
  "model": "escalation-resolution",
  "message": "ESC-2026-07-23-001 resuelto. Decisión: proceder con opción B. Registrado DEC-006.",
  "resultingState": "ready"
}
```

## Reanudación del ticket

Después de resolución:

1. Agente retoma trabajo desde punto de pausa.
2. Implementa con nueva decisión/confirmación.
3. Continúa ciclo normal (agent_review, human_review, etc).

Si escalación causó retrabajar (p.e. cambio de dirección), iniciar desde 0.

## Ejemplos prácticos

### Ejemplo 1: E0 — Informativo

```text
ESCALATION ID: ESC-2026-07-23-A01
TICKET: MKT-005
LEVEL: E0 (Informativo)
TRIGGER: Hallazgo de oportunidad secundaria durante investigación

CONTEXT:
Mientras investigaba buyer persona para MKT-005, descubrimos que el subnicho "colombianos en USA con hijos" 
tiene demanda alta por tutorías en español. No es parte de MKT-005 pero podría ser Stage 7.

CONFLICT: Ninguno. Es hallazgo interesante.

OPTIONS:
1. Guardar como "backlog futuro" para Stage 7.
2. Incorporar en buyer persona actual como "oportunidad anotada".

RECOMMENDATION: Opción 1. No expandir MKT-005, pero documentar en change-requests/CR-XXX para futuro.

WORK PAUSED: Ninguno.

WORK THAT MAY CONTINUE: Todo. MKT-005 continúa sin cambio.

DECISION REQUIRED FROM: Ninguno.

TIMELINE: Informativo.
```

### Ejemplo 2: E1 — Consulta

```text
ESCALATION ID: ESC-2026-07-23-B02
TICKET: STR-001
LEVEL: E1 (Consulta)
TRIGGER: Dato de fundadora no confirmado

CONTEXT:
Para consolidar contexto maestro en STR-001, necesito confirmar años de experiencia de fundadora 
en finanzas personales. Roadmap.md dice "(andres confirma)" en contexto.

CONFLICT: 
Opción A: Asumir 15+ años (conversación con Andrés sugiere esto).
Opción B: Validar exactamente con fundadora primero.

OPTIONS:
1. Escribir "(andres confirma)" y esperar dato exacto.
2. Usar estimación "15+ años" con nota [(HIPÓTESIS)].
3. Pausar STR-001 hasta confirmar exactamente.

RECOMMENDATION: Opción 1. Escribir (andres confirma) y notificar. Continuar ST-001 con marcador.

WORK PAUSED: STR-001 en "draft (pendiente confirmación)". Puede continuar redacción sin ese dato.

WORK THAT MAY CONTINUE: 
- STR-002 (ecosistema amplio) — no depende de esto.
- MKT-001 (entrevistas) — no depende de esto.

DECISION REQUIRED FROM: 
- Andrés: Confirmar años de experiencia (exacto o rango).

TIMELINE: E1, antes de continuar implementación de STR-001 final.
```

### Ejemplo 3: E2 — Bloqueo crítico

```text
ESCALATION ID: ESC-2026-07-23-C03
TICKET: PRD-003
LEVEL: E2 (Bloqueo)
TRIGGER: Contradicción detectada en AC vs decisión aprobada

CONTEXT:
Mientras trabajo en PRD-003 (primera oferta comercial), el AC dice "diseñar 3 paquetes de precio" 
(básico, profesional, premium). Pero DEC-003 aprueba MVP sin plataforma propia, operado manualmente. 
Tres niveles de servicio son complicados de operar sin automatización.

CONFLICT:
DEC-003 (MVP manual) vs AC (3 tiers). El ticket asume capacidad operativa que no hemos validado.

OPTIONS:
1. Simplificar a 1 oferta única (más fácil de operar manualmente).
2. Diseñar 3 tiers pero validar si es operacionalmente viable con fundadora.
3. Cambiar DEC-003 para permitir herramienta de gestión.

RECOMMENDATION: Opción 2. Diseñar 3 tiers pero documentar riesgo operativo. Fundadora valida viabilidad.

WORK PAUSED: 
- PRD-003: bloqueado en "pricing/tiers".

WORK THAT MAY CONTINUE:
- PRD-001 (portafolio): no depende de PRD-003.
- PRD-002 (escalera): puede continuar con estructura genérica.

DECISION REQUIRED FROM:
- Andrés: ¿Proceder con 3 tiers o simplificar a 1?
- Fundadora: ¿Operacionalmente viable 3 tiers manualmente?

TIMELINE: E2, antes de reanudar PRD-003. Reunión con Andrés + Fundadora.
```

### Ejemplo 4: E3 — Crítico estratégico

```text
ESCALATION ID: ESC-2026-07-23-D04
TICKET: Varios (Stage 2 en progreso)
LEVEL: E3 (Crítico)
TRIGGER: Cliente solicita cambio radical de dirección

CONTEXT:
Fundadora nos comunica que cliente está considerando cambiar enfoque de "bienes en Colombia" 
a "remesas internacionales" + "seguros". Esto contradice DEC-001 (una unidad comercial) 
y requeriría redesign de buyer persona, nicho, oferta, roadmap completo.

CONFLICT:
Cliente requiere decisión sobre dirección. No podemos continuar diseño sin validación de cambio.

OPTIONS:
1. Rechazar cambio. Mantener dirección original. Riesgo: cliente se va.
2. Aceptar cambio. Redesign completo. Requiere renegociación presupuesto/timeline.
3. Proponer tercera opción: validar original según plan, luego decidir expansión.

RECOMMENDATION: Opción 3 (si cliente lo considera) o Opción 2 si cliente insiste.

WORK PAUSED:
- STR-001, STR-003, MKT-*, PRD-*, todo Stage 2: pausa hasta decisión.

WORK THAT MAY CONTINUE: Nada significativo. Proyecto en pausa estratégica.

DECISION REQUIRED FROM:
- Andrés: ¿Renegociar contrato? ¿Cuál es presupuesto/timeline nuevo?
- Fundadora: ¿Quieres continuar en nueva dirección o mantener original?
- Cliente: ¿Confirmación de cambio de dirección?

TIMELINE: E3, máxima prioridad. Reunión Andrés + Fundadora + Cliente requerida antes de reanudar.
```

## Protocolo cuando escalación se repite

Si la misma escalación levanta 3+ veces sin resolución:

1. Registrar patrón en timeline/.
2. Escalar a Andrés: "Escalación ESC-XXX se repite. Decisión final requerida ahora."
3. Andrés toma decisión final y la registra en DECISION_LOG.md.
4. Comunicar a equipo: esta es la decisión y no reabre.

## Uso correcto vs incorrecto del escalamiento

### ❌ Incorrecto (evitar)

- "No sé qué hacer → escalo" (sin haber intentado/investigado).
- "Es complicado → escalo" (complicación operativa, no estratégica).
- "Tengo duda menor → escalo" (clarificar o asumir).
- Escalar sin información clara (sin usar formato).
- Escalar sin intentar resolverlo primero.

### ✅ Correcto

- Contradicción real entre ticket y decisión aprobada → E2.
- Dato crítico confirmado falta → E1.
- Descubierto riesgo legal/reputacional → E2.
- Cliente pide cambio radical → E3.
- Hallazgo interesante (no bloquea) → E0.
- Error en ticket, AC ambiguo → E1.

## Evitar escalación innecesaria

**Preguntas antes de escalar:**

1. ¿He leído el ticket línea por línea?
2. ¿He consultado DECISION_LOG.md?
3. ¿He buscado en comments/ o memory/?
4. ¿Es realmente contradicción o es interpretación?
5. ¿Puedo continuar trabajo preparatorio mientras espero?
6. ¿Hay alternativa que no requiera decisión?

Si respondes "sí" a todas = no escales (E0 máximo).

Si respondes "no" a cualquiera = sí, escala (E1 mínimo).

Escalamiento temprano > paralización. Mejor preguntar que inventar.
