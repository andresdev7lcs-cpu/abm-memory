# Protocolo de flujo de trabajo — TINTO

## Propósito

Definir el ciclo completo de cada ticket: desde intake hasta cierre. Estados, transiciones válidas, checklists, protocolos por fase.

## Estado de implementación

Este protocolo está **diseñado para validación humana**. Durante `v0.2.0` (Bloque 1 de TINTO Guardian), estados y transiciones se administran manualmente en `roadmap-status.md`. La automatización del dashboard corresponde a `v0.3.0`. **Requiere aprobación de Andrés antes de cierre de Bloque 1.**

## Flujo general de ticket

```
pending → ready → in_progress → agent_review → human_review → completed
                    ↓                              ↓
                  blocked ← ← ← ← ← ← ← ← ← ← ← ← ↓
                    ↓
                  failed
                    ↓
                  rejected
```

## Estados oficiales y transiciones

### Estados

- **pending:** Esperando inicio. Dependencias sin completar o asignación pendiente.
- **ready:** Dependencias completadas. Listo para ejecución.
- **in_progress:** Productor trabajando.
- **agent_review:** Entregable producido. Esperando revisión de especialista (Claude Code o Codex).
- **human_review:** Revisión técnica aprobada. Esperando aprobación humana (Andrés o fundadora).
- **completed:** Aprobado. Finalizado.
- **blocked:** Detenido por dependencia, información faltante, o escalación.
- **failed:** Ejecución fallida (error técnico, información no encontrada, etc).
- **rejected:** Revisión rechazó entregable. Requiere retrabajar.

### Transiciones válidas

| De | A | Quién | Condición |
|----|---|-------|-----------|
| pending | ready | Sistema | Dependencias completadas |
| ready | in_progress | Productor | Inicia trabajo |
| in_progress | agent_review | Productor | Entregable terminado |
| agent_review | human_review | Revisor especialista | Aprobó técnicamente |
| agent_review | blocked | Revisor | Encontró gaps/contradicciones |
| agent_review | rejected | Revisor | Rechaza entregable |
| human_review | completed | Andrés | Aprobó final |
| human_review | blocked | Andrés | Requiere información adicional |
| human_review | rejected | Andrés | Rechaza entregable |
| blocked | ready | Andrés | Resolvió bloqueo |
| failed | ready | Andrés | Autoriza reintentar |
| rejected | ready | Productor | Retrabajó aceptación AC |

### Transiciones inválidas

**Prohibidas:**
- pending → completed (saltar fases)
- in_progress → completed (sin revisión)
- in_progress → human_review (sin agent_review)
- agent_review → blocked → completed (sin resolver bloqueo)

## Protocolo de inicio de sesión

Antes de trabajar en un ticket:

1. **Lee fuentes de verdad obligatorias:**
   - DECISION_LOG.md (decisiones aprobadas)
   - PROJECT_RULES.md (restricciones)
   - roadmap.md (ticket específico)
   - memory/CURRENT_STATE.md (contexto)
   - comments/[TICKET-ID].jsonl (historial)
   - STRATEGIC_GUARDRAILS.md (evaluar semáforo)

2. **Valida tu rol:**
   - ¿Eres el productor asignado?
   - ¿Tienes especialidad para este ticket (documentación vs código)?
   - ¿No hay conflicto de interés?

3. **Crea entrada de inicio en roadmap-status.md:**
   ```json
   {
     "timestamp": "ISO-8601",
     "ticket": "TICKET-ID",
     "event": "in_progress",
     "runner": "tu-nombre",
     "model": "tu-especialidad",
     "message": "Iniciando trabajo"
   }
   ```

## Protocolo de selección de ticket

Prioridad:

1. Tickets con dependencias completadas (ready).
2. Tickets críticos sin bloqueos (roadmap.md Priority: critical).
3. Tickets que desbloquean otros (high blocker value).
4. Tickets estándar (priority: high, medium).
5. Tickets de deuda técnica (low priority).

No selecciones ticket si:
- Tiene dependencias incompletas (pasa a blocked).
- No tienes claridad en AC (escala a Andrés).
- Hay conflicto de interés (otro productor).

## Protocolo previo a ejecutar

**Checklist:**

- [ ] Leí roadmap.md línea por línea.
- [ ] Entiendo objetivo, scope, archivos permitidos.
- [ ] Validé AC (acceptance criteria).
- [ ] Revisé dependencias (status en roadmap-status.md).
- [ ] Leí DECISION_LOG.md para decisiones aprobadas.
- [ ] Identifiqué información faltante (marcar con `(andres confirma)`).
- [ ] No hay contradicciones con DECISION_LOG.md o PROJECT_RULES.md.
- [ ] Leí comments/[TICKET-ID].jsonl si existen.
- [ ] Creé entrada "in_progress" en roadmap-status.md.

Si algo falla → bloquea ticket, escala a Andrés.

## Protocolo durante ejecución

**Mientras trabajas:**

1. Registra avance en comments/[TICKET-ID].jsonl (opcional, cada N horas si ticket largo).
2. Si encuentras información faltante → escala sin demora (no adivines; registra en comments).
3. Si encuentras contradicción → escala sin demora; detén implementación hasta resolución.
4. Si dependencia falla → actualiza roadmap-status.md a "blocked", registra en comments.
5. Mantén archivos permitidos limitados a roadmap.md "Files allowed to change".

**Formato de avance (opcional):**
```json
{
  "timestamp": "ISO-8601",
  "author": "tu-nombre",
  "type": "note",
  "message": "Avance: [%]. Hallazgo: [si aplica]."
}
```

## Protocolo de handoff

Cuando terminas producción:

1. **Actualiza roadmap-status.md:**
   ```json
   {
     "timestamp": "ISO-8601",
     "ticket": "TICKET-ID",
     "event": "completed",
     "runner": "tu-nombre",
     "model": "tu-especialidad",
     "message": "Producción completada. Esperando agent_review.",
     "logFile": "ruta-del-log-si-aplica"
   }
   ```

2. **Registra entregable en deliveries/:**
   - Nombra: `[TICKET-ID]_v1.[ext]`
   - Copia o resumen del trabajo producido.

3. **Escribe en comments/[TICKET-ID].jsonl:**
   ```json
   {
     "timestamp": "ISO-8601",
     "author": "tu-nombre",
     "type": "completion",
     "message": "Producción completada. Archivos: [lista]. Cambios: [resumen]. Listos para revisión."
   }
   ```

4. **No marques como completado.** Espera revisión.

## Protocolo de QA (agent_review)

**Revisor especialista (Claude Code o Codex, según tipo):**

1. Lee roadmap.md del ticket (AC específicamente).
2. Lee entregable en deliveries/[TICKET-ID]_v1.[ext].
3. Lee comments/[TICKET-ID].jsonl para contexto.
4. Valida:
   - ✓ ¿Cumple AC 100%?
   - ✓ ¿Hay coherencia con decisiones aprobadas (DECISION_LOG.md)?
   - ✓ ¿Hay contradicciones con PROJECT_RULES.md?
   - ✓ ¿Archivos modificados están en "Files allowed to change"?
   - ✓ ¿No hay invención de datos (si es documentación)?
   - ✓ ¿Viabilidad técnica (si es código)?
   - ✓ ✓ ¿Viabilidad operativa (si es documentación)?

5. **Resultado:**
   - ✓ **Aprueba:** Actualiza roadmap-status.md a "human_review".
   - ✗ **Rechaza:** Actualiza a "blocked" o "rejected" + registra razón en comments.

**Entrada en roadmap-status.md (si aprueba):**
```json
{
  "timestamp": "ISO-8601",
  "ticket": "TICKET-ID",
  "event": "in_progress",
  "runner": "revisor-nombre",
  "model": "agent_review",
  "message": "Agent review aprobado. Pasando a human_review."
}
```

**Entrada si rechaza (blocked):**
```json
{
  "timestamp": "ISO-8601",
  "ticket": "TICKET-ID",
  "event": "blocked",
  "runner": "revisor-nombre",
  "model": "agent_review",
  "message": "Agent review: [razón concisa]",
  "blockerType": "agent-review-rejection"
}
```

## Protocolo de aprobación humana (human_review)

**Andrés o fundadora (según ticket):**

1. Lee roadmap.md (objetivo, AC, scope).
2. Lee deliveries/[TICKET-ID]_v1.[ext].
3. Lee comments/[TICKET-ID].jsonl (historial completo).
4. Lee entrada agent_review en roadmap-status.md.
5. Valida:
   - ✓ ¿Alineado con visión y decisiones aprobadas?
   - ✓ ✓ ¿Negociación con cliente si aplica (presupuesto, timeline)?
   - ✓ ✓ ✓ ¿Autorización de fundadora si aplica (marca, avatar, datos)?
   - ✓ ✓ ✓ ✓ ¿No hay riesgo estratégico, reputacional, regulatorio?

6. **Resultado:**
   - ✓ **Aprueba:** Actualiza roadmap-status.md a "completed".
   - ✗ **Rechaza:** Actualiza a "rejected" + registra razón en comments.

**Entrada si aprueba (completed):**
```json
{
  "timestamp": "ISO-8601",
  "ticket": "TICKET-ID",
  "event": "completed",
  "runner": "andrés",
  "model": "human_review",
  "message": "Aprobado. Ticket finalizado."
}
```

## Protocolo de cierre

Cuando ticket está "completed":

1. **Actualizar memory/CURRENT_STATE.md:**
   - Agregar ticket a sección "Tickets completados".
   - Actualizar stage si aplica.
   - Actualizar próximo paso recomendado.

2. **Guardar en timeline/:**
   - Crear archivo `[TICKET-ID]_completed_[fecha].md` con breve resumen.

3. **Comunicar al equipo:**
   - Registrar en memory para visibilidad.

4. **Ticket cerrado.** No reabre sin decisión de Andrés.

## Protocolo de reapertura

Si ticket marcado "completed" necesita cambio:

1. Escala a Andrés.
2. Andrés remueve estado "completed" en roadmap-status.md.
3. Registra razón en comments/[TICKET-ID].jsonl.
4. Vuelve a "in_progress" (reinicia con productor).
5. Requiere revisión completa nuevamente.

## Protocolo de bloqueo

**Cuándo bloquear:**

- Dependencia no completada (verifica roadmap-status.md).
- Información faltante (marca con `(andres confirma)`).
- Contradicción con decisiones aprobadas.
- Escala detecta gap irresoluble.

**Entrada en roadmap-status.md:**
```json
{
  "timestamp": "ISO-8601",
  "ticket": "TICKET-ID",
  "event": "blocked",
  "runner": "quien-bloquea",
  "model": "motivo",
  "message": "Bloqueado por: [razón concisa]",
  "blockerType": "dependencia | información-faltante | contradicción"
}
```

**Entrada en comments/[TICKET-ID].jsonl:**
```json
{
  "timestamp": "ISO-8601",
  "author": "quien-bloquea",
  "type": "blocked",
  "message": "Bloqueado: [razón]. Requiere: (andres confirma). Escalación a: Andrés."
}
```

**Cómo desbloquear:**
1. Andrés resuelve bloqueo (confirma información, aprueba decisión, etc).
2. Registra resolución en DECISION_LOG.md si es decisión.
3. Actualiza roadmap-status.md a "ready".
4. Productor reinicia ticket.

## Protocolo de fallo

**Cuándo fallar:**

- Error técnico irrecuperable (p.e. herramienta no disponible).
- Información no encontrada tras búsqueda exhaustiva.
- Limitación técnica no prevista.

**Entrada en roadmap-status.md:**
```json
{
  "timestamp": "ISO-8601",
  "ticket": "TICKET-ID",
  "event": "failed",
  "runner": "quien-falla",
  "model": "tipo-error",
  "message": "Falló por: [razón concisa]",
  "logFile": "ruta/error.log"
}
```

**Entrada en comments:**
```json
{
  "timestamp": "ISO-8601",
  "author": "quien-falla",
  "type": "blocked",
  "message": "Ejecución fallida: [razón técnica]. Log: [referencia]. Escalación: Andrés decide reintentar o rechazar."
}
```

**Cómo recuperar:**
1. Andrés decide: reintentar o rechazar.
2. Si reintentar: marca "ready", asigna nuevo productor.
3. Si rechazar: marca "rejected", registra enseñanza en memory.

## Protocolo de actualización de archivos

### roadmap-status.md (ledger)

- **Siempre append.** Jamás sobrescribir línea previa.
- **Cada cambio de estado:** Nueva entrada JSON.
- **Formato:** `{timestamp ISO, ticket, event, runner, model, message, logFile?, blockerType?, resultingState?}`

### deliveries/[TICKET-ID]_v1.[ext]

- **Guardar tras entrega:** Copia exacta del entregable.
- **Versionado:** v1, v2, si requiere retrabajar.
- **Nombrado:** `[TICKET-ID]_v[N].[extensión]`

### reviews/[TICKET-ID]_review_[fecha].md

- **Guardar tras revisión:** Evidencia de validación.
- **Contenido:** Checklist de AC, hallazgos, recomendación.
- **Nombrado:** `[TICKET-ID]_review_[YYYY-MM-DD].md`

### memory/CURRENT_STATE.md

- **Actualizar al cierre de stage:** Tickets completados, próximo objetivo.
- **Nunca sobrescribir secciones.** Agregar actualización con timestamp.
- **Responsable:** Productor o Andrés al marcar completado.

### DECISION_LOG.md

- **Solo Andrés escribe.** Registra decisiones nuevas o cambios de decisiones previas.
- **Formato:** DEC-XXX con Estado, Fecha, Decisión, Motivo, Restricción.
- **Referencia desde tickets:** Cita DEC cuando un ticket está limitado por decisión.

### timeline/[TICKET-ID]_completed_[fecha].md

- **Guardar tras completado:** Breve narrativa de qué se logró.
- **Formato simple:** Título, objetivo, entregable, hallazgos, impacto.
- **Nombrado:** `[TICKET-ID]_completed_[YYYY-MM-DD].md`

## Estados oficiales y transiciones (tabla)

| Estado Actual | Siguiente | Quién decide | Condición |
|---------------|-----------|-------------|-----------|
| pending | ready | Sistema | Deps completadas |
| ready | in_progress | Productor | Inicia |
| in_progress | agent_review | Productor | Termina |
| agent_review | human_review | Revisor | Aprueba técnica |
| agent_review | blocked | Revisor | Encuentra gaps |
| agent_review | rejected | Revisor | Rechaza |
| human_review | completed | Andrés | Aprueba final |
| human_review | blocked | Andrés | Requiere info |
| human_review | rejected | Andrés | Rechaza |
| blocked | ready | Andrés | Resuelve bloqueo |
| failed | ready | Andrés | Autoriza reintentar |
| rejected | ready | Productor | Retrabaja |

## Definición operativa de "completado"

Un ticket está completado cuando:

1. ✓ Productor entregó en archivos asignados.
2. ✓ Revisor especialista aprobó (agent_review).
3. ✓ Auditor (si aplica) validó AC.
4. ✓ Andrés o fundadora aprobó (human_review).
5. ✓ Entrada "completed" en roadmap-status.md.
6. ✓ Artefacto en deliveries/[TICKET-ID]_v1.[ext].
7. ✓ Resumen en timeline/[TICKET-ID]_completed_[fecha].md.
8. ✓ memory/CURRENT_STATE.md actualizado.

Sin todos: ticket regresa a "blocked" o "rejected".

## Checklist obligatorio por ticket

### Antes de iniciar

- [ ] Leí roadmap.md línea por línea.
- [ ] Entiendo AC.
- [ ] Validé dependencias (completadas).
- [ ] No hay información faltante.
- [ ] No hay contradicciones con DECISION_LOG.md.
- [ ] Creé entrada "in_progress" en roadmap-status.md.

### Antes de entregar

- [ ] Entregable cumple 100% AC.
- [ ] Archivos modificados están en "Files allowed to change".
- [ ] Sin invención de datos.
- [ ] Guardé en deliveries/[TICKET-ID]_v1.[ext].
- [ ] Escribí en comments/[TICKET-ID].jsonl.

### Antes de marcar completado

- [ ] Agent review aprobó.
- [ ] Human review aprobó.
- [ ] Entrada "completed" en roadmap-status.md.
- [ ] Resumen en timeline/.
- [ ] memory/CURRENT_STATE.md actualizado.

## Ejemplo completo: MKT-005 (Buyer persona)

**Fase 1: Intake**
- Status: pending → ready (STR-001 + MKT-004 completados).
- Entrada: roadmap-status.md event "queued".

**Fase 2: Selección**
- Claude Code selecciona.
- Lee roadmap.md: objetivo, scope (buyer persona caracterizado), AC (datos, estructura, tono).
- Lee DECISION_LOG.md: DEC-001 (unidad única), buyer persona será base para embudos.

**Fase 3: Ejecución**
- Claude Code inicia: roadmap-status.md event "in_progress", runner "claude-code", model "estrategia".
- Escribe docs/02_market/BUYER_PERSONAS.md: demografía, NDP, eneatipo, miedos, deseos, gatillos.
- Consulta con fundadora (comentario en comments/MKT-005.jsonl).
- Descubre dato faltante sobre sector de fundadora: registra "(andres confirma)".
- Termina: roadmap-status.md event "completed" (productor), deliveries/MKT-005_v1.md.

**Fase 4: Agent Review**
- Codex revisa: ¿viabilidad de servir este buyer? ¿segmentación clara?
- Aprueba: roadmap-status.md event "in_progress", runner "codex", message "Agent review OK".

**Fase 5: Human Review**
- Andrés + Fundadora revisan.
- Fundadora valida: "NDP y lenguaje match con conversaciones reales".
- Andrés aprueba: roadmap-status.md event "completed", runner "andres", message "Buyer persona aprobado".

**Fase 6: Cierre**
- Actualizar memory/CURRENT_STATE.md: MKT-005 completado.
- Crear timeline/MKT-005_completed_2026-07-25.md.

## Ejemplo completo: Ticket técnico (WEB-002)

**Fase 1: Intake**
- Status: pending → ready (FUN-002, TECH-001 completados).

**Fase 2: Selección**
- Codex selecciona.
- Lee roadmap.md: objetivo (sitio funcional), scope (pages, forms, analytics).
- Lee DECISION_LOG.md: DEC-003 (sin plataforma propia).

**Fase 3: Ejecución**
- Codex inicia: roadmap-status.md event "in_progress", runner "codex", model "desarrollo-web".
- Desarrolla en tools/tinto-web/ o src/.
- Pruebas locales.
- Descubre que feature X requiere decisión en TECH-001 (no prevista).
- Escala a Claude Code: "¿qué herramienta para analytics?" → Claude Code escala a Andrés.
- Andrés responde en DECISION_LOG.md (DEC-006).
- Codex continúa.
- Termina: roadmap-status.md event "completed" (productor), deliveries/WEB-002_v1_code.zip.

**Fase 4: Agent Review**
- Claude Code revisa: ¿alineado con marca? ¿copy coherente? ¿funnel claro?
- Aprueba: roadmap-status.md event "in_progress", runner "claude-code", message "Coherencia estratégica OK".

**Fase 5: Human Review**
- Andrés revisa: ¿funciona? ¿cliente aprobado?
- Prueba en staging.
- Aprueba: roadmap-status.md event "completed", runner "andres".

**Fase 6: Cierre**
- Deploy a producción.
- timeline/WEB-002_completed_2026-07-30.md.
- memory/CURRENT_STATE.md: Stage 5 avanzado.
