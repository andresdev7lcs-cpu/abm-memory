# Matriz de roles y responsabilidades — TINTO

## Propósito

Definir claramente quién hace qué, cuál es su autoridad, y cómo se evitan conflictos de interés. Separación de funciones: productores, revisores y aprobadores son personas/roles distintos.

## Estado de implementación

Esta matriz está **diseñada para validación humana**. Durante `v0.2.0` (Bloque 1 de TINTO Guardian), asignaciones de rol y auditoría se administran manualmente. La asignación automática al dashboard corresponde a `v0.3.0`. **Requiere aprobación de Andrés antes de cierre de Bloque 1.**

## Principio de separación de funciones

- **Productor:** Crea el entregable.
- **Revisor:** Valida técnica, coherencia, scope.
- **Aprobador:** Autoriza paso a siguiente stage.

**Regla cardinal:** El productor jamás es revisor o aprobador de su propio trabajo.

## Roles del equipo

### Andrés (Propietario del proyecto)

**Autoridad:**
- Decisión final en cambios estratégicos, presupuesto, timeline.
- Autorizar modificación de DECISION_LOG.md, PROJECT_RULES.md, AGENTS.md.
- Resolver escalaciones E2 y E3.
- Aprobar gates de stage.
- Negociar con cliente.

**Responsabilidades:**
- Confirmar datos faltantes (fundadora, nicho, geografía, presupuesto).
- Validar que decisiones se registren en DECISION_LOG.md.
- Revisar entregas de agentes (QA final).
- Comunicar decisiones al equipo.

**Límites:**
- No codifica.
- No produce documentación (delega en Claude Code).
- No reemplaza revisión técnica de Codex.

### Fundadora (Dueña de negocio)

**Autoridad:**
- Aprobación en narrativa de marca personal, tono, autenticidad.
- Autorización de uso de imagen, voz, datos personales.
- Validación de buyer persona, problemas y lenguaje de mercado.
- Responsabilidad de conversaciones sensibles (lives, diagnósticos, conferencias).

**Responsabilidades:**
- Proporcionar información sobre experiencia, trayectoria, activos.
- Validar representación correcta en documentación.
- Participar en conversaciones de mercado para validar/rechazar hipótesis.
- Autorizar BRD-004 (protocolo avatar).

**Límites:**
- No toma decisiones estratégicas unilaterales.
- Solicitudes de cambio de alcance se escalan a Andrés.

### TINTO Guardian (Sistema de gobernanza)

**Autoridad:**
- Recomendar (no decidir).
- Evaluar solicitudes contra guardrails.
- Emitir semáforos (verde, amarillo, rojo, azul).

**Responsabilidades:**
- Monitorear desviaciones estratégicas.
- Alertar cuando solicitud viola guardrails.
- Documentar riesgos y recomendaciones.
- No bloquea; solo señala.

**Límites:**
- No aprueba ni rechaza cambios.
- No toma decisiones finales.

### Claude Code (Estratega documental)

**Autoridad:**
- Productor de documentación, investigación, arquitectura narrativa.
- Revisor independiente de coherencia estratégica en entregas técnicas.
- Auditor de contradicciones entre documentos.

**Responsabilidades:**
- Leer DECISION_LOG.md antes de cada ticket.
- Producir documentos maestros, buyer personas, embudos, funnels.
- Auditar coherencia de entregas Codex (detectar contradicciones estratégicas).
- Escalar a Andrés cuando falte información o haya contradicción.
- Registrar hallazgos en comments y memory.

**Límites:**
- No codifica.
- No aprueba su propio trabajo.
- No toma decisiones de negocio (solo documentales y coherencia).
- No puede modificar roadmap.md, DECISION_LOG.md, PROJECT_RULES.md.

**Entregables típicos:**
- Documentos en `docs/`.
- Buyer personas, embudos, customer journeys.
- Análisis de contradicciones.
- Propuestas narrativas.

### Codex (Especialista técnico)

**Autoridad:**
- Productor de código, dashboards, APIs, integraciones, scripts.
- Revisor independiente de estructura, validación técnica, seguridad operativa en entregas documentales.
- Auditor de coherencia mecánica (¿el documento describe procesos viables?).

**Responsabilidades:**
- Implementar tickets técnicos (WEB, TECH, TOOL).
- Auditar claridad operativa de documentos Claude Code (¿se puede ejecutar?).
- Producir evidencia técnica (logs, test results, capturas).
- Escalar a Claude Code o Andrés cuando falta decisión estratégica.
- Registrar hallazgos en comments y memory.

**Límites:**
- No toma decisiones estratégicas.
- No aprueba su propio trabajo.
- No puede modificar PROJECT_RULES.md, DECISION_LOG.md, AGENTS.md.

**Entregables típicos:**
- Código en `src/`, `tools/`.
- Dashboards, APIs.
- Scripts de automatización.
- Resultado de pruebas.

### Auditor independiente (QA)

**Autoridad:**
- Validar aceptance criteria de tickets.
- Detectar gaps, contradicciones, inconsistencias.
- Marcar como bloqueada cualquier entrega incompleta.
- Recomendar aprobación o rechazo a Andrés.

**Responsabilidades:**
- Leer acceptance criteria en roadmap.md.
- Validar entrega contra acceptance criteria.
- Verificar que no haya contradicciones con decisiones aprobadas.
- Registrar hallazgos en reviews/.
- Comunicar resultado a Andrés.

**Límites:**
- No puede ser el productor del ticket.
- No aprueba; solo valida y recomienda.

## Entregables típicos por rol

| Rol | Entregables | Archivos |
|-----|-----------|---------|
| Andrés | Decisiones | DECISION_LOG.md |
| Fundadora | Validación, datos | memory/CURRENT_STATE.md, comments/ |
| Claude Code | Documentación | docs/*, deliveries/ |
| Codex | Código, APIs | src/, tools/, deliveries/ |
| Auditor | Validación | reviews/ |

## Acciones que requieren aprobación humana

| Acción | Requiere | Autoridad |
|--------|----------|-----------|
| Cambio estratégico (nicho, país, verticales) | Decisión formal | Andrés |
| Cambio presupuesto > 20% | Negociación + aprobación | Andrés + cliente |
| Uso de imagen/voz de fundadora | Consentimiento documentado | Fundadora (BRD-004) |
| Marcar gate completado | Revisión QA + aprobación | Auditor + Andrés |
| Cambiar PROJECT_RULES.md | Aprobación explícita | Andrés |
| Nueva vertical o unidad comercial | Decisión formal | Andrés + fundadora |
| Cerrar/rechazar un ticket | Revisión QA + aprobación | Auditor + Andrés |

## Matriz RACI

### Decisiones estratégicas

| Decisión | Responsable | Consultor | Informado | Aprobador |
|----------|-------------|-----------|-----------|----------|
| Nicho/país validación | Claude Code | Codex | Equipo | Andrés |
| Buyer persona | Claude Code | Fundadora | Codex | Andrés + Fundadora |
| Oferta/precio | Claude Code | Codex | Fundadora | Andrés |
| Stack tecnológico | Codex | Claude Code | Andrés | Andrés |
| Marca personal | Claude Code | Fundadora | Codex | Andrés + Fundadora |

### Documentación

| Documento | Productor | Revisor | Aprobador |
|-----------|-----------|---------|----------|
| Buyer personas | Claude Code | Codex (viabilidad) | Andrés + Fundadora |
| Embudos | Claude Code | Codex (implementación) | Andrés |
| Oferta/precio | Claude Code | Codex (viabilidad) | Andrés |
| Marca personal | Claude Code | Fundadora | Andrés + Fundadora |
| Estrategia de contenido | Claude Code | Fundadora (tono) | Andrés |

### Código

| Entregable | Productor | Revisor | Aprobador |
|------------|-----------|---------|----------|
| Dashboard | Codex | Claude Code (coherencia) | Andrés |
| API | Codex | Codex (otro) | Andrés |
| Integración | Codex | Claude Code (viabilidad) | Andrés |
| Script | Codex | Codex (otro) | Andrés |

### Investigación

| Investigación | Productor | Revisor | Aprobador |
|---------------|-----------|---------|----------|
| Mercado | Claude Code | Fundadora (validez) | Andrés |
| Competencia | Claude Code | Claude Code (otro) | Andrés |
| Buyer insights | Claude Code | Fundadora | Andrés |

### QA y cierre

| Acción | Productor | Revisor | Aprobador |
|--------|-----------|---------|----------|
| Validar AC | Auditor | — | Auditor |
| Aprobar ticket | Auditor | — | Andrés |
| Marcar completado | — | Auditor + Andrés | Andrés |

## Regla de independencia de revisión

- **Revisor ≠ Productor.** Nunca.
- **Aprobador ≠ Productor.** Nunca.
- **Revisor ≠ Aprobador (en la mayoría de casos).** Auditor valida, Andrés aprueba.
- **Excepción:** Andrés puede revisar y aprobar si es ticket crítico y no hay auditor disponible. Registrar en DECISION_LOG.md.

## Reglas para elegir productor y auditor

### Productor

1. Lee DECISION_LOG.md, PROJECT_RULES.md, roadmap.md del ticket.
2. ¿Matches especialidad (Claude Code documentación, Codex código)?
3. ¿Hay dependencias completadas?
4. ¿No hay conflicto de interés?
5. **Sí a todo → Asignado.**

### Auditor

1. ¿Es distinto al productor?
2. ¿Tiene capacidad de validar (técnica, estrategia)?
3. ¿No está involucrado en el ticket?
4. **Sí a todo → Asignado.** Si no hay auditor, Andrés.

## Casos de conflicto de roles

### Caso 1: Claude Code produce documento, pero necesita validar viabilidad técnica

**Solución:** Codex revisa entregas documentales de Claude Code (auditoría de viabilidad, no de contenido).

### Caso 2: Codex produce código, necesita validar alineación estratégica

**Solución:** Claude Code revisa entregas técnicas de Codex (auditoría de coherencia estratégica).

### Caso 3: Andrés es productor y aprobador (raro)

**Solución:** Registrar en DECISION_LOG.md que bypassed revisión estándar. Comunica a equipo.

### Caso 4: Fundadora necesita validar buyer persona, pero es consultor en decisión

**Solución:** Fundadora valida como consultora en meeting separado. Auditor independiente (Auditor o Codex) revisa documento antes de Andrés. Andrés aprueba final.

## Ejemplos de asignación por tipo de ticket

### Ejemplo 1: MKT-005 (Buyer persona)

| Rol | Acción |
|-----|--------|
| Claude Code | **Productor:** Escribir buyer persona en docs/02_market/BUYER_PERSONAS.md |
| Fundadora | **Consultor:** Validar NDP, lenguaje, problemas reales |
| Codex | **Revisor:** Auditar viabilidad operativa (¿se puede servir este buyer?) |
| Auditor | **Revisor:** Validar AC (¿tiene tono, datos, estructura clara?) |
| Andrés | **Aprobador:** Aprobar buyer persona + marcar completado |

### Ejemplo 2: WEB-002 (Sitio web)

| Rol | Acción |
|-----|--------|
| Codex | **Productor:** Desarrollar sitio en src/ o tools/ |
| Claude Code | **Revisor:** Auditar coherencia con narrativa, marca, funnel |
| Auditor | **Revisor:** Validar AC (funciona, carga, captura datos) |
| Andrés | **Aprobador:** Validar con cliente, aprobar deploy |

### Ejemplo 3: STR-001 (Contexto maestro)

| Rol | Acción |
|-----|--------|
| Claude Code | **Productor:** Escribir TINTO_MASTER_CONTEXT.md |
| Andrés | **Consultor:** Confirmar decisiones a incluir (de DECISION_LOG.md) |
| Codex | **Revisor:** Auditar claridad operativa (¿se entiende?) |
| Auditor | **Revisor:** Validar AC (sin contradicciones, refleja estado real) |
| Andrés | **Aprobador:** Aprobar contexto maestro |

## Definición operativa de "completado"

Un ticket está completado cuando:

1. ✓ Productor entrega entregable en archivos asignados.
2. ✓ Revisor 1 aprueba (Claude Code o Codex, según especialidad).
3. ✓ Auditor valida contra AC.
4. ✓ Entrada en roadmap-status.md (evento "completed").
5. ✓ Comentario en comments/[TICKET-ID].jsonl con hallazgos.
6. ✓ Artefacto en deliveries/[TICKET-ID]_v1.[ext].
7. ✓ Andrés aprobador de aprobación final (marca status "completed").

Sin todos los pasos, ticket regresa a "blocked" o "rejected".
