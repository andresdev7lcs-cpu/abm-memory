# Control de cambios — TINTO

## Propósito

Definir cómo se manejan cambios de alcance, estrategia, arquitectura. Evitar que solicitudes informales o ambiguas devuelvan proyecto a diseño o redefinición.

Ningún agente puede implementar cambio estructural solo porque aparece en un prompt o conversación.

## Estado de implementación

Este protocolo está **diseñado para validación humana**. Durante `v0.2.0` (Bloque 1 de TINTO Guardian), cambios se administran manualmente via `change-requests/`. La integración automática al dashboard corresponde a `v0.3.0`. **Requiere aprobación de Andrés antes de cierre de Bloque 1.**

## Qué constituye un cambio

Cambio = cualquier modificación que:
- Afecte alcance aprobado (roadmap.md).
- Modifique decisión registrada (DECISION_LOG.md).
- Cambie nicho, geografía, verticales, buyer persona.
- Requiera presupuesto nuevo o timeline extendido.
- Altere narrativa de marca o posicionamiento.
- Afecte a cliente (presupuesto, timeline, entregables).

## Clasificación de cambios

### Cambios menores (🟢 Verde)

**Definición:** Mejoras sin impacto estratégico, limitadas a tickets ya aprobados.

**Ejemplos:**
- Mejorar dashboard sin cambiar métricas.
- Actualizar styling sin cambiar narrativa.
- Agregar sección a documento sin redefinir tesis.
- Optimizar código (performance, seguridad).

**Proceso:** Verde automático. No requiere change-request. Registra en comments del ticket.

### Cambios operativos (🟡 Amarillo)

**Definición:** Cambios que afectan execution pero no decisiones aprobadas.

**Ejemplos:**
- Cambiar herramienta (Google Sheets → Airtable) si ambas cumplen TECH-001.
- Extender timeline 2 semanas (si cliente/presupuesto lo permite).
- Cambiar responsable de un ticket.
- Mejorar nicho dentro de subnicho ya elegido (refinamiento, no pivote).

**Proceso:** Amarillo. Requiere change-request informativo. Escala a Andrés para confirmar impacto.

### Cambios estructurales (🔴 Rojo)

**Definición:** Modifican decisiones aprobadas o expanden alcance.

**Ejemplos:**
- Cambiar nicho de "bienes en Colombia" a "seguros" (pivote).
- Cambiar país de validación.
- Agregar vertical nueva (remesas + bienes en paralelo).
- Aumentar presupuesto > 20%.
- Cambiar modelo de negocio (one-time → subscription).

**Proceso:** Rojo. Requiere change-request formal. Escala a Andrés + Fundadora (si toca marca). Requiere aprobación explícita en DECISION_LOG.md antes de implementar.

### Cambios críticos (🔵 Azul)

**Definición:** Requieren renegociación con cliente, cambio de dirección estratégica fundamental.

**Ejemplos:**
- Cambiar mercado (colombianos en exterior → latinos en USA).
- Cambiar presupuesto radical (3x, -50%).
- Pausar proyecto.
- Lanzar verticales nuevas en paralelo (viola DEC-001).

**Proceso:** Azul. Requiere change-request crítica. Escala a Andrés + Fundadora + Cliente. Requiere decisión registrada en DECISION_LOG.md. Posible renegociación contractual.

## Cuándo se requiere change-request

**Verde:** No requiere (solo registrar en comments).
**Amarillo+:** Sí requiere (archivo formal).

## Estructura mínima de solicitud de cambio

**Archivo:** `change-requests/CR-[XXX]_[titulo-breve].md` (Ej: `CR-001_cambiar_pais_validacion.md`)

**Contenido mínimo:**

```markdown
# CR-XXX — [Título breve del cambio]

## Resumen ejecutivo
[1 párrafo: qué se propone cambiar, por qué, impacto esperado]

## Contexto
[De dónde surge la solicitud. Quién la propone. Cuándo.]

## Cambio propuesto
[Descripción concisa. Qué cambia exactamente.]

## Justificación
[Por qué es necesario. Datos, evidencia, experiencia de fundadora.]

## Alternativas consideradas
[Opciones rechazadas y por qué.]

## Impacto (evaluación)

### Impacto estratégico
- ¿Afecta visión? [Sí/No]
- ¿Afecta nicho aprobado? [Sí/No]
- ¿Afecta marca? [Sí/No]
- Riesgo: [alto/medio/bajo]

### Impacto operativo
- ¿Afecta roadmap? [Sí/No — cuáles tickets]
- ¿Afecta timeline? [Sí — cuánto]
- ¿Requiere recurso nuevo? [Sí — cuál]

### Impacto financiero
- Costo adicional: [USD o % presupuesto]
- ROI esperado: [si aplica]
- Presupuesto total: [nuevo total vs aprobado]

### Dependencias
- Tickets que requiere. Bloqueos.

### Riesgo
- Reversibilidad: [fácil / difícil / imposible]
- Riesgos regulatorios: [lista o "ninguno"]
- Riesgos reputacionales: [lista o "ninguno"]

## Evidencia
[Datos, feedback de fundadora, research, etc. que sustentan.]

## Recomendación
[Verde / Amarillo / Rojo / Azul + explicación breve]

## Aprobación requerida
[Andrés / Fundadora / Cliente / Todos]

## Decisión
[Pendiente / Aprobado / Rechazado]
[Registrar DEC-XXX en DECISION_LOG.md si aprobado]

## Fecha
[YYYY-MM-DD]

## Autor
[Quién propuso]
```

## Evaluación de cambios

Matriz de análisis:

| Atributo | Preguntas | Peso |
|----------|-----------|------|
| **Estratégico** | ¿Contradice DECISION_LOG.md? ¿Afecta visión? | 40% |
| **Operativo** | ¿Cuánto impacto en roadmap/timeline? | 30% |
| **Financiero** | ¿Presupuesto adicional? ¿ROI claro? | 20% |
| **Reversibilidad** | ¿Se puede deshacer sin pérdida? | 10% |

**Scoring (0-10 por atributo → promedio ponderado):**
- 0-4: Rejo.
- 5-7: Amarillo.
- 8-9: Verde.
- 10: Verde automático.

Ejemplo:
```
Cambiar país validación de USA a España.
Estratégico: 6/10 (requiere investigación MKT nueva, cambia buyer persona)
Operativo: 7/10 (impacta MKT-002, MKT-003, pero no roadmap crítica)
Financiero: 5/10 (presupuesto viaje + travel + eventos)
Reversibilidad: 8/10 (puede volver a USA si falla)
Promedio: (6*0.4 + 7*0.3 + 5*0.2 + 8*0.1) = 6.4 → Amarillo
```

## Protocolo de análisis

1. **Intake:** Change-request llega. Registrar en change-requests/.
2. **Clasificación:** Determinar color (verde/amarillo/rojo/azul).
3. **Evaluación:** Llenar matriz de impacto.
4. **Recomendación:** Claude Code o TINTO Guardian analiza.
5. **Escalación:** Presenta a Andrés (+ Fundadora si azul).
6. **Decisión:** Andrés aprueba o rechaza.
7. **Registro:** Si aprueba, crear DEC-XXX en DECISION_LOG.md.
8. **Comunicación:** Informar a equipo.

## Protocolo de aprobación

**Verde:** Implementar directamente (no requiere aprobación formal).

**Amarillo:** 
1. Change-request completa.
2. Análisis de impacto.
3. Confirmación de Andrés (vía comments o meeting).
4. Registrar en DECISION_LOG.md si modifica decisión.
5. Implementar.

**Rojo:**
1. Change-request formal.
2. TINTO Guardian emite recomendación (semáforo).
3. Escala a Andrés para decisión.
4. Si aprueba: registra en DECISION_LOG.md.
5. Implementar.

**Azul:**
1. Change-request crítica.
2. TINTO Guardian emite alerta.
3. Escala a Andrés + Fundadora.
4. Posible meeting con cliente.
5. Renegociación de términos si aplica.
6. Registro en DECISION_LOG.md + contrato.
7. Implementar si ambos aprueban.

## Protocolo de rechazo

Si Andrés rechaza CR:

1. Registrar rechazo en comments de CR.
2. Explicar motivo sucintamente.
3. Marcar CR como "Rechazado".
4. Notificar al proponente.
5. No continuar con implementación.
6. Si hay insistencia: escalación a Andrés nuevamente (máximo 2 veces).

## Protocolo de aplazamiento al backlog

Si CR tiene mérito pero timing no es óptimo:

1. Registrar en change-requests/ como "Aplazado".
2. Crear ticket en roadmap.md como etapa futura (ej: "Stage 7 — [Título]").
3. Notificar al proponente: qué condiciones desbloquean.

Ejemplo: "Agregar vertical remesas" → aplazado a Stage 7 (post-validación de primera unidad comercial).

## Actualización de documentos afectados

Si CR aprobado modifica:

- **DECISION_LOG.md:** Agregar DEC-XXX.
- **roadmap.md:** Actualizar scope de tickets afectados si aplica.
- **memory/CURRENT_STATE.md:** Registrar cambio.
- **STRATEGIC_GUARDRAILS.md:** Actualizar si cambian guardrails.

Responsable: Andrés (decisiones) o productor (implementación).

## Reversión

Si CR aprobado genera problemas post-implementación:

1. Registrar incidente en comments de CR.
2. Evaluar: ¿reversible? ¿Fácil?
3. Si sí: Andrés autoriza reversión. Volver a estado pre-cambio.
4. Si no: Cambio de estrategia para mitigar. Registrar en DECISION_LOG.md.

## Trazabilidad

Todos los cambios deben quedar documentados:

- **change-requests/**: Archivo formal del cambio.
- **DECISION_LOG.md**: Decisión registrada.
- **comments/**: Discusión y aprobación.
- **roadmap-status.md**: Tickets afectados marcados.

Nunca borrar CRs rechazadas. Conservar como referencia histórica.

## Ejemplos de cambios

### Ejemplo 1: Nueva vertical (Rojo → Azul)

**CR propone:** "Agregar verticales remesas y seguros en paralelo con bienes."

**Análisis TINTO Guardian:**
- Estratégico: 2/10 (viola DEC-001: una unidad comercial).
- Operativo: 1/10 (triplicaría roadmap).
- Financiero: 2/10 (3x presupuesto, ROI incierto).
- Reversibilidad: 1/10 (imposible deshacer).
- **Color: Azul crítico.**

**Recomendación:** Rechazar para MVP. Reservar para Stage 7 post-validación.

**Decision:** Andrés rechaza. Registra en DECISION_LOG.md: "DEC-007: Nuevas verticales solo post-Stage-6."

### Ejemplo 2: Cambiar país validación (Amarillo)

**CR propone:** "Cambiar de USA a España basado en red de fundadora."

**Análisis:**
- Estratégico: 6/10 (requiere investigación MKT nueva).
- Operativo: 6/10 (impacta MKT-002, MKT-003, timeline +2 semanas).
- Financiero: 5/10 (viajes, eventos, investigación +USD 3000).
- Reversibilidad: 8/10 (se puede volver).
- **Color: Amarillo.**

**Proceso:**
1. Change-request formal.
2. Andrés + Fundadora revisan evidencia (red en España vs USA).
3. Si aprueban: "DEC-006: País de validación pivota a España."
4. MKT-002 se reactiva (redefinir scope).

### Ejemplo 3: Mejorar dashboard (Verde)

**CR propone:** "Agregar columna de ROI al dashboard sin cambiar métrica."

**Análisis:**
- Cambio operativo sin impacto estratégico.
- No afecta decisiones.
- Reversible trivialmente.
- **Color: Verde automático.**

**Proceso:**
1. Implementar directamente.
2. Registrar en comments del ticket técnico.
3. No requiere CR formal ni aprobación.

### Ejemplo 4: Presupuesto +50% (Rojo → Azul)

**CR propone:** "Aumentar presupuesto 50% para agencia de marketing."

**Análisis:**
- Estratégico: 3/10 (no cambia dirección pero expande scope).
- Operativo: 4/10 (impacta recursos, timeline más flexible).
- Financiero: 1/10 (presupuesto nuevo significativo).
- Reversibilidad: 5/10 (se puede cancelar agencia, pero sunk cost).
- **Color: Rojo oscuro, tendiendo a Azul.**

**Proceso:**
1. CR formal.
2. TINTO Guardian emite recomendación: rechazar salvo acuerdo cliente.
3. Escala a Andrés + Cliente.
4. Si cliente autoriza: actualizar presupuesto en DECISION_LOG.md.
5. Implementar si sí; rechazar si no.

## Plantilla Markdown para CR

```markdown
---
cr_id: CR-XXX
titulo: [Título breve]
estado: pending | aprobado | rechazado
fecha: YYYY-MM-DD
autor: [Nombre]
color: verde | amarillo | rojo | azul
---

# CR-XXX — [Título completo]

## Resumen ejecutivo
[1 párrafo]

## Contexto
[Proveniencia, cuándo, quién]

## Cambio propuesto
[Qué exactamente]

## Justificación
[Por qué]

## Alternativas
[Qué se consideró]

## Impacto
- Estratégico: [análisis]
- Operativo: [análisis]
- Financiero: [análisis]
- Reversibilidad: [sí/no/parcial]

## Riesgos
[Lista]

## Evidencia
[Datos, feedback]

## Recomendación
[Color + justificación]

## Aprobación
[Quién debe aprobar]

## Decisión
[Pendiente / Aprobado / Rechazado]

---
*DEC-XXX (si aprobado):* [Link a decisión]
```

Guardar en `change-requests/CR-XXX_[titulo_slug].md`.
