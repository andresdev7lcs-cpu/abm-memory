# Puertas de etapa (Stage Gates) — TINTO

## Propósito

Convertir roadmap.md (lista lineal de tickets) en una secuencia de etapas controladas. Cada etapa tiene objetivo, tickets asociados, entregables requeridos, criterios de aprobación. No puede avanzar sin evidencia.

## Diferencias clave

- **Ticket:** Tarea individual (MKT-005: buyer persona).
- **Hito (Milestone):** Conjunto de tickets relacionados que entregan un resultado significativo (p.e. "MKT completo").
- **Stage (Etapa):** Fase del proyecto que agrupa múltiples hitos (p.e. "Stage 1 — Descubrimiento").
- **Gate (Puerta):** Punto de evaluación donde se decide si avanzar a siguiente stage.

## Mapeo: Tickets → Hitos → Stages

```
Stage 0: GOV-001, GOV-002 → Hito "Gobernanza"
Stage 1: STR-001, STR-002, STR-003, MKT-001 a MKT-005 → Hito "Descubrimiento"
Stage 2: BRD-001 a BRD-004, PRD-001 a PRD-003 → Hito "Oferta"
Stage 3: CNT-001 a CNT-003, FUN-001 a FUN-002 → Hito "Funnel"
Stage 4: SAL-001 a SAL-003, TECH-001, WEB-001 a WEB-002 → Hito "Capacidad digital"
Stage 5: VAL-001 a VAL-004 → Hito "Validación comercial"
Stage 6: OPS-001, COST-001 → Hito "Operación"
Stage 7: Escalamiento, nuevas verticales → Futuro
```

## Stage 0 — Gobernanza

**Objetivo:** Estructura operativa base, decisiones iniciales, fuentes de verdad.

**Tickets:**
- GOV-001: Validar estructura inicial (✓ COMPLETED)
- GOV-002: Incorporar fuentes originales (pending)

**Entregables requeridos:**
- Repositorio con carpetas y archivos estructurados (✓).
- Documentos maestros (AGENTS.md, CLAUDE.md, fuentes en source-material/) (✓).
- Decisiones iniciales registradas (DECISION_LOG.md) (✓).

**Evidencia mínima:**
- repository.md + PROJECT_RULES.md + DECISION_LOG.md existentes y completos.
- Datos de fundadora (CV, portfolio, activos) copiados y disponibles.
- [HIPÓTESIS] Propuesta de estructura de gobernanza (este documento).

**Criterios de aprobación:**
- ✓ GOV-001 completado (aprobado por Andrés).
- ✓ GOV-002 completado (datos incorporados, registrados).
- ✓ No hay gaps en fuentes de verdad.

**Bloques típicos:**
- Fundadora no proporciona datos.
- Decisiones iniciales ambiguas (escalación a Andrés).

**Autoridad de aprobación:** Andrés

**Prohibiciones antes de superar Gate 0:**
- No iniciar etapas futuras.
- No tomar decisiones sin registrar en DECISION_LOG.md.

## Stage 1 — Descubrimiento y mercado

**Objetivo:** Validar nicho, geografía, buyer persona. Evidencia de demanda real.

**Tickets:**
- STR-001: Consolidar contexto maestro (pending)
- STR-002: Documentar ecosistema amplio (pending)
- STR-003: Documentar primera unidad comercial (pending)
- MKT-001: Diseñar entrevistas (pending)
- MKT-002: Definir país validación (pending)
- MKT-003: Investigar competidores (pending)
- MKT-004: Priorizar nicho (pending)
- MKT-005: Construir buyer persona (pending)

**Entregables requeridos:**
- docs/00_governance/TINTO_MASTER_CONTEXT.md (v0.2, sin gaps).
- docs/01_ecosystem/TOMO_00_ECOSISTEMA_AMPLIO.md (visión futura, sin confundir con MVP).
- docs/01_ecosystem/TOMO_01_UNIDAD_COMERCIAL_FINANCIERA.md (nicho, subnicho, oferta, operación).
- docs/02_market/ completo: guiones, país seleccionado, competencia, buyer personas.

**Evidencia mínima:**
- Buyer persona detallado basado en (andres confirma) conversaciones reales o datos de fundadora.
- País de validación seleccionado (geografía, acceso, capacidad).
- Matriz competitiva (quién se lleva dinero hoy).
- Nicho priorizado (urgencia, acceso, pago, encaje, viabilidad).
- Contexto maestro sin contradicciones.

**Criterios de aprobación:**
- ✓ STR-001, STR-003 completados (no contradicen).
- ✓ MKT-004 completado (nicho y subnicho elegidos).
- ✓ MKT-005 completado (buyer persona validado con fundadora).
- ✓ [HIPÓTESIS] datos: país, NDP, dolor, disposición de pago.
- ✓ No hay gaps en documentación estratégica.

**Bloques típicos:**
- Datos de fundadora incompletos → (andres confirma).
- Múltiples opciones de nicho sin decisión → escala a Andrés.
- Buyer persona sin validación real → requiere conversaciones.

**Autoridad de aprobación:** Andrés + Fundadora (validación de buyer persona)

**Prohibiciones antes de superar Gate 1:**
- No lanzar publicidad.
- No desarrollar producto/servicio.
- No comprometerse con cliente.
- No activar verticales adicionales.

## Stage 2 — Oferta

**Objetivo:** Definir qué se vende, a quién, por cuánto, con qué promesa.

**Tickets:**
- BRD-001: Arquitectura marca personal + TINTO
- BRD-002: Definir marca personal
- BRD-003: Definir identidad TINTO
- BRD-004: Protocolo avatar IA
- PRD-001: Portafolio inicial de servicios
- PRD-002: Escalera de valor
- PRD-003: Primera oferta comercial

**Entregables requeridos:**
- docs/03_brand/ARQUITECTURA_DE_MARCA.md (dos rieles coherentes).
- docs/03_brand/MARCA_PERSONAL_FUNDADORA.md (brief, trayectoria, autoridad).
- docs/03_brand/IDENTIDAD_TINTO.md (concepto, personalidad, tono).
- docs/03_brand/PROTOCOLO_AVATAR_IA.md (autorización, límites, controles).
- docs/04_products/PORTAFOLIO_DE_SERVICIOS.md (gratuito, entrada, principal, continuidad, premium).
- docs/04_products/ESCALERA_DE_VALOR.md (cada nivel: objetivo, entregable, siguiente paso).
- docs/04_products/OFERTAS_Y_ENTREGABLES.md (promesa, entregables, duración, precio).

**Evidencia mínima:**
- Promesa clara (resumen < 1 minuto).
- Precio definido (USD, modelo).
- Entregables concretos (sesiones, auditorías, guías, etc.).
- Diferenciación vs competencia (matriz).
- Fundadora autoriza marca personal + avatar.

**Criterios de aprobación:**
- ✓ BRD-001, BRD-002, BRD-003 completados (coherencia marca).
- ✓ BRD-004 completado (consentimiento de fundadora documentado).
- ✓ PRD-001, PRD-002, PRD-003 completados (oferta clara).
- ✓ [APROBADO] DEC-002 (marcas dos rieles), DEC-004 (avatar IA).
- ✓ No hay ambigüedad en precio, entregables, duración.

**Bloques típicos:**
- Fundadora no autoriza avatar → no puede avanzar.
- Precio indefinido (requiere decisión de Andrés).
- Oferta confusa o con múltiples opciones no diferenciadas.

**Autoridad de aprobación:** Andrés + Fundadora (marca, avatar, representación)

**Prohibiciones antes de superar Gate 2:**
- No producir contenido sin oferta clara.
- No contactar prospectos (excepto research privado).
- No publicar oferta públicamente.

## Stage 3 — Marca y mensaje

**Objetivo:** Narrativa convincente, contenido de educación, lenguaje comprobado.

**Tickets:**
- CNT-001: Diseñar motor editorial
- CNT-002: Diseñar lead magnets
- CNT-003: Diseñar VSL y eventos

**Entregables requeridos:**
- docs/05_marketing/MOTOR_DE_CONTENIDOS.md (pilares, formatos, canales, CTA, métricas).
- docs/05_marketing/LEAD_MAGNETS.md (PDFs, audios, plantillas, diagnósticos).
- docs/05_marketing/VSL_Y_EVENTOS.md (guiones, narrativa, objeciones, cierre).

**Evidencia mínima:**
- Lead magnet con buyer persona y CTA clara.
- VSL estructura (educación → autoridad → objeciones → CTA).
- Pilares de contenido (3-5 temas recurrentes).
- Métrica de éxito por activo (conversión esperada, ROI).

**Criterios de aprobación:**
- ✓ CNT-001, CNT-002, CNT-003 completados.
- ✓ Lead magnet listo (PDF, audio, whatever).
- ✓ VSL listo para grabar.
- ✓ Fundadora aprueba tono y narrativa.
- ✓ CTA coherente con oferta (Stage 2).

**Bloques típicos:**
- Tono no aprobado por fundadora.
- Lead magnet sin buyer persona clara (de Stage 1).
- VSL sin diferenciación vs competencia.

**Autoridad de aprobación:** Andrés + Fundadora (tono, narrativa)

**Prohibiciones antes de superar Gate 3:**
- No grabar video ni audio sin VSL aprobado.
- No publicar contenido.

## Stage 4 — Funnel y ventas

**Objetivo:** Recorrido del cliente: descubrimiento → conversación → cierre → continuidad.

**Tickets:**
- FUN-001: Diseñar customer journey
- FUN-002: Diseñar funnel inicial
- SAL-001: Diseñar proceso comercial
- SAL-002: Crear guiones diagnóstico/cierre
- SAL-003: Definir CRM

**Entregables requeridos:**
- docs/05_marketing/CUSTOMER_JOURNEYS.md (etapas, creencias, activos, CTA, métricas).
- docs/05_marketing/EMBUDOS_POR_SUBNICHO.md (lead magnet → nutrición → evento/VSL → propuesta → cierre).
- docs/06_sales/PROCESO_COMERCIAL.md (calificación, diagnóstico, propuesta, cierre, seguimiento).
- docs/06_sales/GUIONES_DE_DIAGNOSTICO.md (preguntas, objeciones, cierres).
- docs/06_sales/CRM_Y_SEGUIMIENTO.md (campos, etapas, cadencia, responsables).

**Evidencia mínima:**
- Funnel con 5-7 pasos claros (no improviso).
- Guiones listos para fundadora usar.
- CRM mínimo viable (Airtable, Google Sheet o tercero).
- Métrica de conversión esperada por etapa.

**Criterios de aprobación:**
- ✓ FUN-001, FUN-002, SAL-001, SAL-002, SAL-003 completados.
- ✓ Fundadora aprobó guiones y proceso.
- ✓ CRM está operational (no es template vacío).
- ✓ Cada etapa tiene dueño y métrica.

**Bloques típicos:**
- Funnel con pasos redundantes o confusos.
- Guiones no suenan natural (requiere iteración).
- CRM no configurado.

**Autoridad de aprobación:** Andrés + Fundadora (operación de fundadora)

**Prohibiciones antes de superar Gate 4:**
- No contactar prospectos reales (solo research).

## Stage 5 — Construcción digital

**Objetivo:** Herramientas, integración, automatización mínima. Webinars, email, formularios.

**Tickets:**
- TECH-001: Definir stack tecnológico
- WEB-001: Diseñar arquitectura sitio
- WEB-002: Construir sitio web

**Entregables requeridos:**
- docs/08_costs/ESCENARIOS_DE_INFRAESTRUCTURA.md (dominio, hosting, email, CRM, avatar, analítica).
- Sitio web funcional (landing, páginas de servicio, blog, formulario, email capture).
- Integración básica (email → CRM, form submission → logging).

**Evidencia mínima:**
- Dominio registrado.
- Sitio carga en < 3s.
- Formulario captura nombre + email + teléfono.
- Email automático de bienvenida.
- Analytics básico (Google Analytics).

**Criterios de aprobación:**
- ✓ TECH-001 completado (stack definido, costos claros).
- ✓ WEB-001, WEB-002 completados (sitio funcional).
- ✓ Sitio aprobado por cliente.
- ✓ Testing (funciona en desktop + móvil).
- ✓ No hay secretos en código o config visible.

**Bloques típicos:**
- Sitio sin copy clara (requiere Stage 2 + Stage 3).
- Stack con dependencias no disponibles.
- Performance pobre (optimizar antes).

**Autoridad de aprobación:** Andrés

**Prohibiciones antes de superar Gate 5:**
- No lanzar publicidad paga.

## Stage 6 — Validación comercial

**Objetivo:** Primeros leads, conversaciones reales, primeros clientes pagos.

**Tickets:**
- VAL-001: Preparar lanzamiento de validación (red, contenido, lead magnet, evento)
- VAL-002: Conseguir primeros 100 leads
- VAL-003: Realizar conversaciones calificadas
- VAL-004: Cerrar primeros clientes

**Entregables requeridos:**
- Contenido publicado (LinkedIn, email, sitio web).
- Lead magnet en vivo.
- Primeros 100 leads capturados (registro, segmentación).
- Mínimo 20 conversaciones diagnósticas.
- Mínimo 3-5 clientes pagos + contratos.
- Dashboard de métricas en tiempo real.

**Evidencia mínima:**
- Log de leads con fuente, fecha, email.
- Grabaciones o notas de conversaciones (anonimizadas).
- Contratos firmados.
- Dinero recibido (invoice + pago).
- Feedback de clientes iniciales (qué les gustó, dónde duelen).

**Criterios de aprobación:**
- ✓ VAL-001, VAL-002, VAL-003, VAL-004 completados.
- ✓ [APROBADO - DEC-005] 100 leads validados.
- ✓ Primeros clientes operando.
- ✓ Cobros procesados.
- ✓ Aprendizaje documentado (qué cambió, qué funcionó).

**Bloques típicos:**
- Bajo engagement en contenido (requiere revisión de narrativa, Stage 3).
- Leads sin calidad (revisar criterios, buyer persona).
- Conversiones bajas (revisar guiones, proceso).

**Autoridad de aprobación:** Andrés + Fundadora (operación real de fundadora)

**Prohibiciones antes de superar Gate 6:**
- No escalar a verticales nuevas.
- No lanzar campañas pagadas masivas (hasta validación).

## Stage 7 — Consolidación y escalamiento

**Objetivo:** [FUTURO — No aplica en MVP] Procesos repetibles, equipo, escalamiento, nuevas verticales.

**Prohibición crítica:**
No iniciar Stage 7 hasta validar completamente Stage 6 (primeros 10-20 clientes operando, recurring revenue).

## Indicadores de avance falso

🔴 **Rojo — NO es avance:**
- "Escribimos el documento" (sin validación del contenido).
- "Existe el archivo" (sin que nadie lo haya leído o aprobado).
- "El ticket está abierto" (estar abierto ≠ estar completo).
- "Tenemos un diseño" (sin que funcione realmente).
- "Muchas personas interactuaron" (likes/opens ≠ leads reales).

🟢 **Verde — ES avance:**
- Buyer persona validado en conversaciones reales.
- 100 leads capturados con registro de fuente.
- Dinero recibido de clientes reales.
- Documentos sin contradicciones, aprobados por Andrés.
- Métricas con evidencia (no supuestos).

## Tabla de estado actual vs Gates

| Gate | Status | Bloqueante | Próximo paso |
|------|--------|-----------|---------|
| Gate 0 (GOV) | ✓ Abierto | GOV-002 falta | Incorporar fuentes, confirmar datos fundadora |
| Gate 1 (STR + MKT) | 🟡 Amarillo | STR-001 bloqueado | Consolidar contexto maestro |
| Gate 2 (Oferta) | ⛔ Bloqueado | Gate 1 no superado | Esperar nicho definido |
| Gate 3 (Contenido) | ⛔ Bloqueado | Gate 2 no superado | Esperar oferta aprobada |
| Gate 4 (Funnel) | ⛔ Bloqueado | Gate 3 no superado | Esperar narrativa aprobada |
| Gate 5 (Sitio) | ⛔ Bloqueado | Gate 4 no superado | Esperar funnel definido |
| Gate 6 (Validación) | ⛔ Bloqueado | Gate 5 no superado | Esperar sitio en vivo |
| Gate 7 (Escalamiento) | 🚫 Prohibido | Gate 6 no superado | Completar validación comercial primero |

## Protocolo para aprobar un gate

1. **Revisor** (usualmente Andrés) verifica todas entregas requeridas.
2. Valida aceptance criteria (checklist en sección Gate).
3. Revisa evidencia mínima (no es supuesto).
4. Confirma: no hay contradicciones internas, alineado con decisiones aprobadas.
5. **Aprobación:** Registra en DECISION_LOG.md o timeline/ como "Gate X Aprobado".
6. Comunica al equipo.
7. Desbloquea tickets de siguiente stage (status pending → ready).

## Protocolo para rechazar o reabrir un gate

**Rechazo:**
1. Revisor identifica gaps.
2. Registra en comments/ y timeline/.
3. Tickets de stage regresa a "blocked".
4. Productor retrabaja.
5. Reverificación de puerta.

**Reapertura (si algo cambió después de aprobación):**
1. Escala a Andrés: cambio de circunstancia o decisión.
2. Andrés decide: vale la pena?, cuál es el impacto?
3. Si sí: regresa tickets a "ready", reinicia iteración.
4. Registra razón en DECISION_LOG.md.

## Resumen: Visión de futuro sin prisa

[HIPÓTESIS] Roadmap actual cubre Stages 0-6. Stage 7 (escalamiento, verticales) activa solo si Stage 6 comprueba viabilidad comercial y operativa de la primera unidad. Prohibido ampliar antes de validar.

Principio: **Visión amplia (Stage 7 existe), ejecución estrecha (MVP = Stages 0-6).**
