# TINTO Business Incubator - Ticket Protocol

## 1. Intake

Recibir el ticket, identificar el alcance y confirmar que existe en `roadmap.md`.

## 2. Lectura obligatoria

Antes de ejecutar:

1. `AGENTS.md`
2. `PROJECT_RULES.md`
3. `DECISION_LOG.md`
4. `memory/CURRENT_STATE.md`
5. `orchestration/ROLE_MATRIX.md`
6. `orchestration/WORKFLOW_PROTOCOL.md`
7. `orchestration/STAGE_GATES.md`
8. `orchestration/STRATEGIC_GUARDRAILS.md`
9. `orchestration/CHANGE_CONTROL.md`
10. `orchestration/ESCALATION_PROTOCOL.md`
11. `.claude/agents/tinto-supervisor.md`
12. `.claude/agents/quality-auditor.md`
13. `.claude/skills/tinto-business-incubator/SKILL.md`
14. `.claude/skills/tinto-business-incubator/QUALITY_GATES.md`
15. `roadmap.md`

## 3. Validación de rama

- Confirmar que la rama activa es la esperada para el trabajo.
- Si la rama no coincide, detenerse y escalar.

## 4. Validación de ticket

- Verificar ticket exacto en `roadmap.md`.
- Leer objetivo, scope, dependencias, archivos autorizados y criterios de aceptación.
- Si el ticket no existe o no está claro, bloquear.

## 5. Dependencias

- Revisar estado de cada dependencia.
- Si alguna dependencia no está completada, no continuar.
- Si la dependencia impide evaluar el ticket, el resultado principal es `blocked`.

## 6. Archivos autorizados

- Solo trabajar en los archivos listados en `Files allowed to change`.
- No modificar archivos fuera de alcance.
- Si aparece una necesidad nueva, marcarla y escalar.

## 7. Plan de trabajo

- Definir pasos mínimos.
- Separar trabajo técnico, validación y evidencia.
- Mantener scope estrecho.

## 8. Ejecución

- Implementar solo lo pedido.
- No introducir decisiones estratégicas.
- No inventar datos faltantes.
- Si falta información crítica, usar `(andres confirma)`.

## 9. Verificaciones

- Ejecutar comandos seguros.
- Revisar sintaxis, estructura, rutas, formatos y consistencia.
- Confirmar que el resultado coincide con el ticket.

## 10. Evidencia

- Registrar comandos, hallazgos y resultados.
- Documentar supuestos.
- Guardar trazabilidad de cambios y pruebas.

## 11. Handoff

- Entregar al auditor independiente.
- Incluir resumen técnico y lista de archivos.
- No cerrar el ticket por cuenta propia.

## 12. Bloqueo

- Bloquear si falta dependencia.
- Bloquear si el scope contradice reglas o decisiones.
- Bloquear si el ticket requiere información no disponible.

## 13. Fallo

- Marcar `failed` si la ejecución técnica no puede completarse por error verificable.
- Registrar causa concreta.
- No confundir `failed` con `blocked`.

## 14. Reapertura

- Solo si hay resolución humana o corrección explícita.
- Volver a `ready` o `in_progress` según corresponda.

## 15. Cierre técnico

- Codex completa producción y evidencia.
- El auditor revisa.
- Andrés aprueba el cierre final.

## 16. Estados y transiciones

Regla obligatoria:

```text
pending → ready → in_progress → agent_review → human_review → completed
```

Transiciones válidas:

- `pending → ready`
- `ready → in_progress`
- `in_progress → agent_review`
- `agent_review → human_review`
- `human_review → completed`
- `blocked → ready`
- `failed → ready`
- `rejected → ready`

## 17. Casos inválidos

No permitir:

```text
pending → completed
in_progress → completed
agent_review → completed
```

- Codex no puede escribir `completed` por sí mismo.
- Ningún ticket puede saltar revisión.

## 18. Ejemplo técnico con dashboard

- Ticket técnico implementa una vista o automatización.
- Codex modifica solo archivos autorizados.
- Ejecuta pruebas no destructivas.
- Produce evidencia de funcionamiento.
- Pasa a `agent_review`.
- Auditor revisa y luego se eleva a `human_review`.

## 19. Ejemplo de auditoría documental

- Codex revisa si un documento técnico es ejecutable.
- Verifica rutas, formatos, comandos y consistencia.
- Reporta gaps sin corregir lo no autorizado.
- Si el documento depende de una decisión faltante, se bloquea.

## 20. Operación manual `v0.2.0`

- El flujo se administra manualmente.
- No hay integración automática al dashboard.
- Toda transición debe quedar soportada por evidencia y registro humano.

