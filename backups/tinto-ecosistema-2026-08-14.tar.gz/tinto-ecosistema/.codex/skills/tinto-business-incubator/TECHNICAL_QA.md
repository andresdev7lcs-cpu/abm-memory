# TINTO Technical QA

## Propósito

Definir la revisión técnica y mecánica de entregables de TINTO para asegurar que cumplen el ticket, respetan el scope y dejan evidencia verificable.

## Alcance

Aplica a:

- archivos de documentación técnica;
- scripts;
- automatizaciones;
- dashboards;
- JSON y Markdown;
- revisiones de trazabilidad;
- validación de dependencias y scope.

## Tipos de QA

- estructura
- sintaxis
- rutas
- JSON
- Markdown
- código
- permisos
- alcance
- evidencia
- trazabilidad

## Checklist técnico

- El ticket existe en `roadmap.md`.
- El scope coincide con el entregable.
- Los archivos modificados están autorizados.
- No hay cambios fuera de scope.
- Las dependencias están resueltas o el bloqueo está justificado.
- Los comandos ejecutados son seguros.
- La evidencia está documentada.
- El resultado es trazable.

## Validación de archivos cambiados

- Comparar archivos modificados con `Files allowed to change`.
- Revisar que cada cambio aporte al objetivo del ticket.
- Marcar cualquier archivo no autorizado como hallazgo.

## Validación de archivos fuera de scope

- Si hay modificaciones fuera de scope, reportarlas.
- Si el cambio fuera de scope afecta el resultado, la evaluación no puede ser `pass`.
- Si impide evaluar, usar `blocked`.

## Validación de JSON

- Verificar sintaxis.
- Confirmar estructura esperada.
- Confirmar que claves y valores sean consistentes.
- No aceptar JSON malformado o ambiguo.

## Validación de Node

- Ejecutar validaciones no destructivas si aplica.
- Confirmar que scripts y comandos funcionen.
- Revisar errores de runtime, dependencias faltantes o rutas incorrectas.

## Validación de Markdown

- Verificar encabezados, listas y bloques de código.
- Confirmar legibilidad y consistencia.
- Detectar enlaces rotos o secciones incompletas.

## Validación de logs

- Revisar que existan logs de ejecución o prueba cuando aplique.
- Confirmar que sean consistentes con el resultado reportado.

## Validación de ledger

- Revisar `roadmap-status.md` o el registro equivalente si aplica al ticket.
- Verificar que no haya saltos de estado no permitidos.
- Confirmar trazabilidad entre ejecución, revisión y cierre.

## Validación de dependencias

- Si una dependencia no está completada, no evaluar como cierre final.
- Si la dependencia impide auditar, el resultado principal es `blocked`.
- Si la dependencia no rompe la evaluación, documentarla como riesgo.

## Severidades

- `critical`
- `major`
- `minor`
- `improvement`

## Resultados

- `pass`
- `conditional_pass`
- `changes_required`
- `fail`
- `blocked`

## Regla de bloqueo

- `blocked` prevalece si una dependencia impide evaluar.
- `fail` aplica cuando sí se puede evaluar pero la entrega falla sustancialmente.

## Comandos permitidos

- `git status --short`
- `git diff --check`
- `git diff -- <path>`
- `rg`
- `find`
- `sed`
- validaciones no destructivas del stack

## Comandos prohibidos

- `git commit`
- `git push`
- `git reset --hard`
- `git clean -fd`
- `rm -rf`
- cualquier acción destructiva o de cambio irreversible

## Formato obligatorio de QA

```text
CODEX TECHNICAL QA

TICKET:
PRODUCER:
AUDITOR:
SCOPE:
FILES REVIEWED:
COMMANDS:
TEST RESULTS:
FINDINGS:
SEVERITY:
RESULT:
EVIDENCE:
DEPENDENCIES:
OUT-OF-SCOPE CHANGES:
RECOMMENDATION:
NEXT STEP:
```

## Ejemplos

### Example: pass

- Archivos autorizados únicamente.
- Evidencia completa.
- Sin hallazgos críticos.
- Dependencias completadas.

### Example: conditional_pass

- Cumple el objetivo principal.
- Existe un gap menor documentado.
- Requiere validación humana para cierre.

### Example: changes_required

- Hay hallazgos mayores corregibles.
- El entregable necesita retrabajo antes de revisión final.

### Example: fail

- Hay fallos sustanciales.
- El entregable no cumple el ticket o contradice decisiones.

### Example: blocked

- Falta una dependencia crítica.
- No hay forma de evaluar con evidencia suficiente.

## Estado manual `v0.2.0`

Durante `v0.2.0`, QA y estados se manejan manualmente. La revisión técnica debe dejar evidencia clara para que el auditor humano valide el resultado sin ambigüedad.

