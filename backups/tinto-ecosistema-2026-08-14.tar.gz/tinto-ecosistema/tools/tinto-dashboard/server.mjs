import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HOST = "127.0.0.1";
const PORT = 4570;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, "../..");

const files = {
  index: path.join(__dirname, "index.html"),
  app: path.join(__dirname, "app.js"),
  project: path.join(ROOT, "dashboard-data/project.json"),
  metrics: path.join(ROOT, "dashboard-data/metrics.json"),
  budget: path.join(ROOT, "dashboard-data/budget.json"),
  roadmap: path.join(ROOT, "roadmap.md")
};

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });

  res.end(JSON.stringify(data));
}

function sendText(
  res,
  statusCode,
  text,
  contentType = "text/plain; charset=utf-8"
) {
  res.writeHead(statusCode, {
    "Content-Type": contentType,
    "Cache-Control": "no-store"
  });

  res.end(text);
}

function readJson(filePath) {
  const content = fs.readFileSync(filePath, "utf8");
  return JSON.parse(content);
}

function parseRoadmap(markdown) {
  const tickets = [];
  const sections = markdown.split(/^## /m).slice(1);

  for (const section of sections) {
    const lines = section.trim().split("\n");
    const heading = lines.shift()?.trim() || "";

    const match = heading.match(
      /^([A-Z]{2,8}-\d{3})\s+—\s+(.+)$/
    );

    if (!match) {
      continue;
    }

    const ticket = {
      id: match[1],
      title: match[2],
      area: "",
      priority: "",
      recommendedModel: "",
      owner: "",
      dependencies: [],
      statusBaseline: "pending",
      targetDate: "",
      objective: "",
      scope: "",
      filesAllowedToChange: "",
      verificationCommands: "",
      acceptanceCriteria: ""
    };

    for (const line of lines) {
      const field = line.match(/^- ([^:]+):\s*(.*)$/);

      if (!field) {
        continue;
      }

      const key = field[1].trim();
      const value = field[2].trim();

      switch (key) {
        case "Area":
          ticket.area = value;
          break;

        case "Priority":
          ticket.priority = value;
          break;

        case "Recommended model":
          ticket.recommendedModel = value;
          break;

        case "Owner":
          ticket.owner = value;
          break;

        case "Dependencies":
          ticket.dependencies =
            value.toLowerCase() === "none"
              ? []
              : value
                  .split(",")
                  .map(item => item.trim())
                  .filter(Boolean);
          break;

        case "Status baseline":
          ticket.statusBaseline = value;
          break;

        case "Target date":
          ticket.targetDate = value;
          break;

        case "Objective":
          ticket.objective = value;
          break;

        case "Scope":
          ticket.scope = value;
          break;

        case "Files allowed to change":
          ticket.filesAllowedToChange = value;
          break;

        case "Verification commands":
          ticket.verificationCommands = value;
          break;

        case "Acceptance criteria":
          ticket.acceptanceCriteria = value;
          break;

        default:
          break;
      }
    }

    tickets.push(ticket);
  }

  return tickets;
}

const server = http.createServer((req, res) => {
  try {
    if (req.method !== "GET") {
      sendJson(res, 405, {
        error: "Método no permitido"
      });
      return;
    }

    if (req.url === "/") {
      const html = fs.readFileSync(files.index, "utf8");

      sendText(
        res,
        200,
        html,
        "text/html; charset=utf-8"
      );

      return;
    }

    if (req.url === "/app.js") {
      const javascript = fs.readFileSync(files.app, "utf8");

      sendText(
        res,
        200,
        javascript,
        "text/javascript; charset=utf-8"
      );

      return;
    }

    if (req.url === "/api/project") {
      sendJson(
        res,
        200,
        readJson(files.project)
      );

      return;
    }

    if (req.url === "/api/metrics") {
      sendJson(
        res,
        200,
        readJson(files.metrics)
      );

      return;
    }

    if (req.url === "/api/budget") {
      sendJson(
        res,
        200,
        readJson(files.budget)
      );

      return;
    }

    if (req.url === "/api/tickets") {
      const roadmap = fs.readFileSync(files.roadmap, "utf8");
      const tickets = parseRoadmap(roadmap);

      sendJson(res, 200, {
        tickets
      });

      return;
    }

    sendJson(res, 404, {
      error: "Ruta no encontrada"
    });
  } catch (error) {
    console.error("Error del servidor:", error);

    sendJson(res, 500, {
      error: "Error interno del servidor",
      detail: error.message
    });
  }
});

server.on("error", error => {
  if (error.code === "EADDRINUSE") {
    console.error(
      `El puerto ${PORT} ya está en uso. ` +
      "Cierra el proceso activo o cambia el puerto."
    );
    process.exit(1);
  }

  console.error("Error iniciando el servidor:", error);
  process.exit(1);
});

server.listen(PORT, HOST, () => {
  console.log(
    `TINTO dashboard running at http://${HOST}:${PORT}`
  );
});
