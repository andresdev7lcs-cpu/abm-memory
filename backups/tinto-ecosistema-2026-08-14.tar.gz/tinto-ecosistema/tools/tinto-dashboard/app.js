const state = {
  project: null,
  metrics: null,
  budget: null,
  tickets: []
};

async function getJson(url) {
  const response = await fetch(url);

  if (!response.ok) {
    throw new Error(`Error cargando ${url}: ${response.status}`);
  }

  return response.json();
}

function formatMoney(value, currency = "COP") {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency,
    maximumFractionDigits: 0
  }).format(Number(value || 0));
}

function normalizeStatus(status) {
  const value = String(status || "pending").toLowerCase();

  if (value === "completed" || value === "done") {
    return "completed";
  }

  if (value === "in_progress" || value === "in progress") {
    return "in_progress";
  }

  if (value === "blocked" || value === "failed") {
    return "blocked";
  }

  return "pending";
}

function renderTicket(ticket) {
  const dependencies = ticket.dependencies?.length
    ? ticket.dependencies.join(", ")
    : "Sin dependencias";

  return `
    <article class="ticket">
      <span class="ticket-id">${ticket.id}</span>

      <h5>${ticket.title}</h5>

      <p>${ticket.objective || "Sin objetivo registrado."}</p>

      <div class="ticket-meta">
        <span class="mini-badge">${ticket.area || "(andres confirma)"}</span>
        <span class="mini-badge">${ticket.priority || "(andres confirma)"}</span>
        <span class="mini-badge">${ticket.owner || "(andres confirma)"}</span>
        <span class="mini-badge">Dep.: ${dependencies}</span>
      </div>
    </article>
  `;
}

function renderProject() {
  const project = state.project;

  document.getElementById("project-name").textContent =
    project.name || "TINTO Operations Dashboard";

  document.getElementById("project-summary").textContent =
    project.summary || "";

  document.getElementById("project-badge").textContent =
    `${project.status || "HYPOTHESIS"} · v${project.version || "0.1.0"}`;
}

function renderMetrics() {
  const funnel = state.metrics?.funnel || {};
  const totalTickets = state.tickets.length;

  const completedTickets = state.tickets.filter(
    ticket => normalizeStatus(ticket.statusBaseline) === "completed"
  ).length;

  const progress = totalTickets
    ? Math.round((completedTickets / totalTickets) * 100)
    : 0;

  const leads = funnel.leads || { actual: 0, target: 0 };
  const calls = funnel.qualifiedCalls || { actual: 0, target: 0 };
  const clients = funnel.clients || { actual: 0, target: 0 };

  document.getElementById("progress-metric").textContent =
    `${progress}%`;

  document.getElementById("leads-metric").textContent =
    `${leads.actual} / ${leads.target}`;

  document.getElementById("calls-metric").textContent =
    `${calls.actual} / ${calls.target}`;

  document.getElementById("clients-metric").textContent =
    `${clients.actual} / ${clients.target}`;
}

function renderSummary() {
  const openTickets = state.tickets.filter(
    ticket => normalizeStatus(ticket.statusBaseline) !== "completed"
  );

  const blockedTickets = state.tickets.filter(
    ticket => normalizeStatus(ticket.statusBaseline) === "blocked"
  );

  const highPriorityTickets = state.tickets.filter(
    ticket =>
      String(ticket.priority).toLowerCase() === "critical" ||
      String(ticket.priority).toLowerCase() === "high"
  );

  document.getElementById("summary-content").innerHTML = `
    <article class="list-item">
      <strong>Fase actual</strong>
      <p>${state.project.currentPhase || "(andres confirma)"}</p>
    </article>

    <article class="list-item">
      <strong>Tareas abiertas</strong>
      <p>${openTickets.length}</p>
    </article>

    <article class="list-item">
      <strong>Tareas bloqueadas</strong>
      <p>${blockedTickets.length}</p>
    </article>

    <article class="list-item">
      <strong>Prioridades críticas o altas</strong>
      <p>${highPriorityTickets.length}</p>
    </article>

    <article class="list-item">
      <strong>Principio rector</strong>
      <p>Visión amplia, ejecución estrecha.</p>
    </article>
  `;
}

function renderKanban() {
  const columns = {
    pending: document.getElementById("todo-column"),
    in_progress: document.getElementById("in-progress-column"),
    blocked: document.getElementById("blocked-column"),
    completed: document.getElementById("completed-column")
  };

  Object.values(columns).forEach(column => {
    column.innerHTML = "";
  });

  state.tickets.forEach(ticket => {
    const status = normalizeStatus(ticket.statusBaseline);
    columns[status].insertAdjacentHTML("beforeend", renderTicket(ticket));
  });

  Object.values(columns).forEach(column => {
    if (!column.innerHTML.trim()) {
      column.innerHTML = `<p class="empty">Sin tickets.</p>`;
    }
  });
}

function renderFunnel() {
  const funnel = state.metrics?.funnel || {};

  const labels = {
    visitors: "Visitantes",
    leads: "Leads",
    segmentedLeads: "Leads segmentados",
    engagedLeads: "Leads activos",
    eventAttendees: "Asistentes",
    qualifiedCalls: "Conversaciones",
    proposals: "Propuestas",
    clients: "Clientes",
    recurringClients: "Clientes recurrentes"
  };

  const html = Object.entries(funnel)
    .map(([key, value]) => {
      const actual = Number(value.actual || 0);
      const target = Number(value.target || 0);

      const progress = target
        ? Math.round((actual / target) * 100)
        : 0;

      return `
        <article class="card">
          <span>${labels[key] || key}</span>
          <strong>${actual} / ${target}</strong>
          <p style="color: var(--muted); margin-bottom: 0;">
            ${progress}% de la meta
          </p>
        </article>
      `;
    })
    .join("");

  document.getElementById("funnel-grid").innerHTML =
    html || `<p class="empty">No hay métricas registradas.</p>`;
}

function renderBudget() {
  const budget = state.budget || {};
  const approved = Number(budget.approved || 0);
  const spent = Number(budget.spent || 0);
  const remaining = approved - spent;
  const currency = budget.currency || "COP";

  document.getElementById("budget-approved").textContent =
    formatMoney(approved, currency);

  document.getElementById("budget-spent").textContent =
    formatMoney(spent, currency);

  document.getElementById("budget-remaining").textContent =
    formatMoney(remaining, currency);

  const categories = budget.categories || [];

  document.getElementById("budget-grid").innerHTML = categories.length
    ? categories
        .map(category => `
          <article class="card">
            <span>${category.type}</span>
            <strong>${category.name}</strong>

            <p style="color: var(--muted);">
              Aprobado:
              ${formatMoney(category.approved, currency)}
            </p>

            <p style="color: var(--muted);">
              Ejecutado:
              ${formatMoney(category.spent, currency)}
            </p>

            <p style="color: var(--muted); margin-bottom: 0;">
              ${category.notes || ""}
            </p>
          </article>
        `)
        .join("")
    : `<p class="empty">No hay categorías registradas.</p>`;
}

function bindNavigation() {
  const buttons = document.querySelectorAll(".nav-button");
  const views = document.querySelectorAll(".view");

  buttons.forEach(button => {
    button.addEventListener("click", () => {
      buttons.forEach(item => item.classList.remove("active"));
      views.forEach(view => view.classList.remove("active"));

      button.classList.add("active");

      const target = document.getElementById(button.dataset.view);

      if (target) {
        target.classList.add("active");
      }
    });
  });
}

async function loadDashboard() {
  try {
    const [
      project,
      metrics,
      budget,
      ticketResponse
    ] = await Promise.all([
      getJson("/api/project"),
      getJson("/api/metrics"),
      getJson("/api/budget"),
      getJson("/api/tickets")
    ]);

    state.project = project;
    state.metrics = metrics;
    state.budget = budget;
    state.tickets = ticketResponse.tickets || [];

    renderProject();
    renderMetrics();
    renderSummary();
    renderKanban();
    renderFunnel();
    renderBudget();
  } catch (error) {
    console.error(error);

    document.getElementById("project-summary").textContent =
      "No fue posible cargar los datos del dashboard.";

    document.getElementById("summary-content").innerHTML = `
      <article class="list-item">
        <strong>Error de carga</strong>
        <p>${error.message}</p>
      </article>
    `;
  }
}

bindNavigation();
loadDashboard();