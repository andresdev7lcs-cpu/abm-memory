import { getActiveQuestion, getActiveTerritory } from "./state.mjs";

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function isBeforeTerritoryWorld(sceneId) {
  return [
    "curtain",
    "founder-vsl",
    "atom-command-center",
    "halo-selection",
    "black-transition",
    "office-intro"
  ].includes(sceneId);
}

function sceneNumber(content, sceneId) {
  const index = content.sceneOrder.indexOf(sceneId);
  return `${String(index + 1).padStart(2, "0")} / ${String(content.sceneOrder.length).padStart(2, "0")}`;
}

function renderActionButton(action, label, attrs = "") {
  return `<button class="scene-action ${action === "primary" ? "scene-action--primary" : ""}" type="button" data-action="${attrs}">${escapeHtml(label)}</button>`;
}

function renderSceneRail(content, state) {
  return `
    <nav class="scene-rail" aria-label="Navegación por escenas">
      ${content.sceneOrder
        .map(sceneId => {
          const scene = content.scenes[sceneId];
          const active = sceneId === state.activeScene;
          return `
            <button
              class="scene-rail__pill ${active ? "scene-rail__pill--active" : ""}"
              type="button"
              data-action="jump-scene"
              data-scene-id="${sceneId}"
              aria-current="${active ? "step" : "false"}"
            >
              <span>${escapeHtml(scene.label)}</span>
            </button>
          `;
        })
        .join("")}
    </nav>
  `;
}

function renderChrome(content, state) {
  const scene = content.scenes[state.activeScene];
  const canBack = state.sceneHistory.length > 0 || state.activeScene !== "curtain";
  const canAdvance = state.activeScene !== "booking";
  const showSkip = isBeforeTerritoryWorld(state.activeScene);

  return `
    <header class="site-chrome">
      <div class="brand-lockup">
        <img src="${content.assets.logo}" alt="Logo TINTO" class="brand-lockup__logo">
        <div>
          <p class="brand-lockup__eyebrow">${escapeHtml(content.brand.label)}</p>
          <strong>${escapeHtml(content.brand.name)}</strong>
        </div>
      </div>
      <div class="scene-meta">
        <span class="scene-meta__badge">${escapeHtml(sceneNumber(content, state.activeScene))}</span>
        <span class="scene-meta__badge">${escapeHtml(scene.label)}</span>
        <span class="scene-meta__badge">mode: ${escapeHtml(state.performanceMode)}</span>
      </div>
    </header>
    ${renderSceneRail(content, state)}
    <section class="control-rail" aria-label="Controles globales">
      <button class="control-button" type="button" data-action="toggle-pause">
        ${state.paused ? "Reanudar" : "Pausar"}
      </button>
      <button class="control-button" type="button" data-action="abort-transition" ${state.transitionPhase === "idle" ? "disabled" : ""}>
        Abortar transición
      </button>
      <button class="control-button" type="button" data-action="go-back" ${canBack ? "" : "disabled"}>
        Regresar
      </button>
      <button class="control-button" type="button" data-action="advance-scene" ${canAdvance ? "" : "disabled"}>
        Avanzar
      </button>
      ${showSkip ? `<button class="control-button control-button--accent" type="button" data-action="skip-intro">Omitir introducción</button>` : ""}
      <div class="control-mode" aria-label="Modo de performance">
        ${["cinematic", "balanced", "reduced"]
          .map(mode => `
            <button
              class="control-button ${state.performanceMode === mode ? "control-button--active" : ""}"
              type="button"
              data-action="set-performance-mode"
              data-mode="${mode}"
            >
              ${mode}
            </button>
          `)
          .join("")}
      </div>
    </section>
  `;
}

function renderSceneFrame(content, state, innerHtml, className = "", tone = "", headerOverride = null) {
  const scene = content.scenes[state.activeScene];
  const debugMode = Boolean(content.debugMode);
  const title = headerOverride?.title ?? scene.title;
  const body = headerOverride?.body ?? scene.body;

  return `
    <section class="scene-card ${className} scene-card--${state.activeScene}" data-scene="${state.activeScene}" data-phase="${state.transitionPhase}" ${tone ? `data-tone="${escapeHtml(tone)}"` : ""} tabindex="-1">
      <div class="scene-card__header">
        <div>
          ${debugMode ? `<p class="eyebrow">${escapeHtml(scene.eyebrow)}</p>` : ""}
          <h1>${escapeHtml(title)}</h1>
          <p class="scene-card__body">${escapeHtml(body)}</p>
        </div>
        ${
          debugMode
            ? `
              <div class="scene-card__status">
                <span class="status-badge">${escapeHtml(scene.label)}</span>
                <span class="status-badge">${escapeHtml(state.transitionPhase)}</span>
                <span class="status-badge">${state.interactionLocked ? "locked" : "open"}</span>
              </div>
            `
            : ""
        }
      </div>
      <div class="scene-card__content">
        ${innerHtml}
      </div>
      ${
        debugMode
          ? `
            <footer class="scene-card__footer">
              <div class="scene-chip-list">
                ${(scene.notes || []).map(note => `<span class="scene-chip">${escapeHtml(note)}</span>`).join("")}
              </div>
            </footer>
          `
          : ""
      }
    </section>
  `;
}

function renderMediaFigure(media, caption, className = "", debugMode = false) {
  if (!media) {
    return "";
  }

  const hasVideo = Boolean(media.webm || media.mp4);
  const asset = media.image || media.poster || "";

  return `
    <figure class="scene-media ${className}">
      ${debugMode ? `<span class="scene-media__tag">Placeholder — reemplazo pendiente</span>` : ""}
      ${
        hasVideo
          ? `
            <video class="scene-media__video" autoplay muted loop playsinline poster="${escapeHtml(media.poster || asset)}">
              ${media.webm ? `<source src="${escapeHtml(media.webm)}" type="video/webm">` : ""}
              ${media.mp4 ? `<source src="${escapeHtml(media.mp4)}" type="video/mp4">` : ""}
            </video>
          `
          : asset
            ? `<img class="scene-media__image" src="${escapeHtml(asset)}" alt="${escapeHtml(media.alt || "")}">`
            : `<div class="scene-media__fallback">${escapeHtml(media.alt || "Fallback visual provisional")}</div>`
      }
      ${caption ? `<figcaption class="scene-media__caption">${escapeHtml(caption)}</figcaption>` : ""}
    </figure>
  `;
}

function renderTerritoryBadges(territory) {
  return `
    <div class="badge-row">
      <span class="status-badge">status: ${escapeHtml(territory.status)}</span>
      <span class="status-badge">approval: ${escapeHtml(territory.approval)}</span>
      <span class="status-badge">tone: ${escapeHtml(territory.tone)}</span>
    </div>
  `;
}

function renderHypothesisTag() {
  return `<span class="hypothesis-tag">Exploración inicial</span>`;
}

function renderTerritoryChips(territory, selectedQuestionId) {
  return `
    <div class="question-pills">
      ${territory.questions
        .map(question => `
          <button
            class="question-pill ${question.id === selectedQuestionId ? "question-pill--active" : ""}"
            type="button"
            data-action="select-question"
            data-question-id="${question.id}"
          >
            ${escapeHtml(question.title)}
          </button>
        `)
        .join("")}
    </div>
  `;
}

function renderTerritorySummaryCard(content, territory, question) {
  const debugMode = Boolean(content.debugMode);

  return `
    <article class="summary-card">
      ${debugMode ? `<p class="eyebrow">Territorio activo</p>` : renderHypothesisTag()}
      <h2>${escapeHtml(territory.title)}</h2>
      <p>${escapeHtml(territory.summary)}</p>
      <p class="summary-card__intro">${escapeHtml(territory.intro)}</p>
      ${debugMode ? renderTerritoryBadges(territory) : ""}
      <div class="summary-card__question">
        <span class="scene-chip">Pregunta activa</span>
        <strong>${escapeHtml(question?.title || "Pregunta pendiente")}</strong>
      </div>
    </article>
  `;
}

function renderQuestionCard(question, active = false) {
  return `
    <button class="question-card ${active ? "question-card--active" : ""}" type="button" data-action="select-question" data-question-id="${question.id}">
      <span class="question-card__title">${escapeHtml(question.title)}</span>
      <span class="question-card__prompt">${escapeHtml(question.prompt)}</span>
    </button>
  `;
}

function renderCurtain(content, state) {
  const scene = content.scenes[state.activeScene];
  const debugMode = Boolean(content.debugMode);

  return renderSceneFrame(
    content,
    state,
    `
      ${renderMediaFigure(scene.media, debugMode ? "Entrada visual provisional para la experiencia base." : "", "", debugMode)}
      <div class="scene-actions">
        <button class="scene-action scene-action--primary" type="button" data-action="skip-intro">${escapeHtml(scene.primaryAction.label)}</button>
        <button class="scene-action" type="button" data-action="advance-scene">${escapeHtml(scene.secondaryAction.label)}</button>
      </div>
    `,
    "scene-card--curtain"
  );
}

function renderFounderVsl(content, state) {
  const scene = content.scenes[state.activeScene];
  const debugMode = Boolean(content.debugMode);

  return renderSceneFrame(
    content,
    state,
    `
      <div class="scene-grid scene-grid--split">
        <div class="scene-copy">
          ${renderMediaFigure(scene.media, scene.media.captions, "scene-media--portrait", debugMode)}
        </div>
        <div class="scene-copy">
          ${
            debugMode
              ? `
                <div class="copy-block">
                  <span class="scene-chip">Copy provisional</span>
                  <p>El elevator pitch no queda cerrado. Esta escena sólo reserva el contenedor de media y la temporización base.</p>
                  <p>Si no carga video, el poster conserva el momento y las captions mantienen la accesibilidad.</p>
                </div>
              `
              : ""
          }
          <div class="scene-actions">
            <button class="scene-action scene-action--primary" type="button" data-action="advance-scene">${escapeHtml(scene.primaryAction.label)}</button>
            <button class="scene-action" type="button" data-action="skip-intro">${escapeHtml(scene.secondaryAction.label)}</button>
          </div>
        </div>
      </div>
    `,
    "scene-card--founder-vsl",
    "",
    debugMode ? null : { title: "Un momento con la fundadora", body: "" }
  );
}

function renderAtomCommandCenter(content, state) {
  const scene = content.scenes[state.activeScene];
  const territory = getActiveTerritory(state) || content.territories[0];
  const debugMode = Boolean(content.debugMode);

  return renderSceneFrame(
    content,
    state,
    `
      <div class="atom-stage">
        <canvas class="atom-stage__canvas" data-atmosphere-canvas aria-hidden="true"></canvas>
        <span class="atom-stage__status-indicator">Exploración inicial</span>
        <div class="atom-stage__core" role="button" tabindex="0" data-action="advance-scene" aria-label="Ir al primer territorio">
          <img class="atom-stage__core-portrait" src="${content.assets.founderAvatar}" alt="" aria-hidden="true">
          <span class="atom-stage__core-ring" aria-hidden="true"></span>
          <span class="atom-stage__core-label">Fundadora</span>
          <span class="atom-stage__core-meta">Núcleo narrativo</span>
        </div>
        <div class="atom-stage__territories" aria-label="Territorios provisionales">
          ${content.territories
            .map((item, index) => `
              <button
                class="territory-orbit ${item.id === state.activeTerritoryId ? "territory-orbit--active" : ""}"
                type="button"
                data-action="select-territory"
                data-territory-id="${item.id}"
                data-territory-index="${index}"
                data-tone="${escapeHtml(item.tone)}"
                aria-pressed="${item.id === state.activeTerritoryId ? "true" : "false"}"
              >
                <span class="territory-orbit__title">${escapeHtml(item.title)}</span>
                ${
                  debugMode
                    ? `
                      <span class="territory-orbit__meta">status: ${escapeHtml(item.status)}</span>
                      <span class="territory-orbit__meta">approval: ${escapeHtml(item.approval)}</span>
                    `
                    : ""
                }
              </button>
            `)
            .join("")}
        </div>
      </div>
      <div class="scene-grid scene-grid--split">
        ${renderTerritorySummaryCard(content, territory, getActiveQuestion(state))}
        <div class="scene-copy">
          ${
            debugMode
              ? `
                <div class="copy-block">
                  <span class="scene-chip">Controles de escena</span>
                  <p>Se permiten mouse, touch, teclado y hover sin depender del scroll.</p>
                  <p>La selección territorial abre la siguiente escena con contrato explícito de halo.</p>
                </div>
              `
              : ""
          }
          <div class="scene-actions">
            <button class="scene-action scene-action--primary" type="button" data-action="select-territory" data-territory-id="${territory.id}">
              ${escapeHtml(scene.primaryAction.label)}
            </button>
            ${debugMode ? `<button class="scene-action" type="button" data-action="go-back">${escapeHtml(scene.secondaryAction.label)}</button>` : ""}
          </div>
        </div>
      </div>
    `,
    "scene-card--atom",
    territory.tone
  );
}

function renderHaloSelection(content, state) {
  const scene = content.scenes[state.activeScene];
  const territory = getActiveTerritory(state) || content.territories[0];
  const debugMode = Boolean(content.debugMode);

  return renderSceneFrame(
    content,
    state,
    `
      <div class="scene-grid scene-grid--split">
        <div class="scene-copy">
          <div class="halo-contact">
            <img src="${content.assets.haloHand}" alt="${escapeHtml(scene.media.alt)}" class="halo-contact__image">
            <div class="halo-contact__line"></div>
            <div class="halo-contact__pulse" aria-hidden="true"></div>
          </div>
          ${debugMode ? `<p class="scene-copy__caption">territory_selected → halo_interaction_started → halo_contact_completed</p>` : ""}
        </div>
        <div class="scene-copy">
          <div class="copy-block">
            <span class="scene-chip">Territorio activo</span>
            <h2>${escapeHtml(territory.title)}</h2>
            <p>${escapeHtml(territory.summary)}</p>
            ${debugMode ? `<p>Fallback obligatorio: línea luminosa, pulso, desplazamiento de luz y confirmación del nodo.</p>` : ""}
          </div>
          <div class="scene-actions">
            <button class="scene-action scene-action--primary" type="button" data-action="confirm-halo">${escapeHtml(scene.primaryAction.label)}</button>
            <button class="scene-action" type="button" data-action="go-back">${escapeHtml(scene.secondaryAction.label)}</button>
          </div>
        </div>
      </div>
    `,
    "scene-card--halo-selection",
    territory.tone,
    debugMode ? null : { title: "Un contacto", body: "" }
  );
}

function renderBlackTransition(content, state) {
  const scene = content.scenes[state.activeScene];
  const debugMode = Boolean(content.debugMode);

  return renderSceneFrame(
    content,
    state,
    `
      <div class="transition-stage transition-stage--black" aria-hidden="true">
        <span class="transition-stage__pulse"></span>
      </div>
      ${
        debugMode
          ? `
            <div class="scene-copy">
              <div class="copy-block copy-block--dark">
                <span class="scene-chip">Corte narrativo</span>
                <p>El apagado gradual separa actos sin perder la reversibilidad del flujo.</p>
                <p>En reduced motion la misma transición se vuelve un fade corto y claro.</p>
              </div>
              <div class="scene-actions">
                <button class="scene-action scene-action--primary" type="button" data-action="advance-scene">${escapeHtml(scene.primaryAction.label)}</button>
                <button class="scene-action" type="button" data-action="abort-transition">${escapeHtml(scene.secondaryAction.label)}</button>
              </div>
            </div>
          `
          : ""
      }
    `,
    "scene-card--black-transition",
    "",
    debugMode ? null : { title: "", body: "" }
  );
}

function renderOfficeIntro(content, state) {
  const scene = content.scenes[state.activeScene];
  const territory = getActiveTerritory(state) || content.territories[0];
  const debugMode = Boolean(content.debugMode);

  return renderSceneFrame(
    content,
    state,
    `
      <div class="scene-grid scene-grid--split">
        <div class="scene-copy office-composition">
          ${renderMediaFigure(
            {
              image: scene.media.image,
              poster: scene.media.poster,
              alt: scene.media.alt
            },
            debugMode ? "Puerta de cristal provisional: puente narrativo hacia el mundo del territorio." : "",
            "office-composition__door",
            debugMode
          )}
          <img class="office-composition__cup" src="${content.assets.tintoCup}" alt="" aria-hidden="true">
          <img class="office-composition__portrait" src="${content.assets.founderPortrait}" alt="" aria-hidden="true">
        </div>
        <div class="scene-copy">
          <div class="copy-block">
            <span class="scene-chip">${escapeHtml(territory.title)}</span>
            ${
              debugMode
                ? `
                  <p>La escena conserva el contexto antes de entrar al mundo del territorio.</p>
                  <p>El botón continuar sigue visible y el regreso narrativo apunta a esta escena desde territory-world.</p>
                `
                : `<p>${escapeHtml(territory.intro)}</p>`
            }
          </div>
          <div class="scene-actions">
            <button class="scene-action scene-action--primary" type="button" data-action="advance-scene">${escapeHtml(scene.primaryAction.label)}</button>
            <button class="scene-action" type="button" data-action="go-back">${escapeHtml(scene.secondaryAction.label)}</button>
          </div>
        </div>
      </div>
    `,
    "scene-card--office-intro",
    territory.tone,
    debugMode ? null : { title: "Bienvenida", body: "" }
  );
}

function renderTerritoryWorld(content, state) {
  const scene = content.scenes[state.activeScene];
  const territory = getActiveTerritory(state) || content.territories[0];
  const question = getActiveQuestion(state) || territory.questions[0];
  const debugMode = Boolean(content.debugMode);

  return renderSceneFrame(
    content,
    state,
    `
      <canvas class="territory-world__canvas" data-atmosphere-canvas aria-hidden="true"></canvas>
      <div class="scene-grid scene-grid--split">
        <div class="scene-copy">
          ${renderTerritorySummaryCard(content, territory, question)}
          ${renderTerritoryChips(territory, question?.id)}
        </div>
        <div class="scene-copy">
          ${
            debugMode
              ? `
                <div class="copy-block">
                  <span class="scene-chip">Mundo del territorio</span>
                  <p>Este bloque reutiliza el mismo sistema para cualquier territorio aprobado como hipótesis.</p>
                  <p>La navegación de regreso debe volver a office-intro, no saltarse el puente narrativo.</p>
                </div>
              `
              : `
                <div class="copy-block">
                  <span class="scene-chip">${escapeHtml(question?.title || "Pregunta")}</span>
                  <p>${escapeHtml(question?.prompt || territory.intro)}</p>
                </div>
              `
          }
          <div class="scene-actions">
            <button class="scene-action scene-action--primary" type="button" data-action="advance-scene">${escapeHtml(scene.primaryAction.label)}</button>
            <button class="scene-action" type="button" data-action="go-back">${escapeHtml(scene.secondaryAction.label)}</button>
          </div>
        </div>
      </div>
    `,
    "scene-card--territory-world",
    territory.tone,
    debugMode ? null : { title: territory.title, body: territory.summary }
  );
}

function renderQuestionLayer(content, state) {
  const scene = content.scenes[state.activeScene];
  const territory = getActiveTerritory(state) || content.territories[0];
  const question = getActiveQuestion(state) || territory.questions[0];
  const debugMode = Boolean(content.debugMode);

  return renderSceneFrame(
    content,
    state,
    `
      <div class="scene-grid scene-grid--split">
        <div class="scene-copy">
          <article class="detail-card">
            <span class="scene-chip">Pregunta activa</span>
            <h2>${escapeHtml(question.title)}</h2>
            <p>${escapeHtml(question.prompt)}</p>
            <p class="detail-card__answer">${escapeHtml(question.provisionalAnswer)}</p>
          </article>
          ${renderTerritoryChips(territory, question.id)}
        </div>
        <div class="scene-copy">
          <div class="copy-block">
            <span class="scene-chip">Recurso</span>
            <strong>${escapeHtml(question.resource.label)}</strong>
            <p>${escapeHtml(question.resource.title)}</p>
            <p>${escapeHtml(question.resource.copy)}</p>
            <p class="copy-block__soft">${escapeHtml(question.objection)}</p>
          </div>
          <div class="scene-actions">
            <button class="scene-action scene-action--primary" type="button" data-action="advance-scene">${escapeHtml(scene.primaryAction.label)}</button>
            <button class="scene-action" type="button" data-action="select-question">${escapeHtml(scene.secondaryAction.label)}</button>
          </div>
        </div>
      </div>
    `,
    "scene-card--question-layer",
    territory.tone,
    debugMode ? null : { title: question.title, body: question.prompt }
  );
}

function renderObjectionLayer(content, state) {
  const scene = content.scenes[state.activeScene];
  const territory = getActiveTerritory(state) || content.territories[0];
  const question = getActiveQuestion(state) || territory.questions[0];
  const debugMode = Boolean(content.debugMode);

  return renderSceneFrame(
    content,
    state,
    `
      <div class="scene-grid scene-grid--split">
        <div class="scene-copy">
          <article class="detail-card detail-card--split">
            <span class="scene-chip">Objeción</span>
            <h2>${escapeHtml(question.title)}</h2>
            <p>${escapeHtml(question.objection)}</p>
            <div class="detail-card__stack">
              <strong>Contexto</strong>
              <p>${escapeHtml(question.provisionalAnswer)}</p>
            </div>
          </article>
        </div>
        <div class="scene-copy">
          ${
            debugMode
              ? `
                <div class="copy-block">
                  <span class="scene-chip">Respuesta educativa</span>
                  <p>La capa explica límites, no inventa testimonios ni pruebas.</p>
                  <p>El siguiente paso conserva contexto y prepara la revelación del CTA.</p>
                </div>
              `
              : ""
          }
          <div class="scene-actions">
            <button class="scene-action scene-action--primary" type="button" data-action="advance-scene">${escapeHtml(scene.primaryAction.label)}</button>
            <button class="scene-action" type="button" data-action="go-back">${escapeHtml(scene.secondaryAction.label)}</button>
          </div>
        </div>
      </div>
    `,
    "scene-card--objection-layer",
    territory.tone,
    debugMode ? null : { title: question.title, body: question.objection }
  );
}

function renderConversionLayer(content, state) {
  const scene = content.scenes[state.activeScene];
  const territory = getActiveTerritory(state) || content.territories[0];
  const question = getActiveQuestion(state) || territory.questions[0];
  const debugMode = Boolean(content.debugMode);

  return renderSceneFrame(
    content,
    state,
    `
      <div class="scene-grid scene-grid--split">
        <div class="scene-copy">
          <article class="detail-card detail-card--split">
            <span class="scene-chip">Síntesis</span>
            <h2>${escapeHtml(territory.title)}</h2>
            <p>${escapeHtml(question.prompt)}</p>
            ${debugMode ? `<p>La conversión revela un CTA contextual y puentea hacia booking sin precios ni oferta final.</p>` : ""}
          </article>
        </div>
        <div class="scene-copy">
          ${
            debugMode
              ? `
                <div class="copy-block">
                  <span class="scene-chip">CTA revelado</span>
                  <p>La propuesta es avanzar al booking mock para capturar estructura y contexto.</p>
                  <p>La escena sigue siendo reversible y accesible en todo momento.</p>
                </div>
              `
              : ""
          }
          <div class="scene-actions">
            <button class="scene-action scene-action--primary" type="button" data-action="advance-scene">${escapeHtml(scene.primaryAction.label)}</button>
            <button class="scene-action" type="button" data-action="go-back">${escapeHtml(scene.secondaryAction.label)}</button>
          </div>
        </div>
      </div>
    `,
    "scene-card--conversion-layer",
    territory.tone,
    debugMode ? null : { title: territory.title, body: question.prompt }
  );
}

function renderBookingField(fieldName, field, currentValue) {
  if (field.type === "select") {
    return `
      <label class="booking-field">
        <span>${escapeHtml(field.label)}</span>
        <select name="${escapeHtml(fieldName)}" data-booking-field="${escapeHtml(fieldName)}">
          <option value="">Selecciona una opción</option>
          ${field.options
            .map(
              option => `
                <option value="${escapeHtml(option)}" ${currentValue === option ? "selected" : ""}>
                  ${escapeHtml(option)}
                </option>
              `
            )
            .join("")}
        </select>
      </label>
    `;
  }

  if (field.type === "textarea") {
    return `
      <label class="booking-field booking-field--textarea">
        <span>${escapeHtml(field.label)}</span>
        <textarea name="${escapeHtml(fieldName)}" rows="4" placeholder="${escapeHtml(field.placeholder)}" data-booking-field="${escapeHtml(fieldName)}">${escapeHtml(currentValue)}</textarea>
      </label>
    `;
  }

  if (field.type === "checkbox") {
    return `
      <label class="booking-field booking-field--checkbox">
        <input type="checkbox" name="${escapeHtml(fieldName)}" data-booking-field="${escapeHtml(fieldName)}" ${currentValue ? "checked" : ""}>
        <span>${escapeHtml(field.copy)}</span>
      </label>
    `;
  }

  return `
    <label class="booking-field">
      <span>${escapeHtml(field.label)}</span>
      <input
        type="${escapeHtml(field.type)}"
        name="${escapeHtml(fieldName)}"
        placeholder="${escapeHtml(field.placeholder)}"
        value="${escapeHtml(currentValue)}"
        data-booking-field="${escapeHtml(fieldName)}"
      >
    </label>
  `;
}

function renderBooking(content, state) {
  const scene = content.scenes[state.activeScene];
  const territory = getActiveTerritory(state) || content.territories[0];
  const question = getActiveQuestion(state) || territory.questions[0];
  const debugMode = Boolean(content.debugMode);

  if (state.bookingSubmitted) {
    return renderSceneFrame(
      content,
      state,
      `
        <article class="confirmation-card">
          ${debugMode ? `<span class="scene-chip">Booking mock local</span>` : ""}
          <h2>${debugMode ? "Mock completado en memoria" : "Gracias"}</h2>
          <p>${
            debugMode
              ? "No se conectó calendario real, no se persistieron datos y no se activó scoring automático."
              : "Esto no agenda ni confirma automáticamente — es un primer paso de contexto."
          }</p>
          <div class="confirmation-card__meta">
            <span class="status-badge">${escapeHtml(state.bookingDraft.nombre || "Sin nombre")}</span>
            <span class="status-badge">${escapeHtml(state.bookingDraft.email || "Sin email")}</span>
            <span class="status-badge">${escapeHtml(state.bookingDraft.territorio || territory.title)}</span>
          </div>
          <div class="scene-actions">
            <button class="scene-action scene-action--primary" type="button" data-action="advance-scene">${debugMode ? "Volver a revisar CTA" : "Continuar"}</button>
            <button class="scene-action" type="button" data-action="go-back">Regresar</button>
          </div>
        </article>
      `,
      "scene-card--booking",
      territory.tone,
      debugMode ? null : { title: "Recibido", body: "Gracias por compartir tu contexto." }
    );
  }

  return renderSceneFrame(
    content,
    state,
    `
      <div class="scene-grid scene-grid--split">
        <div class="scene-copy">
          ${
            debugMode
              ? `
                <article class="detail-card detail-card--split">
                  <span class="scene-chip">${escapeHtml(scene.label)}</span>
                  <h2>${escapeHtml(scene.title)}</h2>
                  <p>${escapeHtml(scene.body)}</p>
                  <div class="badge-row">
                    <span class="status-badge">booking_mode: ${escapeHtml(content.booking.mode)}</span>
                    <span class="status-badge">external_calendar: ${escapeHtml(content.booking.externalCalendar)}</span>
                    <span class="status-badge">persistent_storage: ${escapeHtml(content.booking.persistentStorage)}</span>
                  </div>
                </article>
              `
              : ""
          }
          <div class="copy-block">
            <span class="scene-chip">${escapeHtml(territory.title)}</span>
            <p>${escapeHtml(question.prompt)}</p>
          </div>
        </div>
        <form class="booking-form" data-booking-form>
          <div class="booking-grid">
            ${Object.entries(content.booking.fields)
              .map(([fieldName, field]) => renderBookingField(fieldName, field, state.bookingDraft[fieldName]))
              .join("")}
          </div>
          <div class="scene-actions">
            <button class="scene-action scene-action--primary" type="submit" data-action="submit-booking">${escapeHtml(scene.primaryAction.label)}</button>
            <button class="scene-action" type="button" data-action="go-back">${escapeHtml(scene.secondaryAction.label)}</button>
          </div>
        </form>
      </div>
    `,
    "scene-card--booking",
    territory.tone,
    debugMode ? null : { title: "Agenda una conversación inicial", body: "Cuéntanos brevemente tu situación para dar el siguiente paso." }
  );
}

function renderEventFeed(state) {
  return `
    <aside class="event-feed" aria-label="Eventos de escena">
      <header class="event-feed__header">
        <p class="eyebrow">Eventos locales</p>
        <span class="scene-chip">${state.eventLog.length} eventos</span>
      </header>
      <ul class="event-feed__list">
        ${state.eventLog
          .map(
            event => `
              <li class="event-feed__item">
                <span class="event-feed__type">${escapeHtml(event.type)}</span>
                <span class="event-feed__scene">${escapeHtml(event.sceneId || "n/a")}</span>
              </li>
            `
          )
          .join("")}
      </ul>
    </aside>
  `;
}

function renderPublicOverlay(content, state) {
  const canBack = state.sceneHistory.length > 0 || state.activeScene !== "curtain";
  const showSkip = isBeforeTerritoryWorld(state.activeScene);

  return `
    <div class="public-overlay" aria-label="Controles de la experiencia">
      <div class="public-overlay__left">
        ${canBack ? `<button class="public-control" type="button" data-action="go-back" aria-label="Regresar">←</button>` : ""}
      </div>
      <div class="public-overlay__right">
        <button class="public-control" type="button" data-action="toggle-pause" aria-label="${state.paused ? "Reanudar" : "Pausar"}">
          ${state.paused ? "▶" : "❙❙"}
        </button>
        ${showSkip ? `<button class="public-control public-control--text" type="button" data-action="skip-intro">Omitir</button>` : ""}
        <details class="public-settings">
          <summary class="public-control" aria-label="Ajustes de la experiencia">⚙</summary>
          <div class="public-settings__panel" aria-label="Modo de performance">
            ${["cinematic", "balanced", "reduced"]
              .map(mode => `
                <button
                  class="public-settings__option ${state.performanceMode === mode ? "public-settings__option--active" : ""}"
                  type="button"
                  data-action="set-performance-mode"
                  data-mode="${mode}"
                >
                  ${mode}
                </button>
              `)
              .join("")}
          </div>
        </details>
      </div>
    </div>
  `;
}

export function renderMain(content, state, debugMode = false) {
  const viewContent = { ...content, debugMode };
  const sceneRenderer = {
    curtain: renderCurtain,
    "founder-vsl": renderFounderVsl,
    "atom-command-center": renderAtomCommandCenter,
    "halo-selection": renderHaloSelection,
    "black-transition": renderBlackTransition,
    "office-intro": renderOfficeIntro,
    "territory-world": renderTerritoryWorld,
    "question-layer": renderQuestionLayer,
    "objection-layer": renderObjectionLayer,
    "conversion-layer": renderConversionLayer,
    booking: renderBooking
  }[state.activeScene] || renderCurtain;

  const announcer = `
    <div class="sr-only" aria-live="polite" data-scene-announcer>
      Escena ${escapeHtml(state.activeScene)}. ${escapeHtml(content.scenes[state.activeScene].title)}
    </div>
  `;

  if (debugMode) {
    return `
      <div class="app-shell" data-scene="${escapeHtml(state.activeScene)}" data-motion-mode="${escapeHtml(state.performanceMode)}" data-phase="${escapeHtml(state.transitionPhase)}" data-view-mode="debug">
        <a class="skip-link" href="#scene-stage-region">Saltar al contenido de la escena</a>
        <div class="app-shell__backdrop" aria-hidden="true"></div>
        <div class="site-frame">
          ${renderChrome(viewContent, state)}
          <div class="scene-stage" id="scene-stage-region" tabindex="-1">
            ${sceneRenderer(viewContent, state)}
          </div>
          ${renderEventFeed(state)}
        </div>
        ${announcer}
      </div>
    `;
  }

  return `
    <div class="app-shell" data-scene="${escapeHtml(state.activeScene)}" data-motion-mode="${escapeHtml(state.performanceMode)}" data-phase="${escapeHtml(state.transitionPhase)}" data-view-mode="public">
      <a class="skip-link" href="#scene-stage-region">Saltar al contenido de la escena</a>
      <div class="app-shell__backdrop" aria-hidden="true"></div>
      <div class="public-stage" id="scene-stage-region" tabindex="-1">
        ${sceneRenderer(viewContent, state)}
      </div>
      ${renderPublicOverlay(viewContent, state)}
      ${announcer}
    </div>
  `;
}
