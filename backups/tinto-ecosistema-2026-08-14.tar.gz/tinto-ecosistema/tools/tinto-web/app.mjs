import { siteContent } from "./content.mjs";
import { createSceneController } from "./scene-controller.mjs";

const appRoot = document.querySelector("[data-app]");

if (!appRoot) {
  throw new Error("TINTO web app root not found.");
}

const controller = createSceneController({
  content: siteContent,
  root: appRoot
});

controller.start();

window.tintoSceneController = controller;
