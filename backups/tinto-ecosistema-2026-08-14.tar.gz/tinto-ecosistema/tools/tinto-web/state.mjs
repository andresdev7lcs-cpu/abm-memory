import { getQuestion, getSceneIndex, getTerritory } from "./content.mjs";
import { normalizePerformanceMode } from "./performance-mode.mjs";

export function createState(content, initialRoute = null) {
  const route = initialRoute || {
    sceneId: "curtain",
    territoryId: null,
    questionId: null
  };
  const activeTerritoryId =
    route.territoryId || content.territories[0]?.id || null;
  const activeQuestionId =
    route.questionId || getQuestion(content, activeTerritoryId)?.id || null;

  return {
    content,
    sceneOrder: content.sceneOrder.slice(),
    activeScene: route.sceneId || "curtain",
    previousScene: null,
    pendingScene: null,
    transitionOriginScene: null,
    sceneHistory: [],
    transitionPhase: "idle",
    interactionLocked: false,
    reducedMotion: false,
    performanceMode: "cinematic",
    mediaReady: false,
    paused: false,
    activeTerritoryId,
    activeQuestionId,
    eventLog: [],
    lastEvent: null,
    bookingSubmitted: false,
    bookingDraft: {
      nombre: "",
      email: "",
      pais: "",
      territorio: getTerritory(content, activeTerritoryId)?.title || "",
      situacion: "",
      urgencia: "Media",
      tipoAyuda: "Claridad",
      preferenciaContacto: "Email",
      consentimiento: false
    },
    timers: {
      exit: null,
      enter: null,
      auto: null
    }
  };
}

export function getSceneIndexFromState(state, sceneId) {
  return getSceneIndex(state.content, sceneId);
}

export function getActiveTerritory(state) {
  return getTerritory(state.content, state.activeTerritoryId);
}

export function getActiveQuestion(state) {
  const territory = getActiveTerritory(state);

  if (!territory) {
    return null;
  }

  return getQuestion(state.content, territory.id, state.activeQuestionId);
}

export function setPerformanceMode(state, mode) {
  state.performanceMode = normalizePerformanceMode(mode);
  state.reducedMotion = state.performanceMode === "reduced";
}

export function setMediaReady(state, value) {
  state.mediaReady = Boolean(value);
}

export function setPaused(state, value) {
  state.paused = Boolean(value);
  state.interactionLocked = Boolean(value) || state.transitionPhase === "exiting" || state.transitionPhase === "entering";
}

export function setSceneContext(state, { territoryId = null, questionId = null } = {}) {
  if (territoryId !== null) {
    state.activeTerritoryId = territoryId;
    state.bookingDraft.territorio = getTerritory(state.content, territoryId)?.title || "";
  }

  if (questionId !== null) {
    state.activeQuestionId = questionId;
  }
}

export function selectTerritory(state, territoryId) {
  setSceneContext(state, { territoryId, questionId: null });
  state.bookingDraft.territorio =
    getTerritory(state.content, territoryId)?.title || "";
  state.bookingSubmitted = false;
}

export function selectQuestion(state, questionId) {
  state.activeQuestionId = questionId;
  state.bookingSubmitted = false;
}

export function setScene(state, sceneId, options = {}) {
  const { territoryId = null, questionId = null, replaceHistory = false } = options;
  const previousScene = state.activeScene;

  if (!replaceHistory && previousScene && previousScene !== sceneId) {
    state.sceneHistory.push(previousScene);
  }

  state.previousScene = previousScene;
  state.activeScene = sceneId;
  state.pendingScene = null;
  state.transitionPhase = "active";
  state.interactionLocked = false;

  if (territoryId !== null) {
    selectTerritory(state, territoryId);
  }

  if (questionId !== null) {
    selectQuestion(state, questionId);
  }
}

export function startTransition(state, sceneId) {
  state.transitionOriginScene = state.activeScene;
  state.pendingScene = sceneId;
  state.transitionPhase = "exiting";
  state.interactionLocked = true;
}

export function finishExit(state, nextScene, options = {}) {
  const { territoryId = null, questionId = null } = options;
  const origin = state.transitionOriginScene || state.activeScene;
  state.previousScene = origin;
  if (state.sceneHistory[state.sceneHistory.length - 1] !== origin) {
    state.sceneHistory.push(origin);
  }
  state.activeScene = nextScene;
  state.pendingScene = null;
  state.transitionPhase = "entering";

  if (territoryId !== null) {
    selectTerritory(state, territoryId);
  }

  if (questionId !== null) {
    selectQuestion(state, questionId);
  }
}

export function finishEnter(state) {
  state.transitionPhase = "active";
  state.interactionLocked = state.paused;
  state.transitionOriginScene = null;
}

export function abortTransition(state) {
  if (state.transitionOriginScene) {
    state.activeScene = state.transitionOriginScene;
  }

  state.pendingScene = null;
  state.transitionOriginScene = null;
  state.transitionPhase = "idle";
  state.interactionLocked = state.paused;
}

export function goBack(state) {
  const previous = state.sceneHistory.pop();

  if (!previous) {
    return state.activeScene;
  }

  state.pendingScene = null;
  state.activeScene = previous;
  state.previousScene = state.sceneHistory[state.sceneHistory.length - 1] || null;
  state.transitionPhase = "active";
  state.interactionLocked = state.paused;
  return previous;
}

export function advanceScene(state) {
  const currentIndex = getSceneIndexFromState(state, state.activeScene);
  return state.sceneOrder[Math.min(state.sceneOrder.length - 1, currentIndex + 1)];
}

export function prevScene(state) {
  const currentIndex = getSceneIndexFromState(state, state.activeScene);
  return state.sceneOrder[Math.max(0, currentIndex - 1)];
}

export function updateBookingField(state, name, value) {
  state.bookingDraft[name] = value;
}

export function markBookingSubmitted(state) {
  state.bookingSubmitted = true;
}
