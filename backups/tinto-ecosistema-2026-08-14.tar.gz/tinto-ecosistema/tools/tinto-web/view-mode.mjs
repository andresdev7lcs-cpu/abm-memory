export function isDebugMode(location = window.location) {
  const params = new URLSearchParams(location.search);

  if (params.get("debug") === "1") {
    return true;
  }

  const path = location.pathname.replace(/\/+$/, "");
  return path === "/debug";
}
