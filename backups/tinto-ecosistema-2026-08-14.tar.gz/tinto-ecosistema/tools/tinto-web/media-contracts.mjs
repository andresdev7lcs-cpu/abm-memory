export function createMediaContract(media = {}) {
  return {
    image: media.image || "",
    poster: media.poster || media.image || "",
    webm: media.webm || "",
    mp4: media.mp4 || "",
    alt: media.alt || "",
    captions: media.captions || "",
    provisional: media.provisional !== false
  };
}

export function hasPlayableVideo(contract) {
  return Boolean(contract.webm || contract.mp4);
}

export function resolveMediaSource(contract) {
  if (hasPlayableVideo(contract)) {
    return contract;
  }

  return {
    ...contract,
    webm: "",
    mp4: "",
    image: contract.image || contract.poster
  };
}
