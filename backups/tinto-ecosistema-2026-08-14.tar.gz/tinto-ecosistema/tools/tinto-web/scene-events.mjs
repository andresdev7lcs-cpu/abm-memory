export const SCENE_EVENTS = [
  "intro_started",
  "intro_completed",
  "intro_skipped",
  "atom_viewed",
  "territory_hovered",
  "territory_selected",
  "halo_interaction_started",
  "halo_contact_completed",
  "black_transition_started",
  "black_transition_completed",
  "office_intro_started",
  "office_intro_completed",
  "territory_world_entered",
  "question_opened",
  "objection_viewed",
  "cta_revealed",
  "booking_started",
  "booking_completed"
];

export function createEventRecord(type, payload = {}, sceneId = null) {
  return {
    id: `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    timestamp: new Date().toISOString(),
    type,
    sceneId,
    payload
  };
}

export function appendSceneEvent(state, type, payload = {}) {
  if (!SCENE_EVENTS.includes(type)) {
    return null;
  }

  const record = createEventRecord(type, payload, state.activeScene);
  state.eventLog = [record, ...state.eventLog].slice(0, 24);
  state.lastEvent = record;
  return record;
}
