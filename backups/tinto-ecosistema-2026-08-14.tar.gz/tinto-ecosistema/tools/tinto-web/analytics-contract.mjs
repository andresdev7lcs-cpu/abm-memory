export function createAnalyticsContract() {
  return {
    enabled: false,
    trackEvent() {
      return Promise.resolve(false);
    }
  };
}
