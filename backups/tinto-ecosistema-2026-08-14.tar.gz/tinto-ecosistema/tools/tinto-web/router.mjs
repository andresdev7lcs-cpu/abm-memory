import { sceneOrder } from "./content.mjs";
import { isReducedMotion as prefersReducedMotion, prefersReducedData } from "./performance-mode.mjs";

function cleanHash(hash) {
  return String(hash || "")
    .replace(/^#\/?/, "")
    .replace(/^\/+/, "");
}

function normalizeSceneId(sceneId) {
  return sceneOrder.includes(sceneId) ? sceneId : "curtain";
}

export function parseSceneRoute(hash = window.location.hash) {
  const parts = cleanHash(hash).split("/").filter(Boolean);

  if (parts.length === 0 || parts[0] === "home") {
    return { sceneId: "curtain", territoryId: null, questionId: null };
  }

  if (parts[0] === "scene" && parts[1]) {
    return {
      sceneId: normalizeSceneId(parts[1]),
      territoryId: parts[2] || null,
      questionId: parts[3] || null
    };
  }

  if (parts[0] === "territorio" && parts[1]) {
    const territoryId = parts[1];
    const questionId = parts[3] || null;

    if (parts[2] === "pregunta" && questionId) {
      return {
        sceneId: "question-layer",
        territoryId,
        questionId
      };
    }

    return {
      sceneId: "territory-world",
      territoryId,
      questionId: null
    };
  }

  if (parts[0] === "diagnostico" && parts[1]) {
    return {
      sceneId: "booking",
      territoryId: parts[1] || null,
      questionId: parts[3] || null
    };
  }

  if (parts[0] === "board") {
    return {
      sceneId: "atom-command-center",
      territoryId: parts[1] || null,
      questionId: parts[3] || null
    };
  }

  return {
    sceneId: normalizeSceneId(parts[0]),
    territoryId: parts[1] || null,
    questionId: parts[2] || null
  };
}

export function routeToHash(route) {
  const sceneId = normalizeSceneId(route?.sceneId || "curtain");
  const territoryId = route?.territoryId || "";
  const questionId = route?.questionId || "";

  if (sceneId === "curtain") {
    return "#/scene/curtain";
  }

  if (sceneId === "territory-world" || sceneId === "question-layer" || sceneId === "objection-layer" || sceneId === "conversion-layer" || sceneId === "booking") {
    return `#/scene/${sceneId}${territoryId ? `/${territoryId}` : ""}${questionId ? `/${questionId}` : ""}`;
  }

  return `#/scene/${sceneId}${territoryId ? `/${territoryId}` : ""}${questionId ? `/${questionId}` : ""}`;
}

export function isReducedMotion() {
  return prefersReducedMotion();
}

export function shouldReduceData() {
  return prefersReducedData();
}
