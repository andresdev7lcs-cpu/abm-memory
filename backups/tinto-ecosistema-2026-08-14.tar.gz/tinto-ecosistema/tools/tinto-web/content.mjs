const assets = {
  logo: "./assets/logo-mark.svg",
  founderVslPoster: "./assets/founder-vsl-poster.svg",
  founderPortrait: "./assets/founder-portrait.svg",
  founderAvatar: "./assets/founder-avatar.svg",
  haloHand: "./assets/halo-hand.svg",
  glassDoor: "./assets/glass-door.svg",
  tintoCup: "./assets/tinto-cup.svg"
};

export const sceneOrder = [
  "curtain",
  "founder-vsl",
  "atom-command-center",
  "halo-selection",
  "black-transition",
  "office-intro",
  "territory-world",
  "question-layer",
  "objection-layer",
  "conversion-layer",
  "booking"
];

const performanceModes = {
  cinematic: {
    label: "Cinematic",
    description: "Motion completo, canvas, blur suave y capas atmosféricas."
  },
  balanced: {
    label: "Balanced",
    description: "Menos densidad visual, menos loops y media más ligera."
  },
  reduced: {
    label: "Reduced",
    description: "Sin movimiento continuo, navegación clara y contenido completo."
  }
};

const territories = [
  {
    id: "finanzas-patrimonio",
    title: "Finanzas y patrimonio",
    status: "hypothesis",
    approval: "pending_confirmation",
    tone: "forest",
    summary:
      "Territorio provisional para ordenar presión financiera, protección y lectura de decisiones.",
    intro:
      "La experiencia no promete una solución cerrada. Abre una conversación guiada por contexto, urgencia y claridad.",
    questions: [
      {
        id: "flujo-caja",
        title: "Flujo de caja",
        prompt: "¿Qué te está apretando más hoy: gastos, deudas o falta de claridad?",
        provisionalAnswer:
          "Respuesta provisional: ordenar presión, horizonte y prioridades antes de prometer solución.",
        objection:
          "La objeción común es pensar que ordenar también significa vender algo. Aquí no se promete eso.",
        resource: {
          title: "Mapa de lectura provisional",
          copy: "Marco de conversación para detectar presión, urgencia y siguiente paso.",
          label: "Recurso provisional"
        },
        cta: {
          label: "Abrir diagnóstico",
          target: "booking"
        }
      },
      {
        id: "proteccion",
        title: "Protección patrimonial",
        prompt: "¿Qué parte de tu patrimonio necesita más orden o protección?",
        provisionalAnswer:
          "Respuesta provisional: revisar exposición, prioridades y dependencias sin vender una promesa cerrada.",
        objection:
          "La objeción habitual es la incertidumbre: aquí la experiencia aclara sin exagerar resultados.",
        resource: {
          title: "Lista provisional de revisión",
          copy: "Puntos para conversar sin inventar servicios ni resultados.",
          label: "Recurso provisional"
        },
        cta: {
          label: "Ir al diagnóstico",
          target: "booking"
        }
      },
      {
        id: "decisiones",
        title: "Decisiones",
        prompt: "¿Qué decisión financiera has venido posponiendo?",
        provisionalAnswer:
          "Respuesta provisional: convertir la duda en una conversación estructurada y medible.",
        objection:
          "La objeción no es la falta de interés; es la falta de contexto suficiente para actuar.",
        resource: {
          title: "Guion provisional",
          copy: "Preguntas para ordenar la conversación y dejar el siguiente paso claro.",
          label: "Recurso provisional"
        },
        cta: {
          label: "Iniciar diagnóstico",
          target: "booking"
        }
      }
    ]
  },
  {
    id: "activos-inmobiliarios",
    title: "Activos inmobiliarios",
    status: "hypothesis",
    approval: "pending_confirmation",
    tone: "petrol",
    summary:
      "Territorio provisional para decisiones alrededor de inmuebles, tenencia y lectura de activos.",
    intro:
      "El foco no es vender una promesa inmobiliaria. El foco es traducir inquietud en una ruta de conversación útil.",
    questions: [
      {
        id: "tenencia",
        title: "Tenencia",
        prompt: "¿Qué te falta aclarar sobre un inmueble o activo en Colombia?",
        provisionalAnswer:
          "Respuesta provisional: identificar contexto, relación con el activo y decisión pendiente.",
        objection:
          "La duda principal suele ser si el caso es simple o complejo; la experiencia ayuda a leerlo.",
        resource: {
          title: "Marco de aclaración",
          copy: "Diagnóstico preliminar para no mezclar emociones con estructura.",
          label: "Recurso provisional"
        },
        cta: {
          label: "Abrir diagnóstico",
          target: "booking"
        }
      },
      {
        id: "arriendo",
        title: "Arriendo",
        prompt: "¿Qué parte del activo necesita más lectura: ocupación, arriendo o gestión?",
        provisionalAnswer:
          "Respuesta provisional: separar operación, expectativas y próximos pasos.",
        objection:
          "La objeción frecuente es querer resolver todo de una vez. Aquí se separa por capas.",
        resource: {
          title: "Checklist provisional",
          copy: "Revisión ligera para conversación de contexto, no de promesa.",
          label: "Recurso provisional"
        },
        cta: {
          label: "Ir al diagnóstico",
          target: "booking"
        }
      },
      {
        id: "compra",
        title: "Compra",
        prompt: "¿Tu pregunta tiene que ver con comprar, conservar o redefinir el activo?",
        provisionalAnswer:
          "Respuesta provisional: traducir la inquietud a una secuencia clara de conversación.",
        objection:
          "La experiencia no cierra una oferta; ayuda a entender la decisión y su contexto.",
        resource: {
          title: "Ruta provisional",
          copy: "Base para orientar el tablero sin cerrar una oferta no aprobada.",
          label: "Recurso provisional"
        },
        cta: {
          label: "Iniciar diagnóstico",
          target: "booking"
        }
      }
    ]
  },
  {
    id: "educacion-orientacion-financiera",
    title: "Educación y orientación financiera",
    status: "hypothesis",
    approval: "pending_confirmation",
    tone: "copper",
    summary:
      "Territorio provisional para conversación, criterio y orientación sin vender una solución final.",
    intro:
      "Este territorio convierte la pregunta en criterio. No promete resultados ni reemplaza conversación humana sensible.",
    questions: [
      {
        id: "criterio",
        title: "Criterio",
        prompt: "¿Qué decisión necesitas entender mejor antes de actuar?",
        provisionalAnswer:
          "Respuesta provisional: ordenar la decisión en lenguaje simple antes de ofrecer un camino.",
        objection:
          "La objeción más común es sentir que todavía falta información. La escena ayuda a darle forma.",
        resource: {
          title: "Guía provisional de criterio",
          copy: "Marco para traducir complejidad en conversación útil.",
          label: "Recurso provisional"
        },
        cta: {
          label: "Abrir diagnóstico",
          target: "booking"
        }
      },
      {
        id: "habitos",
        title: "Hábito",
        prompt: "¿Qué hábito o patrón quieres cambiar primero?",
        provisionalAnswer:
          "Respuesta provisional: identificar patrón, frecuencia y contexto antes de definir pasos.",
        objection:
          "La resistencia suele venir por hábito, no por falta de interés. El flujo evita presionar.",
        resource: {
          title: "Mapa provisional de hábitos",
          copy: "Apoya la lectura del caso sin inventar credenciales ni promesas.",
          label: "Recurso provisional"
        },
        cta: {
          label: "Ir al diagnóstico",
          target: "booking"
        }
      },
      {
        id: "ruta",
        title: "Ruta",
        prompt: "¿Qué ruta de apoyo te sería útil hoy: claridad, orden o acompañamiento?",
        provisionalAnswer:
          "Respuesta provisional: convertir la necesidad en una conversación medible y reversible.",
        objection:
          "La objeción posible es no querer compromiso inmediato. Por eso la navegación siempre es reversible.",
        resource: {
          title: "Ruta provisional",
          copy: "Estructura para decidir el siguiente paso sin vender un resultado fijo.",
          label: "Recurso provisional"
        },
        cta: {
          label: "Iniciar diagnóstico",
          target: "booking"
        }
      }
    ]
  }
];

const scenes = {
  curtain: {
    label: "Curtain",
    eyebrow: "Escena 01",
    title: "Se abre el telón",
    body:
      "Logo vivo, respiración visual y entrada breve al sistema. El movimiento prepara la llegada de la fundadora sin alargar la carga.",
    primaryAction: { label: "Saltar introducción", action: "skip-intro" },
    secondaryAction: { label: "Entrar", action: "advance" },
    media: {
      image: assets.logo,
      poster: assets.logo,
      alt: "Logo provisional de TINTO"
    },
    notes: ["Logo sin rotación", "Entrada breve", "Fallback reducido disponible"],
    autoAdvance: {
      cinematic: 1100,
      balanced: 800,
      reduced: 0,
      default: 900
    }
  },
  "founder-vsl": {
    label: "Founder VSL",
    eyebrow: "Escena 02",
    title: "VSL breve de la fundadora",
    body:
      "Contenedor de media provisional con poster, soporte futuro para video y captions. El copy no fija un elevator pitch definitivo.",
    primaryAction: { label: "Continuar", action: "advance" },
    secondaryAction: { label: "Omitir introducción", action: "skip-intro" },
    media: {
      poster: assets.founderVslPoster,
      image: assets.founderVslPoster,
      webm: "",
      mp4: "",
      alt: "Poster provisional de la VSL de la fundadora",
      captions: "Captions provisionales para la futura pieza de video."
    },
    notes: ["Captions obligatorios cuando exista video", "Copy claramente provisional"],
    autoAdvance: true
  },
  "atom-command-center": {
    label: "Atom Command Center",
    eyebrow: "Escena 03",
    title: "Home-Átomo",
    body:
      "Tres territorios orbitan alrededor del núcleo. La selección es explícita, accesible y reversible.",
    primaryAction: { label: "Ver territorio", action: "select-territory" },
    secondaryAction: { label: "Regresar", action: "back" },
    media: {
      alt: "Centro narrativo con tres territorios provisionales"
    },
    notes: ["Dotted surface", "Ondas reactivas", "Sin scroll obligatorio"],
    autoAdvance: false
  },
  "halo-selection": {
    label: "Halo Selection",
    eyebrow: "Escena 04",
    title: "Contratación física del halo",
    body:
      "La escena convierte la elección en contacto visual, gesto o fallback abstracto. El contacto es el puente hacia la transición negra.",
    primaryAction: { label: "Confirmar contacto", action: "confirm-halo" },
    secondaryAction: { label: "Volver", action: "back" },
    media: {
      image: assets.haloHand,
      poster: assets.haloHand,
      alt: "Gesto provisional de la mano y el halo"
    },
    notes: ["Fallback obligatorio", "Sin asset final inventado"],
    autoAdvance: false
  },
  "black-transition": {
    label: "Black Transition",
    eyebrow: "Escena 05",
    title: "Corte narrativo",
    body:
      "Apagado gradual, bloqueo temporal y fade simple en reduced motion. La escena solo separa actos.",
    primaryAction: { label: "Continuar", action: "advance" },
    secondaryAction: { label: "Abortar transición", action: "abort-transition" },
    media: {
      alt: "Pantalla de transición oscura"
    },
    notes: ["Corte a negro breve", "Transición abortable", "Interacción bloqueada mientras corre"],
    autoAdvance: true
  },
  "office-intro": {
    label: "Office Intro",
    eyebrow: "Escena 06",
    title: "Puerta de cristal",
    body:
      "Poster provisional, puerta de cristal, taza TINTO y saludo de entrada. Este puente conserva el contexto antes del territorio.",
    primaryAction: { label: "Entrar al territorio", action: "advance" },
    secondaryAction: { label: "Regresar", action: "back" },
    media: {
      image: assets.glassDoor,
      poster: assets.glassDoor,
      alt: "Puerta de cristal provisional"
    },
    notes: ["La navegación de regreso vuelve aquí desde territory-world", "Botón continuar visible"],
    autoAdvance: true
  },
  "territory-world": {
    label: "Territory World",
    eyebrow: "Escena 07",
    title: "Mundo del territorio",
    body:
      "Escena reusable configurada por datos. Permite tema visual, atmósfera, preguntas, recursos, objeciones y CTA.",
    primaryAction: { label: "Abrir preguntas", action: "advance" },
    secondaryAction: { label: "Regresar", action: "back" },
    media: {
      alt: "Mundo temático del territorio activo"
    },
    notes: ["Regreso a office-intro", "No duplica arquitectura por territorio"],
    autoAdvance: false
  },
  "question-layer": {
    label: "Question Layer",
    eyebrow: "Escena 08",
    title: "Preguntas persuasivas",
    body:
      "La capa organiza curiosidad, microcopy, recursos y el siguiente paso sin inventar claims ni recomendaciones.",
    primaryAction: { label: "Ver objeción", action: "advance" },
    secondaryAction: { label: "Cambiar pregunta", action: "select-question" },
    media: {
      alt: "Preguntas progresivas del territorio"
    },
    notes: ["Contenido progresivo", "Regreso visible", "Evento question_opened"],
    autoAdvance: false
  },
  "objection-layer": {
    label: "Objection Layer",
    eyebrow: "Escena 09",
    title: "Objeción y contexto",
    body:
      "Estructura para objeción, contexto, respuesta educativa, limitación y siguiente paso. No incorpora testimonios ni pruebas inventadas.",
    primaryAction: { label: "Continuar", action: "advance" },
    secondaryAction: { label: "Volver", action: "back" },
    media: {
      alt: "Bloque de objeción y respuesta"
    },
    notes: ["Sin testimonios", "Sin prueba falsa", "Regreso reversible"],
    autoAdvance: false
  },
  "conversion-layer": {
    label: "Conversion Layer",
    eyebrow: "Escena 10",
    title: "Síntesis y CTA",
    body:
      "Reconoce el problema, sintetiza y revela el CTA contextual que puentea hacia booking sin precios ni oferta final.",
    primaryAction: { label: "Abrir booking", action: "advance" },
    secondaryAction: { label: "Volver", action: "back" },
    media: {
      alt: "Síntesis de intención y llamado a agendamiento"
    },
    notes: ["CTA contextual", "Sin pricing", "Sin oferta final"],
    autoAdvance: false
  },
  booking: {
    label: "Booking",
    eyebrow: "Escena 11",
    title: "Booking mock local",
    body:
      "Formulario local sin persistencia ni integración externa. Captura estructura, no clientes reales.",
    primaryAction: { label: "Enviar mock", action: "submit-booking" },
    secondaryAction: { label: "Volver", action: "back" },
    media: {
      alt: "Formulario mock local"
    },
    notes: ["external_calendar disabled", "lead_scoring disabled", "persistent_storage disabled"],
    autoAdvance: false
  }
};

const booking = {
  mode: "local_mock",
  externalCalendar: "disabled",
  leadScoring: "disabled",
  automaticApproval: "disabled",
  automaticRejection: "disabled",
  persistentStorage: "disabled",
  fields: {
    nombre: {
      label: "Nombre",
      type: "text",
      placeholder: "Nombre y apellido"
    },
    email: {
      label: "Email",
      type: "email",
      placeholder: "correo@ejemplo.com"
    },
    pais: {
      label: "País",
      type: "select",
      options: ["(andres confirma)", "Colombia", "Estados Unidos", "España", "Canadá", "Otro"]
    },
    territorio: {
      label: "Territorio",
      type: "select",
      options: territories.map(territory => territory.title)
    },
    situacion: {
      label: "Situación",
      type: "textarea",
      placeholder: "Describe brevemente qué está pasando"
    },
    urgencia: {
      label: "Urgencia",
      type: "select",
      options: ["Baja", "Media", "Alta", "Muy alta"]
    },
    tipoAyuda: {
      label: "Tipo de ayuda",
      type: "select",
      options: ["Claridad", "Orden", "Seguimiento", "Acompañamiento"]
    },
    preferenciaContacto: {
      label: "Preferencia de contacto",
      type: "select",
      options: ["Email", "WhatsApp", "Llamada", "Mensaje directo"]
    },
    consentimiento: {
      label: "Consentimiento",
      type: "checkbox",
      copy:
        "Acepto que este formulario es un mock local y que no se guardan datos sensibles de forma permanente."
    }
  }
};

export const siteContent = {
  brand: {
    name: "TINTO",
    label: "WEB TINTO",
    slogan: "Base funcional del motor de escenas v0.2."
  },
  assets,
  sceneOrder,
  performanceModes,
  territories,
  scenes,
  booking
};

export function getTerritory(content, territoryId) {
  if (!territoryId) {
    return null;
  }

  return content.territories.find(item => item.id === territoryId) || null;
}

export function getQuestion(content, territoryId, questionId) {
  const territory = getTerritory(content, territoryId);

  if (!territory) {
    return null;
  }

  if (!questionId) {
    return territory.questions[0] || null;
  }

  return territory.questions.find(item => item.id === questionId) || null;
}

export function getScene(content, sceneId) {
  return content.scenes[sceneId] || content.scenes.curtain;
}

export function getSceneIndex(content, sceneId) {
  const index = content.sceneOrder.indexOf(sceneId);
  return index >= 0 ? index : 0;
}
