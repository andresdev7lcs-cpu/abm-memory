import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HOST = "127.0.0.1";
const PORT = 4580;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".svg": "image/svg+xml; charset=utf-8",
  ".json": "application/json; charset=utf-8"
};

function send(res, statusCode, body, contentType = "text/plain; charset=utf-8") {
  res.writeHead(statusCode, {
    "Content-Type": contentType,
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function safeResolve(requestPath) {
  const urlPath = requestPath === "/" ? "/index.html" : requestPath;
  const normalized = path.normalize(urlPath).replace(/^(\.\.[/\\])+/, "");
  return path.join(__dirname, normalized);
}

const server = http.createServer((req, res) => {
  if (req.method !== "GET") {
    send(res, 405, "Method not allowed");
    return;
  }

  const filePath = safeResolve(req.url || "/");

  if (!filePath.startsWith(__dirname)) {
    send(res, 403, "Forbidden");
    return;
  }

  const exists = fs.existsSync(filePath);
  const isDirectory = exists && fs.statSync(filePath).isDirectory();
  const ext = path.extname(filePath);

  if (!exists || isDirectory) {
    if (!ext) {
      const indexPath = path.join(__dirname, "index.html");
      const indexFile = fs.readFileSync(indexPath);
      send(res, 200, indexFile, MIME[".html"]);
      return;
    }

    send(res, 404, "Not found");
    return;
  }

  const contentType = MIME[ext] || "application/octet-stream";
  const file = fs.readFileSync(filePath);

  send(res, 200, file, contentType);
});

server.listen(PORT, HOST, () => {
  console.log(`TINTO web prototype running at http://${HOST}:${PORT}`);
});
