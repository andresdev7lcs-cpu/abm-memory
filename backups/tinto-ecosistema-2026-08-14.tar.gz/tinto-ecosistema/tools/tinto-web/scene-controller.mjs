import { appendSceneEvent } from "./scene-events.mjs";
import { attachAtmosphere } from "./canvas-atmosphere.mjs";
import { getAutoAdvanceMs, getSceneMotionBudget } from "./motion-engine.mjs";
import { detectPerformanceMode } from "./performance-mode.mjs";
import { parseSceneRoute, routeToHash } from "./router.mjs";
import {
  abortTransition,
  advanceScene,
  createState,
  finishEnter,
  finishExit,
  getActiveTerritory,
  goBack,
  markBookingSubmitted,
  selectQuestion,
  selectTerritory,
  setMediaReady,
  setPaused,
  setPerformanceMode,
  startTransition,
  updateBookingField
} from "./state.mjs";
import { renderMain } from "./components.mjs";
import { isDebugMode } from "./view-mode.mjs";

function defaultTerritory(content) {
  return content.territories[0]?.id || null;
}

function defaultQuestion(content, territoryId) {
  const territory = content.territories.find(item => item.id === territoryId);
  return territory?.questions[0]?.id || null;
}

function resolveRouteContext(content, route) {
  const territoryId = route.territoryId || defaultTerritory(content);
  const questionId = route.questionId || defaultQuestion(content, territoryId);

  return { territoryId, questionId };
}

function sceneNeedsQuestion(sceneId) {
  return ["question-layer", "objection-layer", "conversion-layer", "booking"].includes(sceneId);
}

function sceneNeedsTerritory(sceneId) {
  return ["halo-selection", "black-transition", "office-intro", "territory-world", "question-layer", "objection-layer", "conversion-layer", "booking"].includes(sceneId);
}

function emitEnterEvents(state, sceneId) {
  switch (sceneId) {
    case "curtain":
      if (state.eventLog.length === 0) {
        appendSceneEvent(state, "intro_started");
      }
      break;
    case "atom-command-center":
      appendSceneEvent(state, "atom_viewed", {
        territoryId: state.activeTerritoryId
      });
      break;
    case "black-transition":
      appendSceneEvent(state, "black_transition_started", {
        territoryId: state.activeTerritoryId
      });
      break;
    case "office-intro":
      appendSceneEvent(state, "office_intro_started", {
        territoryId: state.activeTerritoryId
      });
      break;
    case "territory-world":
      appendSceneEvent(state, "territory_world_entered", {
        territoryId: state.activeTerritoryId
      });
      break;
    case "question-layer":
      appendSceneEvent(state, "question_opened", {
        territoryId: state.activeTerritoryId,
        questionId: state.activeQuestionId
      });
      break;
    case "objection-layer":
      appendSceneEvent(state, "objection_viewed", {
        territoryId: state.activeTerritoryId,
        questionId: state.activeQuestionId
      });
      break;
    case "conversion-layer":
      appendSceneEvent(state, "cta_revealed", {
        territoryId: state.activeTerritoryId,
        questionId: state.activeQuestionId
      });
      break;
    case "booking":
      appendSceneEvent(state, "booking_started", {
        territoryId: state.activeTerritoryId,
        questionId: state.activeQuestionId
      });
      break;
    default:
      break;
  }
}

function emitExitEvents(state, sceneId, trigger = "advance") {
  if (sceneId === "founder-vsl" && trigger === "advance") {
    appendSceneEvent(state, "intro_completed");
  }

  if (sceneId === "black-transition" && trigger === "advance") {
    appendSceneEvent(state, "black_transition_completed");
  }

  if (sceneId === "office-intro" && trigger === "advance") {
    appendSceneEvent(state, "office_intro_completed");
  }
}

export function createSceneController({ content, root }) {
  const initialRoute = resolveRouteContext(content, parseSceneRoute());
  const state = createState(content, parseSceneRoute());
  setPerformanceMode(state, detectPerformanceMode());
  state.activeTerritoryId = initialRoute.territoryId;
  state.activeQuestionId = initialRoute.questionId;
  let atmosphereCleanup = null;
  let suppressHashChange = false;
  const debugMode = isDebugMode();

  function clearTimers() {
    if (state.timers.exit) {
      window.clearTimeout(state.timers.exit);
      state.timers.exit = null;
    }

    if (state.timers.enter) {
      window.clearTimeout(state.timers.enter);
      state.timers.enter = null;
    }

    if (state.timers.auto) {
      window.clearTimeout(state.timers.auto);
      state.timers.auto = null;
    }
  }

  function setDocumentState() {
    document.documentElement.dataset.scene = state.activeScene;
    document.documentElement.dataset.motionMode = state.performanceMode;
    document.documentElement.dataset.phase = state.transitionPhase;
    document.documentElement.dataset.paused = state.paused ? "true" : "false";
    document.title = `${content.brand.label} - ${content.scenes[state.activeScene].label}`;
  }

  function mountSceneEffects() {
    if (atmosphereCleanup) {
      atmosphereCleanup();
      atmosphereCleanup = null;
    }

    if (state.activeScene === "atom-command-center" || state.activeScene === "territory-world") {
      const canvas = root.querySelector("[data-atmosphere-canvas]");
      const territory = getActiveTerritory(state);
      atmosphereCleanup = attachAtmosphere(canvas, {
        mode: state.performanceMode,
        reducedMotion: state.reducedMotion,
        tone: territory?.tone || "default"
      });
    }

    setMediaReady(state, true);
  }

  function render(focus = false) {
    root.innerHTML = renderMain(content, state, debugMode);
    root.setAttribute("aria-busy", state.transitionPhase === "active" ? "false" : "true");
    setDocumentState();
    mountSceneEffects();

    const announcer = root.querySelector("[data-scene-announcer]");
    if (announcer) {
      announcer.textContent = `Escena ${content.scenes[state.activeScene].title}.`;
    }

    if (focus) {
      const primaryControl = root.querySelector("[data-action]");
      if (primaryControl) {
        primaryControl.focus({ preventScroll: true });
      }
    }
  }

  function writeHash(route) {
    suppressHashChange = true;
    window.location.hash = routeToHash(route);
  }

  function updateSceneContext(sceneId, options = {}) {
    if (sceneNeedsTerritory(sceneId)) {
      const territoryId = options.territoryId || state.activeTerritoryId || defaultTerritory(content);
      selectTerritory(state, territoryId);
      state.activeQuestionId = options.questionId || state.activeQuestionId || defaultQuestion(content, territoryId);
    }

    if (sceneNeedsQuestion(sceneId)) {
      const territoryId = options.territoryId || state.activeTerritoryId || defaultTerritory(content);
      const questionId = options.questionId || state.activeQuestionId || defaultQuestion(content, territoryId);
      selectTerritory(state, territoryId);
      selectQuestion(state, questionId);
    }

    if (sceneId === "atom-command-center") {
      state.activeQuestionId = null;
    }
  }

  function syncFromRoute(route = parseSceneRoute()) {
    clearTimers();
    state.sceneHistory = [];
    state.transitionPhase = "idle";
    state.interactionLocked = false;
    state.pendingScene = null;
    state.transitionOriginScene = null;
    state.paused = false;

    const sceneId = route.sceneId || "curtain";
    const context = resolveRouteContext(content, route);
    state.activeScene = sceneId;
    state.previousScene = null;
    state.activeTerritoryId = context.territoryId;
    state.activeQuestionId = context.questionId;
    updateSceneContext(sceneId, context);
    emitEnterEvents(state, sceneId);
    render(true);
    scheduleAutoAdvance();
  }

  function scheduleAutoAdvance() {
    clearTimers();

    const scene = content.scenes[state.activeScene];
    const delay = getAutoAdvanceMs(scene, state.performanceMode);

    if (!scene.autoAdvance || delay <= 0 || state.paused || state.interactionLocked) {
      return;
    }

    state.timers.auto = window.setTimeout(() => {
      if (!state.interactionLocked && !state.paused) {
        handleAdvance("auto");
      }
    }, delay);
  }

  function completeTransition(nextScene, options = {}) {
    const { territoryId = null, questionId = null, replaceHistory = false, trigger = "advance" } = options;
    const originScene = state.activeScene;

    startTransition(state, nextScene);
    render();

    const motionBudget = getSceneMotionBudget(state.performanceMode);
    const exitDelay = state.reducedMotion ? 60 : motionBudget.exitMs;
    const enterDelay = state.reducedMotion ? 60 : motionBudget.enterMs;

    state.timers.exit = window.setTimeout(() => {
      emitExitEvents(state, originScene, trigger);
      finishExit(state, nextScene, { territoryId, questionId });
      render();

      state.timers.enter = window.setTimeout(() => {
        finishEnter(state);
        emitEnterEvents(state, nextScene);
        render();

        if (replaceHistory) {
          state.sceneHistory = state.sceneHistory.slice(0, -1);
        }

        if (nextScene === "booking") {
          scheduleAutoAdvance();
        } else {
          scheduleAutoAdvance();
        }
      }, enterDelay);
    }, exitDelay);

    writeHash({
      sceneId: nextScene,
      territoryId: territoryId || state.activeTerritoryId,
      questionId: questionId || state.activeQuestionId
    });
  }

  function jumpTo(sceneId, options = {}) {
    if (state.interactionLocked && !options.force) {
      return;
    }

    clearTimers();
    completeTransition(sceneId, {
      territoryId: options.territoryId || state.activeTerritoryId,
      questionId: options.questionId || state.activeQuestionId,
      replaceHistory: Boolean(options.replaceHistory),
      trigger: options.trigger || "advance"
    });
  }

  function handleSkipIntro() {
    appendSceneEvent(state, "intro_skipped");
    jumpTo("atom-command-center", { replaceHistory: true, trigger: "skip" });
  }

  function handleAdvance(trigger = "advance") {
    const scene = state.activeScene;

    if (scene === "curtain") {
      jumpTo("founder-vsl", { trigger });
      return;
    }

    if (scene === "founder-vsl") {
      jumpTo("atom-command-center", { trigger });
      return;
    }

    if (scene === "atom-command-center") {
      jumpTo("halo-selection", { trigger, territoryId: state.activeTerritoryId });
      return;
    }

    if (scene === "halo-selection") {
      handleConfirmHalo();
      return;
    }

    if (scene === "black-transition") {
      jumpTo("office-intro", { trigger, territoryId: state.activeTerritoryId });
      return;
    }

    if (scene === "office-intro") {
      jumpTo("territory-world", { trigger, territoryId: state.activeTerritoryId });
      return;
    }

    if (scene === "territory-world") {
      jumpTo("question-layer", { trigger, territoryId: state.activeTerritoryId, questionId: state.activeQuestionId });
      return;
    }

    if (scene === "question-layer") {
      jumpTo("objection-layer", { trigger, territoryId: state.activeTerritoryId, questionId: state.activeQuestionId });
      return;
    }

    if (scene === "objection-layer") {
      jumpTo("conversion-layer", { trigger, territoryId: state.activeTerritoryId, questionId: state.activeQuestionId });
      return;
    }

    if (scene === "conversion-layer") {
      jumpTo("booking", { trigger, territoryId: state.activeTerritoryId, questionId: state.activeQuestionId });
      return;
    }

    if (scene === "booking") {
      jumpTo("conversion-layer", { trigger, territoryId: state.activeTerritoryId, questionId: state.activeQuestionId });
    }
  }

  function handleConfirmHalo() {
    appendSceneEvent(state, "halo_interaction_started", {
      territoryId: state.activeTerritoryId
    });

    clearTimers();
    state.interactionLocked = true;
    render();

    const delay = state.reducedMotion ? 80 : 420;
    state.timers.auto = window.setTimeout(() => {
      appendSceneEvent(state, "halo_contact_completed", {
        territoryId: state.activeTerritoryId
      });
      jumpTo("black-transition", {
        territoryId: state.activeTerritoryId,
        trigger: "advance",
        force: true
      });
    }, delay);
  }

  function handleBack() {
    if (state.interactionLocked && state.transitionPhase !== "active") {
      return;
    }

    const fallback = state.sceneHistory[state.sceneHistory.length - 1];
    const target = fallback || (() => {
      const index = state.sceneOrder.indexOf(state.activeScene);
      return state.sceneOrder[Math.max(0, index - 1)];
    })();

    if (!target || target === state.activeScene) {
      return;
    }

    clearTimers();
    state.sceneHistory.pop();
    jumpTo(target, { replaceHistory: true, trigger: "back" });
  }

  function handlePauseToggle() {
    setPaused(state, !state.paused);
    clearTimers();
    if (!state.paused) {
      scheduleAutoAdvance();
    }
    render();
  }

  function handleAbort() {
    clearTimers();
    abortTransition(state);
    render(true);
    scheduleAutoAdvance();
  }

  function handlePerformanceMode(mode) {
    setPerformanceMode(state, mode);
    render();
    scheduleAutoAdvance();
  }

  function handleSelectTerritory(territoryId) {
    if (!territoryId) {
      return;
    }

    selectTerritory(state, territoryId);
    appendSceneEvent(state, "territory_hovered", { territoryId });
    appendSceneEvent(state, "territory_selected", { territoryId });

    if (state.activeScene === "atom-command-center") {
      jumpTo("halo-selection", {
        territoryId,
        trigger: "advance"
      });
      return;
    }

    writeHash({
      sceneId: state.activeScene,
      territoryId: state.activeTerritoryId,
      questionId: state.activeQuestionId
    });
    render();
  }

  function handleSelectQuestion(questionId) {
    if (!questionId) {
      return;
    }

    selectQuestion(state, questionId);
    appendSceneEvent(state, "question_opened", {
      territoryId: state.activeTerritoryId,
      questionId
    });
    writeHash({
      sceneId: state.activeScene,
      territoryId: state.activeTerritoryId,
      questionId
    });
    render();
  }

  function handleBookingInput(target) {
    const field = target.dataset.bookingField;

    if (!field) {
      return;
    }

    const value = target.type === "checkbox" ? target.checked : target.value;
    updateBookingField(state, field, value);
  }

  function handleBookingSubmit(event) {
    event.preventDefault();
    markBookingSubmitted(state);
    appendSceneEvent(state, "booking_completed", {
      territoryId: state.activeTerritoryId,
      questionId: state.activeQuestionId
    });
    render();
  }

  function handlePointerHover(target) {
    const territoryButton = target.closest("[data-territory-id]");
    if (territoryButton && state.activeScene === "atom-command-center") {
      appendSceneEvent(state, "territory_hovered", {
        territoryId: territoryButton.dataset.territoryId
      });
    }
  }

  function bindEvents() {
    root.addEventListener("click", event => {
      const actionTarget = event.target.closest("[data-action]");

      if (!actionTarget) {
        return;
      }

      const action = actionTarget.dataset.action;

      if (action === "advance-scene") {
        handleAdvance();
        return;
      }

      if (action === "go-back") {
        handleBack();
        return;
      }

      if (action === "toggle-pause") {
        handlePauseToggle();
        return;
      }

      if (action === "abort-transition") {
        handleAbort();
        return;
      }

      if (action === "skip-intro") {
        handleSkipIntro();
        return;
      }

      if (action === "set-performance-mode") {
        handlePerformanceMode(actionTarget.dataset.mode);
        return;
      }

      if (action === "jump-scene") {
        const sceneId = actionTarget.dataset.sceneId;
        if (sceneId) {
          jumpTo(sceneId, { replaceHistory: true, force: true });
        }
        return;
      }

      if (action === "select-territory") {
        handleSelectTerritory(actionTarget.dataset.territoryId);
        return;
      }

      if (action === "select-question") {
        const territory = state.activeTerritoryId || defaultTerritory(content);
        const current = content.territories.find(item => item.id === territory);
        const nextQuestionId =
          actionTarget.dataset.questionId || current?.questions[(current.questions.findIndex(question => question.id === state.activeQuestionId) + 1) % current.questions.length]?.id;
        handleSelectQuestion(nextQuestionId);
        return;
      }

      if (action === "confirm-halo") {
        handleConfirmHalo();
        return;
      }
    });

    root.addEventListener("submit", event => {
      const form = event.target.closest("[data-booking-form]");
      if (form) {
        handleBookingSubmit(event);
      }
    });

    root.addEventListener("input", event => {
      const field = event.target.closest("[data-booking-field]");
      if (field) {
        handleBookingInput(field);
      }
    });

    root.addEventListener("pointerenter", event => {
      handlePointerHover(event.target);
    }, true);

    root.addEventListener("focusin", event => {
      handlePointerHover(event.target);
    });

    root.addEventListener("wheel", event => {
      if (state.interactionLocked || state.paused) {
        return;
      }

      if (event.target.closest("input, select, textarea, button, form")) {
        return;
      }

      const delta = Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : event.deltaY;
      if (Math.abs(delta) < 18) {
        return;
      }

      event.preventDefault();
      if (delta > 0) {
        handleAdvance("wheel");
      } else {
        handleBack();
      }
    }, { passive: false });

    let touchStartX = 0;
    let touchStartY = 0;
    let touchActive = false;

    root.addEventListener("touchstart", event => {
      const touch = event.changedTouches[0];
      if (!touch) {
        return;
      }
      touchStartX = touch.clientX;
      touchStartY = touch.clientY;
      touchActive = true;
    }, { passive: true });

    root.addEventListener("touchend", event => {
      if (!touchActive || state.interactionLocked || state.paused) {
        touchActive = false;
        return;
      }

      const touch = event.changedTouches[0];
      if (!touch) {
        touchActive = false;
        return;
      }

      const dx = touch.clientX - touchStartX;
      const dy = touch.clientY - touchStartY;
      touchActive = false;

      if (Math.abs(dx) < 40 && Math.abs(dy) < 40) {
        return;
      }

      if (Math.abs(dx) > Math.abs(dy)) {
        if (dx < 0) {
          handleAdvance("swipe");
        } else {
          handleBack();
        }
      } else if (dy < 0) {
        handleAdvance("swipe");
      } else {
        handleBack();
      }
    }, { passive: true });

    document.addEventListener("keydown", event => {
      if (event.defaultPrevented) {
        return;
      }

      if (event.key === "Escape") {
        handlePauseToggle();
        return;
      }

      if (event.key === "ArrowRight" || event.key === "PageDown") {
        event.preventDefault();
        handleAdvance("keyboard");
      }

      if (event.key === "ArrowLeft" || event.key === "PageUp") {
        event.preventDefault();
        handleBack();
      }

      if (event.key === " " && state.activeScene === "curtain") {
        event.preventDefault();
        handleSkipIntro();
      }
    });

    window.addEventListener("hashchange", () => {
      if (suppressHashChange) {
        suppressHashChange = false;
        return;
      }

      syncFromRoute(parseSceneRoute());
    });
  }

  function start() {
    bindEvents();
    syncFromRoute(parseSceneRoute());
  }

  return {
    state,
    start,
    render: () => render(),
    syncFromRoute,
    jumpTo,
    handleAdvance,
    handleBack,
    handleSkipIntro,
    handleConfirmHalo,
    handleAbort,
    setPerformanceMode: handlePerformanceMode
  };
}
