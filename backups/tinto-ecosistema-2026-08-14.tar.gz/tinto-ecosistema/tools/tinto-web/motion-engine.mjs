import { getPerformanceBudget, normalizePerformanceMode } from "./performance-mode.mjs";

export function getSceneMotionBudget(mode) {
  const normalized = normalizePerformanceMode(mode);
  const budget = getPerformanceBudget(normalized);

  return {
    mode: normalized,
    enterMs: budget.enterMs,
    exitMs: budget.exitMs,
    autoMs: budget.autoMs,
    waveMs: budget.waveMs
  };
}

export function getAutoAdvanceMs(scene, mode) {
  if (!scene || !scene.autoAdvance) {
    return 0;
  }

  if (typeof scene.autoAdvance === "number") {
    return scene.autoAdvance;
  }

  const normalized = normalizePerformanceMode(mode);
  const config = scene.autoAdvance;

  if (config === true) {
    return getPerformanceBudget(normalized).autoMs;
  }

  if (typeof config === "object" && config !== null) {
    return config[normalized] || config.default || 0;
  }

  return 0;
}

export function clampDuration(duration, mode) {
  const budget = getSceneMotionBudget(mode);
  return Math.max(0, Math.min(duration, budget.exitMs + budget.enterMs + budget.autoMs));
}
