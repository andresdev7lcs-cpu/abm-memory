# Changelog

Todas los cambios notables de TINTO Guardian se documentan en este archivo. Formato inspirado en [Keep a Changelog](https://keepachangelog.com/).

## [Unreleased]

### Added

- Apertura del Bloque 3 para estrategia y oferta.
- Rama `feature/tinto-offer-strategy-v1.0.0`.
- Alcance previsto de la oferta comercial: diagnóstico, unidad comercial, buyer persona, oferta principal (transformación, mecanismo, elementos centrales/secundarios, bonos, valor percibido), precio y facilidades de pago, reversión de riesgo, identidad, ecosistema de ascensión, evento de conversión, script de venta y objeciones, propuesta comercial final, auditoría y cierre.

### Known constraints

- No promoción antes de oferta aprobada.
- No país, nicho, buyer persona, precio ni oferta tratados como validados sin evidencia.
- No nuevas verticales sin change request.
- Operación estratégica sujeta a revisión y aprobación humana.
- Bloque 3 no está completado, validado ni publicado. v1.0.0 no producida todavía.

## [0.2.0] — Bloque 1 de TINTO Guardian

Sistema manual de goberanza: tickets, auditoría independiente, aprobaciones humanas, memoria persistente.

### Added

- **Instrucciones maestras:**
  - `AGENTS.md`: Protocolo para agentes técnicos (Claude Code, Codex).
  - `CLAUDE.md`: Protocolo para Claude Code (estratega documental).

- **Agentes:**
  - `.claude/agents/tinto-supervisor.md`: Gatekeeper de guardrails (semáforos verde/amarillo/rojo/azul).
  - `.claude/agents/quality-auditor.md`: Validador independiente de entregas.

- **Skills:**
  - `.claude/skills/tinto-business-incubator/`: Skills Codex para incubación de ofertas.
  - `.codex/skills/tinto-business-incubator/`: Espejo de skills para Codex.

- **Protocolos de orquestación:**
  - `orchestration/WORKFLOW_PROTOCOL.md`: Estados de tickets, transiciones válidas, checklists.
  - `orchestration/ROLE_MATRIX.md`: Roles (Andrés, Fundadora, Claude Code, Codex, Auditor), autoridades, límites.
  - `orchestration/STAGE_GATES.md`: Gates por stage (GOV, STR, MKT, BRD, PRD, CNT, FUN, SAL, TECH, WEB, VAL, OPS).
  - `orchestration/STRATEGIC_GUARDRAILS.md`: Guardrails (verdes, amarillos, rojos, azules).
  - `orchestration/ESCALATION_PROTOCOL.md`: Niveles de escalación (E0-E3).
  - `orchestration/CHANGE_CONTROL.md`: Solicitudes de cambio.

- **Contratos JSON (JSON Schema 2020-12):**
  - `orchestration/DELIVERABLE_SCHEMA.json`: Estructura de entregables.
  - `orchestration/QA_REPORT_SCHEMA.json`: Estructura de reportes QA.
  - `orchestration/HUMAN_APPROVAL_SCHEMA.json`: Estructura de aprobaciones humanas.
  - `orchestration/ticket-router.json`: Routing manual de tickets.

- **Routing manual:**
  - Asignación de productor por ticket (Claude Code, Codex, Fundadora).
  - Asignación de auditor independiente (no igual a productor).
  - Asignación de aprobador (Andrés, Fundadora).

- **Memoria persistente:**
  - `memory/CURRENT_STATE.md`: Snapshot operativo de estado actual.
  - `memory/LEARNINGS.md`: Registros de aprendizajes derivados de trabajo real.
  - `memory/ASSUMPTIONS.md`: Hipótesis activas sin validar.
  - `memory/VALIDATED_FACTS.md`: Hechos verificables en repositorio.

- **Carpetas de operación:**
  - `deliveries/`: Entregables completados por ticket.
  - `reviews/`: Evidencia de revisión e auditoría.
  - `comments/`: Registros por ticket en formato JSONL (append-only).
  - `change-requests/`: Solicitudes de cambio.
  - `timeline/`: Historia de ejecución.

- **Documentación raíz:**
  - `INSTALL.md`: Guía de instalación y verificación.
  - `REVIEW_CHECKLIST.md`: Checklist operativo para revisar tickets.
  - `CHANGELOG.md`: Este archivo.
  - `MIGRATION_NOTES.md`: Notas de migración desde baseline.

### Changed

- **Separación de funciones:** Productor ≠ Auditor ≠ Aprobador (enforced en schema).
- **Estados de tickets:** Redefinidos 9 estados (pending, ready, in_progress, agent_review, human_review, blocked, failed, completed, rejected).
- **Transiciones:** Validadas en WORKFLOW_PROTOCOL.md (no automáticas, manuales).
- **Aprobación:** Requiere entrada explícita. Silencio = no aprobado.
- **Archivos permitidos:** Restricción explícita en `roadmap.md` "Files allowed to change".
- **Ledgers:** `roadmap-status.md` y `comments/` son append-only (jamás reescribir líneas).

### Fixed

- **SLAs inventadas:** Eliminadas referencias a "24h", "2h", "inmediato". Sistema manual sin automatizaciones.
- **Umbrales automáticos:** Removidos. Todas las transiciones requieren intervención humana.
- **Semáforos normalizados:** Verde/Amarillo/Rojo/Azul (STRATEGIC_GUARDRAILS.md).
- **Independencia productor–auditor:** Reforzada en schema (campo `producer` ≠ `auditor`).
- **Distinción QA vs validación comercial:** Auditoría técnica (QA) ≠ Validación de mercado (VAL).
- **Fallback seguro:** Si auditor no disponible → Escalar a Andrés. No auto-asignación.
- **Restricciones JSON Schema:** Trasladadas a WORKFLOW_PROTOCOL.md (runtime/manual).
- **Separación conceptual:** Decisiones (DECISION_LOG.md) ≠ Hipótesis (ASSUMPTIONS.md) ≠ Hechos (VALIDATED_FACTS.md) ≠ Aprendizajes (LEARNINGS.md).

### Known limitations

- **Operación manual:** v0.2.0 sin automatizaciones. Todas las transiciones de estado son manuales en `roadmap-status.md`.
- **Sin runtime automatizado:** No hay webhooks, gatillos, colas de trabajo.
- **Sin integración completa:** Dashboard local sin sincronización a workflow.
- **Sin cierre automático:** Ningún ticket se marca completado sin aprobación humana explícita.
- **Sin selección automática de auditor:** Andrés asigna manualmente según independencia.
- **Sin validación comercial de primera oferta:** Bloque 2 (v0.3.0) incluirá lanzamiento y métricas.
- **Bloque 3 no iniciado:** Escalamiento y nuevas verticales fuera de Bloque 1.

### Dependencias

- **Git 2.x.x:** Para control de versiones.
- **Node 14+:** Opcional para dashboard local y validación JSON.
- **Claude Code:** Para documentación y estrategia.
- **Codex:** Opcional para código y validación técnica.

### Decisiones asociadas

- **DEC-001:** Una sola unidad comercial (MVP).
- **DEC-002:** Marca personal + TINTO como dos rieles.
- **DEC-003:** No plataforma propia en MVP (herramientas existentes).
- **DEC-004:** Avatar IA como multiplicador (con límites).
- **DEC-005:** Primer objetivo: 100 leads (PROPOSED).

---

**Nota:** Bloque 1 v0.2.0 cerrado en main y etiquetado como v0.2.0. Pruebas integrales completadas con resultado `pass`. Merge commit: 5156e65. Implementation commit: 563aa4f. Baseline commit: 454842c. Próxima fase: Bloque 2 (v0.3.0) incluirá integración dashboard y automatizaciones selectivas.
