# REVIEW CHECKLIST — TINTO Guardian v0.2.0

Lista operativa para revisar tickets y cierre del Bloque 1. Manual, no automatizado.

## Antes de producir

- [ ] Ticket identificado en `roadmap.md` (línea exacta).
- [ ] Objetivo y scope definido claramente en acceptance criteria.
- [ ] Archivos autorizados listados en "Files allowed to change".
- [ ] Dependencias completadas (verificar en `roadmap-status.md`).
- [ ] Productor asignado (Claude Code o Codex según tipo).
- [ ] Auditor independiente seleccionado (no igual a productor).
- [ ] Aprobador identificado (Andrés o fundadora según tipo).
- [ ] Fuentes de verdad leídas:
  - [ ] DECISION_LOG.md
  - [ ] PROJECT_RULES.md
  - [ ] roadmap.md (ticket específico)
  - [ ] memory/CURRENT_STATE.md
  - [ ] comments/[TICKET-ID].jsonl (si existe)
- [ ] Supuestos claramente marcados con `[HIPÓTESIS]` o `(andres confirma)`.
- [ ] Cambio estructural detectado (cita de STRATEGIC_GUARDRAILS.md si aplica).
- [ ] No viola guardrails: verificar STRATEGIC_GUARDRAILS.md.

**Si algo falla:** Bloquear ticket. Escalar a Andrés.

## Antes de entregar

### Entregable (productor)

- [ ] Todos los acceptance criteria cumplidos 100%.
- [ ] Archivos modificados solo en "Files allowed to change" (verificar con `git status`).
- [ ] Pruebas ejecutadas (si aplica, ver "Verification commands" en roadmap.md).
- [ ] Cero errores de sintaxis (Node, JSON, Markdown).
- [ ] No fuera de alcance (scope creep detectado).
- [ ] Estado mantenido como `in_progress` (no marcar completado).
- [ ] Evidencia clara (archivos, logs, notas).
- [ ] NO marcado como `completed`. Esperar revisión independiente.

### Registro de entrega

- [ ] Entrada creada en `roadmap-status.md` con evento `completed`:
  ```json
  {
    "timestamp": "ISO-8601",
    "ticket": "TICKET-ID",
    "event": "completed",
    "runner": "productor",
    "model": "model-name",
    "message": "Producción completada. Esperando agent_review."
  }
  ```
- [ ] Entregable guardado en `deliveries/[TICKET-ID]_v1.[ext]`.
- [ ] Comentario registrado en `comments/[TICKET-ID].jsonl`:
  ```json
  {
    "timestamp": "ISO-8601",
    "author": "productor",
    "type": "completion",
    "message": "Qué se completó. Archivos: [lista]. Cambios: [resumen]."
  }
  ```

## Auditoría (revisor independiente)

### Independencia

- [ ] Auditor ≠ Productor (verificar ROLE_MATRIX.md).
- [ ] Auditor competente para tipo de entregable (doc, código, test).
- [ ] Sin conflicto de interés.

### Validación

- [ ] Acceptance criteria cumplidos 100% (o gap explícitamente documentado).
- [ ] Coherencia con DECISION_LOG.md.
- [ ] Coherencia con PROJECT_RULES.md.
- [ ] Coherencia con STRATEGIC_GUARDRAILS.md.
- [ ] Archivos modificados ⊆ "Files allowed to change" (verificar git diff).
- [ ] Cero invención de datos (para documentación).
- [ ] Viabilidad técnica (para código).
- [ ] Viabilidad operativa (para documentación).
- [ ] Supuestos marcados correctamente.
- [ ] Fuentes citadas son de autoridad.

### Clasificación de hallazgos

- [ ] Critical: Bloquea cierre completamente.
- [ ] Major: Afecta funcionalidad o decisión. Requiere rework.
- [ ] Minor: Mejora recomendada, no bloquea.
- [ ] Improvement: Sugerencia, opcional.

**Mapping:**
- Cero Critical + Cero Major → `pass`
- Cero Critical + Minor → `conditional_pass`
- Major hallazgos → `changes_required`
- Critical hallazgos → `fail`
- Dependencia falta → `blocked`

### Resultado canónico (ÚNICO)

- [ ] `pass`: Todo cumple. Listo para human_review.
- [ ] `conditional_pass`: Cumple excepto gap menor documentado.
- [ ] `changes_required`: Major findings. Requiere rework.
- [ ] `fail`: Critical findings. No cumple.
- [ ] `blocked`: Dependencia o información falta.

**¿Cuándo es `blocked` vs `fail`?**
- `blocked`: Algo externo impide auditoría (dependencia pending, información faltante confirmable por Andrés).
- `fail`: Entregable tiene defecto crítico (viola guardrail, AC incumplido, invención de datos).

### Prohibición de auto-aprobación

- [ ] Auditor NO aprueba su propio trabajo.
- [ ] Auditor NO marca `completed`.
- [ ] Auditor registra resultado canónico en `comments/[TICKET-ID].jsonl`:
  ```json
  {
    "timestamp": "ISO-8601",
    "author": "auditor",
    "type": "qa_report",
    "result": "pass|conditional_pass|changes_required|fail|blocked",
    "message": "Auditoría: [RESULTADO]. Hallazgos: [lista si aplica]."
  }
  ```

- [ ] Transición de estado (auditoría → human_review): Responsabilidad de autoridad designada según WORKFLOW_PROTOCOL.md (auditor registra resultado; autoridad formal/Andrés/Sistema actualiza roadmap-status.md).
  - [ ] Si `pass` o `conditional_pass`: Auditor recomienda aprobación. Autoridad formaliza transición a `human_review`.
  - [ ] Si `changes_required`, `fail`, o `blocked`: Auditor registra hallazgos. Estado NO avanza (retorna a `in_progress` si cambios, queda `human_review` si escalación).

## Aprobación humana (Andrés o fundadora)

### Autoridad correcta

- [ ] Cambios estratégicos: Andrés.
- [ ] Representación de fundadora, marca personal, avatar IA: Fundadora + Andrés.
- [ ] Decisiones comerciales: Andrés.
- [ ] Decisiones técnicas: Andrés (basado en recomendación Codex).

### QA disponible

- [ ] Auditoría completada (estado `human_review`).
- [ ] Resultado de auditoría documentado en comments/.
- [ ] Major findings resueltos (si `changes_required`, productor retrabajó).

### Entrega disponible

- [ ] Archivo en `deliveries/[TICKET-ID]_v1.[ext]` accesible.
- [ ] comments/[TICKET-ID].jsonl contiene historial.
- [ ] roadmap-status.md contiene transiciones.

### Condiciones resueltas

- [ ] Si `conditional_pass`: condiciones documentadas y aceptadas.
- [ ] Si `changes_requested` (anterior): cambios completados y reauditoría pasó.

### Validación especial (si aplica)

- [ ] Representación de fundadora: Fundadora valida autenticidad (BRD tickets).
- [ ] Estructura de cambio: Andrés aprueba DEC nueva (si requiere).
- [ ] Avatar IA: Fundadora autoriza consentimiento (BRD-004).
- [ ] Precio o presupuesto: Andrés confirma (PROP tickets).

### Prohibición de aprobación por silencio

- [ ] Aprobación requiere entrada explícita en HUMAN_APPROVAL_SCHEMA.json o comments/.
- [ ] Silencio = no aprobado.
- [ ] Aprobador registra:
  ```json
  {
    "timestamp": "ISO-8601",
    "ticketId": "TICKET-ID",
    "approver": "andres",
    "approverRole": "andres",
    "decision": "approved",
    "scopeApproved": true,
    "nextState": "completed",
    "relatedQaReport": "comments/TICKET-ID.jsonl",
    "relatedDeliverable": "deliveries/TICKET-ID_v1.[ext]",
    "decisionAt": "ISO-8601"
  }
  ```

### Transiciones permitidas post-aprobación

- [ ] Si `approved`: state = `completed`.
- [ ] Si `approved_with_conditions`: state = `in_progress` (no `completed` aún).
- [ ] Si `changes_requested`: state = `in_progress`. Productor retrabaja.
- [ ] Si `rejected`: state = `rejected`. Productor retrabaja desde cero o escala.
- [ ] Si `blocked`: state = `blocked`. Escalar a Andrés.

## Cierre Git (NO automatizado)

Antes de cerrar Bloque 1, verificación humana final:

- [ ] Documentación actualizada:
  - [ ] roadmap-status.md contiene todas las transiciones.
  - [ ] comments/ contiene historial completo por ticket.
  - [ ] deliveries/ contiene todos los entregables.
  - [ ] memory/CURRENT_STATE.md actualizado con estado final Bloque 1.
  
- [ ] Pruebas integrales ejecutadas:
  - [ ] Validar 4 esquemas JSON con Node (sin errores).
  - [ ] Validar que roadmap-status.md es valid JSONL.
  - [ ] Validar que comments/ contiene JSONL válido.
  - [ ] Validar que orchestration/ protocolos están completos.
  
- [ ] Verificación Git:
  - [ ] `git diff --check` sin errores de whitespace.
  - [ ] `git status --short` muestra solo archivos autorizados.
  - [ ] Cero archivos no autorizados modificados.
  - [ ] Cero cambios a DECISION_LOG.md, PROJECT_RULES.md, roadmap.md sin aprobación.

- [ ] Revisión humana (Andrés):
  - [ ] Todos los tickets Bloque 1 en estado `completed`.
  - [ ] Todos los cambios autorizados explícitamente.
  - [ ] Cero contradicciones entre documentos.
  - [ ] Bloque 1 completado según STAGE_GATES.md.

- [ ] Commit explícitamente autorizado (NO automático):
  - [ ] Andrés ejecuta: `git add <archivos-autorizados>`
  - [ ] Andrés ejecuta: `git commit -m "Mensaje aprobado"`
  - [ ] Andrés ejecuta: `git tag -a v0.2.0 -m "TINTO Guardian v0.2.0 Bloque 1 completado"`
  
- [ ] Rama limpia post-commit:
  - [ ] `git status` muestra "working tree clean".
  - [ ] `git log` contiene commit de cierre con tag v0.2.0.
  - [ ] `git diff main..HEAD` muestra cambios de Bloque 1.

## Confirmación final

- [x] Andrés confirmó explícitamente que el Bloque 1 v0.2.0 pasó pruebas integrales (2026-07-28).
- [x] Resultado de pruebas integrales: `pass` (cero hallazgos Critical/Major).
- [x] Aprobación explícita de Andrés registrada.
- [ ] Git tag `v0.2.0` creado y confirmado en `git log`.
- [ ] Rama `feature/tinto-guardian-core-v0.2.0` mergeada a `main` (pendiente).
- [ ] Cierre Git completado (commit, merge, tag).
- [ ] Próxima fase: Bloque 2 (v0.3.0 con integraciones).
- [ ] Contacto: Escalar bloques críticos a Andrés.
