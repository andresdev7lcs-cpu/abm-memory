# Roadmap operativo TINTO

> Fuente operativa de tickets del proyecto.  
> Este archivo es de solo lectura para el dashboard.  
> Los cambios de estado viven en `roadmap-status.md`.

## GOV-001 — Validar estructura inicial del repositorio

- Area: Governance
- Priority: critical
- Recommended model: human
- Owner: Andrés
- Dependencies: none
- Status baseline: completed
- Target date: (andres confirma)
- Objective: Revisar nombres, carpetas, reglas y fuentes de verdad.
- Scope: Validar la arquitectura inicial del proyecto.
- Files allowed to change: DECISION_LOG.md, PROJECT_RULES.md, README.md
- Verification commands: manual review
- Acceptance criteria: La estructura queda aprobada o comentada por Andrés.

## GOV-002 — Incorporar fuentes originales

- Area: Governance
- Priority: high
- Recommended model: human
- Owner: Andrés
- Dependencies: GOV-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Copiar documentos, logo, hoja de vida y activos de la fundadora.
- Scope: Preservar todas las fuentes originales dentro del repositorio.
- Files allowed to change: source-material/client/*
- Verification commands: manual review
- Acceptance criteria: Los archivos originales quedan copiados, registrados y disponibles.

## STR-001 — Consolidar contexto maestro

- Area: Strategy
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: GOV-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Crear la primera versión controlada de TINTO_MASTER_CONTEXT.md.
- Scope: Consolidar visión, límites, principios, hipótesis y decisiones aprobadas.
- Files allowed to change: docs/00_governance/TINTO_MASTER_CONTEXT.md
- Verification commands: manual review
- Acceptance criteria: El documento maestro refleja el estado real del proyecto sin contradicciones.

## STR-002 — Documentar ecosistema amplio

- Area: Strategy
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: STR-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Organizar la visión futura de TINTO como ecosistema de verticales.
- Scope: Documentar casas futuras, condiciones de activación y límites.
- Files allowed to change: docs/01_ecosystem/TOMO_00_ECOSISTEMA_AMPLIO.md
- Verification commands: manual review
- Acceptance criteria: La visión amplia queda documentada sin confundirse con el MVP.

## STR-003 — Documentar primera unidad comercial

- Area: Strategy
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: STR-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Crear el tomo operativo de la primera unidad comercial.
- Scope: Nicho, subnichos, oferta, embudo, operación, métricas y restricciones.
- Files allowed to change: docs/01_ecosystem/TOMO_01_UNIDAD_COMERCIAL_FINANCIERA.md
- Verification commands: manual review
- Acceptance criteria: La primera unidad comercial queda estructurada como sistema validable.

## MKT-001 — Diseñar entrevistas de descubrimiento

- Area: Market
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: STR-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Crear el instrumento para validar momentos, lenguaje, problemas y disposición de pago.
- Scope: Guion, criterios, registro y método de síntesis.
- Files allowed to change: docs/02_market/*
- Verification commands: manual review
- Acceptance criteria: Existe un guion listo para entrevistar prospectos reales.

## MKT-002 — Definir primer país de validación

- Area: Market
- Priority: high
- Recommended model: human
- Owner: Andrés y fundadora
- Dependencies: GOV-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Seleccionar el país inicial según red, acceso y capacidad de generar conversaciones.
- Scope: Comparar mercados y priorizar uno.
- Files allowed to change: docs/02_market/NICHO_Y_SUBNICHOS.md
- Verification commands: manual review
- Acceptance criteria: Un país inicial queda aprobado y justificado.

## MKT-003 — Investigar competidores y sustitutos

- Area: Market
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: MKT-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Identificar quién se lleva hoy la atención, confianza y dinero de la audiencia.
- Scope: Competidores directos, sustitutos, redes informales y referentes.
- Files allowed to change: docs/02_market/COMPETIDORES_Y_SUSTITUTOS.md
- Verification commands: manual review
- Acceptance criteria: Existe una matriz competitiva con hallazgos accionables.

## MKT-004 — Priorizar nicho y subnichos

- Area: Market
- Priority: critical
- Recommended model: human
- Owner: Equipo
- Dependencies: MKT-001, MKT-002, MKT-003
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Elegir el primer microsegmento mediante evidencia y matriz de validación.
- Scope: Aplicar criterios de urgencia, acceso, pago, encaje y viabilidad.
- Files allowed to change: docs/02_market/NICHO_Y_SUBNICHOS.md
- Verification commands: manual review
- Acceptance criteria: Un subnicho queda priorizado y los demás clasificados.

## MKT-005 — Construir buyer persona prioritario

- Area: Market
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: MKT-004
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Caracterizar con precisión el cliente ideal del primer subnicho.
- Scope: BP, eneatipo, arquetipo, NDP, miedos, deseos, objeciones y gatillos.
- Files allowed to change: docs/02_market/BUYER_PERSONAS.md, docs/02_market/NDP_MIEDOS_Y_DESEOS.md
- Verification commands: manual review
- Acceptance criteria: El buyer persona permite orientar mensajes, oferta y funnel.

## BRD-001 — Definir arquitectura marca personal más TINTO

- Area: Brand
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: STR-001, GOV-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Delimitar funciones, mensajes y relación entre las dos marcas.
- Scope: Roles, límites, transferencia de confianza y coordinación editorial.
- Files allowed to change: docs/03_brand/ARQUITECTURA_DE_MARCA.md
- Verification commands: manual review
- Acceptance criteria: Marca personal y TINTO operan como dos rieles coherentes.

## BRD-002 — Definir marca personal de la fundadora

- Area: Brand
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: BRD-001, GOV-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Construir posicionamiento, voz, arquetipo y proyección pública.
- Scope: Trayectoria, personalidad, tono, autoridad y narrativa.
- Files allowed to change: docs/03_brand/MARCA_PERSONAL_FUNDADORA.md
- Verification commands: manual review
- Acceptance criteria: Existe un brief claro y utilizable de la marca personal.

## BRD-003 — Definir identidad estratégica de TINTO

- Area: Brand
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: BRD-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Definir concepto, personalidad, tono, dirección visual y diferenciación.
- Scope: Colorimetría preliminar, arquetipo, mensajes y límites visuales.
- Files allowed to change: docs/03_brand/IDENTIDAD_TINTO.md, docs/03_brand/TONO_VOZ_Y_MENSAJES.md
- Verification commands: manual review
- Acceptance criteria: Existe un brief de identidad previo al manual de marca.

## BRD-004 — Definir protocolo del avatar IA

- Area: AI Avatar
- Priority: high
- Recommended model: human
- Owner: Andrés y fundadora
- Dependencies: BRD-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Aprobar uso de imagen, voz, guiones, herramientas y controles.
- Scope: Consentimiento, límites, revisión, divulgación y flujo de producción.
- Files allowed to change: docs/03_brand/PROTOCOLO_AVATAR_IA.md
- Verification commands: manual review
- Acceptance criteria: El uso del avatar queda delimitado y aprobado.

## PRD-001 — Diseñar portafolio inicial de servicios

- Area: Product
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: MKT-004, MKT-005
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Convertir necesidades del subnicho en servicios concretos y entregables.
- Scope: Productos gratuitos, entrada, principal, continuidad y premium.
- Files allowed to change: docs/04_products/PORTAFOLIO_DE_SERVICIOS.md
- Verification commands: manual review
- Acceptance criteria: El portafolio tiene lógica, jerarquía y foco.

## PRD-002 — Diseñar escalera de valor

- Area: Product
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: PRD-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Organizar el recorrido de valor desde contenido hasta recurrencia.
- Scope: Lead magnet, oferta de entrada, principal, continuidad y premium.
- Files allowed to change: docs/04_products/ESCALERA_DE_VALOR.md
- Verification commands: manual review
- Acceptance criteria: Cada nivel tiene objetivo, entregable y siguiente paso.

## PRD-003 — Diseñar primera oferta comercial

- Area: Product
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: PRD-001, PRD-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Definir promesa, entregables, límites, duración, precio y CTA.
- Scope: Oferta piloto de la primera unidad comercial.
- Files allowed to change: docs/04_products/OFERTAS_Y_ENTREGABLES.md
- Verification commands: manual review
- Acceptance criteria: La oferta se entiende en menos de un minuto y puede entregarse.

## CNT-001 — Diseñar motor editorial

- Area: Content
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: BRD-002, BRD-003, MKT-005
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Crear pilares, formatos, canales y funciones del contenido.
- Scope: Marca personal, TINTO, tono, CTA y métricas.
- Files allowed to change: docs/05_marketing/MOTOR_DE_CONTENIDOS.md
- Verification commands: manual review
- Acceptance criteria: Existe una arquitectura editorial vinculada al funnel.

## CNT-002 — Diseñar lead magnets por subnicho

- Area: Content
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: PRD-001, CNT-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Crear activos de captura alineados con los principales NDP.
- Scope: PDFs, audios, plantillas, diagnósticos, alertas o recursos.
- Files allowed to change: docs/05_marketing/LEAD_MAGNETS.md
- Verification commands: manual review
- Acceptance criteria: Cada lead magnet tiene buyer, función, CTA y métrica.

## CNT-003 — Diseñar VSL y eventos de conversión

- Area: Content
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: PRD-003, CNT-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Crear la narrativa de educación, autoridad, objeciones y CTA.
- Scope: VSL, mini conferencia, live y Tinto virtual.
- Files allowed to change: docs/05_marketing/VSL_Y_EVENTOS.md
- Verification commands: manual review
- Acceptance criteria: Existe al menos un guion de evento listo para producir.

## FUN-001 — Diseñar customer journey

- Area: Marketing
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: MKT-005, PRD-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Definir el recorrido completo del usuario desde descubrimiento hasta continuidad.
- Scope: Etapas, creencias, activos, CTA y métricas.
- Files allowed to change: docs/05_marketing/CUSTOMER_JOURNEYS.md
- Verification commands: manual review
- Acceptance criteria: El journey conecta contenido, embudo, venta y entrega.

## FUN-002 — Diseñar funnel inicial

- Area: Marketing
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: PRD-003, CNT-002, CNT-003, FUN-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Crear lead magnet, nutrición, VSL o evento, sesión y seguimiento.
- Scope: Funnel de validación para el primer subnicho.
- Files allowed to change: docs/05_marketing/EMBUDOS_POR_SUBNICHO.md
- Verification commands: manual review
- Acceptance criteria: El funnel tiene etapas, activos, responsables y metas.

## SAL-001 — Diseñar proceso comercial

- Area: Sales
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: PRD-003, FUN-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Crear calificación, diagnóstico, propuesta, seguimiento y cierre.
- Scope: Proceso comercial completo.
- Files allowed to change: docs/06_sales/PROCESO_COMERCIAL.md
- Verification commands: manual review
- Acceptance criteria: El proceso permite operar oportunidades de forma consistente.

## SAL-002 — Crear guiones de diagnóstico y cierre

- Area: Sales
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: SAL-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Construir preguntas, cierres, objeciones y seguimientos.
- Scope: Llamada diagnóstica, propuesta y cierre.
- Files allowed to change: docs/06_sales/GUIONES_DE_DIAGNOSTICO.md, docs/06_sales/CIERRES_Y_OBJECIONES.md
- Verification commands: manual review
- Acceptance criteria: La fundadora puede realizar llamadas con un guion claro.

## SAL-003 — Definir CRM y seguimiento

- Area: Sales
- Priority: medium
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: SAL-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Definir campos, etapas, responsables y cadencia de seguimiento.
- Scope: CRM mínimo viable.
- Files allowed to change: docs/06_sales/CRM_Y_SEGUIMIENTO.md
- Verification commands: manual review
- Acceptance criteria: Existe una estructura operativa para registrar leads y oportunidades.

## TECH-001 — Definir stack tecnológico

- Area: Technology
- Priority: high
- Recommended model: human
- Owner: Andrés
- Dependencies: FUN-002, SAL-003
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Elegir dominio, hosting, email, CRM, automatización, analítica y avatar.
- Scope: Escenarios esencial, profesional y escalable.
- Files allowed to change: docs/08_costs/COSTOS_FIJOS_TECNOLOGICOS.md, docs/08_costs/ESCENARIOS_DE_INFRAESTRUCTURA.md
- Verification commands: manual review
- Acceptance criteria: El stack queda definido con costos y responsables.

## WEB-001 — Diseñar arquitectura del sitio web

- Area: Technology
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: BRD-003, PRD-003, FUN-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Definir estructura, páginas, copy, formularios y CTA.
- Scope: Sitio fundacional de TINTO.
- Files allowed to change: docs/05_marketing/*, docs/07_proposal/*
- Verification commands: manual review
- Acceptance criteria: Existe un mapa web aprobado antes del desarrollo.

## WEB-002 — Construir sitio web fundacional

- Area: Technology
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: WEB-001, TECH-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Publicar un sitio funcional alineado con oferta, marca y embudo.
- Scope: Desarrollo, formularios, analítica y conexión con CTA.
- Files allowed to change: (andres confirma)
- Verification commands: (andres confirma)
- Acceptance criteria: El sitio carga, captura datos y dirige a la siguiente acción.

## WEB-003 — WEB TINTO v0.3 — Visual Refinement & Asset Direction

- Area: Technology
- Type: specification
- Priority: high
- Recommended model: (andres confirma)
- Owner: Boutique
- Responsable documental: Claude Code
- Responsable de implementación futura: Codex
- Status baseline: in_progress
- Estado final esperado: agent_review
- Dependencies: WEB-002 (`pending`), BRD-003 (`pending`), PRD-003 (`pending`), FUN-002 (`pending`), TECH-001 (`pending`)
- Target date: (andres confirma)
- Objective: Producir la especificación visual completa de la maqueta predefinitiva de WEB TINTO v0.3 (composición, jerarquía, sistema de componentes, tokens, mapa de assets, prompts de producción, motion map y plan responsive) sin ejecutar implementación frontend.
- Scope: Documentación de dirección visual sobre la base funcional v0.2 ya existente (11 escenas, motor de escenas, state machine, 18 eventos, navegación reversible, vista pública/debug, performance tiers, booking mock).

### Nota de dependencias

Ninguna dependencia está completada. Esta fase avanza **solo como especificación documental**, según el permiso de `roadmap-status.md` para producir diagnóstico, hipótesis o propuesta de trabajo sin marcarlos como validados. Ningún entregable de WEB-003 puede marcarse como aprobado sin revisión humana explícita de Andrés. WEB-003 no desbloquea ni sustituye a WEB-001 ni a WEB-002.

### Files allowed to change

- `roadmap.md` (solo el registro de este ticket)
- `docs/03_offer_strategy/web/v0.3/*`
- `deliveries/WEB-TINTO-V0.3-CLAUDE-SPECIFICATION.md`
- `comments/WEB-003.jsonl` (append)

### Files forbidden

- `tools/tinto-web/**` (toda la implementación: HTML, CSS, JavaScript, assets)
- Motor de escenas, state machine, eventos, router, orden canónico, booking mock, performance engine, vista debug
- `DECISION_LOG.md`, `PROJECT_RULES.md`, `AGENTS.md`, `CLAUDE.md`
- `roadmap-status.md` (ledger, solo append autorizado)
- `docs/03_offer_strategy/web/v0.2/**` (documentos aprobados)
- STR-001, EVIDENCE_DIAGNOSIS, `memory/**`, stage gates, guardrails

### Entregables

1. `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_VISUAL_REFINEMENT.md`
2. `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_SCENE_COMPOSITIONS.md`
3. `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_COMPONENT_SYSTEM.md`
4. `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_DESIGN_TOKENS.md`
5. `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_ASSET_MAP.md`
6. `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_ASSET_PROMPTS.md`
7. `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_MOTION_MAP.md`
8. `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_RESPONSIVE_PLAN.md`
9. `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_HUMAN_REVIEW_GUIDE.md`
10. `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_CODEX_IMPLEMENTATION_HANDOFF.md`
11. `deliveries/WEB-TINTO-V0.3-CLAUDE-SPECIFICATION.md`

### Acceptance criteria

- Existen los 11 entregables listados.
- La secuencia canónica de 11 escenas se conserva sin alteración.
- Cada escena tiene composición desktop, tablet y móvil especificada.
- Cada asset tiene ID, prioridad (P0/P1/P2), formato, proporción, fallback y estado.
- Los tokens quedan nombrados y listos para CSS, sin implementarse.
- El motion queda documentado y clasificado, sin implementarse.
- El alcance de Codex queda explícito: archivos permitidos y prohibidos.
- No se modificó ningún archivo de `tools/tinto-web/`.
- No se produjo oferta, precio, claim, garantía, testimonio ni promoción.

### Guardrails

- No se codifica: Claude Code actúa solo como estratega documental (`AGENTS.md`, `CLAUDE.md`).
- No se produce oferta comercial, precios, claims, garantías, resultados ni testimonios.
- No se activa promoción (bloqueada hasta oferta aprobada, `roadmap-status.md`).
- No se define nicho, país prioritario ni buyer persona definitivo.
- No se inventan datos, trayectoria ni credenciales de la fundadora.
- No se generan imágenes: solo prompts de producción en texto.
- Los territorios permanecen como `[HIPÓTESIS]` con `approval: pending_confirmation`.
- Motion avanzado permanece bloqueado hasta aprobación de la maqueta.

### Condición de handoff

WEB-003 pasa a `agent_review` cuando los 11 entregables existen y la validación documental confirma que `tools/tinto-web/` no fue modificado. La implementación queda en manos de Codex **solo después** de `human_pass` de Andrés sobre `WEB_TINTO_V0_3_HUMAN_REVIEW_GUIDE.md`. Si el resultado es `human_changes_required`, la especificación se revisa antes de cualquier implementación.

- Verification commands: `git diff --check`, `git status --short`, revisión manual de Andrés
- Acceptance criteria: Existe una especificación visual predefinitiva aprobada por revisión humana antes de la implementación de Codex.

## PROP-001 — Construir propuesta comercial para TINTO

- Area: Proposal
- Priority: critical
- Recommended model: (andres confirma)
- Owner: Andrés
- Dependencies: STR-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Presentar alcance, entregables, cronograma, costos y responsabilidades.
- Scope: Propuesta comercial narrativa y ejecutiva.
- Files allowed to change: docs/07_proposal/PROPUESTA_COMERCIAL_FUENTE.md
- Verification commands: manual review
- Acceptance criteria: La propuesta está lista para exportarse a DOCX y PDF.

## COST-001 — Estructurar presupuesto del proyecto

- Area: Operations
- Priority: high
- Recommended model: human
- Owner: Andrés
- Dependencies: TECH-001, PROP-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Separar honorarios, implementación, tecnología, producción y distribución.
- Scope: Presupuesto inicial y continuidad.
- Files allowed to change: docs/08_costs/PRESUPUESTO_IMPLEMENTACION.md, dashboard-data/budget.json
- Verification commands: manual review
- Acceptance criteria: La clienta puede distinguir honorarios de costos externos.

## VAL-001 — Preparar lanzamiento de validación

- Area: Validation
- Priority: critical
- Recommended model: human
- Owner: Equipo
- Dependencies: FUN-002, SAL-002, WEB-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Activar red, contenido, lead magnet y eventos.
- Scope: Primera campaña orgánica de validación.
- Files allowed to change: dashboard-data/metrics.json, dashboard-data/content-calendar.json
- Verification commands: manual review
- Acceptance criteria: El sistema está listo para captar y medir los primeros leads.

## VAL-002 — Conseguir primeros 100 leads

- Area: Validation
- Priority: high
- Recommended model: human
- Owner: Equipo
- Dependencies: VAL-001
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Captar y segmentar los primeros 100 leads.
- Scope: Contenido, red, alianzas, eventos y seguimiento.
- Files allowed to change: dashboard-data/metrics.json
- Verification commands: manual review
- Acceptance criteria: Se registran 100 leads con fuente y segmento.

## VAL-003 — Realizar conversaciones calificadas

- Area: Validation
- Priority: critical
- Recommended model: human
- Owner: Fundadora
- Dependencies: VAL-002, SAL-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Convertir leads educados en conversaciones diagnósticas.
- Scope: Calificación, entrevistas y registro de objeciones.
- Files allowed to change: dashboard-data/metrics.json
- Verification commands: manual review
- Acceptance criteria: Se alcanza la meta de conversaciones definida.

## VAL-004 — Cerrar primeros clientes

- Area: Validation
- Priority: critical
- Recommended model: human
- Owner: Fundadora
- Dependencies: VAL-003, PRD-003
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Convertir conversaciones calificadas en clientes de pago y aprendizaje.
- Scope: Propuesta, cierre, onboarding y entrega.
- Files allowed to change: dashboard-data/metrics.json
- Verification commands: manual review
- Acceptance criteria: Se alcanzan los primeros clientes pagos y se documenta aprendizaje.

## OPS-001 — Documentar manual operativo de marketing

- Area: Operations
- Priority: medium
- Recommended model: (andres confirma)
- Owner: Boutique
- Dependencies: CNT-001, FUN-002
- Status baseline: pending
- Target date: (andres confirma)
- Objective: Crear el ciclo operativo semanal de contenidos, captación, seguimiento y medición.
- Scope: Roles, revisión, publicación, respuesta, registro y aprendizaje.
- Files allowed to change: docs/05_marketing/MANUAL_OPERATIVO_MARKETING.md
- Verification commands: manual review
- Acceptance criteria: El equipo puede operar el sistema sin improvisación.