# TINTO Quality Gates — Controles de calidad estratégicos

---

## 1. Propósito

Definir puntos de control (quality gates) que aseguran cada entrega cumple aceptance criteria, no contiene supuestos no validados, y está alineada con decisiones aprobadas. Quality gates previenen sobreconstrucción, falta de evidencia y autoaprobación.

---

## 2. Relación con `orchestration/STAGE_GATES.md`

**Diferencia:**

- **Stage Gate:** ¿Completamos todos los tickets de este stage? ¿Podemos avanzar? (Punto de control macro)
- **Quality Gate:** ¿Este entregable individual cumple aceptance criteria? ¿Es creíble? ¿Es accionable? (Punto de control micro)

**Interrelación:**

```
Stage Gate = AND(Quality Gate 1, Quality Gate 2, ... Quality Gate N)

Un stage pasa si TODOS sus quality gates pasan.
```

---

## 3. Diferencia entre stage gate y quality gate

| Aspecto | Stage Gate | Quality Gate |
|--------|-----------|------------|
| **Scope** | Toda una etapa (MKT, BRD, PRD) | Un ticket individual |
| **Evaluador** | Andrés | Quality auditor |
| **Decisión** | Avanzar a siguiente stage | Pass / Fail / Conditional |
| **Criterio** | Todos tickets completados | AC cumplido 100% |
| **Frecuencia** | Cada 4-8 semanas | Cada ticket (continuo) |

---

## 4. Quality Gates Definidos

### QG-01 — Coherencia estratégica

**Objetivo:** Verificar que entregable no contradice DECISION_LOG.md, PROJECT_RULES.md, o contexto maestro.

**Preguntas de control:**
- ¿Contradice alguna decisión aprobada (DEC-001 a DEC-005)?
- ¿Viola alguna regla de PROJECT_RULES.md?
- ¿Abre nuevas verticales sin autorización?
- ¿Cambia nicho sin decisión de Andrés?

**Evidencia requerida:**
- Cita de DECISION_LOG.md o PROJECT_RULES.md si aplica.
- Listado de decisiones respetadas.

**Pass:** Alineado 100%, no contradice.
**Conditional Pass:** Alineado pero requiere aclaración menor.
**Fail:** Contradice directamente.
**Blocked:** Decisión requerida antes de validar.

**Quién revisa:** Auditor (consulta DECISION_LOG.md).
**Quién aprueba:** Andrés.

**Ejemplos incumplimiento:**
- Ticket propone nueva vertical (viola DEC-001).
- Propuesta cambio de nicho sin datos (requiere Andrés).
- Descripción asume presupuesto (falta decisión).

---

### QG-02 — Especificidad

**Objetivo:** Verificar que entregable es específico, no genérico.

**Preguntas de control:**
- ¿Es el buyer específico (nombre, rol, ingresos, ubicación)?
- ¿Es el problema específico (no "necesitan ayuda")?
- ¿Es la oferta específica (no "asesoría general")?
- ¿El nicho es específico (no "colombianos en exterior")?

**Evidencia requerida:**
- Buyer persona con 3+ atributos demográficos.
- Problema con urgencia, frecuencia, impacto.
- Oferta con entregables concretos.
- Nicho priorizado (de matriz).

**Pass:** Específico en todos niveles.
**Conditional Pass:** Mostly específico, minores clarificaciones.
**Fail:** Genérico, ambiguo.
**Blocked:** Información faltante (andres confirma).

**Quién revisa:** Auditor.
**Quién aprueba:** Andrés.

**Ejemplos incumplimiento:**
- "Profesionales necesitan dinero" → Genérico.
- "Colombianos en exterior" (sin país, rol, ingreso) → Genérico.
- "Asesoría fiscal" (sin duración, entregables) → Ambiguo.

---

### QG-03 — Evidencia

**Objetivo:** Verificar que afirmaciones se sustentan en datos, conversaciones o documentos, no supuestos.

**Preguntas de control:**
- ¿Buyer persona basado en conversaciones reales (cantidad suficiente para patrón)?
- ¿Problema validado (no supuesto)?
- ¿Disposición de pago (dinero o supuesto)?
- ¿Pricing basado en validación?
- ¿Valor percibido calculado (no arbitrario)?

**Evidencia requerida:**
- Notas de conversaciones (cantidad suficiente para patrón, definida en ticket).
- Datos de mercado (fuente, fecha).
- Testimonios o referencias.
- Validación con fundadora (si toca marca).

**Pass:** Todas afirmaciones tienen evidencia.
**Conditional Pass:** Mayoría tiene evidencia, minores huecos (claros como [HIPÓTESIS]).
**Fail:** Afirmaciones sin evidencia marcadas como hechos.
**Blocked:** Información faltante crítica (andres confirma).

**Quién revisa:** Auditor + Quality auditor agent.
**Quién aprueba:** Andrés.

**Ejemplos incumplimiento:**
- "El buyer paga USD 2000" (sin conversación).
- "Existe problema urgente" (sin 3+ mencionan).
- "Competencia cuesta USD 5000" (sin investigación).

---

### QG-04 — Viabilidad operativa

**Objetivo:** Verificar que entregable puede ejecutarse manualmente (MVP) sin plataforma propia.

**Preguntas de control:**
- ¿La oferta puede entregarse sin software propietario?
- ¿Fundadora tiene capacidad de entrega (tiempo)?
- ¿Está documentado el proceso operativo?
- ¿Escalable hasta 10-20 clientes?

**Evidencia requerida:**
- Guion de entrega o proceso documentado.
- Confirmación de fundadora (puede entregar?).
- Herramientas existentes listadas (Google Sheets, Zoom, email).
- Estimado de horas/cliente.

**Pass:** Viable 100% manual.
**Conditional Pass:** Viable con herramienta compra (justificada).
**Fail:** Requiere desarrollo propio (viola DEC-003).
**Blocked:** Información de capacidad fundadora faltante (andres confirma).

**Quién revisa:** Codex (viabilidad técnica) + Auditor.
**Quién aprueba:** Andrés.

**Ejemplos incumplimiento:**
- Propone plataforma SaaS en MVP (viola DEC-003).
- Oferta requiere API (no especificada).
- Proceso operativo no documentado.

---

### QG-05 — Alineación con la fundadora

**Objetivo:** Verificar que propuesta respeta marca personal, autorización, y datos de fundadora.

**Preguntas de control:**
- ¿Fundadora ha validado buyer persona (la reconoce)?
- ¿Marca personal representa correctamente?
- ¿Datos de fundadora usados con consentimiento?
- ¿Avatar IA (si aplica) dentro límites autorizados?
- ¿Mensajes reflejan tono de fundadora?

**Evidencia requerida:**
- Nota de validación con fundadora (fecha, feedback).
- Documento BRD-002 (marca personal) aprobado.
- Si avatar: documento BRD-004 aprobado.
- Mensaje muestras revisadas por fundadora.

**Pass:** Totalmente alineado, autorizado.
**Conditional Pass:** Mostly alineado, requiere ajuste menor en messaging.
**Fail:** No alineado, requiere rework.
**Blocked:** Consentimiento de fundadora faltante (andres confirma).

**Quién revisa:** Auditor + Claude Code (coherencia narrativa).
**Quién aprueba:** Andrés + Fundadora.

**Ejemplos incumplimiento:**
- Messaging no refleja tono de fundadora.
- Buyer persona que ella no reconoce.
- Avatar sin consentimiento documentado.

---

### QG-06 — Valor para el cliente

**Objetivo:** Verificar que oferta resuelve problema real, ofrece transformación creíble, y genera ROI.

**Preguntas de control:**
- ¿La oferta resuelve el problema (JTBD)?
- ¿Transformación es específica y medible?
- ¿Valor percibido calculado (relación beneficio/precio validada)?
- ¿ROI positivo para buyer?
- ¿Diferenciación vs competencia clara?

**Evidencia requerida:**
- Ecuación de valor percibido (cálculo).
- Beneficios monetarios y emocionales.
- Validación con 3+ prospectos (conversión).
- Matriz competitiva.

**Pass:** Valor claro, ROI positivo, diferenciado.
**Conditional Pass:** Valor válido pero requiere validación adicional en mercado.
**Fail:** Valor débil o ROI incierto.
**Blocked:** Información de beneficio faltante (andres confirma).

**Quién revisa:** Auditor + Incubator skill.
**Quién aprueba:** Andrés.

**Ejemplos incumplimiento:**
- "Buyer se sentirá mejor" (beneficio emocional no medible).
- Precio sin justificación.
- Sin diferenciación clara.

---

### QG-07 — Riesgo y regulación

**Objetivo:** Verificar que riesgos legales, financieros, reputacionales se han identificado y mitigado.

**Preguntas de control:**
- ¿Se requiere licencia o regulación (financiera, médica, legal)?
- ¿Riesgos legales identificados?
- ¿Riesgos reputacionales si sale mal?
- ¿Reversión de riesgo implementada?
- ¿Garantía es creíble y ejecutable?

**Evidencia requerida:**
- Matriz de riesgos (legal, operativo, reputacional).
- Consulta legal si aplica (confirmación).
- Reversión de riesgo (garantía, seguro, dinero-atrás).
- Plan de mitigación.

**Pass:** Riesgos identificados, mitigados, creíbles.
**Conditional Pass:** Riesgos identificados, mitigación parcial.
**Fail:** Riesgos altos no mitigados.
**Blocked:** Consulta legal requerida (andres confirma).

**Quién revisa:** Auditor (consulta legal si necesario).
**Quién aprueba:** Andrés.

**Ejemplos incumplimiento:**
- Propuesta asesoría fiscal sin abogado-cliente.
- Garantía que no puede cumplirse.
- Riesgo reputacional alto (marca personal daño).

---

### QG-08 — Coherencia documental

**Objetivo:** Verificar que documentos están consistentes (sin contradicciones internas), bien estructurados, legibles.

**Preguntas de control:**
- ¿Documento bien estructurado (secciones claras)?
- ¿Sin contradicciones internas?
- ¿Estilo consistente?
- ¿Formatted Markdown correctamente?
- ¿Links a dependencias funcionales?

**Evidencia requerida:**
- Documento con estructura clara.
- Revisión de coherencia (sin contradicciones).
- Testing de links (no rotos).

**Pass:** Bien estructurado, sin contradicciones, profesional.
**Conditional Pass:** Buena estructura, minores ajustes.
**Fail:** Estructura confusa, muchas contradicciones.

**Quién revisa:** Auditor.
**Quién aprueba:** Auditor (automático si pass).

**Ejemplos incumplimiento:**
- Secciones desordenadas.
- Contradicción: "Buyer es autónomo" vs "Empleado".
- Links rotos a docs.

---

### QG-09 — Accionabilidad

**Objetivo:** Verificar que entregable es accionable (próximo paso claro, alguien lo puede ejecutar).

**Preguntas de control:**
- ¿Próximo paso especificado (quién, cuándo, cómo)?
- ¿Responsable asignado?
- ¿Deadline claro (o (andres confirma))?
- ¿Entregable es input para otro ticket?
- ¿Dependencias downstream identificadas?

**Evidencia requerida:**
- "Next action" explícita en documento.
- Asignación a persona/rol.
- Deadline o roadmap de ejecución.

**Pass:** Accionable, siguientes pasos claros.
**Conditional Pass:** Mostly accionable, requiere Andrés confirmar timeline.
**Fail:** No accionable, pasos vagos.
**Blocked:** Bloqueado por dependencia incompleta.

**Quién revisa:** Auditor.
**Quién aprueba:** Andrés.

**Ejemplos incumplimiento:**
- Sin especificar quién continúa.
- "Próximo: diseño de oferta" (vago, sin ticket).
- Sin deadline.

---

### QG-10 — Trazabilidad

**Objetivo:** Verificar que decisiones, cambios, y fuentes están documentadas (auditables).

**Preguntas de control:**
- ¿Decisiones citan DECISION_LOG.md?
- ¿Cambios vs versión anterior documentados?
- ¿Fuentes y referencias citadas?
- ¿Supuestos marcados [HIPÓTESIS]?
- ¿Datos validados marcados [APROBADO] o [EVIDENCIA]?

**Evidencia requerida:**
- Changelog interno o apartado "Cambios desde v0".
- Citas de DECISION_LOG.md o fuentes.
- Markings claros (HIPÓTESIS, APROBADO, EVIDENCIA).

**Pass:** Totalmente trazable, auditable.
**Conditional Pass:** Mostly trazable, minores aclaraciones.
**Fail:** No trazable, faltan citas.

**Quién revisa:** Auditor.
**Quién aprueba:** Auditor (automático si pass).

**Ejemplos incumplimiento:**
- Supuesto de buyer persona sin [HIPÓTESIS].
- Cambio de precio sin justificación.
- No cita DECISION_LOG.md.

---

### QG-11 — Medición

**Objetivo:** Verificar que entregable define cómo se mide éxito (métrica clara).

**Preguntas de control:**
- ¿Métrica de éxito definida (cuantitativa)?
- ¿Baseline (antes) y target (después) específicos?
- ¿Responsable de medición asignado?
- ¿Periodicidad de medición (semanal, mensual)?
- ¿Instrumento de medición (sheet, dashboard, survey)?

**Evidencia requerida:**
- Métrica específica (p.e. "% conversión > 20%").
- Baseline conocido o estimado.
- Instrumento definido (cómo se mide).

**Pass:** Métrica clara, medible, periodicidad.
**Conditional Pass:** Métrica definida, instrumento (andres confirma).
**Fail:** Métrica vaga o no medible.
**Blocked:** Datos históricos necesarios (andres confirma).

**Quién revisa:** Auditor.
**Quién aprueba:** Andrés.

**Ejemplos incumplimiento:**
- "Éxito es que sea bueno" (no medible).
- Métrica sin baseline (no puedo comparar).
- Sin instrumento (¿quién mide, cómo?).

---

### QG-12 — Aprobación humana

**Objetivo:** Verificar que entregable tiene aprobación humana requerida antes de cerrar.

**Preguntas de control:**
- ¿Reviewer independiente (no productor)?
- ¿Auditor ha marcado resultado (pass/fail)?
- ¿Andrés ha visto si es Amarillo+?
- ¿Fundadora ha validado si toca marca?
- ¿Productor ha esperado revisión (no auto-aprobó)?

**Evidencia requerida:**
- Comentario en comments/[TICKET-ID].jsonl de auditor.
- Confirmación de Andrés (si Amarillo+).
- Confirmación de Fundadora (si toca marca).

**Pass:** Todas aprobaciones requeridas obtenidas.
**Conditional Pass:** Aprobaciones en progreso, válido esperar.
**Fail:** Falta aprobación crítica.
**Blocked:** Auto-aprobación detectada (violación AGENTS.md).

**Quién revisa:** Auditor.
**Quién aprueba:** Andrés (final).

**Ejemplos incumplimiento:**
- Productor marcó "completed" sin QA.
- Falta validación de Fundadora.
- Auditor no ha revisado.

---

## 5. Tabla de aplicación por tipo de entregable

| Tipo | QG-01 | QG-02 | QG-03 | QG-04 | QG-05 | QG-06 | QG-07 | QG-08 | QG-09 | QG-10 | QG-11 | QG-12 |
|------|-------|-------|-------|-------|-------|-------|-------|-------|-------|-------|-------|-------|
| **Investigación** | — | ✓ | ✓ | — | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Buyer Persona** | — | ✓✓ | ✓✓ | — | ✓ | — | — | ✓ | ✓ | ✓ | — | ✓ |
| **Oferta** | ✓ | ✓ | ✓ | ✓ | ✓ | ✓✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Marca** | ✓ | ✓ | — | — | ✓✓ | — | ✓ | ✓ | ✓ | ✓ | — | ✓ |
| **Funnel** | — | ✓ | ✓ | ✓ | — | — | — | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Contenido** | — | ✓ | ✓ | — | ✓ | — | ✓ | ✓ | ✓ | ✓ | — | ✓ |
| **Ventas** | — | — | ✓ | ✓ | — | ✓ | — | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Documento** | ✓ | ✓ | ✓ | — | ✓ | — | — | ✓✓ | ✓ | ✓ | — | ✓ |
| **Código** | ✓ | ✓ | — | ✓✓ | — | — | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| **Dashboard** | ✓ | — | — | ✓ | — | — | ✓ | ✓ | ✓ | — | ✓✓ | ✓ |
| **Cambio Estructural** | ✓✓ | ✓ | ✓✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | — | ✓ |

**Leyenda:** ✓✓ = crítico, ✓ = requerido, — = no aplica

---

## 6. Reglas especiales

### Entregables sin evidencia

Si un entregable contiene afirmaciones sin evidencia:
- Marcar como `[HIPÓTESIS]` explícitamente.
- Listar qué validaría (quién, cuándo).
- QG-03 = Conditional Pass (no Fail, porque está marcado).
- Requiere validación antes de implementar.

**Ejemplo:** 
```
[HIPÓTESIS] Buyer paga USD 2000 anuales.
Validación requerida: 3 conversaciones confirmando presupuesto.
Responsable: Andrés + Claude Code.
Timeline: MKT-001 entrevistas.
```

---

### Hipótesis no identificadas

Si auditor detecta supuesto no marcado:
- QG-03 = Fail (afirmación no validada presentada como hecho).
- Requiere rework: marcar como [HIPÓTESIS] + validación plan.

**Ejemplo:** 
```
INCUMPLIMIENTO: "Buyer necesita plan de pago flexible" (sin validación, no marcado [HIPÓTESIS])
ACCIÓN: Marcar [HIPÓTESIS], incluir en entrevistas MKT-001.
```

---

### Archivos creados sin función

Si documento existe pero no tiene propósito claro:
- QG-09 (Accionabilidad) = Fail.
- Ejemplo: documento describe alternativas sin recomendación.

---

### Cambios fuera de alcance

Si entregable expande scope del ticket original:
- QG-01 (Coherencia estratégica) = Fail.
- Requiere nuevo ticket o cambio de roadmap.

---

### Falta de aprobación

Si faltan aprobaciones requeridas:
- QG-12 = Fail.
- Ticket regresa a "blocked".

---

### Contradicción con decisiones

Si entregable contradice DECISION_LOG.md:
- QG-01 = Fail.
- Escalación automática a Andrés (E2).

---

### Auto-aprobación

Si productor marca ticket "completed" sin revisión independiente:
- QG-12 = Blocked (violación AGENTS.md).
- Ticket regresa a "agent_review" automáticamente.
- Requiere revisión de Auditor + Andrés.

---

### Dependencias incompletas

Si ticket depende de otro no completado:
- QG-04 o QG-09 = Blocked.
- Ticket se detiene, espera dependencia.

---

## 7. Resultados posibles

### PASS
✓ Cumple 100% AC.
✓ Todas QGs pass.
✓ Alineado con DECISION_LOG.md.
✓ Listo para cerrar.

### CONDITIONAL PASS
~ Cumple AC en mayoría.
~ QGs en su mayoría pass, minores huecos.
~ Requiere ajustes menores o validación adicional.
~ Clausula: qué debe suceder para full pass.

Ejemplos:
- "[HIPÓTESIS] buyer persona marcado, requiere MKT-001 validar".
- "Pricing (andres confirma) antes de lanzar".

### CHANGES REQUIRED
✗ AC no cumplido.
✗ QGs fail en áreas críticas.
✗ Requiere rework sustancial.
✗ Vuelve a "in_progress" o "blocked".

### FAIL
✗✗ AC muy incompleto.
✗✗ Violación de guardrails.
✗✗ Contradice DECISION_LOG.md.
✗✗ Auto-aprobación detectada.
✗✗ Rechazado. Ticket → "rejected".

### BLOCKED
⏸️ No puede evaluarse validadamente.
⏸️ Dependencia crítica incompleta.
⏸️ Información faltante (andres confirma).
⏸️ Aprobación humana requerida antes de continuar.

---

## 8. Checklist final reutilizable

```
QUALITY AUDIT CHECKLIST — [TICKET-ID]

QG-01 Coherencia estratégica
☐ ¿Respeta DECISION_LOG.md?
☐ ¿Respeta PROJECT_RULES.md?
☐ ¿No abre nuevas verticales sin autorización?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-02 Especificidad
☐ ¿Buyer específico (3+ atributos)?
☐ ¿Problema específico (urgencia, frecuencia)?
☐ ¿Oferta específica (entregables concretos)?
☐ ¿Nicho específico (no "colombianos")?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-03 Evidencia
☐ ¿Afirmaciones sustentan en conversaciones/datos?
☐ ¿Buyer persona: cantidad suficiente de conversaciones reales?
☐ ¿Pricing validado (no arbitrario)?
☐ ¿Hipótesis marcadas [HIPÓTESIS]?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-04 Viabilidad operativa
☐ ¿Entregable sin plataforma propia?
☐ ¿Fundadora puede entregar?
☐ ¿Proceso documentado?
☐ ¿Escalable hasta 10-20 clientes?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-05 Alineación con fundadora
☐ ¿Fundadora validó buyer persona?
☐ ¿Marca personal respetada?
☐ ¿Datos de fundadora con consentimiento?
☐ ¿Mensajes reflejan tono?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-06 Valor para cliente
☐ ¿Resuelve JTBD real?
☐ ¿Transformación específica?
☐ ¿Valor percibido calculado (relación validada)?
☐ ¿ROI positivo para buyer?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-07 Riesgo y regulación
☐ ¿Riesgos legal identificados?
☐ ¿Reversión de riesgo implementada?
☐ ¿Garantía creíble?
☐ ¿Consulta legal si aplica?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-08 Coherencia documental
☐ ¿Estructura clara?
☐ ¿Sin contradicciones internas?
☐ ¿Estilo consistente?
☐ ¿Links funcionales?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-09 Accionabilidad
☐ ¿Próximo paso claro?
☐ ¿Responsable asignado?
☐ ¿Deadline especificado?
☐ ¿Dependencias downstream?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-10 Trazabilidad
☐ ¿Cita DECISION_LOG.md?
☐ ¿Cambios documentados?
☐ ¿Supuestos marcados [HIPÓTESIS]?
☐ ¿Datos marcados [APROBADO]/[EVIDENCIA]?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-11 Medición
☐ ¿Métrica de éxito específica?
☐ ¿Baseline conocido?
☐ ¿Target definido?
☐ ¿Instrumento de medición?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

QG-12 Aprobación humana
☐ ¿Reviewer independiente?
☐ ¿Auditor ha revisado?
☐ ¿Andrés aprobó (si Amarillo+)?
☐ ¿Fundadora aprobó (si marca)?
☐ ¿No auto-aprobación?
☐ Resultado: PASS / CONDITIONAL / FAIL / BLOCKED

═══════════════════════════════════════════════════════════════

RESULTADO FINAL:
☐ PASS (todos PASS)
☐ CONDITIONAL PASS (mayoría PASS, minores gaps claros)
☐ CHANGES REQUIRED (QGs fail en áreas mejorables)
☐ FAIL (QGs fail en áreas críticas)
☐ BLOCKED (dependencia o aprobación faltante)

RECOMENDACIÓN:
☐ Cerrar ticket
☐ Rework + revisión
☐ Escalación a Andrés
☐ Esperar dependencia

═══════════════════════════════════════════════════════════════
```

---

## 9. Estado de implementación: v0.2.0

**Bloque 1 — Governance (actual):**

- ✓ Quality gates definidos (12 total, pendiente de auditoría).
- ✓ Aplicación por entregable documentada (pendiente de auditoría).
- ✓ Manual (no automatizado).
- ✓ Auditor valida; Andrés aprueba (protocolo establecido).

**v0.3.0 (futuro):**

- Dashboard de quality gates.
- Integración automática con workflow.
- Tracking de gates por ticket.

**Responsabilidad actual:** Skill producida en v0.2.0. Auditor aplicará manual tras aprobación de quality auditor y Andrés. Documentación en comments/[TICKET-ID].jsonl.
