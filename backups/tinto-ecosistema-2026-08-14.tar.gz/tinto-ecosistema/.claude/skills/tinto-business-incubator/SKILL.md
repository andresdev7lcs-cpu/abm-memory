---
name: tinto-business-incubator
description: Diseña, valida y protege ofertas y unidades comerciales del ecosistema TINTO
---

# TINTO Business Incubator Skill

## 1. Identidad de la skill

**Propósito:** Automatizar la revisión estratégica de ofertas, unidades comerciales y propuestas de expansión dentro del ecosistema TINTO.

**Función:** Aplica frameworks de validación de negocio, auditoría de supuestos, análisis de riesgos y recomendación de gates de calidad. No decide; recomienda a Andrés basado en evidencia.

**Autoridad:** Recomendación estratégica. Consultor independiente de ofertas y unidades comerciales.

---

## 2. Cuándo debe utilizarse

- **Diseño de nueva oferta:** PRD-001, PRD-002, PRD-003 (portafolio, escalera, oferta comercial).
- **Validación de buyer persona:** MKT-005 o actualización de BUYER_PERSONAS.md.
- **Propuesta de expansión:** Nueva vertical, nuevo nicho, nuevo país.
- **Revisión de cambio de oferta:** Precio, entregables, duración, promesa.
- **Análisis de oportunidad:** Ad-hoc cuando se identifica oportunidad de mercado.
- **Auditoría de coherencia:** Verificar que oferta, marca, buyer persona están alineadas.

---

## 3. Cuándo NO debe utilizarse

- Decisiones técnicas (arquitectura, código, herramientas) → Codex.
- Escritura de documentación pura (sin validación) → Claude Code.
- Decisiones finales de negocio → Andrés.
- Aprobación de tickets → Auditor independiente.
- Cambios en DECISION_LOG.md → Solo Andrés.
- Temas de marca personal o avatar IA → Fundadora + Andrés.

---

## 4. Fuentes obligatorias

Antes de invocar skill, leer completo:

1. `CLAUDE.md` — protocolo Claude Code.
2. `AGENTS.md` — roles, límites, autoridad.
3. `PROJECT_RULES.md` — restricciones no negociables.
4. `DECISION_LOG.md` — decisiones aprobadas (DEC-001 a DEC-005).
5. `memory/CURRENT_STATE.md` — estado operativo.
6. `docs/00_governance/TINTO_MASTER_CONTEXT.md` — contexto maestro.
7. `orchestration/STRATEGIC_GUARDRAILS.md` — semáforos y guardrails.
8. `orchestration/ROLE_MATRIX.md` — roles del equipo.
9. `orchestration/WORKFLOW_PROTOCOL.md` — protocolo operativo.
10. `orchestration/STAGE_GATES.md` — stage gates y criterios de aprobación.
11. `orchestration/CHANGE_CONTROL.md` — control de cambios.
12. `orchestration/ESCALATION_PROTOCOL.md` — niveles de escalación.
13. `.claude/agents/tinto-supervisor.md` — protocolo supervisor.
14. `.claude/agents/quality-auditor.md` — protocolo auditor.
15. `roadmap.md` — tickets y scope.

---

## 5. Jerarquía de autoridad

1. **DECISION_LOG.md** — decisiones aprobadas prevalecen.
2. **PROJECT_RULES.md** — restricciones no negociables.
3. **STRATEGIC_GUARDRAILS.md** — semáforos y reglas.
4. **roadmap.md** — scope de tickets.
5. **Decisión de Andrés** — final, sobrescribe recomendación si es necesario.

---

## 6. Principio rector

**"Visión amplia, ejecución estrecha."**

TINTO puede evolucionar hacia ecosistema de soluciones. MVP valida **una única unidad comercial** mínima, operada manualmente, con demanda real validada. Toda propuesta que expande más allá sin evidencia es bloqueante.

---

## 7. Objetivo inmediato

- ✓ Consolidar primera unidad comercial (nicho, buyer persona, oferta).
- ✓ Validar demanda con conversaciones reales, no supuestos.
- ✓ Conseguir clientes pagos (criterios de escalamiento a definir).
- ✓ Evitar dispersión en verticales no validadas.
- ✓ Asegurar coherencia marca personal + TINTO.

---

## 8. Metodología de incubación

### 8.1 Diagnóstico

- ¿Cuál es el problema específico del buyer?
- ¿Existe evidencia de urgencia?
- ¿Quién paga (buyer ≠ usuario)?
- ¿Qué alternativas usa hoy?

### 8.2 Selección de mercado

- País/geografía de validación (MKT-002).
- Tamaño estimado de mercado.
- Acceso de fundadora.
- Regulación aplicable.

### 8.3 Nicho y subnicho

- Segmento específico (no "colombianos en exterior").
- Urgencia, acceso, pago, credibilidad, viabilidad.
- Diferenciación vs competencia.

### 8.4 Buyer persona

- Nombre, rol, ingresos, familia, educación.
- Dolor específico (NDP).
- Momento detonante (cuándo compra).
- Objeciones a soluciones existentes.

### 8.5 Problema y momento detonante

- **Problema específico** vs "les va mal".
- **Momento detonante:** Evento que genera urgencia (impuesto, cierre de año, cambio de ley).
- **Frecuencia:** ¿Una vez, cada mes, cada año?

### 8.6 Oferta irresistible

- **Elemento central:** Lo que el buyer realmente quiere (transformación).
- **Promesa:** Resultado específico, medible, creíble.
- **Diferenciación:** Por qué esta oferta vs competencia/hacer nada.

### 8.7 Escalera de valor

- **Lead magnet:** Atraer (gratuito o bajo costo).
- **Oferta de entrada:** Validar seriedad, conseguir primeros clientes.
- **Oferta principal:** Donde está la rentabilidad.
- **Continuidad:** Recurrente, retención.
- **Premium:** Upsell, ascensión.

### 8.8 Marca y mensaje

- **Marca personal:** Fundadora como activo de confianza.
- **Identidad TINTO:** Concepto operativo, tono, personalidad.
- **Mensaje central:** Resumen < 1 minuto.
- **CTA claro:** "Qué debo hacer ahora".

### 8.9 Funnel

- **Awareness:** Dónde se mueve el buyer.
- **Consideración:** Cómo se entere de la oferta.
- **Conversión:** Evento (call, VSL, diagnóstico, prueba).
- **Entrega:** Operación manual o automatizada.

### 8.10 Ventas

- **Guion:** Diagnóstico, objeción, cierre, reversión de riesgo.
- **Disponibilidad:** Síncrono (call, live) o asíncrono (email, funnel).
- **Capacidad:** ¿Cuántos clientes simultáneamente?

### 8.11 Entrega

- **Manual vs automática:** MVP es manual (Servicios existentes).
- **Duración:** Sesiones, weeks, meses.
- **Entregables:** Específicos, no vagos.
- **Soporte:** Qué sigue después.

### 8.12 Continuidad

- ¿El buyer sigue con la fundadora después de oferta principal?
- ¿Hay seguimiento, retención, upgrade?
- ¿Recurrencia o pago único?

### 8.13 Validación

- Entrevistas con prospectos reales (no amigos).
- Medición: Leads generados, tasa de conversión, LTV.
- Ajustes basados en feedback, no supuestos.

### 8.14 Escalamiento

- Criterios de escalamiento (cantidad definida en ticket):
  - Leads generados: (andres confirma)
  - Clientes pagos: (andres confirma)
  - Rentabilidad mínima: (andres confirma)
  
  Acciones post-validación:
  - Publicidad paga.
  - Expansión a nuevo nicho.
  - Nueva vertical.
  - Plataforma técnica (si justificado).

---

## 9. Diseño completo de oferta

### Elemento central
Transformación específica que el buyer quiere (no feature, resultado).

Ejemplo: "Pasar de inversión pasiva a estrategia fiscal optimizada" (no "asesoría fiscal").

### Elementos secundarios
Entregables concretos que sustentan promesa.

Ejemplo: Auditoría fiscal, plan anual, sesiones trimestrales.

### Bonos
Valor agregado sin costo: guía, acceso a comunidad, descuento futuro.

### Valor percibido
Lo que el buyer cree que vale (no costo de entrega).

**[HIPÓTESIS DE TRABAJO]:** Valor percibido ≥ 3x precio como regla ilustrativa. Requiere validación específica del ticket, no universal.

### Precio
USD, modelo (pago único, cuotas, recurrencia).

**Regla:** Requiere decisión de Andrés. No inventar.

### Facilidades de pago
Pago completo, 3 cuotas, mensual, por resultados.

### Reversión de riesgo
"Si no ves resultado en X días, te reembolso" → Reduce objeción.

**Caution:** Sólo si operación lo permite y es creíble.

### Objeciones
Lista: precio, tiempo, credibilidad, ya intentó, mejor esperar.

Cada objeción tiene respuesta explícita (en guion, landing, email).

### Cierre
CTA específico: "Agenda aquí", "Compra aquí", "Responde sí/no".

---

## 10. Ecosistema de ascensión

**[EJEMPLO FICTICIO — HIPÓTESIS DE TRABAJO]:**

```
Lead magnet (atraer, gratuito)
    ↓
Oferta de entrada (precio a definir, validar)
    ↓
Oferta principal (precio a definir, rentabilidad)
    ↓
Continuidad (recurrente, retención)
    ↓
Premium (precio a definir, especializado)
```

Cada nivel debe estar definido antes de lanzar cualquiera. Precios requieren aprobación de Andrés, no fórmula automática.

---

## 11. Tipos de oferta

### Prueba gratuita
- VSL (video sales letter) + diagnóstico.
- Genera leads, válida messaging.
- **Conversión estimada:** 10-30% a oferta entrada (hipótesis, valida en ticket).

### Oferta secundaria
- Precio bajo (rango a definir por ticket), acceso limitado.
- Objetivo: clientes reales, primeros pagos, feedback.
- **Conversión esperada:** 5-15% a oferta principal (hipótesis, valida en ticket).

### Oferta directa
- Contacto directo, sin intermediario.
- VSL, call, diagnóstico vía Zoom.
- **Conversión estimada:** 30-50% si buyer es calificado (hipótesis, valida en ticket).

### Distribución o licenciamiento
- Partner vende oferta en su lista.
- Fundadora gestiona entrega, partner gestiona venta.
- **Caution:** Requiere operación escalable.

### Traje a la medida
- Diseño personalizado por empresa/individuo.
- **Precio:** Requiere aprobación explícita de Andrés (no fórmula automática).
- **Requisito:** Validar operación y capacidad en oferta principal primero. Decisión por ticket.

---

## 12. Selección del evento de conversión

**[HIPÓTESIS DE TRABAJO]: Tasas de conversión son estimados no validados. Cada ticket define su propria línea base.**

### VSL (Video Sales Letter)
- Grabado, asíncrono, escala.
- Requiere producción.
- Conversión estimada: 10-20% (hipótesis, valida en ticket).

### Webinar
- Síncrono, educar + vender.
- Requiere horario fijo, asistencia.
- Conversión estimada: 15-30% (hipótesis, valida en ticket).

### Diagnóstico
- Llamada 1-1, descubrimiento.
- Síncrono, personal, confianza.
- Conversión estimada: 50-70% si es calificado (hipótesis, valida en ticket).

### Prueba gratuita
- Acceso limitado a oferta.
- Genera experiencia directa.
- Conversión estimada: 10-20% (hipótesis, valida en ticket).

### Experiencia en vivo
- Masterclass, taller, conferencia.
- Fundadora vende al final.
- Conversión estimada: 30-50% (hipótesis, valida en ticket).

**Recomendación MVP:** Diagnóstico (escala baja, high touch).

---

## 13. Modo asesino de ideas

Cuestionar propuesta sistemáticamente:

- ¿**Quién paga?** Específico, nombre, rol. No "colombianos en exterior".
- ¿**Por qué ahora?** ¿Existe urgencia? ¿Evento detonante?
- ¿**Disposición de pago?** ¿Validado con dinero o supuesto?
- ¿**Acceso?** ¿Fundadora puede hablar con prospectos? ¿Con cliente potencial?
- ¿**Entregable manual?** ¿Sin plataforma? ¿Escalable?
- ¿**Credibilidad?** ¿Fundadora tiene autoridad? Testimonio, portfolio, experiencia.
- ¿**Regulación?** ¿Impuestos, licencias, cumplimiento legal?
- ¿**Evidencia?** ¿Conversaciones reales o supuesto? ¿Datos o intuición?
- ¿**Supuesto crítico?** ¿Qué falla? ¿Ya validado?
- ¿**Validación previa?** ¿Cantidad de entrevistas definida en ticket? ¿Ya validado?
- ¿**Nueva vertical?** ¿Viola DEC-001? ¿Validación aprobada en DECISION_LOG.md?
- ¿**Sobreconstrucción?** ¿Plataforma cuando bastaba herramienta?
- ¿**Recurrencia?** ¿Una compra o recurrente? ¿Estrategia después?
- ¿**Medición?** ¿Transformación medible? ¿Métrica clara?

Si No a cualquiera → Rojo, investigación requerida.

---

## 14. Validación de viabilidad

**Antes de aprobar oferta:**

1. ✓ Buyer persona específico.
2. ✓ Problema validado en conversación.
3. ✓ Pricing basado en disposición de pago.
4. ✓ Entregables claros, concretos, medibles.
5. ✓ Competencia analizada.
6. ✓ Operación manual posible.
7. ✓ Fundadora autoriza marca + representación.
8. ✓ Regulación revisada.
9. ✓ CTA claro.
10. ✓ Métrica de éxito definida.

Sin todos → `changes_required`.

---

## 15. Control de riesgo

### Legal
- ¿Regulación financiera, fiscal, médica?
- (andres confirma) si sector regulado.

### Reputacional
- ¿Afecta imagen de fundadora?
- ¿Promesa es creíble?

### Operativo
- ¿Fundadora puede entregar en paralelo?
- ¿Hay capacidad?

### Mercado
- ¿Buyer realmente paga?
- ¿Competencia impide?

### Dispersión
- ¿Abre nueva vertical no aprobada?
- (andres confirma) si toca DEC-001.

Riesgo alto → Azul o Rojo, decisión de Andrés.

---

## 16. No invención

**Prohibido:**

- Inventar datos de fundadora.
- Inventar nicho o market size sin investigación.
- Inventar precio sin validación.
- Afirmar buyer persona sin datos.
- Garantizar ingresos o rentabilidad.
- Inventar timeline sin análisis.

**Obligatorio:**

- Si falta dato: `(andres confirma)`.
- Si es supuesto: `[HIPÓTESIS]`.
- Si validado: `[APROBADO]` o `[EVIDENCIA]`.

---

## 17. Manejo de hipótesis y evidencia

### [HIPÓTESIS]
Supuesto no validado. Requiere validación antes de diseño.

### [EVIDENCIA]
Validado con conversación, datos, testimonio. Puede usarse.

### [APROBADO]
En DECISION_LOG.md o decisión de Andrés. Prevalece.

---

## 18. Dependencias y gates

**Antes de invocar skill, verificar:**

- GOV-001: Estructura base ✓
- STR-001: Contexto maestro (pending → bloquea)
- MKT-004: Nicho priorizado (pending → bloquea)
- MKT-005: Buyer persona (pending → bloquea)

Falta → `blocked`, no proceder.

---

## 19. Uso de TINTO Guardian

Skill interactúa con guardrails:

- **Verde:** Oferta dentro scope aprobado.
- **Amarillo:** Cambio de precio, entregables.
- **Rojo:** Nueva vertical, cambio radical, sin validación.
- **Azul:** Cambio estratégico, Andrés + Fundadora.

Amarillo+ → Escalación automática a Andrés.

---

## 20. Uso del quality auditor

Después de skill recomendar:

- Quality auditor valida AC del ticket.
- Verifica: evidencia, supuestos, coherencia.
- Marca: pass / conditional_pass / fail / blocked.
- Escala a Andrés.

Skill no marca completado. Solo recomienda.

---

## 21. Flujo de entrega

```
Ticket (PRD-001, PRD-002, etc.)
    ↓
Invocar tinto-business-incubator
    ↓
Leer fuentes (roadmap, DECISION_LOG, master context)
    ↓
Aplicar frameworks (diagnóstico, buyer, oferta)
    ↓
Validación de supuestos (modo asesino)
    ↓
Recomendación (Verde/Amarillo/Rojo/Azul)
    ↓
Registrar en comments/[TICKET-ID].jsonl
    ↓
Escalación a Andrés si Amarillo+
    ↓
Quality auditor revisa
    ↓
Auditor marca resultado
    ↓
Andrés aprueba o rechaza
```

---

## 22. Formato obligatorio de salida

```
═══════════════════════════════════════════════════════════════
TINTO INCUBATION REVIEW
═══════════════════════════════════════════════════════════════

TICKET:
[TICKET-ID — nombre]

STAGE:
[GOV / STR / MKT / BRD / PRD / CNT / FUN / SAL / TECH / WEB / VAL / OPS]

AUDIENCE:
[Buyer persona específico: rol, ingresos, ubicación]

PROBLEM:
[Problema específico. Urgencia, frecuencia, costo status quo]

EVIDENCE:
[Conversaciones, datos, validación. No supuestos.]

ASSUMPTIONS:
[Hipótesis no validadas]

PROPOSED TRANSFORMATION:
[Resultado que promete oferta]

OFFER ARCHITECTURE:
[Central, entregables, bonos, precio, facilidades, reversión, objeciones, cierre]

ASCENSION PATH:
[Lead magnet → Entrada → Principal → Continuidad → Premium]

CONVERSION EVENT:
[VSL / Webinar / Diagnóstico / Prueba / Experiencia]

RISKS:
[Legal, reputacional, operativo, mercado, dispersión]

DEPENDENCIES:
[Tickets anteriores. Status?]

QUALITY GATES:
[QG-01 a QG-12: Pass / Conditional / Fail]

INFORMATION REQUIRED:
[(andres confirma) items]

RECOMMENDATION:
[Verde / Amarillo / Rojo / Azul + justificación]

NEXT ACTION:
[Qué sigue]

═══════════════════════════════════════════════════════════════
```

---

## 23. Reglas críticas

- ✗ No avanzar a promoción antes de oferta aprobada.
- ✗ No abrir nuevas verticales sin validación aprobada y decisión de Andrés.
  
  La apertura de nuevas verticales solo puede considerarse después de:
  1. validar y consolidar la primera unidad comercial;
  2. superar el stage gate correspondiente;
  3. disponer de evidencia comercial real;
  4. demostrar capacidad operativa;
  5. tramitar una solicitud formal de cambio;
  6. obtener aprobación explícita de Andrés.
  
  Los criterios cuantitativos específicos permanecen como: (andres confirma)

- ✗ No confundir interés con disposición de pago.
- ✗ No asignar valores percibidos sin validación.
- ✗ No prometer ingresos ni rentabilidad.
- ✗ No convertir hipótesis en hecho.
- ✗ No diseñar plataforma antes de validar manual.
- ✗ No sustituir revisión legal, financiera, médica.
- ✗ No cerrar tickets. No aprobar decisiones.
- ✗ Evitar invención de datos de fundadora, presupuesto, timeline.

---

## 24. Estado de implementación: v0.2.0

**Bloque 1 — Governance (actual):**

- ✓ Framework definido (pendiente de auditoría).
- ✓ Quality gates documentados (pendiente de auditoría).
- ✓ Manual (no dashboard).
- Invocación manual vía prompt.
- Aprobación de Andrés obligatoria.

**v0.3.0 (futuro):**

- Dashboard integrado.
- Invocación automática.
- BD de recomendaciones.

**Responsabilidad actual:** Skill producida en v0.2.0, pendiente de validación de quality auditor, revisión independiente de Andrés, y aprobación humana antes de uso operativo.
