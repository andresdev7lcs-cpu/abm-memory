# TINTO Business Incubator — Frameworks reutilizables

---

## 1. Mapa general de frameworks

```
DISCOVERY STAGE (Validación de idea)
├─ Diagnóstico de idea (idea-screening)
├─ Matriz de selección de unidad comercial (multi-criteria)
└─ Matriz de priorización de nichos (scoring)

MARKET STAGE (Validación de mercado)
├─ Buyer persona operativo (archetype)
├─ Necesidades, deseos y problemas (NDP)
├─ Momento detonante (trigger events)
├─ Jobs to be Done (JTBD)
└─ Mapa de objeciones (objection handling)

OFFER STAGE (Diseño de oferta)
├─ Propuesta de valor (value prop)
├─ Arquitectura de oferta irresistible (offer design)
├─ Ecuación de valor percibido (perceived value)
└─ Escalera de valor (value ladder)

FUNNEL STAGE (Operación de ventas)
├─ Ecosistema de ascensión (ascension path)
├─ Selección del tipo de oferta (offer types)
├─ Selección del evento de conversión (conversion events)
├─ Diseño de funnel (funnel architecture)
├─ Guion de diagnóstico (discovery call)
└─ Guion de cierre (closing script)

EXECUTION STAGE (Validación operativa)
├─ Reversión de riesgo (risk reversal)
├─ Validación manual (MVP execution)
├─ Diseño de experimento (testing)
├─ Matriz de evidencia (evidence gathering)
└─ Matriz de riesgos (risk assessment)

CAPABILITY STAGE (Escalamiento)
├─ Modelo de capacidad operativa (ops model)
├─ Matriz de decisión construir/comprar/integrar/aplazar (make-buy-build)
└─ Modo asesino de ideas (killer questions)
```

---

## 2. Diagnóstico de idea

**Objetivo:** Validar si idea tiene potencial o es prematura.

**Cuándo usarlo:** Cuando surge propuesta nueva de oferta o vertical.

**Entradas:**
- Descripción breve de idea.
- Contexto (de dónde surge, quién la propone).
- Datos iniciales (si existen).

**Pasos:**

1. **Define el problema específico** (no genérico).
   - "Colombianos en exterior creen difícil pagar impuestos en Colombia" → Específico.
   - "Colombianos necesitan ayuda con dinero" → Genérico, rechazar.

2. **Identifica buyer específico** (rol, ingresos, ubicación).
   - "Profesional con USD 50k+ ingresos en USA, autónomo, sin empresa" → Específico.
   - "Colombianos en exterior" → Genérico, rechazar.

3. **Valida urgencia y frecuencia**.
   - ¿Cuándo ocurre el problema? (Anual: impuestos. Mensual: remesas. Cada semana: algo urgente).
   - Sin urgencia → Amarillo (requiere más evidencia).

4. **Identifica acceso a buyer**.
   - ¿Fundadora conoce a 5+ personas en ese segmento?
   - ¿Red pública en LinkedIn?
   - Sin acceso → Rojo (no puede validar).

5. **Mapea alternativas existentes**.
   - ¿Qué usan hoy para resolver? (Nada, amigos, especialista, software).
   - Sin alternativa = problema no resuelto (riesgo, oportunidad).

**Salida:**
- `IDEA_DIAGNOSIS`: Pass / Conditional Pass / Fail / Blocked.

**Evidencia mínima:**
- Descripción clara del problema.
- Buyer específico identificado (cantidad de conversaciones definida en ticket).
- Acceso posible.

**Errores frecuentes:**
- Problema genérico sin urgencia.
- Buyer undefined.
- Sin acceso.

**Gate relacionado:** QG-02 (Especificidad).

---

## 3. Matriz de selección de unidad comercial

**Objetivo:** Priorizar entre múltiples ideas cuál será primera unidad.

**Cuándo usarlo:** Cuando hay varias opciones de negocio viables.

**Entrada:** 3+ ideas de negocio con diagnóstico inicial.

**Criterios de evaluación:**

| Criterio | Escala | Definición | Peso |
|----------|--------|-----------|------|
| **Urgencia** | 1-10 | ¿Qué tan frecuente/urgente es problema? | 20% |
| **Acceso** | 1-10 | ¿Fundadora puede hablar con buyer? | 20% |
| **Disposición de pago** | 1-10 | ¿Buyer paga hoy por soluciones? | 20% |
| **Credibilidad de fundadora** | 1-10 | ¿Tiene autoridad/experiencia en tema? | 15% |
| **Viabilidad operativa** | 1-10 | ¿Puede entregar manualmente? | 15% |
| **Diferenciación** | 1-10 | ¿Es única vs competencia? | 10% |

**Pasos:**

1. Puntúa cada idea en cada criterio (1-10).
2. Multiplica por peso.
3. Suma por idea.
4. Elige top 1.

**Ejemplo:**

```
IDEA A: Asesoría fiscal para autónomos en USA
- Urgencia: 9 (impuestos anuales, deadline)
- Acceso: 8 (red en USA)
- Pago: 8 (USD 1000+ anual)
- Credibilidad: 7 (experiencia contable)
- Viabilidad: 9 (servicios existentes)
- Diferenciación: 6 (competencia existe)
Score: 9*0.2 + 8*0.2 + 8*0.2 + 7*0.15 + 9*0.15 + 6*0.1 = 7.95

IDEA B: Remesas a Colombia
- Urgencia: 8 (recurrente)
- Acceso: 5 (mercado masivo, difícil acceso personal)
- Pago: 7 (comisiones 2-4%)
- Credibilidad: 3 (sin experiencia)
- Viabilidad: 4 (requiere acuerdos bancarios)
- Diferenciación: 3 (mucho competidor)
Score: 8*0.2 + 5*0.2 + 7*0.2 + 3*0.15 + 4*0.15 + 3*0.1 = 5.4

→ Seleccionar IDEA A.
```

**Salida:** Top 1 unidad comercial para primer MVP.

**Evidencia mínima:** Puntajes justificados con datos o feedback.

**Errores frecuentes:**
- Puntuar sin evidencia (intuición).
- No ajustar pesos por contexto.
- Elegir familiar en lugar de mejor opción.

**Gate relacionado:** QG-02 (Especificidad), QG-04 (Viabilidad).

---

## 4. Matriz de priorización de nichos

**Objetivo:** Elegir subnicho específico dentro unidad comercial.

**Cuándo usarlo:** Después de unidad comercial elegida (MKT-004).

**Entrada:** Unidad comercial definida + 2-3 subnichos candidatos.

**Criterios de evaluación:**

| Criterio | Escala | Definición | Peso |
|----------|--------|-----------|------|
| **Urgencia** | 1-10 | Problema acuciante | 20% |
| **Frecuencia** | 1-10 | Problema recurrente | 10% |
| **Disposición de pago** | 1-10 | Presupuesto disponible | 20% |
| **Acceso** | 1-10 | Alcance de fundadora | 15% |
| **Credibilidad de fundadora** | 1-10 | Autoridad relevante | 15% |
| **Viabilidad operativa** | 1-10 | Entregable manual | 10% |
| **Riesgo regulatorio** | 1-10 | Baja regulación = 10 | 5% |
| **Potencial de recurrencia** | 1-10 | Cliente vuelve o sube | 5% |

**[EJEMPLO FICTICIO — HIPÓTESIS DE TRABAJO — NO APROBADO PARA TINTO]:**

```
UNIDAD: Asesoría fiscal para profesionales expatriados (ejemplo de ejercicio de priorización, no datos reales)

SUBNICHO A: Freelancers/autónomos en USA (USD 50k-200k ingresos)
- Urgencia: 9 (deadline impuestos, multas)
- Frecuencia: 10 (anual + cambios)
- Pago: 8 (USD 1000-3000 anuales)
- Acceso: 9 (comunidades en LinkedIn)
- Credibilidad: 8 (experiencia)
- Viabilidad: 9 (puede hacer manual con herramientas)
- Regulación: 6 (regulación fiscal)
- Recurrencia: 9 (retorna cada año)
Promedio ponderado: 8.4

SUBNICHO B: Empresarios con empresa en Colombia + ingreso USA
- Urgencia: 8 (complejo dual)
- Frecuencia: 8 (cambios fiscales)
- Pago: 9 (USD 3000-10000 anuales)
- Acceso: 5 (network menor)
- Credibilidad: 6 (experiencia parcial)
- Viabilidad: 6 (requiere CPA partner)
- Regulación: 3 (muy regulado)
- Recurrencia: 10 (retorna, crece)
Promedio ponderado: 6.7

SUBNICHO C: Amas de casa con ahorros en USA
- Urgencia: 4 (no acuciante)
- Frecuencia: 2 (baja)
- Pago: 3 (presupuesto bajo)
- Acceso: 7 (comunidades)
- Credibilidad: 5 (media)
- Viabilidad: 8 (simple)
- Regulación: 8 (bajo)
- Recurrencia: 4 (bajo)
Promedio ponderado: 4.8

→ Seleccionar SUBNICHO A.
```

**Salida:** Subnicho priorizado + buyer persona específico.

**Evidencia mínima:** Puntajes basados en investigación, no supuestos.

**Gate relacionado:** QG-02 (Especificidad), QG-04 (Viabilidad).

---

## 5. Buyer persona operativo

**Objetivo:** Caracterizar de forma accionable el cliente ideal.

**Cuándo usarlo:** MKT-005, validación de oferta.

**Entradas:**
- Subnicho priorizado.
- Entrevistas con prospectos (cantidad definida en ticket).
- Datos demográficos, psicográficos.

**Componentes:**

```
Nombre: [Archetipo, no persona real]
Edad / Familia: [rango, status]
Ingresos: [rango USD]
Ubicación: [país, ciudad]
Rol/Profesión: [específico]
Educación: [nivel]

Objetivo principal:
[Transformación que quiere]

Dolor principal (NDP):
[Problema específico, frecuencia, impacto]

Momento detonante:
[Evento que genera urgencia a comprar]

Objeciones actuales:
[Por qué no compra hoy]

Canales de descubrimiento:
[Dónde se informa: LinkedIn, podcasts, grupos, email]

Ruta de compra:
[Cómo típicamente decide: investigación → consulta → cierre]

Palabras clave:
[Lenguaje que usa, cómo describe problema]

Diferenciadores que valora:
[Qué lo hace diferente de otro buyer]
```

**[EJEMPLO FICTICIO — NO APROBADO PARA TINTO]:**

```
Nombre: Carlos, El Autónomo Fronterizo (archetype ilustrativo)

Edad / Familia: 32-42, casado, 1-2 hijos
Ingresos: USD 60k-150k (ingresos variables)
Ubicación: USA (Miami, NYC, LA), originario Colombia
Rol: Consultor, especialista técnico, emprendedor

Objetivo principal:
Entender cuánto debe pagar en impuestos en USA + Colombia, optimizar, evitar multas.

Dolor principal:
Confusión sobre dónde, cuándo, cuánto paga. Miedo a auditoría IRS. Tiempo gastado en investigación. Recursos limitados para CPA caro.

Momento detonante:
- Enero-Marzo (tax season)
- Cambio de estado (matrimonio, hijos, mudanza)
- Nuevo cliente o ingreso
- Cambio de ley

Objeciones actuales:
"¿Por qué pagar si puedo hacerlo solo?" "¿Es legal el enfoque?" "¿Qué pasó en el pasado?" "¿Garantiza evitar problemas?"

Canales descubrimiento:
LinkedIn (contenido fiscal), Facebook groups (expatriados), Email (newsletters), Referencia (amigos)

Ruta compra:
1. Busca contenido gratis (primer problema entendido)
2. Conversa con especialista (valida credibilidad)
3. Pide referencias (valida resultados)
4. Negocia precio/plan
5. Firma

Palabras clave:
"Optimización fiscal", "Cumplimiento", "Tranquilidad", "Estructuración", "Estrategia"

Diferenciadores que valora:
Trayectoria con expatriados (no CPA genérico). Explicación clara (no legalese). Acceso contínuo (no solo tax time).
```

**Salida:** Documento `BUYER_PERSONAS.md` en docs/02_market/.

**Evidencia mínima:**
- Conversaciones reales con potenciales buyers (cantidad definida en ticket).
- Datos demográficos verificables.
- Lenguaje exacto extraído de interviews (no parafraseo).
- Validación con fundadora (ella reconoce el persona).

**Errores frecuentes:**
- Persona basado en supuesto (sin entrevistas).
- Demasiado genérico ("profesionales").
- Datos inventados.
- Sin momento detonante específico.

**Gate relacionado:** QG-02 (Especificidad), QG-03 (Evidencia), QG-05 (Fundadora), QG-06 (Valor cliente).

---

## 6. Necesidades, deseos y problemas (NDP)

**Objetivo:** Mapear de forma estructurada qué quiere y necesita buyer.

**Cuándo usarlo:** MKT-005, diseño de oferta.

**Entrada:** Buyer persona + entrevistas de descubrimiento.

**Estructura:**

```
NECESIDADES (Funcionales)
├─ Necesidad 1: [Función específica requerida]
├─ Necesidad 2: ...
└─ Prioridad: [Crítica/Alta/Media]

DESEOS (Emocionales)
├─ Deseo 1: [Cómo quiere sentirse]
├─ Deseo 2: ...
└─ Prioridad: [Crítica/Alta/Media]

PROBLEMAS (Bloqueadores)
├─ Problema 1: [Obstáculo actual]
├─ Problema 2: ...
└─ Impacto: [Costo, tiempo, riesgo]

MIEDOS (Emocionales negativos)
├─ Miedo 1: [Resultado negativo posible]
├─ Miedo 2: ...
└─ Probabilidad percibida: [Alta/Media/Baja]
```

**Ejemplo:**

```
NECESIDADES (Funcionales)
- Saber impuestos exactos en USA + Colombia
- Plan de pago estructurado
- Documentación de cumplimiento
- Respuestas a cambios de ley
Prioridad: CRÍTICA

DESEOS (Emocionales)
- Tranquilidad mental (sin preocupación)
- Confianza en especialista
- Acceso fácil cuando surge duda
- Explicación en lenguaje claro (no legal)
Prioridad: ALTA

PROBLEMAS (Bloqueadores)
- No entiende legislación dual USA-Colombia
- CPAs genéricos cobran caro, no entienden expatriados
- Cambios de ley año a año
- Costo de "equivocarse" es alto (multas 20-40%)
- Tiempo de investigación propia: 20-30 horas anuales
Impacto: Estrés + dinero perdido

MIEDOS (Emocionales negativos)
- Auditoría IRS (improbable pero catastrófica)
- Problema con autoridades Colombia
- Pagar más de lo necesario (derroche)
- Cambio de ley retroactivo
Probabilidad: Media-Alta percibida
```

**Salida:** Documento `NDP_MIEDOS_Y_DESEOS.md` en docs/02_market/.

**Evidencia mínima:** Menciones de entrevistas que no son supuestos (cantidad suficiente para identificar patrones, definida en ticket).

**Gate relacionado:** QG-03 (Evidencia), QG-06 (Valor cliente).

---

## 7. Momento detonante (Trigger events)

**Objetivo:** Identificar exactamente cuándo el buyer está dispuesto a comprar.

**Cuándo usarlo:** Diseño de messaging, timing de ventas.

**Entrada:** Buyer persona + entrevistas.

**Formato:**

| Detonante | Frecuencia | Urgencia | Acceso a buyer | Acción recomendada |
|-----------|-----------|----------|---------------|--------------------|
| [Evento X] | Anual / Mensual / Ad-hoc | Alta/Media/Baja | Sí/No | [Marketing trigger] |

**Ejemplo:**

```
| Detonante | Frecuencia | Urgencia | Acceso | Acción |
|-----------|-----------|----------|--------|--------|
| Tax season (Enero-Marzo USA) | Anual | ALTA | Email list | Email campaign 15/12 |
| Matrimonio o pareja | Ad-hoc | ALTA | Referencia | Contenido: planning matrimonial |
| Nacimiento de hijo | Ad-hoc | ALTA | Referencia | Contenido: beneficios dependientes |
| Cambio de trabajo | Ad-hoc | MEDIA | LinkedIn | LinkedIn ads Q1-Q3 |
| Cambio de ley | Ad-hoc | ALTA | News feed | Contenido reactivo inmediato |
| Fin de año / planificación | Anual | MEDIA | Email list | Email campaign 10/11 |
| Multa o aviso IRS | Ad-hoc | CRÍTICA | Referencia | Contenido: "Si recibiste aviso" |
```

**Salida:** Matriz de detonantes + timing de marketing.

**Evidencia mínima:** Validado en conversaciones (cantidad suficiente), no supuesto.

**Gate relacionado:** QG-06 (Valor cliente).

---

## 8. Jobs to be Done (JTBD)

**Objetivo:** Entender "trabajo" que el buyer quiere hacer (no solución).

**Cuándo usarlo:** Diseño de oferta alternativa, pivote de messaging.

**Entrada:** Buyer persona + entrevistas profundas.

**Estructura:**

```
El buyer quiere hacer este TRABAJO:
[Verbo + contexto + objetivo]

Contexto (cuándo/dónde):
[Situación actual que genera necesidad]

Soluciones que prueba:
[Qué intenta ahora]

Por qué falla:
[Brechas en soluciones actuales]

Éxito se ve como:
[Resultado deseado medible]

Criterios de éxito:
[Qué debe suceder para marcar como ganado]
```

**Ejemplo:**

```
TRABAJO: "Optimizar mis impuestos sin perder tiempo ni plata en diligencia"

Contexto: Profesional expatriado con ingresos en USA + Colombia. Enero llega, tiempo escaso, estrés de deadline.

Soluciones actuales prueba:
- Hacer solo (toma 20-30 horas, error probable)
- CPA genérico (caro USD 2000+, no entiende expatriados)
- Amigos/foros (inconsistente, incompleto)

Por qué falla:
- Hacer solo: consume tiempo valioso (oportunidad costo alto)
- CPA genérico: No entiende dual taxation, cobra caro, responde lento
- Amigos: No responsabilidad, consejos contradictorios

Éxito se ve como:
- Plan claro, por escrito, antes de 15/03
- Estructura optimizada (ahorro > costo consulta)
- Tranquilidad: "sé que estoy legal"

Criterios:
1. ✓ Plan entregado 2 semanas antes tax deadline
2. ✓ Ahorro identificado (USD 500+ vs año anterior)
3. ✓ Documentación completa (futura auditoría OK)
4. ✓ Acceso a especialista para cambios (no abandonado post-venta)
```

**Salida:** Documento de JTBD, informa messaging y posicionamiento.

**Evidencia mínima:** Validado directamente en conversaciones.

**Gate relacionado:** QG-06 (Valor cliente).

---

## 9. Mapa de objeciones

**Objetivo:** Prever y diseñar respuesta a cada objeción.

**Cuándo usarlo:** Diseño de guion de cierre, landing page, emails.

**Entrada:** Buyer persona + entrevistas.

**Formato:**

| Objeción | Causa raíz | Respuesta | Reversión de riesgo |
|----------|-----------|----------|-------------------|
| [Qué dice buyer] | [Por qué la tiene] | [Cómo responder] | [Oferta que reduce riesgo] |

**[EJEMPLO FICTICIO — ESTRUCTURA DE OBJECIONES — NO APROBADO PARA TINTO]:**

```
| Objeción | Causa raíz | Respuesta orientativa | Reversión de riesgo orientativa |
|----------|-----------|----------|-----------|
| "¿Por qué pagar si puedo hacerlo solo?" | Costo, desconfianza en especialista | Costo de oportunidad de tiempo. [Calcular con buyer] | Auditoría o sesión inicial: mostrar valor antes de pagar. |
| "¿Me evita problemas fiscales?" | Miedo a auditoría, confianza baja | Mitigación de riesgos. Sin garantía total (imposible). Documentación defensiva. | Seguro si procede. Reversión de riesgo documentada. |
| "¿Qué pasó en el pasado?" | Deuda de impuestos histórica | Depende caso. Opciones: amnistía, pagos, evaluación individual | Llamada de diagnóstico gratis. Honestidad sobre viabilidad. |
| "Soy caso complejo" | Complejidad genuina, desconfianza | Confirmación que se puede servir. Capacidad validada. | Oferta modular. Renegociación si valor no justifica. |
| "¿Qué tan rápido responden?" | Experiencia mala con otros | Tiempo de respuesta a definir según SLA. | Si incumplimos, reembolso o descuento. |
| "¿Es confidencial?" | Miedo privacidad | Confidencialidad según ley local. Contrato claro. | Confidencialidad firmada. |
```

**Salida:** Documento de objeciones + guion de cierre, informa llamadas ventas.

**Evidencia mínima:** Objeciones reales de conversaciones (cantidad suficiente para patrón, definida en ticket).

**Gate relacionado:** QG-06 (Valor cliente), QG-09 (Accionabilidad).

---

## 10. Propuesta de valor

**Objetivo:** Comunicar de forma clara por qué buyer debe elegir esta oferta.

**Cuándo usarlo:** Messaging, landing pages, email pitch.

**Estructura:**

```
Para [Buyer persona]
Que [Dolor/necesidad]
La solución [Oferta]
Es [Categoría/tipo]
Que [Benefit principal]
A diferencia de [Competencia]
Porque [Razón única]
```

**[EJEMPLO FICTICIO — NO APROBADO PARA TINTO]:**

```
Para [Buyer persona definido en ticket]
Que sufre [Problema específico validado]

La solución "[Nombre de oferta aprobado]"
Es [Categoría clara]

Que proporciona [Beneficio a validar — no asumir ahorro USD 1500]

A diferencia de [Competencia específica validada]

Porque [Diferenciador único validado, no supuesto]
```

**Variantes por canal:**

- **Email:** 1 frase (subject).
- **Landing page:** 3-5 frases (hero section).
- **Call:** 10-20 segundos (pitch inicial).
- **Social:** 1-2 frases + visual.

**Salida:** Propuesta de valor por canal.

**Evidencia mínima:** Basado en JTBD, beneficios, diferenciación validados.

**Gate relacionado:** QG-06 (Valor cliente), QG-09 (Accionabilidad).

---

## 11. Arquitectura de oferta irresistible

**Objetivo:** Diseñar estructura completa de la oferta.

**Cuándo usarlo:** PRD-003 (Primera oferta comercial).

**Entrada:** Buyer persona + NDP + valor + validación.

**Componentes:**

```
TRANSFORMACIÓN CENTRAL
└─ Resultado específico que promete

ELEMENTOS SECUNDARIOS (2-3)
├─ Entregable A (sesiones, auditoría, plan)
├─ Entregable B
└─ Entregable C

BONOS (Sin costo adicional)
├─ Bonus 1 (acceso, guía, descuento)
├─ Bonus 2
└─ Bonus 3

SEGUIMIENTO (Post-venta)
└─ 30, 60, 90 días: check-in, ajustes

GARANTÍA / REVERSIÓN DE RIESGO
└─ Si X condición no se cumple, Y compensación

PRECIO
├─ Modelo (pago único / cuotas / recurrencia)
├─ Monto (USD)
└─ Justificación (valor percibido vs costo)

PLAN DE PAGOS
└─ Pago completo / 3 cuotas / Mensual

VALOR PERCIBIDO (para comunicar)
└─ Monto USD equivalente del valor para buyer

CTA (Call to Action)
└─ Acción específica: "Agenda", "Compra", "Responde"
```

**[EJEMPLO FICTICIO — NO APROBADO PARA TINTO]:**

```
Ejemplo de estructura completa de componentes:

TRANSFORMACIÓN CENTRAL:
[Resultado específico que buyer buscaba — validado]

ELEMENTOS SECUNDARIOS (2-3):
[Entregables concretos que sustentan promesa]

BONOS:
[Valor agregado sin costo — validado con buyer]

SEGUIMIENTO:
[Milestones post-entrega, días/semanas según oferta]

GARANTÍA:
[Reversión de riesgo creíble y ejecutable — NO garantizar ahorro específico sin validación]

PRECIO:
Modelo: [Definir con ticket]
Justificación: [Basada en valor percibido validado, no supuesto]

VALOR PERCIBIDO:
[Cálculo específico por oferta — ver Framework 12 "Ecuación de valor"]

CTA:
[Acción clara: agenda, compra, responde]
```

**Salida:** Documento de arquitectura de oferta, informa landing page, sales call.

**Evidencia mínima:**
- Precio basado en validación (no arbitrario).
- Valor percibido calculado (cantidad a validar con buyer).
- Garantía creíble y ejecutable (reversión de riesgo).

**Gate relacionado:** QG-03 (Evidencia), QG-04 (Viabilidad), QG-06 (Valor cliente), QG-11 (Medición).

---

## 12. Ecuación de valor percibido

**Objetivo:** Calcular y justificar el precio de la oferta.

**Cuándo usarlo:** Pricing de PRD-003.

**Fórmula:**

```
Valor Percibido = (Beneficio monetario + Beneficio emocional) - (Costo + Riesgo percibido)

Precio óptimo = Valor Percibido / 3 (para margen)
```

**[EJEMPLO FICTICIO — HIPÓTESIS DE TRABAJO — NO APROBADO PARA TINTO]:**

```
Estructura de cálculo (no datos validados):

BENEFICIO MONETARIO:
- [Específico: ahorro directo / tiempo ahorrado / eficiencia ganada]
- [Cantidad: validada en conversaciones, no supuesto]
- Beneficio total: [Cálculo específico]

BENEFICIO EMOCIONAL:
- [Tranquilidad / confianza / acceso específico]
- [Cantidad percibida: validada]

COSTO (De la solución):
- Dinero directo: [Definir en ticket]
- Tiempo del buyer (implementación): [Estimado]

RIESGO PERCIBIDO:
- [Riesgo específico de buyer] ← Mitigado con reversión de riesgo
- Riesgo total: [Cálculo]

VALOR PERCIBIDO:
[Beneficio monetario + emocional] - [Costo + riesgo] = [Cantidad]

PRECIO PROPUESTO:
[Basado en validación, no fórmula universal "/ 3"]

HIPÓTESIS A VALIDAR:
- ¿Buyer percibe este valor? ¿Disposición de pago confirmada?
- ¿Reversión de riesgo ejecutable?
- ¿ROI positivo para buyer?
```

**Salida:** Precio justificado con ecuación de valor, no arbitrario.

**Evidencia mínima:**
- Beneficio monetario: data que sustenta (conversaciones, referencias, mercado).
- Costo oportunidad estimado con buyer.
- Riesgo percibido identificado y reversión creíble.

**Gate relacionado:** QG-03 (Evidencia), QG-11 (Medición).

---

## 13. Escalera de valor

**Objetivo:** Diseñar path ascendente de ofertas para retención y upsell.

**Cuándo usarlo:** Estrategia multiproducto, retención.

**Estructura:**

```
NIVEL 0 — LEAD MAGNET (Gratuito)
├─ Oferta: Diagnóstico, webinar, guía
├─ Objetivo: Atraer, demostrar valor
└─ Conversión esperada: 10-30% a nivel 1

NIVEL 1 — OFERTA ENTRADA (USD 50-500)
├─ Oferta: Acceso limitado, pieza única
├─ Objetivo: Conseguir primer cliente pagador
├─ Conversión esperada: 5-15% a nivel 2
└─ Retention: 20-30% se queda

NIVEL 2 — OFERTA PRINCIPAL (USD 500-5000)
├─ Oferta: Servicio completo, resultado
├─ Objetivo: Rentabilidad, relación principal
├─ Conversión esperada: 10-20% a nivel 3
└─ Retention: 30-50% se queda (continuidad)

NIVEL 3 — CONTINUIDAD (Recurrencia)
├─ Oferta: Acceso, soporte, actualizaciones
├─ Objetivo: Ingresos recurrentes
├─ Conversión esperada: 20-40% a nivel 4
└─ Retention: 50-70% (stickiness alto)

NIVEL 4 — PREMIUM (USD 5000+)
├─ Oferta: Traje a la medida, empresa, grupo
├─ Objetivo: Ingresos altos, referencia
└─ Conversion: 5-10% (ventas complejas)
```

**[EJEMPLO FICTICIO — HIPÓTESIS DE TRABAJO — NO APROBADO PARA TINTO]:**

```
Estructura de escalera (no datos validados):

NIVEL 0 — LEAD MAGNET (Gratuito)
[Oferta de atracción definida en ticket]
→ Objetivo: Leads generados (cantidad a validar)
→ Conversión esperada a nivel 1: [Definir con ticket]

NIVEL 1 — ENTRADA (Precio aprobado)
[Oferta de validación con dinero real]
→ Conversión esperada a nivel 2: [A validar]
→ Retention: [A medir]

NIVEL 2 — PRINCIPAL (Precio aprobado)
[Oferta de rentabilidad]
→ Conversión esperada a nivel 3: [A validar]
→ Retention: [A medir]

NIVEL 3 — CONTINUIDAD (Recurrencia)
[Oferta recurrente]
→ Conversión esperada a nivel 4: [A validar]
→ LTV estimado: [A calcular con datos reales]

NIVEL 4 — PREMIUM (Precio aprobado)
[Oferta de especialización]
→ Conversión: [A validar]
→ LTV: [A calcular con datos reales]

HIPÓTESIS A VALIDAR:
- Cada nivel es viable operativamente (no sobreestimar)
- Conversiones y retention basadas en primeros datos, no supuesto
- Ajustar continuamente con feedback real
```

**Salida:** Mapa de escalera de valor, informa roadmap de ofertas.

**Evidencia mínima:** Cada nivel operativamente viable, validaciones claras en roadmap.

**Gate relacionado:** QG-04 (Viabilidad), QG-11 (Medición).

---

## 14-27. Frameworks adicionales (Comprimido)

**14. Selección del tipo de oferta**
- Prueba gratuita (VSL + diagnóstico)
- Oferta secundaria (USD 50-500)
- Oferta directa (1-1, diagnóstico)
- Distribución (partner vende)
- Traje a medida (personalizado)

Criterio: Escala vs control.

---

**15. Selección del evento de conversión**
- VSL: Escala, asíncrono, 10-20% conversión
- Webinar: Síncrono, educar+vender, 15-30%
- Diagnóstico: Alto touch, 50-70%, 1-1
- Prueba: Experiencia directa, 10-20%
- Experiencia viva: Masterclass, 30-50%

MVP: Diagnóstico (escala baja, validación alta).

---

**16. Diseño de funnel**
- Awareness: Dónde se descubre
- Consideración: Cómo se informa
- Conversión: Evento
- Entrega: Operación
- Retención: Seguimiento

---

**17-18. Guiones (Diagnóstico y cierre)**
- Diagnóstico: Preguntas abiertas, escucha, identificar problema
- Cierre: Objection handling, propuesta, CTA

---

**19. Reversión de riesgo**
- Dinero atrás si X
- Piloto gratis antes de compromiso
- Garantía de satisfacción

---

**20. Validación manual**
- 3+ clientes pagos antes de escalar
- Feedback incorporado
- Iteración rápida

---

**21. Diseño de experimento**
- Hipótesis: "Si lanzamos X, Y% convertirá"
- Métrica: Leads, conversión, LTV
- Duración: 30 días
- Exit criteria: Viabilidad comprobada

---

**22. Matriz de evidencia**
Recolectar: Conversaciones reales, datos de mercado, referencias, testimonios.

---

**23. Matriz de riesgos**
Legal, operativo, mercado, reputación. Score 1-10, acción por cada uno.

---

**24. Modelo de capacidad operativa**
¿Fundadora puede entregar X clientes/mes? Manual scalable o requiere team?

---

**25. Matriz de decisión (Make/Buy/Build/Defer)**
Construir internamente, comprar existente, integrar tercero, aplazar.

---

**26. Modo asesino de ideas**
14 preguntas críticas (ver SKILL.md § 13).

---

**27. Plantillas de salida**
- TINTO INCUBATION REVIEW (formato 22-campo)
- Quality gates checklist
- Recommendation (Verde/Amarillo/Rojo/Azul)
