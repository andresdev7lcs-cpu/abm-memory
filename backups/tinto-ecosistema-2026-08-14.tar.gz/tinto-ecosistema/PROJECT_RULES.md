# Reglas del proyecto TINTO

## Sí

- Empezar por una sola unidad comercial.
- Validar problemas con conversaciones, comportamiento y pagos.
- Usar la experiencia de la fundadora como activo de confianza.
- Separar marca personal y TINTO sin desconectarlas.
- Crear activos digitales con una función definida.
- Separar honorarios, tecnología, producción y distribución.
- Mantener las cuentas y licencias a nombre de la clienta.
- Documentar decisiones y cambios.
- Usar IA para escalar contenido aprobado.
- Mantener una comunicación cálida, ejecutiva y responsable.
- Usar `(andres confirma)` cuando falte información.

## No

- Construir todas las verticales al mismo tiempo.
- Presentar una holding como oferta inicial.
- Desarrollar tecnología propia antes de validar demanda.
- Prometer rentabilidad o resultados financieros.
- Publicar recomendaciones sensibles sin revisión.
- Confundir engagement con validación comercial.
- Crear contenido sin objetivo, CTA o métrica.
- Usar nostalgia de forma manipuladora.
- Inventar nombres, precios, fechas, presupuestos o datos de la fundadora.
- Modificar `roadmap.md` desde el dashboard.
- Reemplazar interacciones humanas sensibles con avatar IA.

## Regla de aprobación

Nada queda aprobado únicamente porque aparezca en una conversación.

Toda decisión estructural debe registrarse en `DECISION_LOG.md`.

## Fuentes de verdad

- Estrategia: `docs/00_governance/TINTO_MASTER_CONTEXT.md`
- Decisiones: `DECISION_LOG.md`
- Reglas: `PROJECT_RULES.md`
- Tickets: `roadmap.md`
- Estados: `roadmap-status.md`
- Datos operativos: `dashboard-data/`