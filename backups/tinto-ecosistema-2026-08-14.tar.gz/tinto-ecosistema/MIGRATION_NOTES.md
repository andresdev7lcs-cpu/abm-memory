# MIGRATION_NOTES.md — Paso a TINTO Guardian v0.2.0

Notas técnicas para migrar desde baseline operativo a Bloque 1 de TINTO Guardian v0.2.0.

## Qué cambia

### Nuevo: Sistema de gobernanza manual

- **Antes:** Chats como fuente de verdad. Decisiones dispersas.
- **Ahora:** DECISION_LOG.md como registro oficial. Decisiones aprobadas antes de implementar.

### Nuevo: Separación de funciones

- **Antes:** Agente producía y aprobaba su propio trabajo.
- **Ahora:** Productor ≠ Auditor ≠ Aprobador. Independencia enforced en schema.

### Nuevo: Estados de tickets

- **Antes:** pending, completed (simple).
- **Ahora:** pending, ready, in_progress, agent_review, human_review, blocked, failed, completed, rejected (9 estados).

### Nuevo: Ledgers append-only

- **Antes:** Estados editables.
- **Ahora:** `roadmap-status.md` y `comments/[TICKET-ID].jsonl` son append-only (jamás reescribir).

### Nuevo: Memoria persistente

- **Antes:** Contexto en chats.
- **Ahora:** CURRENT_STATE.md, LEARNINGS.md, ASSUMPTIONS.md, VALIDATED_FACTS.md (en `memory/`).

## Qué NO cambia

- Git como control de versiones (baseline mantiene esto).
- roadmap.md como registro de tickets (no editado, solo leído).
- PROJECT_RULES.md como restricciones (no editado).
- Agentes Claude Code y Codex (mantienen roles).

## Nuevos archivos y carpetas

### Protocolos de orquestación

```
orchestration/
├── WORKFLOW_PROTOCOL.md          # Estados, transiciones, checklists
├── ROLE_MATRIX.md                # Roles, autoridades, límites
├── STAGE_GATES.md                # Gates por stage
├── STRATEGIC_GUARDRAILS.md       # Semáforos
├── ESCALATION_PROTOCOL.md        # Niveles E0-E3
├── CHANGE_CONTROL.md             # Solicitudes de cambio
├── DELIVERABLE_SCHEMA.json       # Schema JSON entregables
├── QA_REPORT_SCHEMA.json         # Schema JSON reportes QA
├── HUMAN_APPROVAL_SCHEMA.json    # Schema JSON aprobaciones
└── ticket-router.json            # Routing manual
```

### Agentes

```
.claude/agents/
├── tinto-supervisor.md           # Gatekeeper de guardrails
└── quality-auditor.md            # Validador independiente
```

### Skills

```
.claude/skills/tinto-business-incubator/
├── SKILL.md
├── TICKET_PROTOCOL.md
└── TECHNICAL_QA.md

.codex/skills/tinto-business-incubator/
├── SKILL.md
├── TICKET_PROTOCOL.md
└── TECHNICAL_QA.md
```

### Memoria

```
memory/
├── CURRENT_STATE.md              # Estado operativo
├── LEARNINGS.md                  # Aprendizajes (8 activos)
├── ASSUMPTIONS.md                # Hipótesis (9 activas)
└── VALIDATED_FACTS.md            # Hechos (12 verificables)
```

### Operación

```
deliveries/                       # Entregables completados
reviews/                          # Evidencia de revisión
comments/                         # Registros por ticket (JSONL)
change-requests/                  # Solicitudes de cambio
timeline/                         # Historia de ejecución
```

### Documentación raíz

- `INSTALL.md`: Guía de instalación.
- `REVIEW_CHECKLIST.md`: Checklist operativo.
- `CHANGELOG.md`: Historial de cambios.
- `MIGRATION_NOTES.md`: Este archivo.

## Nuevos roles

| Rol | Responsabilidad | Cambio desde baseline |
|-----|-----------------|----------------------|
| **Andrés** | Decisiones estratégicas, aprobación final | Mantiene, refuerza escala a DECISION_LOG.md |
| **Fundadora** | Validación marca personal, avatar, sensibles | Nueva explicitez en ROLE_MATRIX.md |
| **Claude Code** | Documentación, estrategia | Sin cambio (no codifica, documenta) |
| **Codex** | Código, validación técnica | Sin cambio (no decide, implementa) |
| **Auditor (QA)** | Validación independiente de entregas | **Nuevo role formal.** No es productor. |
| **tinto-supervisor** | Gatekeeper de guardrails (semáforos) | **Nuevo agente.** Recomienda, no decide. |

## Nuevo flujo manual de tickets

```
pending → ready → in_progress → agent_review → human_review → completed
              ↓                      ↓              ↓
           blocked ← ← ← ← ← ← ← ← ← ↓
                    ↓
                  failed
                    ↓
                  rejected
```

Transiciones manuales en `roadmap-status.md` (append-only).

## Nuevos estados

### Estados oficiales

1. **pending:** Esperando inicio. Dependencias sin completar.
2. **ready:** Dependencias completadas. Listo para ejecución.
3. **in_progress:** Productor trabajando.
4. **agent_review:** Entregable producido. Auditor revisando.
5. **human_review:** Auditoría aprobada. Andrés/Fundadora revisan.
6. **completed:** Aprobado. Finalizado.
7. **blocked:** Detenido. Falta información o dependencia.
8. **failed:** Ejecución fallida. Error técnico.
9. **rejected:** Revisión rechazó. Requiere rework.

### Resultados canónicos de auditoría (ÚNICOS)

- **pass:** Todo cumple. Listo para human_review.
- **conditional_pass:** Cumple excepto gap menor (documentado).
- **changes_required:** Major findings. Requiere rework.
- **fail:** Critical findings. No cumple.
- **blocked:** Dependencia o información falta (no es defecto entregable).

## Separación: productor ≠ auditor ≠ aprobador

### Productor

- Crea entregable.
- Registra en `deliveries/[TICKET-ID]_v1.[ext]`.
- Escribe en `comments/[TICKET-ID].jsonl`.
- **No marca completado.**

### Auditor independiente

- Valida contra AC, DECISION_LOG.md, PROJECT_RULES.md.
- Emite resultado canónico.
- Registra en `comments/[TICKET-ID].jsonl`.
- **No aprueba finalmente.** Solo recomienda.

### Aprobador (Andrés o Fundadora)

- Valida auditoría independiente.
- Verifica coherencia estratégica.
- Aprueba explícitamente.
- Marca `completed` en `roadmap-status.md`.

**Prohibición cardinal:** Productor jamás es auditor o aprobador de su propio trabajo.

## Cómo migrar trabajo anterior

### Paso 1: Identificar ticket

Buscar en `roadmap.md` si existe equivalente a trabajo anterior:

```bash
grep -n "TICKET-ID\|descripción trabajo anterior" roadmap.md
```

### Paso 2: Clasificar estado

Determinar dónde fue trabajo en baseline:

- **Completado sin aprobación:** → estado `in_progress` (reiniciar auditoría).
- **Completado con aprobación informal:** → estado `human_review` (formalizar en HUMAN_APPROVAL_SCHEMA.json).
- **Incompleto o pending:** → estado `pending` (retomar desde dónde quedó).

### Paso 3: Identificar evidencia

- ¿Archivo existe en repositorio?
- ¿Logs o capturas disponibles?
- ¿Información de fundadora confirmada o pendiente?

### Paso 4: Registrar hipótesis

Si trabajo depende de supuestos no validados:

- Crear entrada en `memory/ASSUMPTIONS.md` con estado `open`.
- Ejemplo: "A-012 — Mercado de X es viable" (si se asumió sin datos).

### Paso 5: Asignar productor

- Si trabajo está terminado: productor es quien lo hizo.
- Si trabajo está incomplete: asignar a Claude Code o Codex según tipo.

### Paso 6: Seleccionar auditor independiente

- Auditor ≠ Productor.
- Auditor competente para tipo (doc → Claude Code, código → Codex).

### Paso 7: Solicitar aprobación

- Auditor revisa contra AC.
- Si cumple: recomienda aprobación a Andrés.
- Andrés formaliza en HUMAN_APPROVAL_SCHEMA.json.

## Qué NO debe migrarse como hecho

### ❌ Contenido de chats

- Decisiones en conversaciones verbales.
- Feedbacks sin registro formal.
- Conclusiones sin evidencia documentada.

→ **Acción:** Rescatar sustancia, registrar en DECISION_LOG.md o ASSUMPTIONS.md.

### ❌ Supuestos

- "Asumimos que X es viable."
- "Parece que Y es el nicho."
- Información no confirmada sobre fundadora.

→ **Acción:** Registrar en ASSUMPTIONS.md, no como hecho.

### ❌ Ideas no aprobadas

- "Podemos hacer Z."
- Propuestas sin DECISION_LOG.md formal.
- Cambios de nicho sin aprobación.

→ **Acción:** Documentar en roadmap como ticket futuro. Escalar a Andrés para aprobación.

### ❌ Métricas sin fuente

- "100 leads generados" (sin evidencia).
- "3 clientes pagos" (sin verificación).
- Números del aire.

→ **Acción:** Buscar evidencia (roadmap-status.md, entregables, confirmación Andrés). Si no existe, marcar como `(andres confirma)`.

### ❌ Decisiones no registradas

- "Cambié de nicho" (sin DEC nueva).
- "Activé vertical X" (sin aprobación).
- "Presupuesto es Y" (sin formalizar).

→ **Acción:** Registrar faltante en DECISION_LOG.md. Escalar a Andrés.

## Compatibilidad con dashboard actual

Dashboard actual (OPCIONAL para operación v0.2.0):
- **Lectura local:** muestra tickets desde roadmap.md.
- **Edición local:** permite cambios sin persistencia a git.
- **Sin sincronización:** NO conecta a workflow automático en v0.2.0.
- **No es requisito de migración:** Operación manual funciona completamente sin dashboard. Herramienta de visualización solamente.

Uso si disponible:
1. Lectura de tickets (referencia visual).
2. Visualización de dependencias (exploración).
3. Cambios locales exploratorios (no guardados).

Cambios formales (obligatorios): editar `roadmap-status.md` directamente con editor de texto. Esta es la fuente de verdad para estados de tickets en v0.2.0.

## Cambios previstos para v0.3.0

- **Integración dashboard:** Sincronización bidireccional con workflow.
- **Automatización selectiva:** Webhooks para transiciones permitidas.
- **Selección automática de auditor:** Según independencia y competencia.
- **Aprobación por integración:** Conexión a email/Slack para notificaciones.
- **Cierre automático:** Estado `completed` si auditoría + aprobación OK.

Bloque 1 (v0.2.0) deliberadamente manual para validar proceso antes automatizar.

## Procedimiento de reversión

Si algo falla post-migración:

### Paso 1: No ejecutar rm -rf

Jamás eliminar trabajo sin respaldo:

```bash
# ❌ NO hacer esto
rm -rf orchestration/
git reset --hard
```

### Paso 2: Revertir cambios selectivamente

```bash
# ✓ Revertir un archivo específico
git checkout <commit-baseline> -- orchestration/WORKFLOW_PROTOCOL.md

# ✓ Revertir a commit anterior
git revert <commit-v0.2.0>
```

### Paso 3: Escalar a Andrés

Registrar en `comments/MIGRATION.jsonl`:

```json
{
  "timestamp": "ISO-8601",
  "author": "migrator",
  "type": "blocked",
  "message": "Reversión requerida. Razón: [descripción]. Aprobación de Andrés: (andres confirma)"
}
```

### Paso 4: No ejecutar git push/reset sin aprobación

Todos los cambios a baseline requieren autorización explícita de Andrés.

## Riesgos de migración

| Riesgo | Impacto | Mitigación |
|--------|---------|-----------|
| Trabajo incompleto movido a v0.2.0 | Entrega falsa | Auditoría independiente valida AC antes completar |
| Decisiones perdidas en chats | Contradicción futura | Documentar en DECISION_LOG.md o ASSUMPTIONS.md |
| Supuestos elevados a hechos | Error operativo | Validar con (andres confirma) antes registrar en VALIDATED_FACTS.md |
| Aprobador original no disponible | Bloqueo legal | Formalizar aprobación con Andrés en HUMAN_APPROVAL_SCHEMA.json |
| Archivos fuera de "Files allowed to change" | Scope creep | Auditor rechaza si violan restricción |

## Criterios para considerar migración completada

Bloque 1 v0.2.0 se considera migrado cuando:

- [ ] Todos los tickets baseline están en `roadmap.md`.
- [ ] Estados de tickets formalizados en `roadmap-status.md`.
- [ ] Decisiones documentadas en `DECISION_LOG.md`.
- [ ] Hipótesis no validadas en `ASSUMPTIONS.md`.
- [ ] Hechos verificables en `VALIDATED_FACTS.md`.
- [ ] Aprendizajes registrados en `LEARNINGS.md`.
- [ ] Auditoría independiente completada (todos los tickets agent_review → human_review).
- [ ] Aprobación humana formalizada (Andrés firma HUMAN_APPROVAL_SCHEMA.json por ticket).
- [ ] Cero archivos modificados fuera de "Files allowed to change".
- [ ] `git status` muestra "working tree clean" post-commit.
- [ ] Tag `v0.2.0` registrado en git.

Hasta que estos criterios se cumplan, Bloque 1 permanece en desarrollo (no mergeado a main).

---

**Contacto:** Escalar dudas de migración a Andrés registrando en `comments/MIGRATION.jsonl`.
