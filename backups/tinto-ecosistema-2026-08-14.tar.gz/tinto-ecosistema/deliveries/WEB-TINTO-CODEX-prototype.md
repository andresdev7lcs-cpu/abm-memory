---
ticket: WEB-TINTO
productor: Codex
rama: feature/tinto-offer-strategy-v1.0.0
objetivo: Construir la base funcional del website WEB TINTO
estado: agent_review
---

# WEB TINTO - Codex Prototype

## Alcance

- Loader funcional con logo sin giro.
- Hero provisional funcional.
- Home-Atom con nucleo y tres territorios.
- Seleccion por mouse, touch y teclado.
- Tablero digital accesible.
- Escenario interno con preguntas relacionadas.
- Diagnostico progresivo mock.
- Responsive base.
- Reduced motion.

## Archivos autorizados

- `tools/tinto-web/index.html`
- `tools/tinto-web/styles.css`
- `tools/tinto-web/app.mjs`
- `tools/tinto-web/content.mjs`
- `tools/tinto-web/router.mjs`
- `tools/tinto-web/state.mjs`
- `tools/tinto-web/components.mjs`
- `tools/tinto-web/server.mjs`
- `tools/tinto-web/assets/*.svg`
- `docs/03_offer_strategy/web/*.md`
- `deliveries/WEB-TINTO-CODEX-prototype.md`

## Archivos creados

- `tools/tinto-web/index.html`
- `tools/tinto-web/styles.css`
- `tools/tinto-web/app.mjs`
- `tools/tinto-web/content.mjs`
- `tools/tinto-web/router.mjs`
- `tools/tinto-web/state.mjs`
- `tools/tinto-web/components.mjs`
- `tools/tinto-web/server.mjs`
- `tools/tinto-web/assets/logo-mark.svg`
- `tools/tinto-web/assets/hero-poster.svg`
- `tools/tinto-web/assets/founder-portrait.svg`
- `tools/tinto-web/assets/founder-avatar.svg`
- `docs/03_offer_strategy/web/WEB_TINTO_TECHNICAL_ARCHITECTURE.md`
- `docs/03_offer_strategy/web/WEB_TINTO_COMPONENT_MAP.md`
- `docs/03_offer_strategy/web/WEB_TINTO_CONTENT_MODEL.md`
- `docs/03_offer_strategy/web/WEB_TINTO_NAVIGATION_FLOW.md`
- `docs/03_offer_strategy/web/WEB_TINTO_CODEX_HANDOFF.md`

## Archivos modificados

- Ninguno existente fue sobrescrito.

## Stack detectado

- HTML5 + CSS3 + vanilla JavaScript.
- ESM modules.
- Static local server.
- No dependencies externas.

## Arquitectura

- Contenido desacoplado en `content.mjs`.
- Navegacion por hash routes.
- Estado explicito en `state.mjs`.
- Componentes renderizados por funciones.
- Assets locales reemplazables.

## Modelo de datos

- `brand`
- `assets`
- `loader`
- `hero`
- `founderCore`
- `touchGesture`
- `territories[]`
- `diagnosis`

## Navegacion

- `#/home`
- `#/territorio/:territoryId`
- `#/territorio/:territoryId/pregunta/:questionId`
- `#/diagnostico/:territoryId/pregunta/:questionId`

## Componentes

- Loader.
- Hero.
- Founder core.
- Touch gesture cue.
- Home-Atom.
- Digital board.
- Internal scenario.
- Progressive diagnosis.

## Dependencias

- Ninguna nueva.
- No se instalaron paquetes.
- No se uso WebGL ni Three.js.

## Pruebas

- Servicio estatico servido con `python3 -m http.server`.
- `index.html` responde con `HTTP/1.0 200 OK`.
- `app.mjs` y assets responden por HTTP.
- Revisión visual de sintaxis de los modulos principales.

## Accesibilidad

- Botones reales.
- Focus visible.
- Semantica HTML.
- Fallback de reduced motion.
- Navegacion por teclado preparada.

## Responsive

- Layout adaptativo.
- Home-Atom pasa a stack vertical en pantallas pequenas.
- Board, scenario y diagnosis colapsan en una sola columna.

## Limitaciones

- No hay parser JS disponible en el entorno actual.
- `node` no esta instalado en este shell.
- El hero no tiene video real local aun.
- Los territorios son hipotesis.

## Riesgos

- Que el siguiente paso convierta hipotesis en afirmaciones aprobadas.
- Que se invente oferta o credenciales en la siguiente iteracion.
- Que se agreguen dependencias innecesarias.

## Contenido provisional

- logo provisional
- retrato provisional
- avatar provisional
- hero poster provisional
- copy provisional
- territorios con `status: hypothesis`
- `approval: pending_confirmation`

## Fuera de alcance

- Direccion de arte final.
- Motion design final.
- Microanimaciones finales.
- Hero cinematografico final.
- Gesto de toque final.
- Oferta final.
- Pagos.
- Publicacion del website.

## Handoff a Claude Code

- Mantener contenido fuera de componentes.
- Reemplazar assets sin romper rutas.
- Enriquecer estetica y motion.
- Mantener reversibilidad de vistas.

## Auditor por seleccionar

- Auditor independiente: por seleccionar.

## Resultado

- Estado final de la entrega: `agent_review`

