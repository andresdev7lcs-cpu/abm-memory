# WEB-TINTO-V0.2-ARCHITECTURE-CODEX

## 1. Rama

- `feature/tinto-offer-strategy-v1.0.0`

## 2. Objetivo

- Convertir el analisis aprobado de WEB TINTO v0.2 en documentacion canonica dentro del repositorio.

## 3. Decisiones aprobadas

- stack_v0_2: HTML/CSS/JavaScript modular
- experience_level: cinematic
- performance_modes: cinematic, balanced, reduced
- territories: hypothesis
- founder_media_contract: approved_for_architecture
- office_door_transition: after_halo_selection
- promotion_status: blocked
- commercial_offer_status: not_produced

## 4. Documentos creados

- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_EXPERIENCE_ENGINE.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_SCENE_ARCHITECTURE.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_MOTION_ARCHITECTURE.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_MEDIA_PIPELINE.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_CONTENT_FUNNEL.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_ACCESSIBILITY_FALLBACK.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_MIGRATION_PLAN.md`
- `docs/03_offer_strategy/web/v0.2/WEB_TINTO_V0_2_CODEX_HANDOFF.md`

## 5. Arquitectura narrativa

- telon de entrada;
- logo vivo;
- apertura del telon;
- mini VSL de la fundadora;
- elevator pitch corto;
- Home-Atom como command center;
- seleccion de halo;
- contacto fisico narrativo;
- blackout;
- puerta de cristal;
- territorio;
- preguntas;
- objeciones;
- decision;
- booking.

## 6. Arquitectura tecnica

- scene based system;
- scene state explicito;
- transitions state explicito;
- media contracts;
- fallback chain;
- reversible navigation;
- conceptual event contracts;
- no analytics provider conectado.

## 7. Stack

- HTML/CSS/JavaScript modular
- contenido desacoplado
- assets locales
- no dependencias nuevas
- no migracion a framework en esta entrega

## 8. State machine

Se documenta en `WEB_TINTO_V0_2_SCENE_ARCHITECTURE.md` con:

- `SceneId`
- `SceneState`
- transiciones por escena
- entradas, salidas, eventos, media, fallback y regreso

## 9. Transiciones

- curtain
- founder VSL
- halo selection
- black transition
- office intro
- conversion timeline

## 10. Performance tiers

- cinematic
- balanced
- reduced

## 11. Media pipeline

- logo;
- mini VSL;
- retrato;
- avatar;
- brazo y mano;
- puerta de cristal;
- taza TINTO;
- audio;
- captions;
- posters;
- mobile variants;
- transparent media;
- fallbacks.

## 12. Funnel

- curiosity;
- education;
- objection;
- relevance;
- decision;
- conversion.

## 13. Accesibilidad

- skip intro;
- pause;
- reduced motion;
- keyboard navigation;
- focus;
- captions;
- audio control;
- drag alternative;
- hover alternative;
- linear fallback;
- no JS fallback;
- mobile mode;
- no timeline trap.

## 14. Migracion

- conservar base modular;
- adaptar escenas y contratos;
- reemplazar la logica lineal por scene controller;
- eliminar el mental model de landing vertical.

## 15. Handoff

- Claude Code debe usar `ui-ux-pro-max`, `ui-styling`, `design-system` y `brand` como capa de recomendacion y consistencia;
- no debe inventar oferta, claims, credenciales ni media final.

## 16. Riesgos

- sobre-ingenieria;
- conversion de la experiencia en scroll disfrazado;
- animacion sin accesibilidad;
- falsificacion de assets finales;
- perdida de reversibilidad;
- mezcla de contenido estrategico dentro de componentes.

## 17. Pendientes

- aprobacion humana final de nuevas decisiones de produccion;
- assets finales;
- validacion tecnica independiente en la siguiente fase;
- no hay oferta comercial producida.

## 18. Confirmacion de no modificar codigo

- no se modifico `tools/tinto-web/`;
- no se toco el prototipo v0.1;
- no se altero STR-001;
- no se instalaron dependencias;
- no se ejecuto migracion;
- no se ejecuto commit, push, merge ni tag.

## 19. Confirmacion de no instalar dependencias

- confirmado.

## 20. Confirmacion de no commit, push, merge ni tag

- confirmado.

## 21. Resultado canonico

- `pass`

## 22. Estado final

- `agent_review`

