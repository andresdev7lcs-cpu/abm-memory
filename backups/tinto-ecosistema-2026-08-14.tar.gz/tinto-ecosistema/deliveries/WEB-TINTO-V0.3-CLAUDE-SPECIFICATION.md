# WEB TINTO v0.3 — Claude Specification (Delivery)

- Ticket: WEB-003 — WEB TINTO v0.3 Visual Refinement & Asset Direction
- Tipo: specification
- Autor: Claude Code (estratega documental)
- Rama: `feature/tinto-offer-strategy-v1.0.0`
- Fecha: 2026-08-03
- Estado: `agent_review`
- Resultado canónico: `pass`

## 1. Qué se entregó

Especificación visual completa de la maqueta predefinitiva de WEB TINTO, sobre la base funcional v0.2 existente. Diez documentos de especificación más este registro de entrega.

**No se implementó código.** `tools/tinto-web/` no fue modificado.

### 1.1 Archivos creados

| # | Ruta | Contenido |
|---|---|---|
| 1 | `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_VISUAL_REFINEMENT.md` | Visión, principios, jerarquía, composición, tono, profundidad, tratamiento editorial, continuidad, restricciones |
| 2 | `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_SCENE_COMPOSITIONS.md` | Las 11 escenas: objetivo, foco, composición desktop/tablet/móvil, zonas de imagen, jerarquía, CTA, navegación, fallback, dependencias, criterios |
| 3 | `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_COMPONENT_SYSTEM.md` | CTA, controles, títulos, captions, progreso, halos, nodos, labels, formularios, mensajes, placeholders, estados, reglas anti-card |
| 4 | `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_DESIGN_TOKENS.md` | Colores, tipografía, espacio, radios, sombras, transparencia, capas, contraste, tamaños, breakpoints, touch, estados |
| 5 | `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_ASSET_MAP.md` | 13 entradas con ID, escena, función, prioridad, formato, proporción, resoluciones, fallback, estado, dependencia, reemplazo |
| 6 | `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_ASSET_PROMPTS.md` | Briefs de producción con composición, cámara, iluminación, paleta, vestuario, expresión, fondo, proporción, uso, restricciones, versión móvil, consistencia |
| 7 | `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_MOTION_MAP.md` | Motion por elemento con trigger, entrada, salida, dirección, duración, easing, objetivo, reduced motion, dependencia y clasificación |
| 8 | `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_RESPONSIVE_PLAN.md` | 6 breakpoints, móvil horizontal, pantallas altas, safe areas, halos, núcleo, títulos, captions, overlays, booking, touch, overflow, colisiones, fallback |
| 9 | `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_HUMAN_REVIEW_GUIDE.md` | Guía de evaluación para Andrés con 15 decisiones pendientes y formato de registro |
| 10 | `docs/03_offer_strategy/web/v0.3/WEB_TINTO_V0_3_CODEX_IMPLEMENTATION_HANDOFF.md` | Alcance de Codex: permitidos, prohibidos, componentes, tokens, pruebas, criterios |
| 11 | `deliveries/WEB-TINTO-V0.3-CLAUDE-SPECIFICATION.md` | Este documento |

### 1.2 Archivos modificados

| Ruta | Cambio |
|---|---|
| `roadmap.md` | Ticket WEB-003 insertado entre WEB-002 y PROP-001 |

## 2. Ticket WEB-003

Registrado en `roadmap.md` con: ID, nombre, tipo `specification`, responsable documental (Claude Code), responsable de implementación (Codex), estado `in_progress`, dependencias reales, archivos permitidos, archivos prohibidos, 11 entregables, criterios de aceptación, guardrails, condición de handoff y estado final esperado `agent_review`.

### 2.1 Dependencias — ninguna completada

| Dependencia | Estado |
|---|---|
| WEB-002 | `pending` |
| BRD-003 | `pending` |
| PRD-003 | `pending` |
| FUN-002 | `pending` |
| TECH-001 | `pending` |

Ninguna se marcó como completada. WEB-003 avanza **solo como especificación documental**, bajo el permiso de `roadmap-status.md` para producir diagnóstico, hipótesis o propuesta de trabajo sin marcarlos como validados.

WEB-003 no desbloquea ni sustituye a WEB-001 ni a WEB-002.

## 3. Base heredada — sin alteración

| Elemento | Estado |
|---|---|
| 11 escenas y orden canónico | Intacto |
| Motor de escenas | Intacto |
| State machine | Intacta |
| 18 eventos | Intactos |
| Navegación reversible y puente `territory-world → office-intro` | Intacto |
| Vista pública / debug | Intacta |
| Performance tiers | Intactos |
| Booking mock local | Intacto |
| Router y deep links | Intacto |
| Guardrails | Intactos |
| Stack (HTML modular, CSS modular, ES modules) | Sin migración |

Secuencia canónica conservada:

```
curtain → founder-vsl → atom-command-center → halo-selection → black-transition
→ office-intro → territory-world → question-layer → objection-layer
→ conversion-layer → booking
```

## 4. Contenido de la especificación

### 4.1 Dirección visual

Cinematográfica, editorial, premium, cálida, humana, estratégica, sofisticada, confiable, colombiana sin clichés, orientada a conversación.

Tres palabras rectoras: **cálido, editorial, reservado**.

Ocho principios con orden de prioridad. Cinco niveles de jerarquía. Tres encuadres canónicos (A centrado, B asimétrico 60/40, C editorial textual) asignados por escena con lógica narrativa: la experiencia empieza cinematográfica y aterriza en conversación.

Paleta heredada sin cambio. Verde profundo acotado a confirmación (≤2% del área). Tres actos narrativos con `black-transition` como bisagra.

### 4.2 Restricciones aplicadas

Prohibido y documentado: dashboards, templates SaaS, landing convencional, estética bancaria, interfaces gamer, cyberpunk, neón, fintech azul, cards repetitivas, iconografía genérica, glassmorphism excesivo.

"Colombiana sin clichés" con regla explícita: prohibidos granos de café dispersos, yute, mapas, banderas, sombreros vueltiaos, paisaje cafetero.

### 4.3 Hallazgos sobre la implementación actual

Tres problemas detectados en v0.2 y especificados para corrección:

1. **Cards repetitivas.** `copy-block`, `summary-card`, `detail-card`, `question-card` y `confirmation-card` repiten el patrón panel-con-borde, produciendo la estética de dashboard que la dirección prohíbe. Reemplazo especificado en `COMPONENT_SYSTEM.md` §16.

2. **Caracteres como icono.** El overlay público usa `←`, `❙❙`, `▶`, `⚙` como texto. Dependen de la fuente, se rompen entre plataformas y violan la regla de no-emoji. Set de 8 iconos SVG especificado.

3. **Escala espacial irregular.** `--space-1..4` usa 6/10/14/18, que no es escala 4/8. Normalizada en `DESIGN_TOKENS.md` §6, con advertencia de regresión.

## 5. Guardrails respetados

| # | Guardrail | Cumplimiento |
|---|---|---|
| 1 | Claude Code no codifica | Sin código. Solo Markdown |
| 2 | Sin oferta comercial | No se produjo |
| 3 | Sin precios ni planes | No se produjeron |
| 4 | Sin claims ni promesas | No se produjeron |
| 5 | Sin testimonios ni pruebas | No se produjeron. Sin componente que los soporte |
| 6 | Sin garantías | No se produjeron |
| 7 | Sin buyer persona definitivo | No se definió |
| 8 | Sin país prioritario | No se definió |
| 9 | Sin recomendaciones financieras | No se produjeron |
| 10 | Sin credenciales de la fundadora | No se inventaron |
| 11 | Territorios como hipótesis | Conservados con `approval: pending_confirmation` y tag visible |
| 12 | Sin imágenes generadas | Ninguna |
| 13 | Promoción bloqueada | Sin cambio |
| 14 | Escala de unidad comercial única | Preservada; assets no pueden implicar escala corporativa |
| 15 | Motion avanzado bloqueado | Documentado, no implementado |
| 16 | Sin migración de framework | Stack conservado |

## 6. Confirmaciones pendientes

15 decisiones agrupadas en `HUMAN_REVIEW_GUIDE.md` §12.

### 6.1 Bloqueantes de producción de assets

| # | Tema |
|---|---|
| 1 | Autorización de uso de imagen y voz de la fundadora — **requiere revisión humana** |
| 2 | ¿Sesión fotográfica real o avatar IA bajo DEC-004? |
| 3 | ¿El logo actual es provisional o definitivo? |
| 4 | Locación para puerta de cristal y taza |
| 5 | ¿Se graba mini-VSL? Guion, duración, proporción |

### 6.2 Decisiones de sistema

| # | Tema |
|---|---|
| 6 | Valor hex del verde de confirmación |
| 7 | Tipografía: sistema o licenciada |
| 8 | Indicador de progreso: ninguno o tres puntos |
| 9 | Etiqueta del CTA de conversión |
| 10 | Etiqueta del botón de envío |
| 11 | Lista definitiva de países |
| 12 | Confirmación de los tres territorios como hipótesis |

### 6.3 Decisiones de alcance

| # | Tema |
|---|---|
| 13 | ¿Continuidad de elemento 03→04 (costosa)? |
| 14 | Duración máxima del blackout |
| 15 | ¿Motion antes o después de assets finales? |

Ninguna bloquea la especificación. Bloquean producción de assets e implementación.

## 7. Limitaciones

1. **Especificación, no maqueta renderizada.** Andrés evalúa sobre documentos y diagramas ASCII, no sobre pantallas. `HUMAN_REVIEW_GUIDE.md` §14 ofrece la opción de maqueta parcial (escenas 01, 03, 10) antes de comprometer las once.

2. **Contraste estimado, no medido.** Los ratios de `DESIGN_TOKENS.md` §10 se calcularon sobre valores hex. Codex debe verificarlos con herramienta real.

3. **Responsive sin dispositivo físico.** La validación de v0.2 usó Chrome headless. Safari iOS difiere en `dvh`, safe areas y `backdrop-filter`.

4. **Cinco assets P0 sin producir.** Los placeholders permiten evaluar composición, pero la maqueta no mostrará la imagen final.

5. **Copy heredado sin revisión.** El contenido de `content.mjs` se conserva sin alteración. Su calidad narrativa no fue objeto de esta fase.

## 8. Riesgos

| # | Riesgo | Impacto | Mitigación |
|---|---|---|---|
| 1 | Aprobar una dirección visual sin verla renderizada | Retrabajo tras implementar | Maqueta parcial de 3 escenas antes de las 11 |
| 2 | Sin sesión fotográfica, 4 de 5 P0 bloqueados | Maqueta con placeholders | Composición evaluable; sustitución sin tocar código |
| 3 | Normalización de espacio produce regresión | Layouts desalineados | Verificación escena por escena tras C1 |
| 4 | Reflujo 760→768px desalinea media queries | Comportamiento inconsistente | Actualizar todas en el mismo cambio |
| 5 | Halos en móvil se leen como menú | Se pierde el carácter distintivo | Glow de tono conservado; verificar al implementar |
| 6 | Quitar contenedores reduce claridad | Contenido menos separable | Reversible; decisión de Andrés en revisión |
| 7 | Espera de assets frena la implementación | Fase detenida sin necesidad | C1–C4 no dependen de fotografía |
| 8 | Territorios sin confirmar como hipótesis | Especificación sobre base inestable | Tag visible y `approval: pending_confirmation` conservados |

## 9. Validación documental

### 9.1 `git status --short`

```
 M roadmap.md
?? comments/
?? deliveries/STR-001-evidence-diagnosis.md
?? deliveries/WEB-TINTO-CLAUDE-prototype.md
?? deliveries/WEB-TINTO-CODEX-prototype.md
?? deliveries/WEB-TINTO-V0.2-ARCHITECTURE-CODEX.md
?? deliveries/WEB-TINTO-V0.2-CLAUDE-VISUAL.md
?? deliveries/WEB-TINTO-V0.2-CODEX-IMPLEMENTATION.md
?? deliveries/WEB-TINTO-V0.3-CLAUDE-SPECIFICATION.md
?? docs/03_offer_strategy/
?? tools/tinto-web/
```

Único archivo modificado: `roadmap.md`. El resto son archivos nuevos no rastreados.

### 9.2 `git diff --check`

Sin errores de espacios en blanco.

### 9.3 Integridad de `tools/tinto-web/`

Hash agregado de los 24 archivos, antes y después:

```
Antes:   59d7cae128eab072c48e8634cbcd006972b11dcd
Después: 59d7cae128eab072c48e8634cbcd006972b11dcd
```

Idéntico. Ningún archivo de implementación fue tocado.

### 9.4 Verificaciones

| # | Verificación | Resultado |
|---|---|---|
| 1 | `tools/tinto-web/` sin cambios | Confirmado por hash |
| 2 | State machine sin modificar | `state.mjs` intacto |
| 3 | Eventos sin modificar | `scene-events.mjs` intacto |
| 4 | STR-001 intacto | `deliveries/STR-001-evidence-diagnosis.md` sin cambios |
| 5 | Oferta no producida | Confirmado |
| 6 | Promoción bloqueada | Sin cambio |
| 7 | Documentos v0.2 intactos | Los 19 sin cambios |
| 8 | `DECISION_LOG.md` intacto | Sin cambios |
| 9 | `PROJECT_RULES.md` intacto | Sin cambios |
| 10 | `AGENTS.md` / `CLAUDE.md` intactos | Sin cambios |
| 11 | `memory/` intacto | Sin cambios |
| 12 | Sin commit, push, merge ni tag | Ninguno ejecutado |

## 10. Resultado canónico

```
pass
```

Criterios:

- [x] WEB-003 existe en `roadmap.md`
- [x] La especificación está completa (11 entregables)
- [x] El alcance de Codex queda claro
- [x] No hubo implementación
- [x] No existen contradicciones documentales

## 11. Estado final

```
agent_review
```

Claude Code no marca su propio trabajo como `completed` (`AGENTS.md`). La entrega queda esperando revisión.

## 12. Handoff

```
HANDOFF: WEB-003 especificación visual → Andrés (revisión humana)
Qué se entrega: 11 documentos de especificación visual
Qué se necesita próximo: decisión human_pass | human_changes_required | maqueta_parcial
Bloques identificados:
  - 15 confirmaciones pendientes (HUMAN_REVIEW_GUIDE.md §12)
  - Autorización de imagen de la fundadora (requiere revisión humana)
  - 5 assets P0 sin producir
Recomendación: si hay duda entre aprobar y corregir, pedir maqueta parcial de las
  escenas 01, 03 y 10. Valida la dirección con una iteración de costo bajo en
  lugar de comprometer once escenas sobre documentos.
Próximo paso: revisión de Andrés → si human_pass, Codex implementa fases C1–C9
```

## 13. Nota de gobernanza

Esta fase se ejecutó bajo decisión explícita de Andrés (opción A): Claude Code actúa únicamente como estratega documental, sin tocar HTML, CSS, JavaScript, assets ni `tools/tinto-web/`.

La decisión resolvió un conflicto detectado al inicio: la solicitud original pedía refinamiento frontend directo, lo que contradice `CLAUDE.md` ("No codifica") y `AGENTS.md` §61-68 (los tickets WEB corresponden a Codex). El conflicto se escaló antes de escribir código y se resolvió por decisión humana.
