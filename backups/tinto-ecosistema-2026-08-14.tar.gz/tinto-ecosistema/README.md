# TINTO Ecosistema

Repositorio estratégico y operativo del proyecto TINTO.

## Propósito

Conservar la memoria del proyecto, separar estrategia de ejecución y evitar que las decisiones dependan únicamente del contexto temporal de chats, reuniones o archivos aislados.

## Principio rector

> Visión amplia, ejecución estrecha.

TINTO puede evolucionar hacia un ecosistema de soluciones para colombianos en el exterior. La fase inicial construye y valida una sola unidad comercial capaz de atraer, convertir y atender clientes.

## Fuentes de verdad

- Contexto estratégico: `docs/00_governance/TINTO_MASTER_CONTEXT.md`
- Decisiones: `DECISION_LOG.md`
- Reglas: `PROJECT_RULES.md`
- Tickets: `roadmap.md`
- Estados operativos: `roadmap-status.md`
- Datos del dashboard: `dashboard-data/`
- Especificación técnica: `specs/tinto-ops-dashboard-spec.json`

## Dashboard

El dashboard se ejecutará con Node.js desde:

```text
tools/tinto-dashboard/server.mjs