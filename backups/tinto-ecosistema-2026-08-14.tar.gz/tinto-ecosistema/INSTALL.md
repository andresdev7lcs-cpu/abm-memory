# TINTO Guardian v0.2.0 — Guía de instalación

## Propósito

Preparar y verificar entorno para operar TINTO Guardian v0.2.0: sistema manual de goberanza, tickets, auditoría y aprobaciones.

## Alcance de v0.2.0

Sistema completamente manual sin automatizaciones:
- Estados de tickets administrados manualmente en `roadmap-status.md`.
- Auditoría de entregas realizada por revisores humanos.
- Aprobaciones ejecutadas por Andrés o fundadora (humanos).
- Dashboard local sin integración a workflow automatizado.
- Transiciones de estado sin webhooks, sin gatillos, sin colas de trabajo.

Integración dashboard automatizada: v0.3.0 (futuro).

## Prerrequisitos verificables

### 1. Git

```bash
git --version
# Esperado: git version 2.x.x o superior
```

### 2. Acceso al repositorio

```bash
git status
# Confirmar acceso a repositorio local
```

### 3. Claude Code (cuando se use para documentación)

Claude Code debe detectar:
- Instrucciones maestras: `CLAUDE.md`
- Agentes: `.claude/agents/`

Verificar:
```bash
ls -la .claude/agents/
# Debe listar: tinto-supervisor.md, quality-auditor.md
```

### 4. Codex (cuando se use para código/validación técnica)

Codex debe detectar:
- Instrucciones maestras: `AGENTS.md`
- Skills: `.codex/skills/`

Verificar:
```bash
ls -la .codex/skills/tinto-business-incubator/
# Debe listar: SKILL.md, TICKET_PROTOCOL.md, TECHNICAL_QA.md
```

### 5. Node (solo para dashboard local y validación JSON)

```bash
node --version
# Esperado: v14 o superior
```

No es requisito para flujo manual.

## Clonación del repositorio

```bash
git clone <ruta-repositorio> tinto-ecosistema
cd tinto-ecosistema
```

## Verificación de raíz del repositorio

**Ejecutar todos los comandos desde la raíz de `tinto-ecosistema`, salvo que el paso indique otra ruta.**

Verificar contexto:
```bash
pwd
# Esperado: .../tinto-ecosistema

git rev-parse --show-toplevel
# Esperado: ruta absoluta de tinto-ecosistema
```

## Verificación de rama

No asumir que rama `feature/tinto-guardian-core-v0.2.0` existe localmente.

```bash
git branch --show-current
# Muestra rama actual

git branch --list
# Lista ramas locales

git remote -v
# Lista remotos configurados
```

**Comportamiento esperado:**
- Si rama actual es `feature/tinto-guardian-core-v0.2.0`: continuar.
- Si existe localmente pero no activa: cambio de rama requiere acción consciente (no automática).
- Si no existe localmente: verificar remoto (`git remote -v`). Si existe remoto `origin` y rama existe allá, requiere aprobación explícita para descargar/cambiar.
- Si no existe remoto o rama no aparece: detener y escalar a Andrés. No crear, descargar ni cambiar ramas sin aprobación.

**Nota:** Una herramienta aislada (ej. Claude Code) puede no ver el mismo contexto Git que tu terminal local. Verificar siempre manualmente.

## Estructura principal

```
tinto-ecosistema/
├── AGENTS.md                         # Instrucción agentes técnicos
├── CLAUDE.md                         # Instrucción Claude Code
├── PROJECT_RULES.md                  # Reglas (Sí/No)
├── DECISION_LOG.md                   # Decisiones aprobadas (DEC-001 a DEC-005)
├── roadmap.md                        # Tickets, scope, AC, dependencias
├── roadmap-status.md                 # Ledger manual de estados (append-only)
│
├── .claude/agents/
│   ├── tinto-supervisor.md           # Gatekeeper de guardrails
│   └── quality-auditor.md            # Validador independiente
│
├── .codex/skills/tinto-business-incubator/
│   ├── SKILL.md
│   ├── TICKET_PROTOCOL.md
│   └── TECHNICAL_QA.md
│
├── orchestration/
│   ├── WORKFLOW_PROTOCOL.md          # Estados, transiciones
│   ├── ROLE_MATRIX.md                # Roles, autoridades, límites
│   ├── STAGE_GATES.md                # Gates por stage
│   ├── STRATEGIC_GUARDRAILS.md       # Semáforos
│   ├── ticket-router.json            # Routing manual
│   └── [otros protocolos]
│
├── memory/
│   ├── CURRENT_STATE.md              # Estado operativo
│   ├── LEARNINGS.md                  # Aprendizajes
│   ├── ASSUMPTIONS.md                # Hipótesis activas
│   └── VALIDATED_FACTS.md            # Hechos verificables
│
├── deliveries/                       # Entregables completados
├── reviews/                          # Evidencia de revisión
├── comments/                         # Registros por ticket (JSONL)
└── [otras carpetas]
```

## Verificación: Claude Code detecta archivos

```bash
cat CLAUDE.md | head -5
# Debe mostrar: "# Instrucción maestra para Claude Code — TINTO"

ls .claude/agents/tinto-supervisor.md
ls .claude/agents/quality-auditor.md
```

## Verificación: Codex detecta archivos

```bash
cat AGENTS.md | head -5
# Debe mostrar: "# Instrucción maestra para agentes técnicos — TINTO"

ls .codex/skills/tinto-business-incubator/SKILL.md
ls .codex/skills/tinto-business-incubator/TICKET_PROTOCOL.md
```

## Iniciar dashboard local

Dashboard es visualización local sin automatización backend.

```bash
# Si existe script en package.json
npm run dashboard

# Si no, ejecutar manualmente con Node o abrir HTML en navegador
```

**Resultado esperado:**
- Kanban visible con estados: pending, ready, in_progress, agent_review, human_review, blocked, completed.
- Edición local (sin persistencia a git durante v0.2.0).

## Validar contratos JSON

```bash
node -e "const s = require('./orchestration/DELIVERABLE_SCHEMA.json'); console.log('✓ DELIVERABLE_SCHEMA válido');"
node -e "const s = require('./orchestration/QA_REPORT_SCHEMA.json'); console.log('✓ QA_REPORT_SCHEMA válido');"
node -e "const s = require('./orchestration/HUMAN_APPROVAL_SCHEMA.json'); console.log('✓ HUMAN_APPROVAL_SCHEMA válido');"
node -e "const s = require('./orchestration/ticket-router.json'); console.log('✓ ticket-router válido');"
```

**Resultado:** Cuatro confirmaciones sin errores de sintaxis.

## Flujo operativo manual

### 1. Abrir ticket

```bash
grep -A 20 "TICKET-ID" roadmap.md
tail -10 roadmap-status.md
```

### 2. Producir

Agente ejecuta trabajo según acceptance criteria.
- Modificar solo archivos en "Files allowed to change".
- Registrar en `comments/[TICKET-ID].jsonl`.
- Guardar en `deliveries/[TICKET-ID]_v1.[ext]`.

### 3. Auditar

Auditor independiente revisa contra AC, DECISION_LOG.md, PROJECT_RULES.md.
Emite: `pass`, `conditional_pass`, `changes_required`, `fail`, `blocked`.

### 4. Solicitar cambios

Si falla: productor retrabaja, estado vuelve a `in_progress`.

### 5. Aprobar

Andrés o fundadora aprueba explícitamente.

### 6. Cerrar ticket

Actualizar roadmap-status.md a `completed`. No commit automático.

## Componentes NO automatizados en v0.2.0

1. **Transiciones de estado:** Actualizar manualmente en `roadmap-status.md`.
2. **Selección de auditor:** Andrés asigna manualmente.
3. **Cierre de tickets:** Andrés marca completado explícitamente.
4. **Integración dashboard:** Solo lectura local.
5. **Aprobación por silencio:** Prohibido. Requiere entrada explícita.
6. **Commits automáticos:** Prohibido. Requieren autorización humana.

## Solución de problemas

### Error: "Rama no encontrada"

1. Verificar si rama existe:
   ```bash
   git branch --list
   ```
2. Si no existe localmente pero esperas que exista:
   - Verificar si existe remoto: `git remote -v`
   - **Requiere aprobación explícita antes de** `git fetch origin` o crear rama
   - Contactar a Andrés en `comments/`.
3. Cambiar de rama (si existe localmente):
   ```bash
   git checkout feature/tinto-guardian-core-v0.2.0
   ```

### Error: "Node no disponible"

Dashboard es opcional. Editar roadmap-status.md con editor de texto.

### Error: "Skill no detectada"

```bash
ls -la .claude/skills/tinto-business-incubator/SKILL.md
ls -la .codex/skills/tinto-business-incubator/SKILL.md
```

### Error: "Auditor igual al productor"

Prohibido. Ticket rechazado. Seleccionar auditor independiente.

### Error: "Dependencia incompleta"

Esperar hasta que dependencia esté `completed`.

### Error: "Archivo modificado fuera de alcance"

Auditor rechaza. Productor revierte cambios.

## Prohibiciones críticas

1. **No commits automáticos.** Requieren aprobación humana explícita.
2. **No marcar tickets sin aprobación independiente.**
3. **No inventar datos.** Escribir `(andres confirma)` y escalar.
4. **No activar verticales nuevas.** Solo Andrés registra decisión.
5. **No reescribir roadmap-status.md.** Siempre append-only.

## Referencias a fuentes de verdad

| Archivo | Propósito |
|---------|----------|
| `DECISION_LOG.md` | Decisiones aprobadas (DEC-001 a DEC-005) |
| `PROJECT_RULES.md` | Reglas Sí/No vinculantes |
| `AGENTS.md` | Instrucción agentes técnicos |
| `CLAUDE.md` | Instrucción Claude Code |
| `WORKFLOW_PROTOCOL.md` | Estados, transiciones, checklists |
| `ROLE_MATRIX.md` | Roles, autoridades, límites |
| `STAGE_GATES.md` | Criterios de aprobación por stage |
| `STRATEGIC_GUARDRAILS.md` | Semáforos verde/amarillo/rojo/azul |
| `memory/CURRENT_STATE.md` | Estado operativo (snapshot) |

## Siguiente paso

1. Leer `WORKFLOW_PROTOCOL.md`.
2. Leer `roadmap.md`.
3. Seleccionar primer ticket con estado `ready`.
4. Asignar productor y auditor independientes.
5. Ejecutar según `AGENTS.md` y `CLAUDE.md`.

**Contacto:** Escalar bloques a Andrés registrando en `comments/[TICKET-ID].jsonl`.
