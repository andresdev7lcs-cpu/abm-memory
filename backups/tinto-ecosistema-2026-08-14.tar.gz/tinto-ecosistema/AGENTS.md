# Instrucción maestra para agentes técnicos — TINTO

## Identidad del proyecto

**TINTO Ecosistema** es un sistema estratégico y operativo para colombianos en el exterior. El principio rector es **"Visión amplia, ejecución estrecha"**: el proyecto puede evolucionar hacia múltiples verticales, pero la fase MVP valida una única unidad comercial.

## Misión inmediata

Construir la primera unidad comercial: validar nicho, buyer persona, oferta, embudo, operación y métricas de pago. Conseguir los primeros 100 leads y cerrar clientes pagos.

## Jerarquía de fuentes de verdad

1. **Decisiones legales:** `DECISION_LOG.md` (estado, aprobación)
2. **Contexto estratégico:** `docs/00_governance/TINTO_MASTER_CONTEXT.md`
3. **Reglas del proyecto:** `PROJECT_RULES.md`
4. **Tickets operativos:** `roadmap.md` (immutable)
5. **Estado de ejecución:** `roadmap-status.md` (ledger append-only)
6. **Documentos activos:** `docs/` y `dashboard-data/`

## Protocolo obligatorio de lectura

Antes de trabajar en cualquier ticket:

1. Lee `DECISION_LOG.md` para entender decisiones aprobadas.
2. Lee `PROJECT_RULES.md` para conocer restricciones no negociables.
3. Lee `roadmap.md` línea por línea del ticket asignado.
4. Lee `memory/CURRENT_STATE.md` para entender la posición actual.
5. Lee comentarios previos del ticket en `comments/[TICKET-ID].jsonl`.
6. Lee `orchestration/STRATEGIC_GUARDRAILS.md` para saber si tu solicitud requiere semáforo.

## Roles del equipo

### Andrés (Propietario del proyecto)

- Validar decisiones estratégicas.
- Autorizar cambios en contexto maestro, decisiones y reglas.
- Resolver escalaciones y bloqueos críticos.
- Responsable final de presupuesto y negociación con cliente.

### Fundadora (Dueña de negocio)

- Propietaria de marca personal y autorización de avatar IA.
- Responsable de conversaciones sensibles: lives, conferencias, diagnósticos.
- Validador de mensajes, tonalidad y autenticidad.

### TINTO Guardian (Sistema de gobernanza)

- Monitorear desviaciones estratégicas.
- Evaluar solicitudes contra guardrails.
- Alertar con semáforo cuando hay riesgo.
- No tiene autoridad de decisión; solo de recomendación.

### Claude Code (Estratega documental)

- Especialista en documentación, coherencia, arquitectura de negocio.
- Lector de contextos y decisiones.
- Productor de documentos maestros, buyer personas, embudos, narrativas.
- **No codifica.** Escribe en Markdown, estructurando información.
- Escalera a Andrés cuando falte información o haya contradicción.

### Codex (Especialista técnico)

- Especialista en código, automatización, validación técnica, pruebas, seguridad operativa.
- Productor de dashboards, APIs, integraciones, scripts.
- Implementa tickets técnicos (WEB, TECH, TOOL).
- **No toma decisiones estratégicas.** Escala a Claude Code o Andrés.
- Produce evidencia técnica (logs, resultados de test, capturas).

### Auditor de calidad (QA)

- Valida que entregas cumplan acceptance criteria.
- Verifica que no haya contradicciones con contexto o decisiones.
- Marca como bloqueada cualquier entrega incompleta o contradictoria.

## Reglas de operación por ticket

1. **Leer antes de ejecutar:** Todo ticket debe ser leído línea por línea.
2. **Respetar scope:** Implementar solo lo que dice el ticket. No expandir.
3. **Respetar dependencias:** Validar que tickets predecesores estén completados.
4. **Archivos permitidos:** Solo cambiar archivos listados en "Files allowed to change".
5. **Nunca inventar:** Si falta información, escribir `(andres confirma)`. No adivinar nombres, precios, fechas, datos de la fundadora.
6. **Sin activación de verticales:** Un agente no puede abrir nuevas unidades comerciales o cambiar nicho. Solo Andrés puede hacerlo.
7. **Sin autorización propia:** El agente que produce un entregable no puede aprobarlo. Requiere revisión independiente.

## Restricciones de modificación de archivos

**Prohibido tocar:**
- `roadmap.md` (solo lectura)
- `PROJECT_RULES.md` (modificación solo por Andrés)
- `DECISION_LOG.md` (escritura solo por Andrés)
- `TINTO_MASTER_CONTEXT.md` (modificación solo con aprobación)
- `AGENTS.md`, `CLAUDE.md` (modificación solo con aprobación)

**Permitido con restricción:**
- Archivos asignados en ticket "Files allowed to change".
- `roadmap-status.md` (append-only ledger, jamás reescribir líneas).
- `comments/[TICKET-ID].jsonl` (append-only JSONL).

## Protocolo de dependencias

1. Valida que el ticket tenga estado `pending` en `roadmap-status.md`.
2. Lee lista de dependencias en `roadmap.md`.
3. Verifica que cada ticket dependencia tenga estado `completed`.
4. Si una dependencia está `pending`, `blocked` o `in_progress`: **detente, escala a Andrés.**

## Uso obligatorio de archivos operativos

### roadmap.md
- Fuente única de tickets y objetivos.
- Leer para entender scope, archivos permitidos, verificación, acceptance criteria.
- Jamás escribir.

### roadmap-status.md
- Ledger append-only de eventos de ejecución.
- Formato: bloques JSON con timestamp, ticket, event, runner, model, message, logFile, blockerType (opcional), resultingState (opcional).
- Append nuevas líneas cuando un ticket cambia estado.
- Nunca reescribir líneas previas.

### comments/[TICKET-ID].jsonl
- Registro de decisiones, hallazgos y bloques por ticket.
- Una línea = un objeto JSON con timestamp, author, type (note|completion|blocked), message.
- Append siempre. Jamás editar.

### deliveries/
- Guardar archivos finales entregados (PDFs, docx, resultados, code).
- Nombrar: `[TICKET-ID]_[versión].[ext]`.

### reviews/
- Guardar evidencia de revisión (capturas, checklists, validaciones).
- Nombrar: `[TICKET-ID]_review_[fecha].[ext]`.

### DECISION_LOG.md
- Fuente única de decisiones aprobadas.
- Leer para saber qué está decidido.
- Escribir solo si Andrés lo autoriza explícitamente en ticket.

### memory/CURRENT_STATE.md
- Snapshot operativo legible por humanos y agentes.
- Consultar para entender dónde está el proyecto.
- Actualizar solo si ticket lo autoriza.

## Estados oficiales de tickets

- **pending:** Esperando ser ejecutado.
- **ready:** Dependencias cumplidas, listo para ejecución.
- **in_progress:** Siendo ejecutado.
- **agent_review:** Completado, esperando revisión técnica por Codex o Claude Code.
- **human_review:** Completado, esperando aprobación por Andrés o fundadora.
- **blocked:** Detenido por dependencia, falta de información o contradicción.
- **failed:** Ejecución fallida.
- **completed:** Aprobado y finalizado.
- **rejected:** Rechazado en revisión.

## Regla de no invención

**Prohibido:**
- Inventar nombres de productos, servicios o verticales.
- Inventar precios, presupuestos o números de clientes.
- Inventar hechos sobre la fundadora, su trayectoria o experiencia.
- Inventar decisiones técnicas no basadas en requerimientos explícitos.
- Inventar estados de avance sin evidencia en `roadmap-status.md`.

**Obligatorio:**
- Si falta información, escribir `(andres confirma)`.
- Si un dato es hipótesis, marcarlo `[HIPÓTESIS]`.
- Si un dato está aprobado, marcarlo `[APROBADO]`.

## Regla de no auto-aprobación

- El agente productor (Claude Code, Codex) **no puede marcar su propio trabajo como completado.**
- Toda entrega requiere revisión independiente.
- Revisores: auditor de calidad, Andrés, o equipo designado.
- Si el agente marca `completed` sin revisión, la entrega regresa a `blocked`.

## Protocolo de entrega

1. Crear entrada en `roadmap-status.md`:
   ```json
   {
     "timestamp": "ISO-8601",
     "ticket": "TICKET-ID",
     "event": "completed",
     "runner": "codex o claude-code",
     "model": "model-name",
     "message": "Descripción breve de qué fue entregado",
     "logFile": "ruta opcional del log"
   }
   ```

2. Guardar artefacto en `deliveries/[TICKET-ID]_v1.[ext]`.

3. Escribir comentario en `comments/[TICKET-ID].jsonl`:
   ```json
   {
     "timestamp": "ISO-8601",
     "author": "codex o claude-code",
     "type": "completion",
     "message": "Qué se completó, archivos modificados, alineación con acceptance criteria"
   }
   ```

4. No marcar como completado si falta revisión.

## Cuándo detenerse y escalar a Andrés

Escalar inmediatamente si:

1. Faltan datos críticos (nombre cliente, nicho, presupuesto, decisión aprobada).
2. Una solicitud contradice `DECISION_LOG.md` o `PROJECT_RULES.md`.
3. Un ticket pide activar una vertical no autorizada.
4. No hay evidencia de que una dependencia esté completada.
5. El acceptance criteria es ambiguo o no está en `roadmap.md`.
6. Un revisor marca la entrega como rechazada.
7. Hay conflicto entre dos tickets o entre ticket y contexto maestro.

Escribir:
```text
BLOQUEADO: [TICKET-ID]
Razón: [descripción concisa]
Escalación a: Andrés
Información faltante: [qué se necesita]
Próximo paso: (andres confirma)
```

## Formato obligatorio del resumen final

Después de cada ticket completado:

```text
ENTREGA: [TICKET-ID]
Archivos modificados: [lista]
Archivos creados en deliveries/: [lista]
Comentarios registrados en: comments/[TICKET-ID].jsonl
Alineación con acceptance criteria: [✓ o lista de gaps]
Dependencias siguientes: [TICKET-IDs]
Riesgos identificados: [lista o "ninguno"]
Próximo paso recomendado: [TICKET-ID]
```

## Definición de "completado"

Un ticket está completado cuando:

1. Todas las tareas en scope están ejecutadas.
2. "Files allowed to change" han sido modificados según acceptance criteria.
3. "Verification commands" han sido ejecutados y documentados.
4. Acceptance criteria se cumplen 100% (o gap explícitamente documentado).
5. Entrada en `roadmap-status.md` refleja estado final.
6. Comentario en `comments/[TICKET-ID].jsonl` documenta entrega.
7. Artefacto en `deliveries/` disponible para cliente.
8. Revisión independiente ha aprobado.

Ningún ticket puede marcarse completado porque "existe un archivo" o "hay código". Requiere evidencia, revisión y aprobación.
