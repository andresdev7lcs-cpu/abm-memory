# TINTO Roadmap Status Ledger

> Archivo generado y actualizado por el dashboard.
> No editar entradas anteriores manualmente.

## Bloque 1 v0.2.0 — Estado final

```json
{
  "date": "2026-07-28",
  "block": "Bloque 1 v0.2.0",
  "event": "closed",
  "runner": "andres",
  "status": "closed",
  "mergedToMain": true,
  "tag": "v0.2.0",
  "mergeCommit": "5156e65",
  "implementationCommit": "563aa4f",
  "baselineCommit": "454842c",
  "integralTestResult": "pass",
  "criticalFindings": 0,
  "majorFindings": 0,
  "minorFindings": 1,
  "operationalMode": "manual",
  "automationScheduled": "v0.3.0",
  "message": "Pruebas integrales completadas (Pruebas 1-12). Resultado: pass. Merged to main, tagged v0.2.0. Sistema manual operativo."
}
```

---

## Bloque 3 — Estrategia y oferta (v1.0.0) — opened

```json
{
  "date": "2026-07-28",
  "block": "Bloque 3 v1.0.0",
  "event": "opened",
  "runner": "andres",
  "status": "opened",
  "branch": "feature/tinto-offer-strategy-v1.0.0",
  "offerProduced": false,
  "message": "Bloque 3 formalmente abierto. Objetivo: construir, validar y aprobar la primera oferta comercial de TINTO. Ninguna oferta, precio, país, buyer persona o nicho aprobado todavía. Oferta aún no producida."
}
```

**Estado inicial:** `opened`

**Entregables previstos (todos pendientes o planificados):**

1. Diagnóstico y consolidación de evidencia existente — `pending`
2. Selección o confirmación de la primera unidad comercial — `pending` (andres confirma)
3. Buyer persona y problema prioritario — `pending` (andres confirma)
4. Oferta principal (transformación, mecanismo, elementos centrales, elementos secundarios, bonos, valor percibido) — `pending`
5. Precio y facilidades de pago — `pending` (andres confirma)
6. Reversión de riesgo — `pending`
7. Identidad (naming, pertenencia, lenguaje, acrónimo si aplica) — `pending` (andres confirma)
8. Ecosistema de ascensión (lead magnet o prueba, oferta principal, continuidad, premium) — `planificado`
9. Evento de conversión — `planificado`
10. Script de venta y objeciones — `planificado`
11. Documento o propuesta comercial final — `planificado`
12. Auditoría, aprobación humana y cierre Git — `planificado`

**Bloqueantes activos:** nicho, país, buyer persona y precio sin decisión registrada en `DECISION_LOG.md` (ver `memory/ASSUMPTIONS.md` A-001, A-002, A-006). Entregables 2-7 pueden avanzar como diagnóstico, hipótesis o propuesta de trabajo, pero no pueden marcarse como validados, aprobados o completados sin evidencia y aprobación humana explícita de Andrés o fundadora.

**Restricciones:** no promoción antes de oferta aprobada; no anuncios; no país/nicho/buyer persona/precio/oferta validados sin evidencia; no nuevas verticales sin change request (`orchestration/CHANGE_CONTROL.md`); operación sujeta a revisión y aprobación humana (`orchestration/WORKFLOW_PROTOCOL.md`).

---
