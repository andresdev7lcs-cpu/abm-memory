
import React from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Clock, 
  UserCheck, 
  ChevronRight, 
  CheckCircle2, 
  Plus, 
  Minus,
  AlertCircle,
  TrendingUp,
  Target
} from 'lucide-react';
import { motion } from 'framer-motion';

// --- Shared Components ---

const PrimaryButton: React.FC<{ text: string; onClick?: () => void; fullWidth?: boolean }> = ({ text, onClick, fullWidth = true }) => (
  <button 
    onClick={onClick}
    className={`bg-[#2ECC71] hover:bg-[#27ae60] transition-all duration-300 text-white font-semibold py-4 px-8 rounded-xl shadow-lg shadow-green-200 active:scale-95 ${fullWidth ? 'w-full' : ''}`}
  >
    {text}
  </button>
);

const SectionTitle: React.FC<{ children: React.ReactNode; dark?: boolean }> = ({ children, dark }) => (
  <h2 className={`text-2xl md:text-3xl font-semibold mb-8 text-center ${dark ? 'text-white' : 'text-primary'}`}>
    {children}
  </h2>
);

// --- Section 1: Hero ---
const HeroSection = () => (
  <section className="pt-12 pb-20 px-6 max-w-4xl mx-auto text-center">
    <div className="inline-block px-4 py-1.5 mb-6 rounded-full bg-blue-50 text-primary text-sm font-medium border border-blue-100 uppercase tracking-wider">
      Planificación FIRE PASS
    </div>
    <h1 className="text-3xl md:text-5xl font-semibold leading-tight text-primary mb-6">
      Recupera entre <span className="text-accent">$100 y $300</span> al mes sin trabajar más horas
    </h1>
    <p className="text-lg text-slate-600 mb-10 max-w-2xl mx-auto leading-relaxed">
      Un diagnóstico personalizado para ordenar tus gastos, reducir fugas invisibles y empezar a construir un plan financiero realista.
    </p>
    
    <div className="flex flex-wrap justify-center gap-6 md:gap-12 mb-10">
      <div className="flex items-center gap-2 text-slate-500 text-sm">
        <ShieldCheck size={18} className="text-accent" />
        <span>Privado</span>
      </div>
      <div className="flex items-center gap-2 text-slate-500 text-sm">
        <Lock size={18} className="text-accent" />
        <span>Confidencial</span>
      </div>
      <div className="flex items-center gap-2 text-slate-500 text-sm">
        <UserCheck size={18} className="text-accent" />
        <span>Sin juicios</span>
      </div>
      <div className="flex items-center gap-2 text-slate-500 text-sm">
        <Clock size={18} className="text-accent" />
        <span>En minutos</span>
      </div>
    </div>

    <div className="max-w-md mx-auto">
      <PrimaryButton text="Quiero mi diagnóstico FIRE PASS — $4.99" />
      <p className="mt-4 text-xs text-slate-400">
        Menos de lo que gastas en cafés o suscripciones que no usas.
      </p>
    </div>
  </section>
);

// --- Section 2: This is for you if ---
const TargetsSection = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, x: -10 },
    visible: { 
      opacity: 1, 
      x: 0,
      transition: { duration: 0.5, ease: "easeOut" }
    }
  };

  const checkVariants = {
    hidden: { scale: 0, rotate: -45 },
    visible: { 
      scale: 1, 
      rotate: 0,
      transition: { 
        type: "spring", 
        stiffness: 300, 
        damping: 12,
        delay: 0.2 // Small extra delay for the icon relative to the row
      }
    }
  };

  return (
    <section className="py-16 bg-secondary px-6">
      <div className="max-w-2xl mx-auto">
        <SectionTitle>Esto es para ti si…</SectionTitle>
        <motion.ul 
          className="space-y-4 mb-10"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          {[
            "Trabajas duro pero el dinero no rinde",
            "No sabes exactamente a dónde se va tu dinero",
            "Pagas cosas ‘normales’ que poco a poco te ahogan",
            "Quieres orden, no teorías",
            "Quieres un plan sin volverte experto"
          ].map((item, i) => (
            <motion.li 
              key={i} 
              variants={itemVariants}
              className="flex items-start gap-4 p-4 bg-white rounded-xl shadow-sm border border-slate-100"
            >
              <motion.div variants={checkVariants} className="shrink-0 mt-0.5">
                <CheckCircle2 size={24} className="text-accent" />
              </motion.div>
              <span className="text-slate-700">{item}</span>
            </motion.li>
          ))}
        </motion.ul>
        <p className="text-center text-xl font-semibold text-primary italic">
          “No necesitas ganar más. Necesitas ver claro.”
        </p>
      </div>
    </section>
  );
};

// --- Section 3: What is it? ---
const DescriptionSection = () => (
  <section className="py-20 px-6 max-w-4xl mx-auto">
    <SectionTitle>¿Qué es el Diagnóstico FIRE PASS?</SectionTitle>
    <div className="grid md:grid-cols-2 gap-12 items-center">
      <div className="space-y-6">
        <p className="text-slate-600 leading-relaxed">
          El Diagnóstico FIRE PASS es una evaluación personalizada que analiza tus gastos, pagos y hábitos financieros para mostrarte:
        </p>
        <ul className="space-y-4">
          <li className="flex gap-3">
            <div className="bg-accent/10 p-2 rounded-lg text-accent shrink-0"><AlertCircle size={20} /></div>
            <span className="text-slate-700">Dónde estás perdiendo dinero sin notarlo</span>
          </li>
          <li className="flex gap-3">
            <div className="bg-accent/10 p-2 rounded-lg text-accent shrink-0"><TrendingUp size={20} /></div>
            <span className="text-slate-700">Cuánto podrías recuperar solo organizándote</span>
          </li>
          <li className="flex gap-3">
            <div className="bg-accent/10 p-2 rounded-lg text-accent shrink-0"><Target size={20} /></div>
            <span className="text-slate-700">Qué pasos concretos dar esta semana y este mes</span>
          </li>
        </ul>
      </div>
      <div className="bg-primary text-white p-8 rounded-3xl shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full -mr-16 -mt-16 blur-3xl"></div>
        <p className="text-xl md:text-2xl font-semibold mb-4">No es un curso.</p>
        <p className="text-xl md:text-2xl font-semibold mb-4">No es teoría.</p>
        <p className="text-accent text-2xl md:text-3xl font-semibold">Es claridad aplicada a tu realidad.</p>
      </div>
    </div>
  </section>
);

// --- Section 4: What you receive ---
const DeliverablesSection = () => (
  <section className="py-20 bg-primary text-white px-6">
    <div className="max-w-4xl mx-auto">
      <SectionTitle dark>¿Qué recibes exactamente?</SectionTitle>
      <div className="grid md:grid-cols-2 gap-8">
        {[
          "Diagnóstico personalizado con tus números",
          "Estimación realista de ahorro mensual ($100–$300 en muchos casos)",
          "Plan claro en 3 etapas: 7, 30 y 90 días",
          "Reglas simples para manejar gastos y pagos",
          "Sensación inmediata de orden y control"
        ].map((item, i) => (
          <div key={i} className="flex items-center gap-4 bg-white/5 border border-white/10 p-6 rounded-2xl hover:bg-white/10 transition-colors">
            <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center shrink-0">
              <ChevronRight size={20} className="text-primary" />
            </div>
            <span className="text-lg">{item}</span>
          </div>
        ))}
      </div>
      <p className="mt-16 text-center text-2xl font-semibold border-t border-white/10 pt-8 italic text-white/80">
        “No más improvisar.”
      </p>
    </div>
  </section>
);

// --- Section 5: Preview ---
const PreviewSection = () => (
  <section className="py-20 px-6 max-w-4xl mx-auto">
    <SectionTitle>Así se ve un resultado</SectionTitle>
    <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden max-w-2xl mx-auto">
      <div className="bg-slate-50 p-4 border-b border-slate-200 flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Ejemplo de Reporte</span>
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full bg-slate-200"></div>
          <div className="w-3 h-3 rounded-full bg-slate-200"></div>
          <div className="w-3 h-3 rounded-full bg-slate-200"></div>
        </div>
      </div>
      <div className="p-8 space-y-6">
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-orange-100 text-orange-600 shrink-0"><AlertCircle size={24} /></div>
          <div>
            <p className="font-semibold text-primary">Diagnóstico de Fugas</p>
            <p className="text-slate-600">Detectamos 4 fugas principales en tus gastos.</p>
          </div>
        </div>
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-green-100 text-green-600 shrink-0"><TrendingUp size={24} /></div>
          <div>
            <p className="font-semibold text-primary">Potencial de Recuperación</p>
            <p className="text-slate-600">Con solo reorganizar pagos, podrías liberar <span className="font-bold text-accent">$210</span> al mes.</p>
          </div>
        </div>
        <div className="flex items-start gap-4">
          <div className="p-3 rounded-xl bg-blue-100 text-blue-600 shrink-0"><Target size={24} /></div>
          <div>
            <p className="font-semibold text-primary">Próximo Paso</p>
            <p className="text-slate-600">Este es tu primer paso recomendado esta semana.</p>
          </div>
        </div>
      </div>
    </div>
    <p className="text-center mt-6 text-sm text-slate-400">Ejemplo ilustrativo. Tu resultado será personalizado.</p>
  </section>
);

// --- Section 6: FAQ ---
const FAQItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = React.useState(false);
  return (
    <div className="border-b border-slate-200">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-6 flex items-center justify-between text-left focus:outline-none"
      >
        <span className="text-lg font-semibold text-primary pr-8">{question}</span>
        {isOpen ? <Minus size={20} className="text-slate-400 shrink-0" /> : <Plus size={20} className="text-slate-400 shrink-0" />}
      </button>
      <div className={`overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-96 pb-6' : 'max-h-0'}`}>
        <p className="text-slate-600 leading-relaxed">{answer}</p>
      </div>
    </div>
  );
}

const FAQSection = () => (
  <section className="py-20 bg-secondary px-6">
    <div className="max-w-3xl mx-auto">
      <SectionTitle>Preguntas frecuentes</SectionTitle>
      <div className="bg-white p-8 rounded-3xl shadow-sm">
        <FAQItem 
          question="¿Esto es para mí si no sé nada de finanzas?" 
          answer="Absolutamente. El diagnóstico está diseñado para personas reales, no para expertos. Recibirás un plan en lenguaje sencillo y pasos que puedes aplicar de inmediato."
        />
        <FAQItem 
          question="¿Tengo que cambiar de trabajo o sacrificar mi vida?" 
          answer="No. El objetivo es optimizar lo que ya tienes. Se trata de ver dónde el dinero se está 'escapando' para que puedas disfrutarlo más o ahorrarlo para tu tranquilidad."
        />
        <FAQItem 
          question="¿Me van a vender algo después?" 
          answer="Este es un diagnóstico completo por sí solo. Nuestra meta es darte claridad inmediata. No hay presiones de ventas ni suscripciones ocultas."
        />
        <FAQItem 
          question="¿Por qué cuesta $4.99?" 
          answer="Queremos que la barrera de entrada sea mínima. El costo cubre la personalización de tu reporte y nos ayuda a mantener el servicio disponible para más familias."
        />
        <FAQItem 
          question="¿Mis datos están seguros?" 
          answer="Sí. Tu información es confidencial y solo se utiliza para generar tu diagnóstico personalizado. Valoramos tu privacidad por encima de todo."
        />
      </div>
    </div>
  </section>
);

// --- Section 7: Trust ---
const TrustSection = () => (
  <section className="py-16 px-6 text-center max-w-4xl mx-auto">
    <div className="flex flex-wrap justify-center gap-10 mb-12">
      <div className="flex flex-col items-center gap-2">
        <div className="w-14 h-14 bg-slate-50 rounded-full flex items-center justify-center border border-slate-100"><ShieldCheck size={28} className="text-primary/60" /></div>
        <span className="text-sm font-medium text-slate-500">Privado</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <div className="w-14 h-14 bg-slate-50 rounded-full flex items-center justify-center border border-slate-100"><UserCheck size={28} className="text-primary/60" /></div>
        <span className="text-sm font-medium text-slate-500">Personalizado</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <div className="w-14 h-14 bg-slate-50 rounded-full flex items-center justify-center border border-slate-100"><Lock size={28} className="text-primary/60" /></div>
        <span className="text-sm font-medium text-slate-500">Sin presión</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <div className="w-14 h-14 bg-slate-50 rounded-full flex items-center justify-center border border-slate-100"><Clock size={28} className="text-primary/60" /></div>
        <span className="text-sm font-medium text-slate-500">A tu ritmo</span>
      </div>
    </div>
    <div className="bg-slate-50 p-8 rounded-2xl border border-dashed border-slate-200">
      <p className="text-lg text-primary/80">
        Tu información es confidencial.<br />
        <span className="font-semibold text-primary">El objetivo es ayudarte a ver claro, no juzgarte.</span>
      </p>
    </div>
  </section>
);

// --- Section 8: Final CTA ---
const FinalCTASection = () => (
  <section className="py-24 px-6 text-center bg-gradient-soft border-t border-slate-100">
    <div className="max-w-2xl mx-auto">
      <h2 className="text-3xl md:text-4xl font-semibold text-primary mb-6">Da el primer paso hoy</h2>
      <p className="text-lg text-slate-600 mb-10 leading-relaxed">
        Puedes seguir como estás… o invertir <span className="font-semibold text-primary">$4.99</span> para ver con claridad lo que hoy no estás viendo.
      </p>
      <div className="max-w-md mx-auto">
        <PrimaryButton text="Acceder a mi diagnóstico FIRE PASS — $4.99" />
        <p className="mt-6 text-sm italic text-slate-500 font-medium">
          “Una sola decisión puede cambiar tu relación con el dinero.”
        </p>
      </div>
    </div>
  </section>
);

// --- Main App Component ---
const App: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Sticky Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
             <span className="text-white font-bold text-xs">FP</span>
          </div>
          <span className="font-semibold text-primary tracking-tight">FIRE PASS</span>
        </div>
        <button className="text-sm font-semibold text-primary border border-primary/20 px-4 py-2 rounded-lg hover:bg-primary/5 transition-colors">
          Ingresar
        </button>
      </header>

      <main>
        <HeroSection />
        <TargetsSection />
        <DescriptionSection />
        <DeliverablesSection />
        <PreviewSection />
        <FAQSection />
        <TrustSection />
        <FinalCTASection />
      </main>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-slate-100 text-center text-slate-400 text-sm">
        <div className="flex items-center justify-center gap-2 mb-4">
          <ShieldCheck size={16} />
          <span>Pagos Seguros & Encriptados</span>
        </div>
        <p>© {new Date().getFullYear()} FIRE PASS. Todos los derechos reservados.</p>
        <div className="mt-4 flex justify-center gap-6">
          <a href="#" className="hover:underline">Privacidad</a>
          <a href="#" className="hover:underline">Términos</a>
          <a href="#" className="hover:underline">Contacto</a>
        </div>
      </footer>
    </div>
  );
};

export default App;
